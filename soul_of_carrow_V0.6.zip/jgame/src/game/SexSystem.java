package game;

import game.data.NpcData;
import java.util.*;
import java.util.function.Supplier;

/**
 * SexSystem — dynamic sex scene prose builder.
 * Registers tokens into the shared Engine handler map.
 * Each token call advances SexState by one beat and returns flavour prose.
 *
 * Prose varies by: MC traits, NPC personality, breast/cock size,
 * SexState (arousal, position, closeness), drunk tier, hurt flags.
 *
 * Diminishing returns via SexState.activityMultiplier() — same action
 * repeated reduces stimulation. Switch activity to restore effectiveness.
 */
public class SexSystem {

    private final GameState state;
    private final NpcLoader npcs;

    public SexSystem(GameState state, NpcLoader npcs) {
        this.state = state;
        this.npcs  = npcs;
    }

    // ── Token registration ────────────────────────────────────────────────────

    public void registerTokens(Map<String, Supplier<String>> m) {
        // Status / state
        m.put("{sex_status_text}",            this::buildStatusText);
        m.put("{sex_body_text}",              this::buildBodyText);
        m.put("{sex_npc_close_warning}",      this::buildNpcCloseWarning);
        m.put("{sex_player_close_warning}",   this::buildPlayerCloseWarning);

        // Foreplay
        m.put("{sex_kiss_text}",              this::buildKissText);
        m.put("{sex_touch_text}",             this::buildTouchText);
        m.put("{sex_nothing_text}",           this::buildNothingText);
        m.put("{sex_handjob_text}",           this::buildHandjobText);
        m.put("{sex_handjob_faster_text}",    this::buildHandjobFasterText);
        m.put("{sex_handjob_slower_text}",    this::buildHandjobSlowerText);
        m.put("{sex_handjob_stop_text}",      this::buildHandjobStopText);

        // Oral
        m.put("{sex_oral_giving_text}",       this::buildOralGivingText);
        m.put("{sex_oral_giving_more_text}",  this::buildOralGivingMoreText);
        m.put("{sex_oral_stop_text}",         this::buildOralGivingStopText);
        m.put("{sex_oral_receiving_text}",    this::buildOralReceivingText);
        m.put("{sex_oral_receive_stop_text}", this::buildOralReceivingStopText);

        // Undressing — legacy bulk
        m.put("{sex_undress_mc_text}",        this::buildUndressMcText);
        m.put("{sex_undress_npc_text}",       this::buildUndressNpcText);

        // Undressing — granular
        m.put("{sex_remove_shirt_text}",      this::buildRemoveShirtText);
        m.put("{sex_remove_bra_text}",        this::buildRemoveBraText);
        m.put("{sex_remove_bottom_text}",     this::buildRemoveBottomText);
        m.put("{sex_hike_skirt_text}",        this::buildHikeSkirtText);
        m.put("{sex_remove_npc_top_text}",    this::buildRemoveNpcTopText);
        m.put("{sex_remove_npc_bottom_text}", this::buildRemoveNpcBottomText);

        // Condom
        m.put("{sex_put_condom_text}",        this::buildPutCondomText);
        m.put("{sex_remove_condom_text}",     this::buildRemoveCondomText);

        // Special interactions
        m.put("{sex_dirty_talk_text}",        this::buildDirtyTalkText);
        m.put("{sex_tease_text}",             this::buildTeaseText);
        m.put("{sex_ask_rough_text}",         this::buildAskRoughText);
        m.put("{sex_ask_top_text}",           this::buildAskTopText);

        // Riding (MC on top)
        m.put("{sex_riding_text}",            this::buildRidingStartText);
        m.put("{sex_riding_faster_text}",     this::buildRidingFasterText);
        m.put("{sex_riding_slower_text}",     this::buildRidingSlowerText);
        m.put("{sex_riding_kiss_text}",       this::buildRidingKissText);
        m.put("{sex_riding_grind_text}",      this::buildRidingGrindText);
        m.put("{sex_riding_dismount_text}",   this::buildRidingDismountText);

        // Missionary (NPC on top)
        m.put("{sex_missionary_text}",        this::buildMissionaryStartText);
        m.put("{sex_missionary_faster_text}", this::buildMissionaryFasterText);
        m.put("{sex_missionary_slower_text}", this::buildMissionarySlowerText);
        m.put("{sex_missionary_legs_text}",   this::buildMissionaryLegsText);
        m.put("{sex_missionary_push_text}",   this::buildMissionaryPushText);
        m.put("{sex_missionary_stop_text}",   this::buildMissionaryStopText);

        // Doggy
        m.put("{sex_doggy_text}",             this::buildDoggyStartText);
        m.put("{sex_doggy_faster_text}",      this::buildDoggyFasterText);
        m.put("{sex_doggy_slower_text}",      this::buildDoggySlowerText);
        m.put("{sex_doggy_hair_text}",        this::buildDoggyHairText);
        m.put("{sex_doggy_stop_text}",        this::buildDoggyStopText);

        // 69
        m.put("{sex_69_text}",                this::build69Text);
        m.put("{sex_69_stop_text}",           this::build69StopText);

        // Size/pain awareness
        m.put("{sex_adaptation_status}",      this::buildAdaptationStatusText);
        // Anal
        m.put("{sex_anal_ask_text}",          this::buildAnalAskText);
        // Roughness
        m.put("{sex_ass_slap_text}",          this::buildAssSlapText);
        m.put("{sex_npc_goes_rough}",         this::buildNpcGoesRoughText);
        // Hickey concealment during sex
        m.put("{sex_shirt_lift_hiding_text}", this::buildShirtLiftHidingText);
        m.put("{sex_shirt_reveal_text}",      this::buildShirtRevealText);

        // NPC oral
        m.put("{sex_npc_oral_text}",          this::buildNpcOralText);
        m.put("{sex_npc_oral_more_text}",     this::buildNpcOralMoreText);

        // Climax / safety
        m.put("{sex_climax_mc_text}",         this::buildClimaxMcText);
        m.put("{sex_climax_npc_text}",        this::buildClimaxNpcText);
        m.put("{sex_afterglow_text}",         this::buildAfterglowText);
        m.put("{sex_pull_out_ask_text}",      this::buildPullOutAskText);
        m.put("{sex_pull_out_npc_ignores}",   this::buildPullOutIgnoresText);
        m.put("{sex_violation_give_in}",      this::buildViolationGiveInText);
        m.put("{sex_violation_upset}",        this::buildViolationUpsetText);
        m.put("{sex_violation_npc_response}",  this::buildViolationNpcResponseText);
        m.put("{sex_upset_flavor}",            this::buildUpsetFlavorText);
        m.put("{sex_violation_stop}",         this::buildViolationStopText);
    }

    // ── Status / state ────────────────────────────────────────────────────────

    private String buildStatusText() {
        SexState sx = state.sexState;
        NpcData  n  = currentNpc();
        if (!sx.active || n == null) return "";
        int pa = sx.playerArousal, na = sx.npcArousal;
        String pl = pa >= 80 ? "intense" : pa >= 55 ? "high" : pa >= 30 ? "building" : "low";
        String nl = na >= 80 ? "intense" : na >= 55 ? "high" : na >= 30 ? "building" : "low";
        StringBuilder sb = new StringBuilder();
        sb.append("*Your arousal: ").append(pl).append(" — {npc_name}: ").append(nl).append(".*");
        if (sx.playerIsClose())   sb.append("\n\n*You're close.*");
        if (sx.npcIsVeryClose())  sb.append("\n\n*{npc_name} is right on the edge.*");
        else if (sx.npcIsClose()) sb.append("\n\n*{npc_name} is getting close.*");
        if (!sx.position.isEmpty()) {
            String pos = sx.position.equals("riding") ? "You're on top."
                       : sx.position.equals("missionary") ? "{npc_name} is on top."
                       : sx.position.equals("doggy") ? "{npc_name} is behind you."
                       : sx.position.equals("69") ? "Both of you." : "";
            if (!pos.isEmpty()) sb.append("\n").append(pos);
        }
        return sb.toString();
    }

    private String buildBodyText() {
        NpcData n = currentNpc();
        if (n == null) return "";
        String cup = state.breastDescriptor();
        if (hasTrait(n, "Huge_Cock") || hasTrait(n, "Massive_Cock") || hasTrait(n, "Painfully_Massive_Cock"))
            return "{npc_name}'s size registers immediately — larger than expected. Your " + cup + " press against {npc_his} chest.";
        if (hasTrait(n, "Small_Cock"))
            return "You adjust to {npc_name} — a comfortable fit, unhurried.";
        return "Your " + cup + " against {npc_his} chest. The warmth of {npc_him}.";
    }

    private String buildNpcCloseWarning() {
        SexState sx = state.sexState;
        if (sx.npcIsVeryClose()) return "{npc_name} is right at the edge — {npc_his} breathing has gone ragged.";
        if (sx.npcIsClose())     return "{npc_name} is getting close. You can feel it.";
        return "";
    }

    private String buildPlayerCloseWarning() {
        SexState sx = state.sexState;
        if (sx.playerIsClose())           return "*You're close. The pressure has been building.*";
        if (sx.playerIsBuildingToClimx()) return "*Something is building. Not there yet.*";
        return "";
    }

    // ── Foreplay ──────────────────────────────────────────────────────────────

    private String buildKissText() {
        NpcData n = currentNpc(); if (n == null) return "You kiss.";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("kiss");
        sx.currentActivity = "kiss";
        sx.tick(Math.round(30 * mult), Math.round(30 * mult));

        String npcKiss;
        if      (hasTrait(n, "Magnetic"))     npcKiss = "{npc_He} kisses you like {npc_he} was waiting for this.";
        else if (hasTrait(n, "Engaging"))     npcKiss = "{npc_He} checks in with the kiss — slow, attentive.";
        else if (hasTrait(n, "Shy"))          npcKiss = "{npc_He} kisses you carefully. Both hands cup your face.";
        else if (hasTrait(n, "Self_Assured")) npcKiss = "{npc_He} takes the kiss without hesitation.";
        else if (hasTrait(n, "Outgoing"))     npcKiss = "{npc_He} kisses you with the same energy {npc_he} does everything.";
        else if (hasTrait(n, "Jerk"))         npcKiss = "{npc_He} bites your lip. Deliberate.";
        else if (hasTrait(n, "Sleazy"))       npcKiss = "{npc_He} deepens it faster than you expected.";
        else                                   npcKiss = "{npc_He} kisses you back.";

        String mc;
        if (drunkTier().equals("blackout"))
            mc = "*Warm. {npc_name}. Yes.*";
        else if (sx.playerIsClose())
            mc = mcReact("*Already close — and this is making it harder to think.*",
                         "*Every part of me at high alert.*",
                         "*The kissing makes the edge more urgent.*");
        else if (mult < 0.5f)
            mc = mcReact("*We've kissed a lot tonight. Still good.*",
                         "*The kissing has become fluent.*",
                         "*Still right. Less edge to it now.*");
        else
            mc = mcReact("*My mouth on his. My hands uncertain.*",
                         "*Good. Clear.*",
                         "*Exactly right. This.*");
        return npcKiss + "\n\n" + mc;
    }

    private String buildTouchText() {
        NpcData n = currentNpc(); if (n == null) return "{npc_He} touches you.";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("touch");
        sx.currentActivity = "touch";
        sx.tick(Math.round(35 * mult), Math.round(20 * mult));

        boolean braless = state.isBraless() || sx.mcBraOff;
        String cup = state.breastDescriptor();
        String base;
        if      (hasTrait(n, "Magnetic"))     base = "{npc_name}'s hands move over you slowly. Not rushing. Learning.";
        else if (hasTrait(n, "Engaging"))     base = "{npc_name} adjusts where {npc_he} touches based on what you do.";
        else if (hasTrait(n, "Shy"))          base = "{npc_name}'s hands are gentle. Every movement has permission in it.";
        else if (hasTrait(n, "Self_Assured")) base = "{npc_name} touches you like {npc_he} knows what {npc_he}'s doing.";
        else if (hasTrait(n, "Jerk"))         base = "{npc_name} grabs more than touches. Purposeful. For {npc_him}.";
        else                                   base = "{npc_name}'s hands on you. Warm and deliberate.";

        String mc = braless
            ? "*Bare skin under {npc_his} hands — nothing between. Very aware of my " + cup + ".*"
            : mcReact("*The touch through fabric. Trying to stay present.*",
                      "*Good. Registering each place.*",
                      "*Yes. More of this.*");
        return base + "\n\n" + mc;
    }

    private String buildNothingText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.currentActivity = "nothing";
        sx.tick(15, 30);
        if (hasTrait(n, "Magnetic"))     return "{npc_name} fills the pause — hand at your jaw. Not rushing.";
        if (hasTrait(n, "Outgoing"))     return "{npc_name} says something warm and slightly absurd. You laugh. It's better.";
        if (hasTrait(n, "Shy"))          return "{npc_name} holds still with you. Not anxious. Just present.";
        if (hasTrait(n, "Self_Assured")) return "{npc_name} pulls you close and holds you there. Patient.";
        if (hasTrait(n, "Jerk"))         return "{npc_name} uses the pause to move things where {npc_he} wants them.";
        return "{npc_name} stays close. The moment breathes.";
    }

    // ── Handjob ───────────────────────────────────────────────────────────────

    private String buildHandjobText() {
        NpcData n = currentNpc(); if (n == null) return "You take {npc_him} in your hand.";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("handjob");
        sx.currentActivity = "handjob";
        awardSexRep("sex_handjob");
        sx.tick(10, Math.round(55 * mult));
        String sizeNote = npcSizeNote(n);

        String npcReact;
        if      (hasTrait(n, "Magnetic"))     npcReact = "{npc_name} makes a low sound. Eyes on yours.";
        else if (hasTrait(n, "Engaging"))     npcReact = "\"That's — yes.\" {npc_He} shifts. Lets you set the pace.";
        else if (hasTrait(n, "Shy"))          npcReact = "{npc_name} goes quiet. Breathing changes.";
        else if (hasTrait(n, "Self_Assured")) npcReact = "{npc_He} responds, controlled. Doesn't perform surprise.";
        else if (hasTrait(n, "Outgoing"))     npcReact = "\"Oh — hell yes.\" Enthusiastic and not shy about it.";
        else if (hasTrait(n, "Jerk"))         npcReact = "{npc_He} watches you with a look that says {npc_he} expected this.";
        else                                   npcReact = "{npc_name} exhales.";

        String mc = mcReact(
            "*Hand around {npc_him}. Enough to know the motion, new enough to be nerve-aware.*",
            "*The weight of {npc_him} in my hand. Reading the responses.*",
            "*I know what I'm doing here. The evidence agrees.*");
        return "You reach for {npc_him}." + (sizeNote.isEmpty() ? "" : "\n\n" + sizeNote)
             + "\n\n" + npcReact + "\n\n" + mc;
    }

    private String buildHandjobFasterText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("handjob_fast");
        sx.tick(5, Math.round(70 * mult));
        if (hasTrait(n, "Shy"))           return "{npc_name} grips the sheet. Small sounds now.";
        if (hasTrait(n, "Self_Assured"))  return "{npc_name} lets go of the composure. Just barely.";
        if (hasTrait(n, "Outgoing"))      return "\"— don't stop. Don't stop.\"";
        if (hasTrait(n, "Jerk"))          return "{npc_name} grabs your wrist. Not to stop you — steadying.";
        if (sx.npcIsClose()) return "{npc_name}'s hips lift. {npc_He}'s close. You can tell.";
        return "{npc_name}'s breathing gets louder. The pace working.";
    }

    private String buildHandjobSlowerText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.tick(5, 40);
        if (hasTrait(n, "Self_Assured"))
            return "{npc_name} seems to understand what you're doing. Rolls his head back. Waits.";
        if (hasTrait(n, "Outgoing"))
            return "\"You're torturing me.\" He doesn't actually want you to stop.";
        return "Slower. {npc_name} adjusts. More deliberate now.";
    }

    private String buildHandjobStopText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.currentActivity = "";
        if (hasTrait(n, "Jerk"))     return "{npc_name} gives you a look. Not annoyed — just checking.";
        if (hasTrait(n, "Outgoing")) return "\"Oh — coming back to that?\"";
        return "{npc_name} waits. The pause recalibrates things.";
    }

    // ── Oral (giving) ─────────────────────────────────────────────────────────

    private String buildOralGivingText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("oral_giving");
        sx.currentActivity = "oral_giving";
        awardSexRep("sex_oral_give");
        sx.tick(5, Math.round(75 * mult));
        String sizeNote = npcSizeFirstTime(n);

        String npcReact;
        if      (hasTrait(n, "Magnetic"))     npcReact = "{npc_name}'s hand goes to your hair. Not pushing. Just resting.";
        else if (hasTrait(n, "Engaging"))     npcReact = "\"You don't have to—\" He stops. \"Thank you.\"";
        else if (hasTrait(n, "Shy"))          npcReact = "{npc_name} makes a small sound and goes completely still.";
        else if (hasTrait(n, "Self_Assured")) npcReact = "{npc_name} exhales slowly. Fully present. Watching.";
        else if (hasTrait(n, "Outgoing"))     npcReact = "\"Oh my god.\" Fully out loud. Not embarrassed.";
        else if (hasTrait(n, "Jerk"))         npcReact = "His hand tightens in your hair. Not pulling. Gripping.";
        else                                   npcReact = "{npc_name} goes quiet.";

        String mc = mcReact(
            "*Down here. Doing this. A lot of nerve-awareness.*",
            "*Focused. Reading {npc_him}. Working out what works.*",
            "*I like doing this. The specific power of it.*");
        return "You move down." + (sizeNote.isEmpty() ? "" : "\n\n" + sizeNote)
             + "\n\n" + npcReact + "\n\n" + mc;
    }

    private String buildOralGivingMoreText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("oral_giving");
        sx.tick(5, Math.round(80 * mult));
        if (sx.npcIsVeryClose())
            return "{npc_name}'s hips have started moving. Trying not to. {npc_He}'s right at the edge.";
        if (sx.npcIsClose()) {
            if (hasTrait(n, "Self_Assured"))
                return "{npc_name} loses the composure — just for a second. \"I'm—\" Stops.";
            if (hasTrait(n, "Shy"))
                return "{npc_name} makes a sound {npc_he} immediately muffles. Too late.";
            return "{npc_name} is getting close. The breathing has gone ragged.";
        }
        if (mult < 0.5f) return "The pace is settled. {npc_name} has stopped trying to be quiet.";
        return "{npc_name}'s hand is still in your hair. {npc_He} makes a low sound.";
    }

    private String buildOralGivingStopText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.currentActivity = "";
        if (hasTrait(n, "Outgoing"))
            return "\"— oh. Okay. Coming back to that?\" Genuinely bereft.";
        if (hasTrait(n, "Jerk"))
            return "{npc_name} lets go of your hair. Watching you come back up.";
        if (hasTrait(n, "Shy"))
            return "{npc_name} exhales slowly. Still processing. Quiet.";
        return "You sit back. {npc_name} breathes. The pause has its own quality.";
    }

    // ── Oral (receiving) ──────────────────────────────────────────────────────

    private String buildOralReceivingText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("oral_receiving");
        sx.currentActivity = "oral_receiving";
        awardSexRep("sex_oral_receive");
        sx.tick(Math.round(80 * mult), 5);
        String cup = state.breastDescriptor();

        String base;
        if      (hasTrait(n, "Engaging"))     base = "{npc_name} takes {npc_his} time. Checking your responses.";
        else if (hasTrait(n, "Magnetic"))     base = "{npc_name}'s focus is absolute. Like {npc_he}'s entirely in this.";
        else if (hasTrait(n, "Shy"))          base = "{npc_name} is careful. Learning what works. Genuinely trying.";
        else if (hasTrait(n, "Self_Assured")) base = "{npc_name} knows what {npc_he}'s doing. You can tell immediately.";
        else if (hasTrait(n, "Outgoing"))     base = "{npc_name} is enthusiastic about this. It shows. Pleasantly.";
        else                                   base = "{npc_name} moves down. Warm and deliberate.";

        String mc = mcReact(
            "*My " + cup + " rising and falling fast. Trying not to make too much noise.*",
            "*Focused entirely on this. Everything else gone.*",
            "*Yes. Exactly this. Don't stop.*");
        return base + "\n\n" + mc;
    }

    private String buildOralReceivingStopText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.currentActivity = "";
        if (state.sexState.playerIsClose())
            return "You pull {npc_him} back up. *Too close — not yet.* {npc_He} reads it right.";
        if (hasTrait(n, "Engaging"))
            return "\"Good?\" {npc_name} asks, coming back up. You nod. Very.";
        return "{npc_name} comes back up. You both breathe.";
    }

    // ── Undressing — legacy bulk ──────────────────────────────────────────────

    private String buildUndressMcText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.mcNaked = true;
        state.sexState.mcShirtOff = true;
        state.sexState.mcBraOff = true;
        state.sexState.mcBottomOff = true;
        String cup = state.breastDescriptor();
        String npcReact;
        if      (hasTrait(n, "Magnetic"))     npcReact = "{npc_name} looks at you like you've confirmed what {npc_he} suspected.";
        else if (hasTrait(n, "Engaging"))     npcReact = "\"You're—\" {npc_He} stops. Starts over. \"Hi.\"";
        else if (hasTrait(n, "Shy"))          npcReact = "{npc_name} looks and then makes a point of meeting your eyes. Flushed.";
        else if (hasTrait(n, "Self_Assured")) npcReact = "{npc_name}'s gaze moves over you. Unhurried.";
        else if (hasTrait(n, "Outgoing"))     npcReact = "\"Okay wow.\" Absolutely not embarrassed about saying that.";
        else if (hasTrait(n, "Jerk"))         npcReact = "{npc_name} looks. Doesn't say anything. Doesn't look away.";
        else                                   npcReact = "{npc_name} looks at you.";
        String mc = mcReact("*All of it visible now. My " + cup + ". Very naked.*",
                            "*Bare in front of {npc_name}.*",
                            "*Good. Now we're somewhere.*");
        return "Your clothes are gone.\n\n" + npcReact + "\n\n" + mc;
    }

    private String buildUndressNpcText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.npcNaked = true;
        state.sexState.npcTopOff = true;
        state.sexState.npcBottomOff = true;
        String sizeNote = npcSizeNote(n);
        String mc = mcReact("*{npc_name} in front of me like this.*", "*There it is.*", "*Good. Now we can start.*");
        return "{npc_name}'s clothes join yours." + (sizeNote.isEmpty() ? "" : "\n\n" + sizeNote) + "\n\n" + mc;
    }

    // ── Undressing — granular ─────────────────────────────────────────────────

    private String buildRemoveShirtText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.mcShirtOff = true;
        boolean bra = !state.isBraless() && !state.sexState.mcBraOff;
        String cup = state.breastDescriptor();
        String npcReact;
        if      (hasTrait(n, "Magnetic"))     npcReact = "{npc_name}'s gaze drops immediately. Back to yours. The honesty of it.";
        else if (hasTrait(n, "Engaging"))     npcReact = "\"Oh.\" Appreciative.";
        else if (hasTrait(n, "Shy"))          npcReact = "{npc_name} looks and then very deliberately meets your eyes. Still flushed.";
        else if (hasTrait(n, "Self_Assured")) npcReact = "{npc_name} takes in the view. Unhurried.";
        else if (hasTrait(n, "Outgoing"))     npcReact = "\"Okay — you are really something.\"";
        else if (hasTrait(n, "Jerk"))         npcReact = "{npc_name} reaches for you immediately.";
        else                                   npcReact = "{npc_name} looks.";
        String mc = bra
            ? mcReact("*Shirt off. Still the bra. Still something between us.*",
                      "*Top layer down.*",
                      "*His turn to look.*")
            : "*My " + cup + " bare now. The air and {npc_name}'s eyes both on them.*";
        return "You pull your shirt off.\n\n" + npcReact + "\n\n" + mc;
    }

    private String buildRemoveBraText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        if (state.isBraless()) { sx.mcBraOff = true; return ""; }
        sx.mcBraOff = true;
        String cup = state.breastDescriptor();
        String npcReact;
        if      (hasTrait(n, "Magnetic"))     npcReact = "{npc_name} reaches out and cups one. Gentle. Present.";
        else if (hasTrait(n, "Engaging"))     npcReact = "\"These are—\" {npc_name} stops. \"Really.\"";
        else if (hasTrait(n, "Outgoing"))     npcReact = "\"God.\" Wholehearted. You believe him.";
        else if (hasTrait(n, "Jerk"))         npcReact = "{npc_name}'s hands are on your " + cup + " before the bra hits the floor.";
        else if (hasTrait(n, "Shy"))          npcReact = "{npc_name} breathes in. Slow. Composing himself.";
        else                                   npcReact = "{npc_name} looks at your bare chest. Stays looking.";
        String mc = mcReact("*Bare now. My " + cup + " loose and visible. Aware of them.*",
                            "*The bra gone. {npc_name}'s eyes.*",
                            "*Good. Now he can really see.*");
        return "The bra comes off.\n\n" + npcReact + "\n\n" + mc;
    }

    private String buildRemoveBottomText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.mcBottomOff = true;
        sx.mcNaked = sx.mcShirtOff || state.isTopless();
        boolean commando = state.outfitUnderwear == null;
        String npcReact;
        if      (hasTrait(n, "Magnetic"))     npcReact = "{npc_name}'s hands find your hips before you've finished stepping out.";
        else if (hasTrait(n, "Self_Assured")) npcReact = "{npc_name} looks you over completely. Deliberate.";
        else if (hasTrait(n, "Outgoing"))     npcReact = "\"Okay, yes. Absolutely yes.\"";
        else if (hasTrait(n, "Shy"))          npcReact = "{npc_name} goes quiet. The full sight of you landing.";
        else if (hasTrait(n, "Jerk"))         npcReact = "{npc_name} grabs your waist and pulls you in immediately.";
        else                                   npcReact = "{npc_name} takes in all of you.";
        String mc = commando
            ? "*Nothing between my legs and the air. And him.*"
            : mcReact("*Exposed. All of it now.*", "*Everything visible to {npc_name}.*", "*There it is.*");
        return "Your bottom half is off.\n\n" + npcReact + "\n\n" + mc;
    }

    private String buildHikeSkirtText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.mcSkirtHiked = true;
        boolean commando = state.outfitUnderwear == null;
        String mc = commando
            ? "*Skirt up. Nothing underneath. He can see exactly what that means.*"
            : mcReact("*Skirt hiked. The exposure of this.*",
                      "*Skirt up. Close enough now.*",
                      "*Efficient. I like that this works without taking it off.*");
        String npcReact = commando
            ? "{npc_name} looks down. Inhales. \"Oh.\""
            : "{npc_name}'s hand slides to your thigh immediately.";
        return "You hike your skirt up.\n\n" + npcReact + "\n\n" + mc;
    }

    private String buildRemoveNpcTopText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.npcTopOff = true;
        String fig = n.figure != null ? n.figure.toLowerCase() : "";
        String note = "muscular".equals(fig) ? "The muscle of {npc_him} — more than expected under the shirt."
                    : "lean".equals(fig)     ? "The lean of {npc_him}. Efficient."
                    : "heavyset".equals(fig) ? "Solid. Warm. {npc_name} underneath." : "";
        return "You get {npc_name}'s shirt off.\n\n"
             + (note.isEmpty() ? "{npc_name}'s chest against your hands." : note)
             + "\n\n" + mcReact("*Skin now. Real.*", "*There he is.*", "*Better. Much better.*");
    }

    private String buildRemoveNpcBottomText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.npcBottomOff = true;
        state.sexState.npcNaked = true;
        String sizeNote = npcSizeNote(n);
        return "{npc_name}'s clothes join yours."
             + (sizeNote.isEmpty() ? "" : "\n\n" + sizeNote)
             + "\n\n" + mcReact("*There it is. All of {npc_him}.*", "*He's fully here now.*", "*Good. Now we can actually start.*");
    }

    // ── Condom ────────────────────────────────────────────────────────────────

    private String buildPutCondomText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.playerRequestedCondom = true;

        // Refuses_Condoms: NPC won't comply — track the refusal, don't put it on
        if (hasTrait(n, "Refuses_Condoms")) {
            state.sexState.npcRefusedCondom = true;
            String refusal = hasTrait(n, "Jerk") || hasTrait(n, "Dom")
                ? "{npc_name} removes your hand. "No." Final."
                : "{npc_name} pulls back slightly. "I'd rather not. If that's a dealbreaker —""
                + "\n\n{npc_He} leaves it there.";
            return "You reach for a condom.\n\n" + refusal
                 + "\n\n*He's not going to. You need to decide what that means.*";
        }

        state.sexState.condomOn = true;
        state.sexState.condomUsed = true;
        String npcReact;
        if      (hasTrait(n, "Prefers_Condoms"))  npcReact = "{npc_name} hands you one before you've asked.";
        else if (hasTrait(n, "Dislikes_Condoms")) npcReact = "{npc_name} doesn't protest. Slightly less enthusiastic about the pause.";
        else if (hasTrait(n, "Jerk"))             npcReact = "{npc_name} makes a noise but doesn't stop you.";
        else                                       npcReact = "{npc_name} waits. Patient.";
        return "You get a condom.\n\n" + npcReact + "\n\n*Practical. The right call.*";
    }

    private String buildRemoveCondomText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.condomOn = false;
        String npcReact = hasTrait(n, "Prefers_Condoms")
            ? "{npc_name} raises an eyebrow. Doesn't argue."
            : "{npc_name}'s response is immediately warmer.";
        return "The condom comes off.\n\n" + npcReact
             + "\n\n*The difference is immediate. You knew it would be.*"
             + "\n\n*You know what this means. You're choosing it.*";
    }

    // ── Special interactions ──────────────────────────────────────────────────

    private String buildDirtyTalkText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.dirtyTalkActive = !sx.dirtyTalkActive;
        if (sx.dirtyTalkActive) awardSexRep("sex_dirty_talk");
        float mult = sx.activityMultiplier("dirty_talk");
        sx.tick(Math.round(20 * mult), Math.round(25 * mult));
        if (!sx.dirtyTalkActive)
            return "You let the dirty talk taper off.\n\n{npc_name} adjusts to the quieter register.";
        String npcReact;
        if      (hasTrait(n, "Outgoing"))     npcReact = "{npc_name} gives it back immediately. Better than yours.";
        else if (hasTrait(n, "Magnetic"))     npcReact = "{npc_name} says something low and deliberate. Exact.";
        else if (hasTrait(n, "Self_Assured")) npcReact = "{npc_name}'s version is confident and specific. Accurate.";
        else if (hasTrait(n, "Shy"))          npcReact = "{npc_name} gets halfway there. Close enough.";
        else if (hasTrait(n, "Jerk"))         npcReact = "{npc_name} takes the invitation without any prompting.";
        else                                   npcReact = "{npc_name} responds in kind.";
        return "Words.\n\n" + npcReact + "\n\n"
             + mcReact("*Saying it out loud. More charged than expected.*",
                       "*The specific heat of words during this.*",
                       "*I'm good at this. He knows I'm good at this.*");
    }

    private String buildTeaseText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.tick(10, Math.round(50 * sx.activityMultiplier("tease")));
        sx.addFrustration(5);
        String cup = state.breastDescriptor();
        if (hasTrait(n, "Outgoing"))     return "You slow everything deliberately. {npc_name} protests verbally and at length. You don't accelerate.";
        if (hasTrait(n, "Self_Assured")) return "{npc_name} retaliates — does the same thing back. Now you're both doing this.";
        if (hasTrait(n, "Jerk"))         return "{npc_name} grabs you. Trying to end it by force of will. You move back out of reach.";
        if (hasTrait(n, "Shy"))          return "{npc_name} doesn't say anything. Makes a small desperate sound instead.";
        return "You pull back just when it's getting somewhere.\n\n"
             + "*My " + cup + " and his eyes and the gap between us.*\n\n"
             + "{npc_name}'s breathing gets louder.";
    }

    private String buildAskRoughText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.askedForRough = true;
        float mult = sx.activityMultiplier("rough");
        sx.tick(Math.round(40 * mult), Math.round(30 * mult));
        String npcResponse;
        if (hasTrait(n, "Sadist") || hasTrait(n, "Dom")) {
            npcResponse = "{npc_name} stops. Looks at you. Something changes in {npc_his} expression — less performed.\n\n"
                        + "\"Yeah?\"\n\n\"Yeah,\" you say.\n\n"
                        + "What follows is different. More specific. More of what you asked for.";
        } else if (hasTrait(n, "Magnetic")) {
            npcResponse = "{npc_name} pauses. \"Are you sure?\"\n\nYou are. He gives you what you asked for.";
        } else if (hasTrait(n, "Shy")) {
            npcResponse = "{npc_name} tries. Carefully. More carefully than you asked for.\n\nClose enough.";
        } else if (hasTrait(n, "Jerk")) {
            npcResponse = "{npc_name} doesn't ask twice. What follows is delivered efficiently.";
        } else {
            npcResponse = "{npc_name} takes it in. Adjusts. Gives you what you said you wanted.";
        }
        return "You say it.\n\n"
             + mcReact("*Said it. He's going to do it.*",
                       "*My request. Now we see.*",
                       "*Good. I wanted to say that.*")
             + "\n\n" + npcResponse;
    }

    private String buildAskTopText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        if (hasTrait(n, "Dom")) {
            if (sx.askedForRough) {
                sx.npcDomLocked = false;
                sx.position = "riding";
                sx.currentActivity = "riding";
                sx.setPenetration(true, state);
                sx.tick(55, 65);
                return "You ask.\n\n{npc_name} considers. Looks at you.\n\n\"Go ahead.\" Permission, not deference.\n\nYou take the position.";
            }
            return "You ask.\n\n{npc_name} shakes {npc_his} head.\n\n\"Not yet.\"\n\n"
                 + mcReact("*Told no. He means it.*", "*He's not moving on this.*", "*Interesting.*");
        }
        return buildRidingStartText();
    }

    // ── Riding (MC on top) ────────────────────────────────────────────────────

    private String buildRidingStartText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.position = "riding";
        sx.currentActivity = "riding";
        sx.setPenetration(true, state);
        // Auto-set hiding flag: cheating sex + visible hickey from someone else
        if (state.isCheatingSexSession() && state.hasTrait("Neck_Hickey")
                && !state.hasTrait("Covered_Neck_Hickey")
                && !state.neckHickeyFromNpcId.isEmpty()
                && !state.neckHickeyFromNpcId.equals(state.currentApproachingNpc)) {
            sx.mcHidingHickey = true;
        }
        awardSexRep("sex_penetrate");
        if (!sx.condomOn) awardSexRep("sex_bareback");
        float mult = sx.activityMultiplier("riding");
        sx.tick(Math.round(65 * mult), Math.round(70 * mult));
        String painEntry = painEntryText();
        String sizeNote = ridesSizeNote(n);
        String cup = state.breastDescriptor();
        String npcStart;
        if      (hasTrait(n, "Magnetic"))     npcStart = "{npc_name}'s hands go to your hips. Holding, not controlling.";
        else if (hasTrait(n, "Engaging"))     npcStart = "\"Take your time,\" {npc_name} says. {npc_He} means it.";
        else if (hasTrait(n, "Shy"))          npcStart = "{npc_name} goes very still beneath you. Waiting for your lead.";
        else if (hasTrait(n, "Self_Assured")) npcStart = "{npc_name}'s hands guide your hips. Confident. Not rough.";
        else if (hasTrait(n, "Outgoing"))     npcStart = "\"Yes — god, yes.\" Hands at your waist.";
        else if (hasTrait(n, "Jerk"))         npcStart = "{npc_name} smirks up at you. Lets you work.";
        else                                   npcStart = "{npc_name} exhales. Hands find your thighs.";
        String mc = sx.virginityLostThisScene
            ? mcReact("*Oh. That's a real thing.*", "*Full. Warm. Moving now.*", "*There it is. Mine.*")
            : mcReact("*Setting the pace. Nerve-aware of everything.*",
                      "*Good angle. Finding the rhythm.*",
                      "*Mine to control. I like it up here.*");
        return "You move over {npc_name}. Settle.\n\n"
             + (sizeNote.isEmpty() ? "" : sizeNote + "\n\n")
             + painEntry
             + npcStart + "\n\n" + mc
             + "\n\n*My " + cup + " move with each shift. {npc_name}'s eyes don't miss it.*";
    }

    private String buildRidingFasterText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("riding_fast");
        sx.tick(Math.round(75 * mult), Math.round(80 * mult));
        String cup = state.breastDescriptor();
        String npcReact;
        if      (hasTrait(n, "Outgoing"))     npcReact = "\"— fuck, yeah—\" Hips starting to meet you.";
        else if (hasTrait(n, "Self_Assured")) npcReact = "{npc_name}'s grip tightens. {npc_He} starts moving with you.";
        else if (hasTrait(n, "Jerk"))         npcReact = "{npc_name} grabs your hips, pulls you down harder.";
        else if (hasTrait(n, "Shy"))          npcReact = "{npc_name}'s whole body is taut. Making sounds {npc_he} can't suppress.";
        else                                   npcReact = "{npc_name}'s hands tighten. Meeting the pace.";
        int painDelta = state.penetrationPainDelta();
        String mc;
        if (painDelta >= 2) {
            mc = "*Too fast. The pain spikes. You slow back down immediately.*";
            return "You try to speed up.\n\n"
                 + "*Too much too fast. The stretch becomes sharp.*\n\n"
                 + "You ease the pace back. {npc_name} adjusts without comment.";
        } else if (painDelta == 1) {
            mc = sx.playerIsClose()
                ? "*Close — and the edge of pain makes it more intense, not less.*"
                : "*The stretch is there in the faster pace. Workable. Walk the line.*";
        } else {
            mc = sx.playerIsClose()
                ? "*Getting close — the urgency is hard to manage.*"
                : "*Harder. My " + cup + " moving with each drop. The burn in my thighs is distant.*";
        }
        return "You speed up.\n\n" + npcReact + "\n\n" + mc;
    }

    private String buildRidingSlowerText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.tick(50, 55);
        if (hasTrait(n, "Jerk"))
            return "{npc_name} makes an impatient sound. Hands try to keep the pace. You slow anyway.";
        if (hasTrait(n, "Outgoing"))
            return "\"You are actually killing me.\" You keep your pace. {npc_He} groans.";
        return "Slower. {npc_name} exhales. The slow rhythm — longer, fuller, more deliberate.";
    }

    private String buildRidingKissText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.tick(Math.round(55 * sx.activityMultiplier("riding_kiss")),
                Math.round(60 * sx.activityMultiplier("riding_kiss")));
        String cup = state.breastDescriptor();
        return "You lean down. Find {npc_his} mouth.\n\n"
             + "Your " + cup + " press against {npc_his} chest. "
             + "{npc_name}'s arms come around your back.\n\n"
             + mcReact("*Kissing {npc_him} while he's inside me. A lot happening at once.*",
                       "*Close now. The kiss and the movement together.*",
                       "*Everything closer. Better like this.*");
    }

    private String buildRidingGrindText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("riding_grind");
        sx.tick(Math.round(70 * mult), Math.round(50 * mult));
        String cup = state.breastDescriptor();
        return "You shift from riding to grinding — forward and back instead of up and down.\n\n"
             + "*Different angle. My " + cup + " moving differently. Finding what I need.*\n\n"
             + "{npc_name} makes a low, approving sound.";
    }

    private String buildRidingDismountText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.position = "";
        sx.currentActivity = "";
        sx.setPenetration(false, state);
        return "You shift off {npc_name}. Both of you breathe.\n\n"
             + "{npc_name} lets you move. Hands loosening.\n\n"
             + mcReact("*Off. Ground under me. Okay.*", "*Good stop. Reorienting.*", "*Taking a beat.*");
    }

    // ── Missionary (NPC on top) ───────────────────────────────────────────────

    private String buildMissionaryStartText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.position = "missionary";
        sx.currentActivity = "missionary";
        sx.setPenetration(true, state);
        awardSexRep("sex_penetrate");
        if (!sx.condomOn) awardSexRep("sex_bareback");
        float mult = sx.activityMultiplier("missionary");
        sx.tick(Math.round(70 * mult), Math.round(65 * mult));
        String painEntry = painEntryText();
        String sizeNote = entersSizeNote(n);
        String npcStart;
        if      (hasTrait(n, "Magnetic"))     npcStart = "{npc_name} braces above you. Looks at you first.";
        else if (hasTrait(n, "Engaging"))     npcStart = "\"Tell me if—\" You pull {npc_him} down.";
        else if (hasTrait(n, "Shy"))          npcStart = "{npc_name} is careful. Every movement checked.";
        else if (hasTrait(n, "Self_Assured")) npcStart = "{npc_name} takes over. The transition is smooth.";
        else if (hasTrait(n, "Outgoing"))     npcStart = "{npc_name} moves over you with wholehearted commitment.";
        else if (hasTrait(n, "Jerk"))         npcStart = "{npc_name} takes {npc_his} position like {npc_he} owns the space.";
        else                                   npcStart = "{npc_name} moves over you.";
        String mc = mcReact("*{npc_name}'s weight. The specific press of {npc_him}. A lot to hold.*",
                            "*{npc_name} above me. Working out the angle.*",
                            "*Yes. There. Let {npc_him} work.*");
        return npcStart + "\n\n" + (sizeNote.isEmpty() ? "" : sizeNote + "\n\n") + painEntry + mc;
    }

    private String buildMissionaryFasterText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("missionary_fast");
        sx.tick(Math.round(80 * mult), Math.round(80 * mult));
        String cup = state.breastDescriptor();
        String npcFast;
        if      (hasTrait(n, "Jerk"))         npcFast = "{npc_name} doesn't hold back. The impact of {npc_him} loud and clear.";
        else if (hasTrait(n, "Self_Assured")) npcFast = "{npc_name} builds the pace with control. You feel every change.";
        else if (hasTrait(n, "Outgoing"))     npcFast = "Both of you are audible now. You've stopped trying not to be.";
        else if (hasTrait(n, "Shy"))          npcFast = "{npc_name} has forgotten to be quiet. Small sounds getting louder.";
        else                                   npcFast = "{npc_name} picks up the pace. {npc_He}'s breathing hard.";
        int painDelta = state.penetrationPainDelta();
        String mc;
        if (painDelta >= 2) {
            return "{npc_name} starts to pick up the pace.\n\n"
                 + "*No — too much. The speed makes the pain spike.*\n\n"
                 + "You put your hand on {npc_his} hip. "Slower."

"
                 + "{npc_name} reads it. Pulls back.";
        } else if (painDelta == 1) {
            mc = sx.playerIsClose()
                ? "*Close — and the intensity of it is almost too much.*"
                : "*The faster pace sharpens the stretch. Real but manageable.*";
        } else {
            mc = sx.playerIsClose()
                ? "*Close — the speed is pushing me right to the edge.*"
                : "*My " + cup + " moving with each thrust. {npc_name}'s weight and momentum. Loud now.*";
        }
        return npcFast + "\n\n" + mc;
    }

    private String buildMissionarySlowerText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.tick(55, 55);
        if (hasTrait(n, "Jerk"))
            return "You put your hands on {npc_his} hips. \"Slow down.\" {npc_He} does, with effort.";
        return "\"Slower,\" you say. {npc_name} drops the pace. Deep and slow. Each one deliberate.";
    }

    private String buildMissionaryLegsText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.tick(Math.round(75 * sx.activityMultiplier("missionary_legs")),
                Math.round(70 * sx.activityMultiplier("missionary_legs")));
        return "You wrap your legs around {npc_him}. Change the angle.\n\n"
             + "*Deeper. The position locks in something better.*\n\n"
             + "{npc_name} makes a sound that is not composure.";
    }

    private String buildMissionaryPushText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.tick(Math.round(70 * sx.activityMultiplier("missionary_push")),
                Math.round(65 * sx.activityMultiplier("missionary_push")));
        return "You push back into {npc_name}'s movement. Meeting each thrust.\n\n"
             + "{npc_name} registers it — the rhythm syncing.\n\n"
             + mcReact("*Active in this. Not just receiving.*",
                       "*The meeting of it. Two-directional now.*",
                       "*There. Working with {npc_him}.*");
    }

    private String buildMissionaryStopText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.position = "";
        sx.currentActivity = "";
        sx.setPenetration(false, state);
        if (hasTrait(n, "Engaging"))
            return "You push {npc_his} shoulder. {npc_He} rolls off immediately. \"You okay?\"\n\n\"Yeah. Just — yeah.\"";
        if (hasTrait(n, "Jerk"))
            return "You get a hand between you and push. {npc_name} moves, reluctant. \"Seriously?\"\n\n\"Seriously,\" you say.";
        return "You shift and {npc_name} rolls off. Both of you breathe.";
    }

    // ── Doggy style ───────────────────────────────────────────────────────────

    private String buildDoggyStartText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.position = "doggy";
        sx.currentActivity = "doggy";
        sx.setPenetration(true, state);
        awardSexRep("sex_penetrate");
        if (!sx.condomOn) awardSexRep("sex_bareback");
        float mult = sx.activityMultiplier("doggy");
        sx.tick(Math.round(70 * mult), Math.round(75 * mult));
        String painEntry = painEntryText();
        String sizeNote = entersSizeNote(n);
        String cup = state.breastDescriptor();
        String npcStart;
        if      (hasTrait(n, "Jerk"))         npcStart = "{npc_name} takes the position like he designed it. Grips your hips without ceremony.";
        else if (hasTrait(n, "Self_Assured")) npcStart = "{npc_name} moves you where he wants you. Deliberate. You let him.";
        else if (hasTrait(n, "Magnetic"))     npcStart = "{npc_name} runs a hand down your spine first. Then finds position.";
        else if (hasTrait(n, "Outgoing"))     npcStart = "\"Oh this—\" {npc_name} says approvingly. \"Yes. This.\"";
        else if (hasTrait(n, "Dom"))          npcStart = "{npc_name}'s hand at the back of your neck — light, present — as he moves into position.";
        else                                   npcStart = "{npc_name} behind you. The different angle.";
        String mc = drunkTier().equals("blackout") || drunkTier().equals("drunk")
            ? "*Him behind me. The warmth and the movement of it.*"
            : mcReact("*New angle. A lot of sensation at once.*",
                      "*Different from riding. Fuller. More of him.*",
                      "*Yes. This angle. This.*")
              + "\n\n*My " + cup + " hanging free with each movement.*";
        return npcStart + "\n\n" + (sizeNote.isEmpty() ? "" : sizeNote + "\n\n") + painEntry + mc;
    }

    private String buildDoggyFasterText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("doggy_fast");
        sx.tick(Math.round(80 * mult), Math.round(85 * mult));
        String cup = state.breastDescriptor();
        String npc = hasTrait(n, "Jerk") ? "{npc_name} doesn't hold back. The impact of it."
                   : hasTrait(n, "Outgoing") ? "Both of you are audible now."
                   : hasTrait(n, "Dom") ? "{npc_name} picks up the pace when he decides to. Not negotiated."
                   : "{npc_name} drives harder.";
        String mc = sx.playerIsClose()
            ? "*Close — the position and the pace. Right at the edge.*"
            : "*My " + cup + " swinging with each thrust now.*";
        return npc + "\n\n" + mc;
    }

    private String buildDoggySlowerText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.tick(55, 60);
        if (hasTrait(n, "Dom"))
            return "{npc_name} sets the pace how he wants it. He ignores the request.\n\n"
                 + mcReact("*He's not listening. This is his pace.*", "*He decides the pace.*", "*His rhythm.*");
        if (hasTrait(n, "Jerk"))
            return "You say slower. {npc_name} slows marginally. \"Like this?\" The tone says he knows.";
        return "Slower. {npc_name} pulls back the pace — longer strokes, unhurried.";
    }

    private String buildDoggyHairText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("doggy_hair");
        sx.tick(Math.round(65 * mult), Math.round(70 * mult));
        sx.addFrustration(-10);
        String npcReact;
        if      (hasTrait(n, "Dom") || hasTrait(n, "Sadist")) npcReact = "{npc_name} takes a proper grip. Pulls back until your spine arches. Held.";
        else if (hasTrait(n, "Jerk"))         npcReact = "{npc_name} doesn't hesitate. The grip is firm and he uses it.";
        else if (hasTrait(n, "Shy"))          npcReact = "{npc_name} tries. Gets a grip. You push into it to tell him more.";
        else if (hasTrait(n, "Self_Assured")) npcReact = "{npc_name} grips your hair like he knows what he's doing with it.";
        else                                   npcReact = "{npc_name}'s hand finds your hair. Pulls.";
        return "You tell {npc_name} to pull your hair.\n\n" + npcReact + "\n\n"
             + mcReact("*The pull. My neck extended. Exposed. More sensation everywhere.*",
                       "*The grip and the pull. Something shifts.*",
                       "*Yes. That specifically. Good.*");
    }

    private String buildDoggyStopText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.position = "";
        sx.currentActivity = "";
        sx.setPenetration(false, state);
        return "You shift forward and pull away.\n\n"
             + "{npc_name} lets you move." + (hasTrait(n, "Dom") ? " Just." : "") + "\n\n"
             + "*Off. Reorienting.*";
    }

    // ── 69 ────────────────────────────────────────────────────────────────────

    private String build69Text() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.position = "69";
        sx.currentActivity = "69";
        float mult = sx.activityMultiplier("69");
        awardSexRep("sex_69");
        sx.tick(Math.round(80 * mult), Math.round(80 * mult));
        String cup = state.breastDescriptor();
        String npcReact;
        if      (hasTrait(n, "Engaging"))     npcReact = "{npc_name} settles into position with the attentiveness {npc_he} brings to everything.";
        else if (hasTrait(n, "Magnetic"))     npcReact = "{npc_name} without looking at you — focused. The intensity of it.";
        else if (hasTrait(n, "Shy"))          npcReact = "{npc_name} is careful arranging this. Making sure you're comfortable.";
        else if (hasTrait(n, "Outgoing"))     npcReact = "{npc_name} gets into position with obvious enthusiasm.";
        else if (hasTrait(n, "Jerk"))         npcReact = "{npc_name} manoeuvres you into position. Efficient. For both of you.";
        else                                   npcReact = "{npc_name} and you, facing opposite directions.";
        return "69. Both of you.\n\n" + npcReact + "\n\n"
             + mcReact("*Him against my mouth. His mouth on me. Both at once.*",
                       "*Simultaneous. Hard to know where to put the attention.*",
                       "*Both at once. This is my favourite way to not be able to focus.*")
             + "\n\n*My " + cup + " pressing into {npc_his} stomach. The geometry of this.*";
    }

    private String build69StopText() {
        state.sexState.position = "";
        state.sexState.currentActivity = "";
        return "You roll off {npc_name}. Both of you breathe.\n\n*Too much happening at once to maintain. Good problem.*";
    }

    // ── NPC oral ──────────────────────────────────────────────────────────────

    private String buildNpcOralText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.currentActivity = "npc_oral";
        float mult = sx.activityMultiplier("npc_oral");
        sx.tick(Math.round(85 * mult), 5);
        String cup = state.breastDescriptor();
        boolean condom = sx.condomOn;
        String base;
        if      (hasTrait(n, "Engaging"))     base = "{npc_name} moves down slowly. Checks in before he starts.";
        else if (hasTrait(n, "Magnetic"))     base = "{npc_name} does this like {npc_he}'s been thinking about it. Specific. Focused.";
        else if (hasTrait(n, "Shy"))          base = "{npc_name} is careful. Learning. Genuinely trying to get it right.";
        else if (hasTrait(n, "Self_Assured")) base = "{npc_name} moves down with confidence. He knows what he's doing.";
        else if (hasTrait(n, "Outgoing"))     base = "{npc_name} is enthusiastic about this. It shows immediately.";
        else if (hasTrait(n, "Jerk"))         base = "{npc_name} does this. Effectively. For his own reasons as much as yours.";
        else                                   base = "{npc_name} moves down on you.";
        String condomNote = condom ? "\n\n*The latex. Different. Still working.*" : "";
        String mc = mcReact("*Him down here. My " + cup + " rising and falling fast.*",
                            "*The specific attention of {npc_name} down here.*",
                            "*Good. Right. Stay there.*");
        return base + condomNote + "\n\n" + mc;
    }

    private String buildNpcOralMoreText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("npc_oral");
        sx.tick(Math.round(90 * mult), 5);
        if (sx.playerIsVeryClose())
            return "*Right at the edge. {npc_name} is right there.*\n\n"
                 + "{npc_name} picks up something in your body — adjusts exactly right.";
        if (sx.playerIsClose())
            return "{npc_name} settles into it. You're getting close. {npc_name} seems to know.";
        if (mult < 0.5f)
            return "{npc_name} has settled into a rhythm. You've stopped trying to be quiet.";
        return "{npc_name} keeps going. Focus absolute.\n\n"
             + mcReact("*Still going. Can't look down. Ceiling.*",
                       "*The sustained attention of him. Building.*",
                       "*Don't stop.*");
    }

    // ── Climax ────────────────────────────────────────────────────────────────

    private String buildClimaxMcText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.tick(100, 40);
        sx.playerClimaxCount++;
        sx.playerHasClimaxed = true;
        sx.playerFrustration = 0;
        String cup = state.breastDescriptor();
        boolean drunk = state.drunk >= 6;
        boolean hurt = state.getBodyFlag("flag_is_traumatised") || state.getBodyFlag("flag_is_broken");
        String base;
        if (drunk)
            base = "The orgasm is warm and diffuse and takes longer to process than usual.\n\n*There it is. Good.*";
        else if (hurt)
            base = "It happens. Fully. You're present for it.\n\n*I got to have this. I was here for it.*";
        else if ("riding".equals(sx.position))
            base = "You come on top of {npc_name}.\n\n"
                 + mcReact("*Loud. More than I planned. My " + cup + " and the shaking.*",
                           "*Good. Clear. His hands on my hips through it.*",
                           "*Yes. Right there. All of it.*");
        else
            base = "It comes.\n\n"
                 + mcReact("*Oh. There. My " + cup + " pressed to him.*",
                           "*Good. Right. All of it at once.*",
                           "*Yes. Mine. Good.*");
        String npcReact = hasTrait(n, "Engaging") ? "\n\n{npc_name}: \"Good?\"\n\nVery."
                        : hasTrait(n, "Magnetic") ? "\n\n{npc_name} holds you through it."
                        : hasTrait(n, "Outgoing") ? "\n\n{npc_name} looks unreasonably pleased with himself."
                        : "";
        return base + npcReact;
    }

    private String buildClimaxNpcText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.tick(30, 100);
        sx.npcClimaxCount++;
        sx.npcHasClimaxed = true;
        String base;
        if      (hasTrait(n, "Magnetic"))     base = "{npc_name} goes very quiet and then not quiet at all. His grip. The weight of him through it.";
        else if (hasTrait(n, "Shy"))          base = "{npc_name} muffles a sound that doesn't get fully muffled. Goes still.";
        else if (hasTrait(n, "Self_Assured")) base = "{npc_name} loses the composure. Just once. For about thirty seconds. Then it's gone.";
        else if (hasTrait(n, "Outgoing"))     base = "{npc_name} is not quiet about it. At all.";
        else if (hasTrait(n, "Jerk"))         base = "{npc_name} finishes hard. Controlled even now, but the edge shows.";
        else                                   base = "{npc_name} finishes. The weight of him afterward.";
        return base + "\n\n" + mcReact("*He came. We're past that point.*",
                                       "*He's done. Or done for now.*",
                                       "*Good. I wanted to see that.*");
    }

    private String buildAfterglowText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.active = false;

        // ── Oral consequence tracking ────────────────────────────────────────────
        // Cum breath: NPC climaxed during oral giving
        boolean wasOralGiving = sx.activityBeats.getOrDefault("oral_giving", 0) > 0;
        if (sx.npcHasClimaxed && wasOralGiving && !sx.penetrationHasOccurred) {
            state.addTimedTrait("Cum_Breath", 1);
        }

        // ── Track unprotected sex day for Plan B window ──────────────────────────
        if (sx.penetrationHasOccurred && !sx.condomOn) {
            state.lastUnprotectedSexDay = state.dayCount;
        }

        // ── Pregnancy roll ───────────────────────────────────────────────────────
        // Fires when: penetration occurred + no condom + NPC climaxed
        if (sx.penetrationHasOccurred && !sx.condomOn && sx.npcHasClimaxed && n != null) {
            // Pull-out success: if agreed and NPC didn't ignore it
            boolean effectivePullOut = sx.pullOutAgreed && !sx.npcIgnoredCondom;
            // Only roll if NPC didn't pull out (or if they were supposed to but didn't)
            if (!effectivePullOut || sx.npcIgnoredCondom) {
                if (state.rollPregnancy(state.currentApproachingNpc, effectivePullOut)) {
                    state.addTrait("Pregnant");
                    state.addTimedTrait("Pregnant_Unconfirmed", 7);
                    state.pregnantByNpcId   = state.currentApproachingNpc;
                    state.pregnancyStartDay = state.dayCount;
                    // Assign gender at conception — revealed at birth
                    state.childGender = Math.random() < 0.5 ? 'f' : 'm';
                }
            } else if (effectivePullOut) {
                // Pull-out was followed: tiny pre-ejaculate risk only
                if (state.rollPregnancy(state.currentApproachingNpc, true)) {
                    state.addTrait("Pregnant");
                    state.addTimedTrait("Pregnant_Unconfirmed", 7);
                }
            }
        }

        // Record penetration session for size adaptation tracking
        if (sx.penetrationHasOccurred) {
            state.recordPenetrationSession();
            // Virginity: remove Virgin trait on first penetration
            if (sx.virginityLostThisScene) {
                state.removeTrait("Virgin");
                state.addTrait("Non_Virgin");
                // Immediate rep bump — the psychological shift
                // (applied directly, bypasses daily cap — it's a one-time milestone)
                state.slut_rep = Math.min(100, state.slut_rep + 3);
            }
        }

        // Sore trait — assigned when penetration occurred with large+ NPC
        if (sx.penetrationHasOccurred && n != null) {
            double soreChance = 0.0;
            if      (hasTrait(n, "Painfully_Massive_Cock")) soreChance = 0.95;
            else if (hasTrait(n, "Massive_Cock"))           soreChance = 0.65;
            else if (hasTrait(n, "Huge_Cock"))              soreChance = 0.35;
            else if (hasTrait(n, "Large_Cock"))             soreChance = 0.12;
            if (soreChance > 0 && Math.random() < soreChance) {
                state.addTimedTrait("Sore_From_Sex", 1); // clears next day
            }
        }
        String cup = state.breastDescriptor();
        boolean both = sx.playerHasClimaxed && sx.npcHasClimaxed;
        boolean long_ = sx.beatCount > 15;
        String base = both ? "After. Both of you." : sx.playerHasClimaxed ? "After." : "The session closes here.";
        String npcAfter;
        if      (hasTrait(n, "Magnetic"))     npcAfter = "\n\n{npc_name} pulls you close. Doesn't say anything.";
        else if (hasTrait(n, "Engaging"))     npcAfter = "\n\n\"You okay?\" {npc_name} asks.\n\n\"Very,\" you say.";
        else if (hasTrait(n, "Shy"))          npcAfter = "\n\n{npc_name} is quiet and warm and not quite meeting your eyes.";
        else if (hasTrait(n, "Self_Assured")) npcAfter = "\n\n{npc_name} settles beside you. Easy, like this is something he knows how to do. It is.";
        else if (hasTrait(n, "Outgoing"))     npcAfter = "\n\n\"That was excellent,\" {npc_name} says. \"You agree? I feel like you agree.\"";
        else                                   npcAfter = "\n\n{npc_name} stays close.";
        String bodyNote = long_ ? "\n\n*My " + cup + " sore in a good way. Awareness settling back in slowly.*" : "";
        return base + npcAfter + bodyNote;
    }



    // ── Hickeys ───────────────────────────────────────────────────────────────────

    private String buildHickeyNeckText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        boolean cheating = state.isCheatingSexSession();

        // NPC personality determines if they ask / just do it / do it possessively
        String approach;
        if (hasTrait(n, "Magnetic") || hasTrait(n, "Engaging")) {
            // Asks first — or does it gently enough that it's clearly checkable
            approach = "{npc_name}'s mouth finds your neck. Slow. Not quite asking — but pausing, "
                     + "reading whether you push back.";
        } else if (hasTrait(n, "Shy")) {
            approach = "{npc_name}'s lips press to your neck. Tentative. The warmth of them staying.";
        } else if (hasTrait(n, "Dom") || (hasTrait(n, "Jerk") && cheating)) {
            // Intentional mark — possessive, especially if cheating
            sx.npcMarkedIntentional = true;
            approach = cheating
                ? "{npc_name}'s mouth finds the curve of your neck and stays there — deliberate, unhurried. "
                  + "Marking. Like {npc_he} knows exactly what {npc_he}'s doing and the reason behind it."
                : "{npc_name} bites. Measured. Intentional. The kind that leaves something behind.";
        } else if (hasTrait(n, "Self_Assured") || hasTrait(n, "Outgoing")) {
            approach = "{npc_name} bites your neck. Not hard — but enough.";
        } else if (hasTrait(n, "Jerk")) {
            approach = "{npc_name}'s mouth finds your neck. {npc_He} doesn't particularly ask.";
        } else {
            approach = "{npc_name}'s mouth on your neck. The particular warmth of staying.";
        }

        // MC reaction — varies by whether they wanted this
        String mc;
        if (state.hasTrait("Loves_Being_Watched") || state.hasTrait("Provocative_Sexual"))
            mc = "*Good. Let him.*";
        else if (sx.npcMarkedIntentional && cheating)
            mc = mcReact("*He knows. He knows and he's doing it anyway.*",
                         "*A mark. On purpose. He knows what he's doing.*",
                         "*Interesting move.*");
        else
            mc = mcReact("*His mouth on my neck. Warm and specific.*",
                         "*Noted. Might show later.*",
                         "*That's going to leave something. I don't care.*");

        sx.npcLeftNeckHickey = true;
        state.addTimedTrait("Neck_Hickey", 4);
        state.neckHickeyFromNpcId = state.currentApproachingNpc; // track who left it
        awardSexRep("sex_hickey");
        return approach + "

" + mc;
    }

    private String buildHickeyNeckStopText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        boolean cheating = state.isCheatingSexSession();

        // Does NPC stop?
        boolean stops;
        if (hasTrait(n, "Engaging") || hasTrait(n, "Magnetic") || hasTrait(n, "Shy")) {
            stops = true;
        } else if (hasTrait(n, "Dom") || hasTrait(n, "Jerk")) {
            // Dom and Jerk stop less often; almost never if this is intentional marking during cheating
            stops = !cheating && Math.random() > 0.4;
        } else {
            stops = Math.random() > 0.3;
        }

        if (stops) {
            sx.npcLeftNeckHickey = false;
            // Remove the trait if just applied
            state.removeTrait("Neck_Hickey");
            if (hasTrait(n, "Jerk") || hasTrait(n, "Self_Assured"))
                return "You pull back. {npc_name} reads it and lifts {npc_his} head.

"Fine," {npc_he} says. Not offended. Moving on.";
            if (hasTrait(n, "Shy"))
                return "You say something — he stops immediately. "Sorry," {npc_name} says. Genuinely.";
            return ""Don't," you say. {npc_name} stops. Moves elsewhere. No argument.";
        } else {
            // Doesn't stop
            sx.npcIgnoredNeckStop = true;
            if (hasTrait(n, "Dom"))
                return "You try to move. {npc_name}'s hand holds your jaw — gentle, firm.

"
                     + "*Not asking. Telling.*

"
                     + "He doesn't stop.

"
                     + "*He's leaving a mark and he knows it and he doesn't care what I said.*

"
                     + "The anger and the arousal arrive at the same time and don't resolve easily.";
            if (cheating && hasTrait(n, "Jerk"))
                return ""Stop —" He doesn't.

"
                     + "{npc_name} keeps {npc_his} mouth on your neck.

"
                     + "*He knows. That's why he's doing it.*

"
                     + "The mark is going to show. He knows that too.";
            return "You say something. {npc_name} barely slows.

"
                 + "*Too far along to care what I said.*

"
                 + mcReact("*He's going to leave a mark. I can feel it already.*",
                           "*He's not stopping.*",
                           "*Well. That's happening.*");
        }
    }

    private String buildHickeyBreastText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        String cup = state.breastDescriptor();

        String approach;
        if      (hasTrait(n, "Magnetic"))     approach = "{npc_name}'s mouth moves to your " + cup + ". Stays. Slow.";
        else if (hasTrait(n, "Engaging"))     approach = "{npc_name} checks in — not with words, with the pause. You don't pull back.";
        else if (hasTrait(n, "Outgoing"))     approach = "{npc_name}'s mouth on your " + cup + ". Warm, direct. Leaves a mark he is transparently pleased about.";
        else if (hasTrait(n, "Dom") || hasTrait(n, "Jerk"))
            approach = "{npc_name} bites your " + cup + ". Holds it. The pressure past comfortable for one second.

"
                     + "He lets go. A mark, under the skin. Invisible to anyone but you — and him.";
        else approach = "{npc_name}'s mouth on your breast. Warm. Staying.";

        sx.npcLeftBreastHickey = true;
        state.addTimedTrait("Breast_Hickey", 4);
        state.breastHickeyFromNpcId = state.currentApproachingNpc;
        String mc = mcReact(
            "*His mouth on my " + cup + ". Going to leave a mark. At least it's coverable.*",
            "*That'll bruise. Could be worse. Could be my neck.*",
            "*Good. There.*");
        return approach + "

" + mc;
    }

    private String buildHickeyMarkAnywayText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        boolean cheating = state.isCheatingSexSession();
        sx.npcMarkedIntentional = true;
        sx.npcLeftNeckHickey = true;
        state.addTimedTrait("Neck_Hickey", 4);
        state.neckHickeyFromNpcId = state.currentApproachingNpc;

        // This fires when NPC deliberately marks despite MC saying not to — cheating scenario
        String mcReaction;
        if (cheating)
            mcReaction = "*He knows I have someone. That's exactly why he's doing it.*

"
                       + "*This isn't about desire. It's about territory.*

"
                       + "The anger is cold and specific.
"
                       + "The mark is going to be visible.
"
                       + "You're going to have to explain it or cover it.

"
                       + "That's the point. He knows that's the point.";
        else
            mcReaction = "*He decided to leave a mark. My input wasn't part of that.*

"
                       + mcReact("*And I can't undo it now. Four days minimum.*",
                                 "*Annoying. I'll deal with it.*",
                                 "*I'm going to have things to say about this.*");

        return "{npc_name}'s mouth on your neck — and {npc_he} doesn't stop.

" + mcReaction;
    }



    // ── Size / tightness pain system ─────────────────────────────────────────────

    /**
     * Returns a pain/comfort prefix string for the start of penetration.
     * Called internally from riding/missionary/doggy start texts.
     */
    private String painEntryText() {
        int delta = state.penetrationPainDelta();
        int adaptLevel = state.sizeAdaptLevel(state.currentNpcSizeTier());
        String tier = state.currentNpcSizeTier();
        boolean adapting = adaptLevel > 0 && adaptLevel < state.maxAdaptation(tier);
        boolean adapted  = adaptLevel >= state.maxAdaptation(tier) && delta <= 0;

        if (delta <= 0) {
            // Comfortable — size matches or smaller than what MC handles
            if (adapted && !tier.equals("medium") && !tier.equals("small")) {
                return "*Your body knows this now. Full and familiar.*

";
            }
            return ""; // no extra text for comfortable/small
        }

        if (delta == 1) {
            // Mild stretch — noticeable but workable
            String note;
            if (adapting)
                note = "*A stretch. Less than the first time — the body remembers.*";
            else
                note = "*Full. A lot. Workable, but it takes a moment.*";
            return note + "

";
        }

        if (delta == 2) {
            // Significant pain — real discomfort, needs adjustment
            String note;
            if (adapting)
                note = "*Still a lot. Better than the first time — not comfortable yet.*

"
                     + "You breathe out. Adjust. Take your time.";
            else
                note = "*That's — a lot. More than expected. You stop moving.*

"
                     + "A breath. Two. Your body needs a moment to adjust.";
            return note + "

";
        }

        // delta >= 3: serious pain
        String note;
        if (adapting)
            note = "*Still significant. You're getting there — but not there yet.*

"
                 + "You go slow. Control the pace completely. Nothing happens until you say.";
        else
            note = "*That's—*

"
                 + "You stop immediately. One hand flat on his chest.

"
                 + "*Too much. Way too much. He needs to wait.*

"
                 + "Slow. Controlled. You inch forward rather than sink.";
        return note + "

";
    }

    /**
     * Returns status text about MC's current adaptation level with this NPC's size.
     * Used as a token to show progress/regression.
     */
    private String buildAdaptationStatusText() {
        int delta = state.penetrationPainDelta();
        int adapt = state.sizeAdaptLevel(state.currentNpcSizeTier());
        int max   = state.maxAdaptation(state.currentNpcSizeTier());
        String tier = state.currentNpcSizeTier();

        if (tier.equals("small") || tier.equals("medium")) return "";
        if (delta <= 0 && adapt >= max)
            return "*Your body's used to {npc_name} now. The fit that once needed patience is just your fit.*";
        if (adapt == 0)
            return "*Your body hasn't had time to learn this yet.*";
        if (adapt == 1)
            return "*Getting there. Your body remembers enough to make the start easier.*";
        if (adapt >= 2)
            return "*You've done this enough. The adjustment is still there — smaller now.*";
        return "";
    }


    // ── Anal ─────────────────────────────────────────────────────────────────────

    private String buildAnalAskText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        int delta = state.penetrationPainDelta(); // anal always adds +2 effective

        String mc = mcReact(
            "*Saying it. I want to know if I want this.*",
            "*Asking. The question is real.*",
            "*I want to try this with {npc_name}. Saying so.*");

        String npcReact;
        if      (hasTrait(n, "Magnetic") || hasTrait(n, "Engaging"))
            npcReact = "{npc_name} pauses. Takes it in. "Yeah?"\n\nThe checking-in quality of {npc_him}. He wants to know you mean it.";
        else if (hasTrait(n, "Shy"))
            npcReact = "{npc_name} goes slightly still. Then: "Really?"\n\nNot against it. Surprised. Careful.";
        else if (hasTrait(n, "Self_Assured"))
            npcReact = "{npc_name} looks at you. Takes a breath. "Okay. Slow."";
        else if (hasTrait(n, "Outgoing"))
            npcReact = ""Yeah — yes. Absolutely. Are you sure?"\n\nThe enthusiasm and the checking-in at the same time.";
        else if (hasTrait(n, "Jerk") || hasTrait(n, "Dom"))
            npcReact = "{npc_name}'s hands slow. He looks at you with something sharp in his expression.\n\n"Yeah," he says. "We can do that."";
        else
            npcReact = "{npc_name} slows. Takes the question seriously. "Okay. If you want."";

        String painNote = delta >= 2
            ? "\n\n*It's a lot. Slower than slow. Your body adjusts or it doesn't — either answer is allowed.*"
            : delta == 1
            ? "\n\n*More than riding. Different kind of full. Working through it.*"
            : "";

        return mc + "\n\n" + npcReact + painNote;
    }


    // ── Roughness ─────────────────────────────────────────────────────────────────

    /** NPC slaps MC's ass — available during doggy/riding, gated on rough context or Jerk. */
    private String buildAssSlapText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        float mult = sx.activityMultiplier("rough");
        sx.tick(Math.round(60 * mult), Math.round(55 * mult));
        sx.currentActivity = "rough";
        awardSexRep("sex_rough");

        boolean masochist = state.hasTrait("Masochist") || state.hasTrait("Pain_Positive");
        boolean likesPain = state.hasTrait("Prefers_Larger") || masochist; // proxy for intensity preference
        String cup = state.breastDescriptor();

        String npcDeliver;
        if (hasTrait(n, "Dom") || hasTrait(n, "Jerk"))
            npcDeliver = "{npc_name} brings {npc_his} palm down hard.

Clean. Deliberate. Leaves a sting.";
        else if (hasTrait(n, "Self_Assured"))
            npcDeliver = "{npc_name} doesn't ask. The slap lands with a crack that surprises you both.";
        else if (hasTrait(n, "Outgoing"))
            npcDeliver = "{npc_name} slaps your ass and immediately looks pleased about it.";
        else
            npcDeliver = "{npc_name}'s palm connects. Sharp. Warm after.";

        String mcReaction;
        if (masochist)
            mcReaction = mcReact("*Yes. That. More of that.*", "*Good. The sting of it good.*",
                                 "*Yes — I asked for that and it delivered.*");
        else if (likesPain)
            mcReaction = "*The sting. The specific heat of it.*

*Yes.*";
        else
            mcReaction = mcReact(
                "*The sound of it before I register the feeling. Then the feeling.*",
                "*Stings. Hot. Still moving.*",
                "*Warranted. Keeps things interesting.*");

        return npcDeliver + "

" + mcReaction
             + "

*My " + cup + " swing with the rhythm. The mark he's left is already warm.*";
    }

    /**
     * NPC goes rough naturally — fires for Jerk/Dom NPCs during doggy/riding
     * without MC explicitly asking. The intensity is present from the start.
     */
    private String buildNpcGoesRoughText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        boolean cheating = state.isCheatingSexSession();
        String cup = state.breastDescriptor();

        String npcRough;
        if (hasTrait(n, "Jerk")) {
            npcRough = cheating
                ? "{npc_name} doesn't ease into it.

"
                  + "Hard and fast and without asking. There's an edge to it —
"
                  + "like {npc_he} knows what {npc_he}'s doing and why."
                : "{npc_name} doesn't build to it. Just: hard, fast, taking what {npc_he} came for.

"
                  + "You weren't asked. You weren't told. {npc_He} just did.";
        } else if (hasTrait(n, "Dom")) {
            npcRough = "{npc_name} sets the pace without negotiation. Controlled intensity —
"
                     + "not reckless but not gentle. The kind that says {npc_he}'s thought about this.";
        } else {
            npcRough = "The pace has gone somewhere you weren't expecting.

"
                     + "{npc_name} is less careful than before. More urgent.";
        }

        String mcReact2 = state.hasTrait("Masochist")
            ? "*Oh. Yes. This version.*"
            : mcReact(
                "*He didn't ask. He didn't slow down. That's what this is.*",
                "*More intense than expected. Still here.*",
                "*He decided the pace. I can work with this.*");

        sx.tick(75, 80);
        awardSexRep("sex_rough");
        return npcRough + "

" + mcReact2
             + "

*My " + cup + " swing. The full weight of {npc_him}.*";
    }


    // ── Hickey concealment ───────────────────────────────────────────────────────

    /** MC lifts her shirt but keeps it on — hiding hickey while allowing torso access. */
    private String buildShirtLiftHidingText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.mcShirtLifted = true;
        sx.mcHidingHickey = true;

        String mc = mcReact(
            "*Shirt up, not off. Keep the mark covered. He doesn't need to see it.*",
            "*Shirt stays on. Lifted is enough. Works fine.*",
            "*Practical compromise. He gets what he wants, I keep the secret.*");

        String npcReact;
        if (hasTrait(n, "Engaging") || hasTrait(n, "Magnetic"))
            npcReact = "{npc_name} notices the shirt staying on. Doesn't press it.
"
                     + "{npc_He} works with what you're offering.";
        else if (hasTrait(n, "Jerk") || hasTrait(n, "Dom"))
            npcReact = "{npc_name}'s hand finds the hem anyway. Pushes it higher — stops short of removing it.
"
                     + "*He's testing the boundary.*

*Don't let him get further.*";
        else
            npcReact = "{npc_name} reads nothing into it. Continues.";

        return "You lift your shirt. Leave it on.

" + npcReact + "

" + mc;
    }

    /** NPC pushes the shirt up/off despite MC keeping it on — hickey revealed. */
    private String buildShirtRevealText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.mcShirtLifted = false;
        sx.mcShirtOff = true;

        String npcNotices;
        if (hasTrait(n, "Engaging"))
            npcNotices = "{npc_name} goes still.

"
                       + "His hand is on your side, and his eyes have found your neck,
"
                       + "and the stillness is the specific kind that means {npc_he}'s seen something.

"
                       + ""Was that there before?" {npc_He} asks.

"
                       + "Quiet. Already knowing.";
        else if (hasTrait(n, "Magnetic"))
            npcNotices = "{npc_name} looks at you.

"
                       + "Doesn't say anything for a moment. Takes in the mark on your neck.
"
                       + "Takes in the shirt you were keeping on.

"
                       + "*He knows. He can do the maths.*

"
                       + ""Oh," he says.";
        else if (hasTrait(n, "Jerk"))
            npcNotices = "{npc_name}'s eyes go to your neck.

"
                       + "He looks at it for a beat longer than he should.
"
                       + "Then at you. Then at the shirt.

"
                       + ""Right," he says. Flat. Final.

"
                       + "*He's already decided what this means.*";
        else if (hasTrait(n, "Shy"))
            npcNotices = "{npc_name} sees it and immediately looks away.

"
                       + "Then back. Can't help it.

"
                       + ""That's— " {npc_He} doesn't finish. Swallows.

"
                       + "The hurt is quiet and total.";
        else
            npcNotices = "{npc_name} sees the mark.

"
                       + "The moment where everything is clear at once.
"
                       + "{npc_He} looks at you. You look back.

"
                       + "This is what you were trying to prevent.";

        return "The shirt goes.

" + npcNotices
             + "

*The shirt was the last thing between him and knowing.
"
             + "It's gone now. So is the possibility of pretending.*";
    }

    // ── Period disclosure ─────────────────────────────────────────────────────────

    private String buildPeriodDisclosureText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;

        // How MC says it varies by confidence/shyness
        String mc;
        if (state.hasTrait("Shy") || state.hasTrait("Fragile_Ego"))
            mc = "*Say it.*

"I'm — I'm on my period."

*There. Said.*";
        else if (state.hasTrait("Self_Assured") || state.hasTrait("Confrontational"))
            mc = "You put your hand over his.

"I'm on my period." Easy. Matter-of-fact.";
        else
            mc = "You catch his wrist before he gets there.

"I'm on my period," you say.";

        // NPC reaction varies by personality
        String npcReact;
        if (hasTrait(n, "Engaging") || hasTrait(n, "Magnetic")) {
            npcReact = "{npc_name} stops. Nods. Moves his hands somewhere else without making anything of it.

"
                     + ""Okay," {npc_he} says. Just that.";
        } else if (hasTrait(n, "Shy")) {
            npcReact = "{npc_name} pulls back immediately. Goes a little pink.

"Sorry — I didn't—"

"It's fine," you say.";
        } else if (hasTrait(n, "Outgoing")) {
            npcReact = ""Oh! Yeah — yeah, of course. Sorry."

He moves on. No drama.";
        } else if (hasTrait(n, "Self_Assured")) {
            npcReact = "{npc_name} moves his hands without comment. The way confident people handle things
"
                     + "they didn't know: efficiently, without embarrassment.";
        } else if (hasTrait(n, "Jerk")) {
            npcReact = "{npc_name} pauses. For a moment you don't know which version of him this is.

"
                     + "Then: "Fine," {npc_he} says. Moves on.

"
                     + "*Fine is fine. Fine works.*";
        } else if (hasTrait(n, "Dom")) {
            npcReact = "{npc_name} stops. Assesses.

"Noted." He doesn't push it.

"
                     + "The control of him extends to this too.";
        } else {
            npcReact = "{npc_name} hears you. Adjusts. Hands going elsewhere.

"Okay," {npc_he} says.";
        }
        return mc + "

" + npcReact
             + "

*He knows now. The rest of this is what it is.*";
    }

    // ── Pull out request ──────────────────────────────────────────────────────

    private String buildPullOutAskText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;

        String npcReact;
        boolean complies;
        if (hasTrait(n, "Engaging") || hasTrait(n, "Magnetic") || hasTrait(n, "Shy")) {
            npcReact = ""Yeah," {npc_name} says. Breathless. "Okay. Tell me when."

"
                     + "{npc_name} keeps going but differently now — present to the signal.";
            complies = true;
        } else if (hasTrait(n, "Self_Assured")) {
            npcReact = "{npc_name} nods once. Controlled.

"I'll know."";
            complies = true;
        } else if (hasTrait(n, "Outgoing")) {
            npcReact = ""Yeah, yeah — fine. Got it." Not annoyed. Just focused.";
            complies = true;
        } else if (hasTrait(n, "Jerk") || hasTrait(n, "Dom")) {
            npcReact = "{npc_name} makes a sound — noncommittal. Not a yes.

"
                     + "*He heard you. Whether he'll follow through is something else.*";
            complies = false;
        } else {
            npcReact = "{npc_name} slows for a beat. "Yeah. Okay."";
            complies = true;
        }

        sx.pullOutAgreed = complies;
        if (!complies) return "You tell {npc_name} you want him to pull out before he finishes.

" + npcReact
             + "

*You said it. What happens next is on him.*";
        return "You tell {npc_name} you want him to pull out before he finishes.

" + npcReact;
    }

    private String buildPullOutIgnoresText() {
        NpcData n = currentNpc(); if (n == null) return "";
        // NPC ignored the pull out request — finishes inside
        state.sexState.pullOutAgreed = false;
        String base;
        if (hasTrait(n, "Jerk"))
            base = "{npc_name} doesn't pull out.

"
                 + "You feel the moment happen and there's no undoing it.

"
                 + "*He didn't pull out. I told him to pull out.*

"
                 + "The anger comes after the fact. Clean and cold.";
        else if (hasTrait(n, "Dom"))
            base = "{npc_name} doesn't pull out.

"
                 + "No acknowledgment. No eye contact afterward.

"
                 + "*He decided. Without asking.*

"
                 + "That's the version of this you're going to sit with.";
        else
            base = "{npc_name} doesn't pull out.

"
                 + "Maybe he didn't hear you. Maybe he was too far along.

"
                 + "*It happened anyway. You said stop and it happened anyway.*

"
                 + "You're not sure what to do with that yet.";
        return base;
    }

    // ── Condom violation paths ─────────────────────────────────────────────────

    private String buildViolationGiveInText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.npcIgnoredCondom = true;
        // Note in penetration state but mark the cause
        sx.tick(30, 40); // limited arousal — present but compromised

        // May earn Rattled flag at random
        if (Math.random() < 0.4) {
            state.addTrait("Rattled");
        }

        String cup = state.breastDescriptor();
        return "You let it happen.

"
             + "*He's not wearing one. I said I needed him to. He didn't.*

"
             + "*And I'm letting it happen anyway.*

"
             + "The sensation is there — {npc_name} above or behind you, the warmth of {npc_him}. "
             + "Your " + cup + " against {npc_his} chest or the mattress.

"
             + "*This isn't what I agreed to.*

"
             + "The thought sits in the back of everything that follows.

"
             + "Not erased by it. Present in it.";
    }

    private String buildViolationUpsetText() {
        NpcData n = currentNpc(); if (n == null) return "";
        SexState sx = state.sexState;
        sx.npcIgnoredCondom = true;
        sx.setPenetration(false, state);
        state.addTrait("Rattled");

        return "You say something.

"
             + "Not quiet. Not a question.

"
             + mcReact(
                 "*I said no. I said not without one. He did it anyway.*

"
                 + "The words come out fractured but they come out.",
                 ""I said not without a condom."

"
                 + "Clear. The thing that was done is named.",
                 ""Stop. Now. I told you — condom or nothing."

"
                 + "{npc_name} stops.

"
                 + "The room is different than it was ten seconds ago.")
             + "

{npc_name} stills. Whatever comes next is between you and "
             + "whatever version of {npc_him} this turns out to be.";
    }

    private String buildViolationStopText() {
        NpcData n = currentNpc(); if (n == null) return "";
        state.sexState.reset();
        return "You stop it.

"
             + "Move away. Create space.

"
             + "*No. This isn't what I agreed to. We're done.*

"
             + "{npc_name} registers what just happened.

"
             + "You're not going to process this in front of {npc_him}.
"
             + "That's for later. For now: distance.

"
             + "You find your clothes.";
    }


    private String buildUpsetFlavorText() {
        SexState sx = state.sexState;
        NpcData n = currentNpc();
        // Flavor that appears in the hub when MC is upset but scene continues
        String pos = sx.position;
        String posNote = "riding".equals(pos) ? "*On top of him. After what he did.*"
                       : "missionary".equals(pos) ? "*His weight. After what he chose.*"
                       : "doggy".equals(pos) ? "*From behind. Not looking at each other.*"
                       : "*Still here. Still in this.*";
        return posNote + "\n\n"
             + mcReact(
                 "*The upset sits under everything. Present in every movement.*",
                 "*The two things existing at once: the physical and what it means.*",
                 "*I'm letting this finish. That's my choice now. Mine.*");
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Awards slut rep for an in-progress sex action using the same diminishing returns. */
    private void awardSexRep(String actionType) {
        // Base gain per action: same base value for all sex types (1),
        // but lifetime cap and diminishing returns differ per type
        int gain = state.applySlutRepEarned(actionType, 1);
        // Sex scene daily cap check
        int dayRemaining = GameState.SLUT_REP_SEX_DAILY_CAP - state.slutRepGainedToday;
        gain = Math.min(gain, Math.max(0, dayRemaining));
        int sceneRemaining = 4 - state.slutRepGainedThisScene; // sex scene cap = 4 per scene
        gain = Math.min(gain, Math.max(0, sceneRemaining));
        if (gain > 0) {
            state.slut_rep = Math.min(100, state.slut_rep + gain);
            state.slutRepGainedThisScene += gain;
            state.slutRepGainedToday     += gain;
        }
    }

    private NpcData currentNpc() {
        return npcs.get(state.currentApproachingNpc);
    }

    private String drunkTier() {
        if (state.drunk >= 15) return "blackout";
        if (state.drunk >= 11) return "drunk";
        if (state.drunk >=  6) return "tipsy";
        return "sober";
    }

    private boolean hasTrait(NpcData n, String trait) {
        if (n == null || n.traits == null) return false;
        for (String t : n.traits) if (t.equalsIgnoreCase(trait)) return true;
        return false;
    }

    private String mcReact(String shy, String neutral, String enjoy) {
        if (state.hasTrait("Shy") || state.hasTrait("Fragile_Ego") || state.hasTrait("Conflict_Avoidant"))
            return shy;
        if (state.hasTrait("Self_Assured") || state.hasTrait("Confrontational") ||
            state.hasTrait("Outgoing")     || state.hasTrait("Provocative_Sexual"))
            return enjoy;
        return neutral;
    }

    private String npcSizeFirstTime(NpcData n) {
        if (n == null) return "";
        return state.sexState.activityBeats.getOrDefault("oral_giving", 0) == 0
               ? npcCockNote(n) : "";
    }

    private String npcSizeNote(NpcData n) { return npcCockNote(n); }

    private String npcCockNote(NpcData n) {
        if (n == null) return "";
        if (hasTrait(n, "Painfully_Massive_Cock")) return "*He's — a lot. More than expected. You adjust carefully.*";
        if (hasTrait(n, "Massive_Cock"))           return "*Larger than expected. Noticeably. You register that.*";
        if (hasTrait(n, "Huge_Cock"))              return "*Big. You feel the size before anything else.*";
        if (hasTrait(n, "Large_Cock"))             return "*Noticeably above average. A good fit.*";
        if (hasTrait(n, "Small_Cock"))             return "*Smaller than average — comfortable, unhurried.*";
        return "";
    }

    private String ridesSizeNote(NpcData n) {
        if (hasTrait(n, "Huge_Cock") || hasTrait(n, "Massive_Cock") || hasTrait(n, "Painfully_Massive_Cock"))
            return "*Going slow to start. The size is something to manage.*";
        if (hasTrait(n, "Large_Cock"))
            return "*Full. The angle up here is particularly clear.*";
        return "";
    }

    private String entersSizeNote(NpcData n) {
        if (hasTrait(n, "Painfully_Massive_Cock") || hasTrait(n, "Massive_Cock"))
            return "*The weight of {npc_him} and the size of {npc_him}. You take a breath.*";
        if (hasTrait(n, "Huge_Cock") || hasTrait(n, "Large_Cock"))
            return "*The angle under {npc_him} — deeper like this.*";
        return "";
    }
}
