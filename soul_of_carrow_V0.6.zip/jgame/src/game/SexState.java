package game;

import game.data.NpcData;

/**
 * Tracks the state of an active sex scene.
 *
 * Lifecycle:
 *   begin(npcId, npc)  — call when a sex scene starts
 *   tick(...)          — call once per narrative beat to advance arousal / climax
 *   reset()            — call when the scene ends
 *
 * All progress values are 0–100.
 * A party climaxes when their climaxProgress reaches 100.
 * After climax, climaxProgress resets and climaxCount increments.
 *
 * Climax rates (progress added per tick of stimulation):
 *   Premature_Ejaculator : 50   (~2 beats to climax)
 *   Hair_Trigger         : 30   (~3-4 beats)
 *   Quick_Finish         : 16   (~6-7 beats)
 *   Average_Stamina      :  8   (~12-13 beats)   ← default
 *   Good_Stamina         :  5   (~20 beats)
 *   Long_Lasting         :  3   (~33+ beats)
 */
public class SexState {

    // ── Session identity ─────────────────────────────────────────
    /** ID of the NPC involved in the scene. Empty string when no scene is active. */
    public String  npcId  = "";

    /** Whether a scene is currently in progress. */
    public boolean active = false;

    // ── Arousal (0–100): how turned on each party currently is ───
    /** Player arousal. Feeds into how fast playerClimaxProgress builds. */
    public int playerArousal = 0;

    /** NPC arousal. Feeds into how fast npcClimaxProgress builds. */
    public int npcArousal    = 0;

    // ── Climax progress (0–100): how close each party is to finishing ──
    /** Player's progress toward climax. Reaches 100 → climax triggers. */
    public int playerClimaxProgress = 0;

    /** NPC's progress toward climax. Reaches 100 → climax triggers. */
    public int npcClimaxProgress    = 0;

    // ── Climax counts: how many times each party has climaxed ────
    /** How many times the player has climaxed this scene. */
    public int playerClimaxCount = 0;

    /** How many times the NPC has climaxed this scene. */
    public int npcClimaxCount    = 0;

    // ── Beat counter ─────────────────────────────────────────────
    /** How many action beats (ticks) have occurred this scene. */
    public int beatCount = 0;

    // ── Stamina config (set from NPC traits at scene start) ──────
    /**
     * How much npcClimaxProgress increases per tick of stimulation.
     * Higher = finishes faster. Set automatically from NPC stamina trait.
     */
    public int npcClimaxRate    = 8;   // default: Average_Stamina

    /**
     * How much playerClimaxProgress increases per tick of stimulation.
     * Can be modified by player traits, items, or scene conditions.
     */
    public int playerClimaxRate = 8;   // default: moderate

    // ── Frustration (0–100) ──────────────────────────────────────
    /**
     * Player frustration level.
     * Rises when the player is highly aroused but climax is being denied or delayed.
     * Falls when the player climaxes or arousal drops.
     * Scene writers can also push it directly via addFrustration() / clearFrustration().
     */
    public int playerFrustration = 0;

    /**
     * NPC frustration level.
     * Rises when the NPC is highly aroused but climax is blocked or drawn out.
     */
    public int npcFrustration    = 0;

    // ── Penetration ──────────────────────────────────────────────
    /**
     * Whether penetration is currently occurring.
     * Setting this via setPenetration(true, state) will also flip the player's
     * Virgin trait to Non_Virgin if this is their first time.
     */
    public boolean isPenetration = false;

    /**
     * True if penetration has occurred at any point this scene.
     * Stays true even if isPenetration is later set to false.
     */
    public boolean penetrationHasOccurred = false;

    // ── Flags ────────────────────────────────────────────────────
    /** True once the NPC has climaxed at least once (convenience flag). */
    public boolean npcHasClimaxed    = false;

    /** True once the player has climaxed at least once (convenience flag). */
    public boolean playerHasClimaxed = false;

    /**
     * True if the player lost their virginity during this scene.
     * Useful for scene writers who want to react to the moment after the fact.
     */
    public boolean virginityLostThisScene = false;

    // ── Activity / position / clothing tracking ───────────────────
    public String  currentActivity  = "";
    public String  position         = ""; // "riding"|"missionary"|"doggy"|"69"|""

    // MC clothing removed during scene
    public boolean mcShirtOff       = false;
    public boolean mcBraOff         = false;
    public boolean mcBottomOff      = false;
    public boolean mcUnderwearOff   = false;
    public boolean mcSkirtHiked     = false;

    // NPC clothing removed
    public boolean npcTopOff        = false;
    public boolean npcBottomOff     = false;

    // Condom
    public boolean condomOn             = false;
    public boolean condomUsed           = false;
    /** Player attempted to put a condom on this scene. */
    public boolean playerRequestedCondom = false;
    /** NPC refused a condom request this scene. */
    public boolean npcRefusedCondom      = false;
    /** NPC penetrated without consent (after condom refusal + player request). */
    public boolean npcIgnoredCondom      = false;
    /** NPC agreed to pull out before climaxing. */
    public boolean pullOutAgreed         = false;
    /** MC has expressed upset/objection during scene (non-consensual condom situation). */
    public boolean mcIsUpsetDuringScene  = false;

    // Special states
    public boolean askedForRough    = false;
    public boolean npcDomLocked     = false;
    public boolean dirtyTalkActive  = false;

    // ── Hickeys ───────────────────────────────────────────────────
    /** NPC left a hickey on MC's neck this scene. */
    public boolean npcLeftNeckHickey    = false;
    /** MC is actively trying to hide a hickey from current partner. */
    public boolean mcHidingHickey       = false;
    /** Shirt has been lifted but not removed (access without full exposure). */
    public boolean mcShirtLifted        = false;
    /** NPC left a hickey on MC's breast this scene. */
    public boolean npcLeftBreastHickey  = false;
    /** MC asked NPC to stop leaving a hickey and was ignored. */
    public boolean npcIgnoredNeckStop   = false;
    /** NPC marked MC intentionally (possessive/cheating context). */
    public boolean npcMarkedIntentional = false;

    // Legacy naked flags (kept for SexSystem compatibility)
    public boolean mcNaked          = false;
    public boolean npcNaked         = false;
    public boolean bothNaked()      { return mcNaked && npcNaked; }

    // Activity diminishing returns
    public java.util.Map<String,Integer> activityBeats = new java.util.HashMap<>();

    /** Returns 1.0 → 0.8 → 0.6 → 0.4 → 0.25 as activity repeats. */
    public float activityMultiplier(String activity) {
        int n = activityBeats.getOrDefault(activity, 0);
        activityBeats.put(activity, n + 1);
        if (n == 0) return 1.00f;
        if (n <= 2)  return 0.80f;
        if (n <= 5)  return 0.60f;
        if (n <= 9)  return 0.40f;
        return 0.25f;
    }

    /** MC lower body accessible for penetration. */
    public boolean mcHasLowerAccess(GameState state) {
        if (mcBottomOff || mcUnderwearOff) return true;
        if (mcSkirtHiked && state.outfitUnderwear == null) return true;
        if (state.outfitLower != null && state.outfitUnderwear == null) return true;
        return false;
    }

    public boolean npcIsAccessible()               { return npcBottomOff; }
    public boolean penetrationPossible(GameState s){ return mcHasLowerAccess(s) && npcIsAccessible(); }
    public boolean playerIsBuildingToClimx()       { return playerClimaxProgress >= 60; }

    // ── Lifecycle ────────────────────────────────────────────────

    /**
     * Start a new sex scene with the given NPC.
     * Reads the NPC's stamina trait and sets npcClimaxRate accordingly.
     */
    public void begin(String npcId, NpcData npc) {
        reset();
        this.npcId  = npcId;
        this.active = true;
        this.npcClimaxRate = climaxRateFromNpc(npc);
    }

    /** Reset all state. Call when a scene ends. */
    public void reset() {
        npcId                  = "";
        active                 = false;
        playerArousal          = 0;
        npcArousal             = 0;
        playerClimaxProgress   = 0;
        npcClimaxProgress      = 0;
        playerClimaxCount      = 0;
        npcClimaxCount         = 0;
        beatCount              = 0;
        npcClimaxRate          = 8;
        playerClimaxRate       = 8;
        npcHasClimaxed         = false;
        playerHasClimaxed      = false;
        playerFrustration      = 0;
        npcFrustration         = 0;
        isPenetration          = false;
        penetrationHasOccurred = false;
        virginityLostThisScene = false;
        currentActivity        = "";
        position               = "";
        mcShirtOff             = false;
        mcBraOff               = false;
        mcBottomOff            = false;
        mcUnderwearOff         = false;
        mcSkirtHiked           = false;
        npcTopOff              = false;
        npcBottomOff           = false;
        condomOn               = false;
        condomUsed             = false;
        askedForRough          = false;
        npcDomLocked           = false;
        dirtyTalkActive        = false;
        currentActivity  = "";
        position         = "";
        mcShirtOff       = false;  mcBraOff    = false;
        mcBottomOff      = false;  mcUnderwearOff = false;
        mcSkirtHiked     = false;
        npcTopOff        = false;  npcBottomOff   = false;
        condomOn              = false;  condomUsed           = false;
        playerRequestedCondom = false;  npcRefusedCondom     = false;
        npcIgnoredCondom      = false;  pullOutAgreed        = false;
        mcIsUpsetDuringScene  = false;
        askedForRough    = false;  npcDomLocked      = false;
        dirtyTalkActive  = false;
        npcLeftNeckHickey   = false;  npcLeftBreastHickey  = false;
        npcIgnoredNeckStop  = false;  npcMarkedIntentional = false;
        mcHidingHickey      = false;  mcShirtLifted        = false;
        mcNaked          = false;  npcNaked    = false;
        activityBeats.clear();
    }

    /**
     * Set or clear the penetration flag.
     *
     * If penetration is being set to true and the player has the Virgin trait,
     * it is automatically removed and Non_Virgin is added. The one-time flag
     * virginityLostThisScene is also set so scene writers can react.
     *
     * @param penetrating  true = penetration is occurring, false = it has stopped
     * @param state        the current GameState (used to check/flip virginity traits)
     */
    public void setPenetration(boolean penetrating, GameState state) {
        isPenetration = penetrating;
        if (penetrating) {
            penetrationHasOccurred = true;
            // Virgin check — flip once, permanently
            if (state != null && state.hasTrait("Virgin")) {
                state.removeTrait("Virgin");
                state.addTrait("Non_Virgin");
                virginityLostThisScene = true;
            }
        }
    }

    /**
     * Advance one beat.
     *
     * @param playerStimulation  0–100: how much stimulation the player is receiving this beat
     * @param npcStimulation     0–100: how much stimulation the NPC is receiving this beat
     *
     * Arousal rises with stimulation and decays slightly without it.
     * Climax progress scales with current arousal × climax rate.
     * Frustration rises when arousal is high (≥ 70) but climax hasn't triggered.
     *
     * @return TickResult describing what happened (climaxes, etc.)
     */
    public TickResult tick(int playerStimulation, int npcStimulation) {
        beatCount++;
        TickResult result = new TickResult();

        // ── Player ──────────────────────────────────────────────
        playerArousal = clamp(playerArousal + (playerStimulation / 10) - 2);
        if (playerArousal > 20) {
            int gain = (playerClimaxRate * playerArousal) / 100;
            playerClimaxProgress = clamp(playerClimaxProgress + Math.max(1, gain));
        }
        if (playerClimaxProgress >= 100) {
            playerClimaxProgress  = 0;
            playerClimaxCount++;
            playerHasClimaxed     = true;
            playerFrustration     = clamp(playerFrustration - 40);  // relief
            result.playerClimaxed = true;
        } else if ((playerArousal >= 40 && !isPenetration) || playerArousal >= 90) {
            // Frustrated if aroused with no penetration, or extremely aroused regardless
            playerFrustration = clamp(playerFrustration + 5);
        }

        // ── NPC ─────────────────────────────────────────────────
        npcArousal = clamp(npcArousal + (npcStimulation / 10) - 2);
        if (npcArousal > 20) {
            int gain = (npcClimaxRate * npcArousal) / 100;
            npcClimaxProgress = clamp(npcClimaxProgress + Math.max(1, gain));
        }
        if (npcClimaxProgress >= 100) {
            npcClimaxProgress  = 0;
            npcClimaxCount++;
            npcHasClimaxed     = true;
            npcFrustration     = clamp(npcFrustration - 40);  // relief
            result.npcClimaxed = true;
        } else if ((npcArousal >= 40 && !isPenetration) || npcArousal >= 90) {
            // Frustrated if aroused with no penetration, or extremely aroused regardless
            npcFrustration = clamp(npcFrustration + 5);
        }

        return result;
    }

    // ── Frustration helpers ──────────────────────────────────────

    /** Directly add to the player's frustration (clamped 0–100). */
    public void addFrustration(int amount)    { playerFrustration = clamp(playerFrustration + amount); }

    /** Zero out the player's frustration (e.g. after a satisfying climax or scene change). */
    public void clearFrustration()            { playerFrustration = 0; }

    /** True if the player is noticeably frustrated (≥ 40). */
    public boolean playerIsFrustrated()       { return playerFrustration >= 40; }

    /** True if the player is very frustrated (≥ 70). */
    public boolean playerIsVeryFrustrated()   { return playerFrustration >= 70; }

    /** True if the NPC is noticeably frustrated (≥ 40). */
    public boolean npcIsFrustrated()          { return npcFrustration >= 40; }

    // ── Convenience queries ──────────────────────────────────────

    /** True if the player is close to climaxing (progress ≥ 80). */
    public boolean playerIsClose() { return playerClimaxProgress >= 80; }

    /** True if the NPC is close to climaxing (progress ≥ 80). */
    public boolean npcIsClose()    { return npcClimaxProgress >= 80; }

    /** True if the NPC is very close (progress ≥ 90). */
    public boolean npcIsVeryClose() { return npcClimaxProgress >= 90; }

    /** True if the player is very close (progress ≥ 90). */
    public boolean playerIsVeryClose() { return playerClimaxProgress >= 90; }

    /** Rough label for how much stamina the NPC has shown so far. */
    public String npcStaminaLabel() {
        if (npcClimaxRate >= 40) return "Premature";
        if (npcClimaxRate >= 25) return "Hair Trigger";
        if (npcClimaxRate >= 14) return "Quick";
        if (npcClimaxRate >=  6) return "Average";
        if (npcClimaxRate >=  4) return "Good";
        return "Long Lasting";
    }

    // ── Internal helpers ─────────────────────────────────────────

    /** Derive NPC climax rate from their stamina trait. */
    private static int climaxRateFromNpc(NpcData npc) {
        if (npc == null || npc.traits == null) return 8;
        for (String t : npc.traits) {
            switch (t.toLowerCase()) {
                case "premature_ejaculator": return 50;
                case "hair_trigger":         return 30;
                case "quick_finish":         return 16;
                case "average_stamina":      return  8;
                case "good_stamina":         return  5;
                case "long_lasting":         return  3;
            }
        }
        return 8; // default: average
    }

    private static int clamp(int v) { return Math.max(0, Math.min(100, v)); }

    // ── Tick result ──────────────────────────────────────────────

    /** Returned by tick() to tell the caller what happened this beat. */
    public static class TickResult {
        /** True if the player climaxed this beat. */
        public boolean playerClimaxed = false;
        /** True if the NPC climaxed this beat. */
        public boolean npcClimaxed    = false;

        public boolean anyClimaxed() { return playerClimaxed || npcClimaxed; }
    }
}
// NOTE: Append block — added below class closing brace
