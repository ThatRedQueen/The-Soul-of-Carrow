package game;

import game.data.SceneData;
import org.yaml.snakeyaml.Yaml;
import java.io.*;
import java.util.*;

public class SceneLoader {
    private final String rootDir;
    private final Map<String, SceneData> cache   = new HashMap<>();
    private final Map<String, String>    modSrc  = new HashMap<>(); // sceneId → modId
    private volatile boolean loaded = false;

    public SceneLoader(String rootDir) {
        this.rootDir = rootDir;
        // Load in background so UI doesn't freeze
        Thread t = new Thread(this::preloadAll, "scene-loader");
        t.setDaemon(true);
        t.start();
    }

    private void preloadAll() {
        File root = new File(rootDir);
        if (!root.exists()) { loaded = true; return; }
        loadDir(root);
        loaded = true;
        System.out.println("[SceneLoader] Loaded " + cache.size() + " scenes.");
    }

    private void loadDir(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) loadDir(f);
            else if (f.getName().endsWith(".yml")) loadFile(f);
        }
    }

    @SuppressWarnings("unchecked")
    private void loadFile(File f) {
        try (InputStream is = new FileInputStream(f)) {
            // loadAll supports multi-document YAML (scenes separated by ---),
            // which lets one .yml file contain multiple related scenes.
            Yaml yaml = new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions()));
            for (Object doc : yaml.loadAll(is)) {
                if (!(doc instanceof Map)) continue;
                SceneData scene = parseScene((Map<String, Object>) doc);
                if (scene != null && scene.id != null && !scene.id.isEmpty()) {
                    synchronized (cache) { cache.put(scene.id, scene); }
                }
            }
        } catch (Exception e) {
            System.err.println("[SceneLoader] YAML parse error in " + f.getName() + ": " + e.getMessage());
            game.CrashReporter.reportError("YAML parse error in " + f.getAbsolutePath(), e);
        }
    }

    @SuppressWarnings("unchecked")
    private SceneData parseScene(Map<String, Object> raw) {
        SceneData s = new SceneData();
        s.id   = str(raw, "id");
        s.text           = str(raw, "text");
        s.image          = str(raw, "image");
        s.image_position = str(raw, "image_position");
        if (s.image_position == null || s.image_position.isEmpty()) s.image_position = "top";
        Object imgH = raw.get("image_height");
        if (imgH != null) { try { s.image_height = Integer.parseInt(imgH.toString()); } catch (Exception ignored) {} }

        // text_variants
        List<Map<String,Object>> variants = (List<Map<String,Object>>) raw.getOrDefault("text_variants", Collections.emptyList());
        for (Map<String,Object> v : variants) {
            SceneData.TextVariant tv = new SceneData.TextVariant();
            tv.requires_trait     = str(v, "requires_trait");
            tv.requires_flag      = str(v, "requires_flag");
            tv.requires_npc_trait = str(v, "requires_npc_trait");
            tv.text               = str(v, "text");
            s.text_variants.add(tv);
        }

        // choices
        List<Map<String,Object>> choices = (List<Map<String,Object>>) raw.getOrDefault("choices", Collections.emptyList());
        for (Map<String,Object> c : choices) {
            SceneData.ChoiceData cd = new SceneData.ChoiceData();
            cd.text        = str(c, "text");
            cd.next        = str(c, "next");
            cd.result_text = str(c, "result_text");
            cd.requires_traits  = strList(c, "requires_traits");
            cd.blocks_if_traits = strList(c, "blocks_if_traits");
            cd.requires_any_traits = strList(c, "requires_any_traits");
            cd.add_traits       = strList(c, "add_traits");
            cd.timed_traits     = strList(c, "timed_traits");
            cd.remove_traits    = strList(c, "remove_traits");
            cd.stat_changes     = intMap(c, "stat_changes");
            cd.stat_set         = intMap(c, "stat_set");
            cd.requires_npc_traits = npcTraitMap(c);
            // Flag gates
            cd.requires_flag    = strVal(c, "requires_flag",    "");
            cd.blocks_if_flag   = strVal(c, "blocks_if_flag",   "");
            // Willpower gates
            cd.min_willpower          = intVal(c, "min_willpower",          0);
            cd.max_willpower          = intVal(c, "max_willpower",         -1);
            cd.arousal_wp_drain_above = intVal(c, "arousal_wp_drain_above", 0);
            // Priority / NPC
            cd.priority      = intVal(c,  "priority",      0);
            cd.locks_others  = boolVal(c, "locks_others",  false);
            cd.npc_decides   = boolVal(c, "npc_decides",   false);
            cd.wip                = boolVal(c, "wip",                false);
            cd.show_when_locked   = boolVal(c, "show_when_locked",   false);
            cd.requires_sa_enabled = boolVal(c, "requires_sa_enabled", false);
            // NPC rep gates
            cd.min_npc_rep      = intVal(c, "min_npc_rep", 0);
            cd.rep_bypass_traits = strList(c, "rep_bypass_traits");
            // Slut rep system
            cd.slut_rep_req          = intVal(c, "slut_rep_req",          0);
            cd.slut_rep_gain         = intVal(c, "slut_rep_gain",         0);
            cd.slut_rep_gain_surprise= intVal(c, "slut_rep_gain_surprise", 0);
            // accidental: true — halves the rep gain via the surprise formula (floor × 0.5)
            // e.g. accidental: true + slut_rep_gain: 2 → surprise=2 → effective=floor(1.0)=1
            //      accidental: true + slut_rep_gain: 1 → surprise=1 → effective=floor(0.5)=0
            // Use slut_rep_gain: 2 on accidental choices to ensure at least 1 rep registers.
            if (boolVal(c, "accidental", false) && cd.slut_rep_gain > 0) {
                cd.slut_rep_gain_surprise = cd.slut_rep_gain;
                cd.slut_rep_gain = 0;
            }
            cd.slut_rep_gain_max_rep = intVal(c, "slut_rep_gain_max_rep", 0);
            cd.accidental_threshold  = intVal(c, "accidental_threshold",  0);
            cd.slut_rep_action_type  = strVal(c, "slut_rep_action_type",  "");
            cd.path_traits           = strList(c, "path_traits");
            // Additional gates
            cd.min_arousal   = intVal(c, "min_arousal",  intVal(c, "arousal_req", 0));
            cd.min_money     = intVal(c, "min_money",    0);
            cd.max_slut_rep  = intVal(c, "max_slut_rep", -1);
            cd.min_work_rep  = intVal(c, "min_work_rep",  0);
            cd.min_npc_rep_map = intMap(c, "min_npc_rep_map");
            // Clothing
            cd.min_formal_rating   = intVal(c, "min_formal_rating",   0);
            cd.min_lewdness_rating = intVal(c, "min_lewdness_rating",  0);
            cd.min_casual_rating   = intVal(c, "min_casual_rating",    0);
            cd.requires_seethrough = boolVal(c, "requires_seethrough", false);
            cd.requires_wet        = boolVal(c, "requires_wet",        false);
            cd.requires_fertile_window = boolVal(c, "requires_fertile_window", false);
            cd.requires_period         = boolVal(c, "requires_period",         false);
            cd.requires_not_period     = boolVal(c, "requires_not_period",     false);
            cd.change_outfit   = str(c, "change_outfit");
            cd.set_wet         = boolVal(c, "set_wet", false);
            cd.set_dry         = boolVal(c, "set_dry", false);
            cd.advance_cycle   = intVal(c, "advance_cycle", 0);
            cd.money_change    = intVal(c, "money_change",  0);
            cd.car_action      = strVal(c, "car_action",   "");
            s.choices.add(cd);
        }

        // possible_triggers
        List<Map<String,Object>> triggers = (List<Map<String,Object>>) raw.getOrDefault("possible_triggers", Collections.emptyList());
        for (Map<String,Object> t : triggers) {
            game.data.TriggerData td = new game.data.TriggerData();
            td.scene_id               = str(t, "scene_id");
            td.weight                 = intVal(t, "weight",             5);
            td.nothing_multiplier     = intVal(t, "nothing_multiplier", 3);
            td.requires_dynamic_trait = str(t, "requires_dynamic_trait");
            td.requires_flag          = str(t, "requires_flag");
            td.cooldown_days          = intVal(t, "cooldown_days",      0);
            td.requires_sa_enabled    = boolVal(t, "requires_sa_enabled", false);
            if (!td.scene_id.isEmpty()) s.possible_triggers.add(td);
        }

        return s;
    }

    /**
     * Load a scene by ID.
     * Returns null for special tokens (__return__, __hub__, etc.).
     * Returns a SafeScene fallback if the scene doesn't exist.
     * Waits at most 3 seconds for background loading to complete.
     */
    public SceneData load(String id) {
        return load(id, null);
    }

    public SceneData load(String id, String callerContext) {
        if (id == null || id.startsWith("__")) return null;
        // Wait for background load — HARD TIMEOUT 3 seconds
        if (!loaded) {
            long deadline = System.currentTimeMillis() + 3_000;
            while (!loaded && System.currentTimeMillis() < deadline) {
                try { Thread.sleep(25); } catch (InterruptedException ignored) {}
            }
            if (!loaded) {
                System.err.println("[SceneLoader] WARNING: 3s timeout waiting for scenes. Loaded so far: " + cache.size());
            }
        }
        synchronized (cache) {
            SceneData scene = cache.get(id);
            if (scene == null) {
                return game.SafeScene.notFound(id, callerContext);
            }
            return scene;
        }
    }

    /** Returns null instead of a fallback — for optional scene checks. */
    public SceneData tryLoad(String id) {
        if (id == null || id.startsWith("__")) return null;
        if (!loaded) {
            long deadline = System.currentTimeMillis() + 3_000;
            while (!loaded && System.currentTimeMillis() < deadline) {
                try { Thread.sleep(25); } catch (InterruptedException ignored) {}
            }
        }
        synchronized (cache) { return cache.get(id); }
    }

    /** Returns true if a scene with this ID exists. */
    public boolean exists(String id) {
        if (id == null || id.startsWith("__")) return false;
        synchronized (cache) { return cache.containsKey(id); }
    }

    /** Returns count of loaded scenes. */
    public int sceneCount() { synchronized (cache) { return cache.size(); } }

    /** All currently loaded scene IDs. */
    public Set<String> allIds() {
        synchronized (cache) { return new HashSet<>(cache.keySet()); }
    }

    /** True if scene was injected by the given mod. */
    public boolean isFromMod(String sceneId, String modId) {
        synchronized (cache) { return modId.equals(modSrc.get(sceneId)); }
    }

    /**
     * Inject a scene from a mod. Returns true on success, false if parse fails.
     * If a scene with the same ID already exists it is overwritten (mod override).
     */
    @SuppressWarnings("unchecked")
    public boolean injectModScene(java.util.Map<String, Object> raw, String modId) {
        try {
            SceneData scene = parseScene(raw);
            if (scene == null || scene.id == null || scene.id.isEmpty()) return false;
            synchronized (cache) {
                cache.put(scene.id, scene);
                modSrc.put(scene.id, modId);
            }
            return true;
        } catch (Exception e) {
            System.err.println("[SceneLoader] injectModScene failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Applies a mod patch to an existing scene.
     * The raw map must contain "patch_scene" (target scene ID) plus any of:
     *   "add_choices"       → List of choice maps appended to scene.choices
     *   "add_text_variants" → List of variant maps appended to scene.text_variants
     *
     * If the target scene doesn't exist the patch is silently skipped.
     * Returns true if the patch was applied, false otherwise.
     */
    @SuppressWarnings("unchecked")
    public boolean applyModPatch(java.util.Map<String, Object> raw, String modId) {
        if (raw == null) return false;
        String targetId = str(raw.get("patch_scene"));
        if (targetId.isEmpty()) return false;

        SceneData target;
        synchronized (cache) { target = cache.get(targetId); }
        if (target == null) {
            System.err.println("[SceneLoader] Patch from mod '" + modId
                + "' targets unknown scene: '" + targetId + "' — skipped.");
            return false;
        }

        boolean changed = false;

        // ── Append choices ─────────────────────────────────────────────────
        java.util.List<java.util.Map<String,Object>> addChoices =
            (java.util.List<java.util.Map<String,Object>>) raw.getOrDefault("add_choices",
            java.util.Collections.emptyList());
        for (java.util.Map<String,Object> cm : addChoices) {
            game.data.SceneData.ChoiceData c = parseChoice(cm);
            if (c != null) { target.choices.add(c); changed = true; }
        }

        // ── Append text_variants ───────────────────────────────────────────
        java.util.List<java.util.Map<String,Object>> addVariants =
            (java.util.List<java.util.Map<String,Object>>) raw.getOrDefault("add_text_variants",
            java.util.Collections.emptyList());
        for (java.util.Map<String,Object> vm : addVariants) {
            game.data.SceneData.TextVariant v = new game.data.SceneData.TextVariant();
            v.requires_trait = str(vm.getOrDefault("requires_trait", "default"));
            v.requires_flag  = str(vm.getOrDefault("requires_flag", ""));
            v.text           = str(vm.getOrDefault("text", "")).trim();
            if (!v.text.isEmpty()) { target.text_variants.add(v); changed = true; }
        }

        // ── Suppress rules ─────────────────────────────────────────────
        java.util.List<java.util.Map<String,Object>> suppresses =
            (java.util.List<java.util.Map<String,Object>>) raw.getOrDefault("suppress_choices",
            java.util.Collections.emptyList());
        for (java.util.Map<String,Object> sm : suppresses) {
            game.data.SceneData.SuppressRule rule = new game.data.SceneData.SuppressRule();
            rule.text_contains = str(sm.getOrDefault("text_contains", ""));
            rule.when_trait    = str(sm.getOrDefault("when_trait",    ""));
            rule.when_flag     = str(sm.getOrDefault("when_flag",     ""));
            if (!rule.text_contains.isEmpty()) {
                target.suppressRules.add(rule);
                changed = true;
            }
        }

        if (changed) {
            synchronized (cache) { modSrc.put(targetId, modSrc.getOrDefault(targetId, "") + "+" + modId); }
            System.out.println("[SceneLoader] Patch from mod '" + modId
                + "' applied to scene: '" + targetId + "'");
        }
        return changed;
    }

    public void reload() {
        synchronized (cache) { cache.clear(); }
        loaded = false;
        Thread t = new Thread(this::preloadAll, "scene-reload");
        t.setDaemon(true);
        t.start();
    }

    // ── Parsing helpers ──────────────────────────────────────────
    private String str(Map<String,Object> m, String k) {
        Object v = m.get(k); return v == null ? "" : v.toString().trim();
    }

    @SuppressWarnings("unchecked")
    private List<String> strList(Map<String,Object> m, String k) {
        Object v = m.get(k);
        if (v instanceof List) {
            List<String> out = new ArrayList<>();
            for (Object o : (List<?>) v) if (o != null) out.add(o.toString());
            return out;
        }
        return new ArrayList<>();
    }

    @SuppressWarnings("unchecked")
    private Map<String,Integer> intMap(Map<String,Object> m, String k) {
        Object v = m.get(k);
        Map<String,Integer> out = new LinkedHashMap<>();
        if (v instanceof Map) {
            for (Map.Entry<?,?> e : ((Map<?,?>)v).entrySet()) {
                if (e.getValue() != null) {
                    try { out.put(e.getKey().toString(), Integer.parseInt(e.getValue().toString())); }
                    catch (NumberFormatException ignored) {}
                }
            }
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    private Map<String,List<String>> npcTraitMap(Map<String,Object> m) {
        Object v = m.get("requires_npc_traits");
        Map<String,List<String>> out = new LinkedHashMap<>();
        if (v instanceof Map) {
            for (Map.Entry<?,?> e : ((Map<?,?>)v).entrySet()) {
                List<String> traits = new ArrayList<>();
                if (e.getValue() instanceof List)
                    for (Object o : (List<?>)e.getValue()) if (o != null) traits.add(o.toString());
                out.put(e.getKey().toString(), traits);
            }
        }
        return out;
    }

    private int intVal(Map<String,Object> m, String k, int def) {
        Object v = m.get(k);
        if (v == null) return def;
        try { return Integer.parseInt(v.toString()); } catch (NumberFormatException e) { return def; }
    }

    private String strVal(Map<String,Object> m, String k, String def) {
        Object v = m.get(k);
        return v != null ? v.toString() : def;
    }

    private boolean boolVal(Map<String,Object> m, String k, boolean def) {
        Object v = m.get(k);
        if (v == null) return def;
        return Boolean.parseBoolean(v.toString());
    }
}
