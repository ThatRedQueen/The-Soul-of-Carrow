package game;

import game.data.*;
import java.util.*;

public class Engine {
    private final GameState      state;
    private final SceneLoader    scenes;
    private final NpcLoader      npcs;
    private final ClothingLoader clothes;
    private final BarSystem      bar;
    private       GameSettings   settings = null;
    private final CafeSystem     cafe;
    private final SexSystem      sex;
    private final HairSystem     hair;
    private final JobConversationSystem jobConvo;

    public Engine(GameState state, SceneLoader scenes, NpcLoader npcs, ClothingLoader clothes) {
        this.state    = state;
        this.scenes   = scenes;
        this.npcs     = npcs;
        this.clothes  = clothes;
        this.bar      = new BarSystem(state, npcs);
        this.sex      = new SexSystem(state, npcs);
        this.cafe     = new CafeSystem(state);
        this.hair     = new HairSystem(state);
        this.jobConvo = new JobConversationSystem(npcs, state);
        bar.registerTokens(tokenHandlers);
        sex.registerTokens(tokenHandlers);
        cafe.registerTokens(tokenHandlers);
    }

    /** Call after construction to give Engine access to job data for bar filtering. */
    /** Inject settings so Engine can check content filters. */
    public void setSettings(GameSettings s) { this.settings = s; }

    /** Pass mod text pools to BarSystem and CafeSystem. */
    public void setTextPoolRegistry(TextPoolRegistry pools) {
        if (bar  != null) bar.setTextPoolRegistry(pools);
        if (cafe != null) cafe.setTextPoolRegistry(pools);
    }

    public void setJobs(game.JobLoader jobs) {
        this.bar.setJobs(jobs);
    }

    public SceneData loadCurrent() {
        if (state.currentScene == null || state.currentScene.isEmpty()) return null;
        return scenes.load(state.currentScene, "loadCurrent");
    }

    public SceneData loadScene(String id) {
        return scenes.load(id, "loadScene");
    }

    /** Returns null if not found — for optional checks. */
    public SceneData tryLoadScene(String id) {
        return scenes.tryLoad(id);
    }

    /** True if a scene with this ID exists in the loader. */
    public boolean sceneExists(String id) {
        return scenes.exists(id);
    }

    public String resolveText(SceneData scene) {
        if (scene == null) return "";
        try {
            return resolveTextInternal(scene);
        } catch (Exception e) {
            CrashReporter.reportError("resolveText failed for scene: " + scene.id, e);
            return "[Display error — see crash report]";
        }
    }

    private String resolveTextInternal(SceneData scene) {
        Set<String> dyn = state.computeDynamicTraits(clothes);

        // ── Collect ALL matching non-default variants ────────────────────
        // Then pick one at random so repeat scenes show different text
        // each visit when multiple conditions are true simultaneously.
        java.util.List<String> matches = new java.util.ArrayList<>();
        for (SceneData.TextVariant v : scene.text_variants) {
            if ("default".equalsIgnoreCase(v.requires_trait) && v.requires_flag.isEmpty()) continue;
            boolean flagMatch  = !v.requires_flag.isEmpty() && state.getBodyFlag(v.requires_flag);
            boolean traitMatch = v.requires_flag.isEmpty()
                && !v.requires_trait.isEmpty()
                && (state.hasTrait(v.requires_trait.toLowerCase())
                    || dyn.contains(v.requires_trait.toLowerCase()));
            // Check NPC trait of the current approaching NPC
            boolean npcTraitMatch = v.requires_flag.isEmpty()
                && v.requires_trait.equals("default")
                && !v.requires_npc_trait.isEmpty()
                && !state.currentApproachingNpc.isEmpty()
                && npcs.hasTrait(state.currentApproachingNpc, v.requires_npc_trait);
            if (flagMatch || traitMatch || npcTraitMatch) {
                matches.add(v.text.trim());
            }
        }
        if (!matches.isEmpty()) {
            String picked = matches.get((int)(Math.random() * matches.size()));
            return applyTextVars(picked);
        }

        // ── Fallback: default variant, then base scene text ──────────────
        for (SceneData.TextVariant v : scene.text_variants)
            if ("default".equalsIgnoreCase(v.requires_trait)) return applyTextVars(v.text.trim());
        return scene.text != null ? applyTextVars(scene.text.trim()) : "";
    } // end resolveTextInternal

    /**
     * Replaces dynamic text tokens with runtime values.
     *
     * Supported tokens:
     *   {breast_desc}  — size-appropriate breast descriptor, e.g. "soft breasts"
     *                    Rotates through a pool per cup size (varies by day).
     *
     * Add new tokens here as the system grows.
     */
    private String applyTextVars(String text) {
        if (text == null) return "";
        if (text.contains("{breast_desc}"))
            text = text.replace("{breast_desc}", state.breastDescriptor());
        // ── Dynamic text tokens — bar, café, mall subsystems ─────────────────
        for (java.util.Map.Entry<String,java.util.function.Supplier<String>> e
                : tokenHandlers.entrySet()) {
            if (text.contains(e.getKey()))
                text = text.replace(e.getKey(), applyTextVars(e.getValue().get()));
        }
        if (text.contains("{hair_breeze_text}"))
            text = text.replace("{hair_breeze_text}", hair.buildHairBreezeText());
        if (text.contains("{home_furnish_prompt}"))
            text = text.replace("{home_furnish_prompt}", buildHomeFurnishPrompt());
        if (text.contains("{npc_job_text}"))
            text = text.replace("{npc_job_text}", jobConvo.buildJobText());
        // {npc_hair_breeze_text} requires explicit args — resolved via builder call in YAML
        // Use: scene result_text calling {npc_hair_breeze_text} with hardcoded NPC hair color/type
        if (text.contains("{npc_name}") || text.contains("{npc_he}") || text.contains("{npc_him}")
         || text.contains("{npc_his}") || text.contains("{npc_He}") || text.contains("{npc_Him}")) {
            // Prefer currently approaching NPC, fall back to dating partner
            String activeNpcId = state.currentApproachingNpc;
            if (activeNpcId == null || activeNpcId.isEmpty()) {
                // Find the dating partner (first match)
                for (java.util.Map.Entry<String,String> e : state.npcMemory.entrySet()) {
                    if (e.getKey().endsWith(":relationship_status") && state.isDating(e.getKey().replace(":relationship_status",""))) {
                        activeNpcId = e.getKey().replace(":relationship_status","");
                        break;
                    }
                }
            }
            game.data.NpcData npc = npcs.get(activeNpcId);
            if (npc != null) {
                boolean male = "MALE".equalsIgnoreCase(npc.type);
                text = text.replace("{npc_name}", npc.name);
                text = text.replace("{npc_he}",  male ? "he"  : "she");
                text = text.replace("{npc_He}",  male ? "He"  : "She");
                text = text.replace("{npc_him}",  male ? "him"  : "her");
                text = text.replace("{npc_Him}",  male ? "Him"  : "Her");
                text = text.replace("{npc_his}",  male ? "his"  : "her");
                text = text.replace("{npc_His}",  male ? "His"  : "Her");
            }
        }
        return text;
    }

    /**
     * Called when a new scene loads (not on loop returns within the same scene).
     * Handles one-time setup for special scenes.
     */
    public void onSceneEnter(String sceneId) {
        // Fresh bar visit — populate NPCs and clear session stats
        if ("bar_night".equals(sceneId) && !state.currentScene.equals(sceneId)) {
            bar.populateBar();
            clearNpcSessionStats();
        }
        // Each loop back to bar_with_npc ticks NPC frustration by trait-based rate
        if ("bar_with_npc".equals(sceneId)) {
            state.hubScene = "bar_with_npc";
            state.currentNpcFrustration += bar.npcFrustrationRate();
            // At 100 frustration the NPC leaves
            if (state.currentNpcFrustration >= 100) {
                state.currentScene = "bar_npc_leaves";
                return;
            }
        }
        if ("bar_mc_home".equals(sceneId)) {
            state.hubScene = "bar_mc_home";
        }
        if ("bar_slow_dance".equals(sceneId)) {
            state.slowDanceCount++;
        }

        // ── Dance lock — drunk + enjoying = can't voluntarily stop ────────────
        // When effectiveWP < 25 AND slut_rep in "enjoy" tier:
        //   - flagDanceLocked = true → hides "End the dance" and all push-away choices
        //   - Locked for 5 bar_dance_floor visits, then auto-unlocks
        if ("bar_dance_floor".equals(sceneId) && state.currentApproachingNpc != null) {
            if (state.flagDanceLocked) {
                // Already locked — decrement counter
                state.danceLockTurns--;
                if (state.danceLockTurns <= 0) {
                    state.danceLockTurns  = 0;
                    state.flagDanceLocked = false;
                }
            } else if (bar.isDanceLocked()) {
                // Freshly locked this visit
                state.danceLockTurns  = 5;
                state.flagDanceLocked = true;
            }
        }

        // ── Transition scene injection — weighted pool, 1-in-3 chance ─────────
        // Pool: 0-10 weight per scene, null = 2× scene total → P(scene) = 1/3
        if ("bar_dance_floor".equals(sceneId)) {
            String trigger = state.usedDanceMoments.isEmpty() ? "to_dance" : "mid_dance";
            String redirect = bar.rollTransitionScene(trigger);
            if (redirect != null) {
                state.currentScene = redirect;
                return;
            }
        }
        if ("bar_pool_with_npc".equals(sceneId) && state.usedDanceMoments.isEmpty()) {
            String redirect = bar.rollTransitionScene("to_pool");
            if (redirect != null) {
                state.currentScene = redirect;
                return;
            }
        }
        // Hub loop — rare other-patron event
        if ("bar_with_npc".equals(sceneId) && state.currentNpcArousal < 20) {
            String redirect = bar.rollTransitionScene("hub_loop");
            if (redirect != null) {
                state.currentScene = redirect;
                return;
            }
        }
        // Ditching or going home — flush liking into npc_rep and clear session stats
        if ("bar_night".equals(sceneId) && state.currentScene.equals("bar_with_npc")) {
            flushNpcLiking();
            clearNpcSessionStats();
        }
    }

    /**
     * Returns the internal-monologue text shown during the dance lock loop.
     * Tone shifts based on how many turns remain.
     */
    /** Short prompt shown at end of housing arrival scenes nudging player to furnish. */
    private String buildHomeFurnishPrompt() {
        boolean hasMirror   = state.hasTrait("has_mirror");
        boolean hasTv       = state.hasTrait("has_tv");
        boolean hasDresser  = state.hasTrait("has_dresser_basic")
                           || state.hasTrait("has_dresser_nice")
                           || state.hasTrait("has_wardrobe");
        if (hasMirror && hasTv && hasDresser)
            return "The place is looking settled. You can always add more later.";
        if (!hasMirror && !hasTv && !hasDresser)
            return "You could pick up a few things — a mirror, something for your clothes, "
                 + "maybe a TV. Small improvements. They add up.";
        if (!hasMirror)
            return "A mirror would help. There's a spot that would be perfect for one.";
        if (!hasDresser)
            return "Your clothes are still in the bag. A dresser would fix that.";
        return "There are a few things that would make this feel more permanent.";
    }

    private String buildDanceLockTurnsText() {
        int turns = state.danceLockTurns;
        String d = bar.drunkTierPublic();
        if (d.equals("blackout"))
            return "*Everything is movement. You can't remember why stopping would matter.*";
        switch (turns) {
            case 5:
            case 4:
                return "*Something in you just doesn't want this to end yet. "
                     + "You tell yourself one more song.*";
            case 3:
                return "*You could stop. You're not stopping.*";
            case 2:
                return "*Soon. Just not right now.*";
            case 1:
                return "*Almost. You can feel the end of it approaching.*";
            default:
                return "*You keep moving.*";
        }
    }

    private void clearNpcSessionStats() {
        state.currentNpcFrustration = 0;
        state.currentNpcArousal     = 0;
        state.currentNpcLiking      = 0;
        state.slowDanceCount        = 0;
        state.usedDanceMoments.clear();
        state.flagBreastGroped      = false;
        state.flagAssGroped         = false;
        state.flagPussyGroped       = false;
        state.flagFingered          = false;
        state.flagKissed            = false;
        state.flagNeckKissed        = false;
        state.flagDeepKissed        = false;
        state.flagCornered          = false;  // cornered/hidden on dance floor
        state.flagNpcCame           = false;  // NPC orgasmed — affects exit text, clear per session
        state.flagCookedTonight     = false;  // 1x cook gate resets each bar session
        state.flagDanceLocked       = false;
        state.danceLockTurns        = 0;
        // flagGloryHoleUsed: cleared daily in advanceDay() — persists for morning-after
        // flagCafeJumpFlashed / flagCafeSleazyVisited: cleared daily, not per-session
    }

    /**
     * Converts accumulated liking into a small npc_rep bump.
     * Rep is intentionally hard to build — liking divides down heavily.
     * Roughly: 50 liking points = +1 npc_rep.
     */
    private void flushNpcLiking() {
        if (state.currentApproachingNpc.isEmpty()) return;
        int repGain = state.currentNpcLiking / 50;
        if (repGain > 0)
            state.changeStat("npc_rep_" + state.currentApproachingNpc, repGain);
    }

    public List<SceneData.ChoiceData> availableChoices(SceneData scene) {
        List<SceneData.ChoiceData> out = new ArrayList<>();
        for (SceneData.ChoiceData c : scene.choices) {
            if (isSuppressed(scene, c)) continue;
            // SA content filter
            if (c.requires_sa_enabled && settings != null && !settings.saContentEnabled) continue;   // mod suppress_choices rule
            if (c.wip || c.show_when_locked) {
                out.add(c);  // always include — rendered grey/disabled in UI
            } else if (visible(c)) {
                out.add(c);
            }
        }

        // ── Bar NPC eye-contact injection ─────────────────────────────
        // When in the bar_night scene, append one "Catch X's eye" choice per NPC.
        if ("bar_night".equals(scene.id)) {
            out.addAll(bar.buildEyeContactChoices());
            out.addAll(bar.buildWaveOverChoices());
        }
        if ("bar_npc_approach".equals(scene.id)) {
            out.addAll(bar.buildMcResponseChoices());
        }

        // ── Priority locking ─────────────────────────────────────────
        // If any visible choice has locks_others=true, find the highest
        // such priority and suppress all choices below it.
        int lockPriority = -1;
        for (SceneData.ChoiceData c : out)
            if (c.locks_others && c.priority > lockPriority)
                lockPriority = c.priority;
        if (lockPriority >= 0) {
            final int lp = lockPriority;
            out.removeIf(c -> c.priority < lp);
        }

        return out;
    }

    public  boolean isChoiceVisible(SceneData.ChoiceData c) { return visible(c); }
    private boolean visible(SceneData.ChoiceData c) {
        Set<String> dyn = state.computeDynamicTraits(clothes);

        // ── Hard trait gates (AND logic) ─────────────────────────────
        for (String t : c.requires_traits)
            if (!state.hasTrait(t) && !dyn.contains(t.toLowerCase())) return false;
        for (String t : c.blocks_if_traits)
            if  (state.hasTrait(t) ||  dyn.contains(t.toLowerCase())) return false;

        // ── Trauma suppresses assertive paths ────────────────────────────────────
        // Shaken/Hurt: hides Confrontational, Self_Assured, Driven paths.
        // Broken: additionally hides Outgoing, Provocative paths — MC cannot perform confidence.
        if (dyn.contains("shaken_suppresses_assertive")) {
            java.util.Set<String> suppressed = new java.util.HashSet<>(
                java.util.Arrays.asList("confrontational","self_assured","driven"));
            if (dyn.contains("broken_suppresses_all"))
                suppressed.addAll(java.util.Arrays.asList("outgoing","provocative","magnetic"));
            for (String t : c.requires_traits)
                if (suppressed.contains(t.toLowerCase())) return false;
            if (!c.requires_trait.isEmpty()
                    && suppressed.contains(c.requires_trait.toLowerCase())) return false;
        }

        // ── OR trait gate — at least one must be present ─────────────
        if (!c.requires_any_traits.isEmpty()) {
            boolean any = false;
            for (String t : c.requires_any_traits)
                if (state.hasTrait(t) || dyn.contains(t.toLowerCase())) { any = true; break; }
            if (!any) return false;
        }

        for (Map.Entry<String,List<String>> e : c.requires_npc_traits.entrySet())
            for (String t : e.getValue()) if (!npcs.hasTrait(e.getKey(), t)) return false;

        // ── Slut rep gates ───────────────────────────────────────────
        if (c.slut_rep_req > 0) {
            int effectiveReq = computeEffectiveSlutRepReq(c.slut_rep_req, c.path_traits);
            if (state.slut_rep < effectiveReq) return false;
        }
        if (c.max_slut_rep >= 0 && state.slut_rep > c.max_slut_rep) return false;

        // ── Arousal gate ─────────────────────────────────────────────
        if (c.min_arousal > 0 && state.arousal < c.min_arousal) return false;
        if (c.min_money  > 0 && state.money  < c.min_money)  return false;

        // ── Body-state flag gates ─────────────────────────────────
        if (!c.requires_flag.isEmpty()  && !state.getBodyFlag(c.requires_flag))  return false;
        if (!c.blocks_if_flag.isEmpty() &&  state.getBodyFlag(c.blocks_if_flag)) return false;
        // NPC reputation gate — passes if rep >= threshold OR NPC has a bypass trait
        if (c.min_npc_rep > 0) {
            boolean hasRep     = state.getNpcRep(state.currentApproachingNpc) >= c.min_npc_rep;
            boolean hasBypass  = c.rep_bypass_traits.stream()
                .anyMatch(t -> bar.currentNpcHasTrait(t));
            if (!hasRep && !hasBypass) return false;
        }
        // ── Willpower gate ────────────────────────────────────────────
        if (c.min_willpower > 0 || c.max_willpower >= 0 || c.arousal_wp_drain_above > 0) {
            int wp = state.effectiveWillpowerForCheck(c.arousal_wp_drain_above);
            if (c.min_willpower > 0  && wp <  c.min_willpower) return false;
            if (c.max_willpower >= 0 && wp >  c.max_willpower) return false;
        }

        // ── Work rep gate ─────────────────────────────────────────────
        if (c.min_work_rep > 0 && state.work_rep < c.min_work_rep) return false;

        // ── NPC rep gates ─────────────────────────────────────────────
        for (Map.Entry<String,Integer> e : c.min_npc_rep_map.entrySet())
            if (state.getNpcRep(e.getKey()) < e.getValue()) return false;

        // ── Willpower gate (MC sees likely harassment paths only) ──────
        // Path_Trait_MC_Sees_Likely_Harassment marks choices where MC can
        // recognise she may be harassed and assert herself. Low effective
        // willpower (drunk or baseline) disables the assertive option.
        if (c.path_traits.contains("Path_Trait_MC_Sees_Likely_Harassment")
                && state.effectiveWillpower() < 30)
            return false;

        // ── Clothing gates ────────────────────────────────────────────
        ClothingData upper = effectiveUpper();
        if (upper != null) {
            if (upper.formal_rating   < c.min_formal_rating)  return false;
            if (upper.lewdness_rating < c.min_lewdness_rating) return false;
            if (upper.casual_rating   < c.min_casual_rating)   return false;
            if (c.requires_seethrough && !upper.seethrough
                    && !(state.isWet && upper.seethrough_when_wet)) return false;
        }
        if (c.requires_wet && !state.isWet) return false;
        if (c.requires_fertile_window && !state.isFertileWindow()) return false;
        if (c.requires_period         && !state.isOnPeriod())      return false;
        if (c.requires_not_period     &&  state.isOnPeriod())      return false;
        return true;
    }

    /**
     * Rolls for STD transmission and pregnancy risk after a sex scene.
     * Called from applyChoice() when the completed scene has path_trait "Sex_Scene"
     * and choice has path_trait "Sex_Unprotected" or "Sex_Protected".
     *
     * STD rates:
     *   Unprotected — Sleazy/Jerk NPC: 10% minor, 3% serious
     *                 Outgoing/Nightlife_Lover: 5% minor, 1% serious
     *                 Other: 2% minor, 0.5% serious
     *   Protected (condom) — multiply all rates by 0.15
     *
     * Pregnancy: 15% per encounter if in fertile window and unprotected.
     */
    private void rollSexualHealthConsequences(boolean protectedSex) {
        if (state.hasTrait("STD_minor") || state.hasTrait("STD_serious")) return; // already infected

        String npcId = state.currentApproachingNpc;
        double minorRate, seriousRate;

        if (npcs.hasTrait(npcId, "Sleazy") || npcs.hasTrait(npcId, "Jerk")) {
            minorRate = 0.10; seriousRate = 0.03;
        } else if (npcs.hasTrait(npcId, "Outgoing") || npcs.hasTrait(npcId, "Nightlife_Lover")) {
            minorRate = 0.05; seriousRate = 0.01;
        } else {
            minorRate = 0.02; seriousRate = 0.005;
        }

        if (protectedSex) { minorRate *= 0.15; seriousRate *= 0.15; }

        double roll = Math.random();
        if (roll < seriousRate) {
            state.addTrait("STD_serious");
        } else if (roll < seriousRate + minorRate) {
            state.addTrait("STD_minor");
        }

        // Pregnancy risk — fertile window, unprotected
        if (!protectedSex && state.isFertileWindow() && Math.random() < 0.15) {
            state.addTrait("Pregnant_Risk"); // triggers pregnancy arc (pending implementation)
        }
    }

    /**
     * Checks mod-injected suppress rules for the current scene against a choice.
     * Called from the choice list builder — not from visible() to keep separation clean.
     * Returns true if this choice should be suppressed (hidden).
     */
    private boolean isSuppressed(SceneData scene, SceneData.ChoiceData c) {
        if (scene.suppressRules.isEmpty()) return false;
        String choiceText = c.text.toLowerCase();
        Set<String> dyn = state.computeDynamicTraits(clothes);
        for (SceneData.SuppressRule rule : scene.suppressRules) {
            if (!choiceText.contains(rule.text_contains.toLowerCase())) continue;
            // Rule matches text — check conditions
            boolean condMet = true;
            if (!rule.when_trait.isEmpty())
                condMet = state.hasTrait(rule.when_trait) || dyn.contains(rule.when_trait.toLowerCase());
            if (condMet && !rule.when_flag.isEmpty())
                condMet = state.getBodyFlag(rule.when_flag);
            if (condMet) return true;
        }
        return false;
    }

    /**
     * Computes the effective slut_rep requirement after applying path_trait modifiers.
     *
     * Modifier convention:
     *   Positive multiplier (e.g. 1.5) = harder — req * 1.5
     *   Negative multiplier (e.g. -1.5) = easier — req / 1.5
     * Multiple path_traits stack multiplicatively.
     */
    /**
     * Bonus applied to slut_rep_gain_max_rep based on exhibitionist/shy traits.
     * Max +4 for strong exhibitionist tendencies, up to -4 for strong aversion.
     * Applied per-choice based on which path traits the choice is tagged with.
     */
    private int slutRepGainCeilingBonus(List<String> pathTraits) {
        // Find the most relevant exhibitionist trait for this choice's context
        boolean lowRisk  = pathTraits.contains("Path_Trait_Low_Risk_Exhibitionist");
        boolean highRisk = pathTraits.contains("Path_Trait_High_Risk_Exhibitionist");
        boolean watched  = pathTraits.contains("Path_Trait_Watched_Exhibitionist");

        if (!lowRisk && !highRisk && !watched) return 0;

        if (state.hasTrait("Loves_Being_Watched"))         return 4;
        if (state.hasTrait("Risky_Exhibitionist"))         return watched ? 3 : 2;
        if (state.hasTrait("Secret_Exhibitionist"))        return lowRisk ? 3 : (highRisk ? 1 : 0);
        if (state.hasTrait("Likes_Being_Watched"))         return 2;
        if (state.hasTrait("Hates_Being_Watched"))         return -4;
        if (state.hasTrait("Uncomfortable_Being_Watched")) return watched ? -3 : -1;
        if (state.hasTrait("Shy"))                         return -2;
        return 0;
    }

    private int computeEffectiveSlutRepReq(int baseReq, List<String> pathTraits) {
        double modifier = 1.0;
        for (String pt : pathTraits) {
            modifier *= pathTraitModifier(pt);
        }
        // Modifier < 1 = easier, > 1 = harder
        int result = (int) Math.round(baseReq * modifier);
        return Math.max(0, result);
    }

    private double pathTraitModifier(String pathTrait) {
        switch (pathTrait) {
            case "Path_Trait_Public": {
                if (state.hasTrait("Shy"))           return 1.5;
                if (state.hasTrait("Fragile_Ego"))   return 1.25;
                if (state.hasTrait("Outgoing"))      return 1.0 / 1.5;   // ×-1.5 = easier
                if (state.hasTrait("Magnetic"))      return 1.0 / 1.25;  // ×-1.25 = easier
                // Self_Assured, Antisocial = no modifier
                return 1.0;
            }
            case "Path_Trait_Public_Exhibitionist": {
                if (state.hasTrait("Hates_Being_Watched"))           return 2.0;
                if (state.hasTrait("Uncomfortable_Being_Watched"))   return 1.5;
                if (state.hasTrait("Secret_Exhibitionist") ||
                    state.hasTrait("Risky_Exhibitionist"))           return 1.5;
                if (state.hasTrait("Loves_Being_Watched"))           return 1.0 / 2.0;  // ×-2
                if (state.hasTrait("Likes_Being_Watched"))           return 1.0 / 1.5;  // ×-1.5
                // Neutral_On_Exhibitionism = no modifier
                return 1.0;
            }
            case "Path_Trait_Low_Risk_Exhibitionist": {
                // Low-risk flash: hidden/empty space, very unlikely to be seen
                // Secret exhibitionists love this — feels thrilling but safe
                if (state.hasTrait("Hates_Being_Watched"))          return 1.5;
                if (state.hasTrait("Secret_Exhibitionist"))         return 1.0 / 2.0;  // half req
                if (state.hasTrait("Risky_Exhibitionist"))          return 1.0 / 1.5;
                if (state.hasTrait("Shy"))                          return 1.25;
                return 1.0;
            }
            case "Path_Trait_High_Risk_Exhibitionist": {
                // High-risk flash: crowd around, real chance of being seen
                if (state.hasTrait("Hates_Being_Watched"))          return 2.0;
                if (state.hasTrait("Uncomfortable_Being_Watched"))  return 1.5;
                if (state.hasTrait("Shy"))                          return 1.5;
                if (state.hasTrait("Risky_Exhibitionist"))          return 1.0 / 1.5;
                if (state.hasTrait("Loves_Being_Watched"))          return 1.0 / 1.5;
                if (state.hasTrait("Secret_Exhibitionist"))         return 1.0 / 1.25;
                return 1.0;
            }
            case "Path_Trait_Watched_Exhibitionist": {
                // Watched flash: deliberate, someone is actively looking
                if (state.hasTrait("Hates_Being_Watched"))          return 3.0;
                if (state.hasTrait("Uncomfortable_Being_Watched"))  return 2.0;
                if (state.hasTrait("Shy"))                          return 2.0;
                if (state.hasTrait("Loves_Being_Watched"))          return 1.0 / 2.0;  // half req
                if (state.hasTrait("Likes_Being_Watched"))          return 1.0 / 1.5;
                if (state.hasTrait("Risky_Exhibitionist"))          return 1.0 / 1.25;
                return 1.0;
            }
            // Path_Trait_MC_Sees_Likely_Harassment has no slut_rep modifier —
            // handled separately via effectiveWillpower() gate
            default:
                return 1.0;
        }
    }

    public String applyChoice(SceneData.ChoiceData c) {
        for (Map.Entry<String,Integer> e : c.stat_changes.entrySet()) state.changeStat(e.getKey(), e.getValue());
        for (Map.Entry<String,Integer> e : c.stat_set.entrySet())     state.setStat(e.getKey(), e.getValue());
        // Apply timed traits (format "TraitName:days")
        // NOTE: these go ONLY into timedTraits — NOT into the permanent traits Set.
        // hasTrait() checks both, so gating still works. On expiry they vanish cleanly.
        for (String entry : c.timed_traits) {
            int colon = entry.lastIndexOf(':');
            if (colon > 0) {
                String traitName = entry.substring(0, colon).trim().toLowerCase();
                int days = 1;
                try { days = Integer.parseInt(entry.substring(colon+1).trim()); } catch (Exception ignored) {}
                // Put in timedTraits only — not permanent traits
                state.timedTraits.put(traitName, state.dayCount + days);
            } else {
                state.addTrait(entry); // no duration → permanent
            }
        }
        for (String t : c.add_traits) {
            if (t.startsWith("_bar_approach_")) {
                state.currentApproachingNpc = t.substring("_bar_approach_".length());
            } else if (t.equals("_clear_starting_outfits")) {
                state.startingOutfitsOnly = false;
            } else if (t.startsWith("owns_")) {
                // owns_tank_top → adds "tank_top" to ownedClothing so OutfitPanel can show it
                // Non-clothing owns_* (owns_condoms etc) just add the trait
                String itemId = t.substring("owns_".length());
                if (!itemId.equals("condoms")) {
                    state.ownedClothing.add(itemId);
                    state.startingOutfitsOnly = false;
                }
                state.addTrait(t); // keep trait for gate checks
            } else if (t.equals("_quit_job")) {
                state.quitJob();
            } else if (t.equals("_fire_player")) {
                state.fireFromJob();
            } else if (t.equals("_npc_trauma_current")) {
                // Adds a permanent NPC-specific trauma link for the currently approaching NPC.
                // npc_trauma_{npc_id} — never removed, persists across saves.
                // npc_trauma_timer_{npc_id} — timed, lasts for the combined duration of all
                //   active trauma tiers at the moment of trauma infliction.
                //   While active: intense scared reactions fire.
                //   After expiry: only the permanent mild residual reaction fires.
                String traumaNpcId = state.currentApproachingNpc;
                if (!traumaNpcId.isEmpty()) {
                    state.addTrait("npc_trauma_" + traumaNpcId);
                    // Timer = combined days remaining across all active trauma tiers
                    int timerDays = 0;
                    for (String tier : new String[]{"Broken","Shaken","Hurt","Rattled"})
                        timerDays += state.getTimedTraitDaysLeft(tier);
                    if (timerDays < 1) timerDays = 3; // floor: at least 3 days
                    state.addTimedTrait("npc_trauma_timer_" + traumaNpcId, timerDays);
                }
            // ── Relationship status handlers ──────────────────────────────────
            // ── Location discovery ───────────────────────────────────────
            } else if (t.startsWith("_discover_loc_")) {
                state.discoverLocation(t.substring("_discover_loc_".length()));
            // ── Neighbourhood tracking ────────────────────────────────────
            } else if (t.startsWith("_set_neighbourhood_")) {
                state.currentNeighbourhood = t.substring("_set_neighbourhood_".length()).replace('_',' ');
            // ── Work mode rep/promo trait shorthands ──────────────────────
            } else if (t.startsWith("_add_promo_")) {
                try {
                    int pts = Integer.parseInt(t.substring("_add_promo_".length()));
                    state.applyPromotionGain(pts);
                } catch (NumberFormatException ignored) {}
            } else if (t.startsWith("_rep_penalty_")) {
                try {
                    int pts = Integer.parseInt(t.substring("_rep_penalty_".length()));
                    state.applyOfficeRepGain(-pts);
                } catch (NumberFormatException ignored) {}
            } else if (t.equals("_start_dating_npc")) {
                if (state.currentApproachingNpc != null && !state.currentApproachingNpc.isEmpty())
                    state.setRelationshipStatus(state.currentApproachingNpc, "dating");
            } else if (t.equals("_end_relationship_npc")) {
                if (state.currentApproachingNpc != null && !state.currentApproachingNpc.isEmpty())
                    state.setRelationshipStatus(state.currentApproachingNpc, "");
            } else if (t.equals("_open_relationship_npc")) {
                if (state.currentApproachingNpc != null && !state.currentApproachingNpc.isEmpty())
                    state.setRelationshipStatus(state.currentApproachingNpc, "open_relationship");
            } else if (t.equals("_fwb_npc")) {
                if (state.currentApproachingNpc != null && !state.currentApproachingNpc.isEmpty())
                    state.setRelationshipStatus(state.currentApproachingNpc, "friends_with_benefits");
            } else if (t.startsWith("_apply_raise_")) {
                // Format: _apply_raise_15 → adds 15/day to payPerDayBonus
                try {
                    int amt = Integer.parseInt(t.substring("_apply_raise_".length()));
                    state.applyRaise(amt);
                } catch (NumberFormatException ignored) {}
            } else if (t.startsWith("_set_housing_")) {
                String payload = t.substring("_set_housing_".length());
                int lastUs = payload.lastIndexOf('_');
                if (lastUs >= 0) {
                    state.currentLandlordNpc = payload.substring(0, lastUs);
                    try { state.rent = Integer.parseInt(payload.substring(lastUs + 1)); }
                    catch (NumberFormatException ignored) {}
                }
                state.removeTrait("sleeping_on_floor");
            } else {
                state.addTrait(t);
            }
        }
        for (String t : c.remove_traits) {
            if (t.startsWith("owns_")) {
                // Clothing item loss — track for auto-rebuy
                state.loseClothingItem(t.substring("owns_".length()));
                state.removeTrait(t);
            } else {
                state.removeTrait(t);
            }
        }
        if (c.money_change != 0) state.money += c.money_change;

        // ── Slut rep gain — diminishing returns + lifetime cap by action type ──
        int rawGain     = c.slut_rep_gain;
        int surpriseRaw = c.slut_rep_gain_surprise;

        // Per-choice rep ceiling: if current rep >= max_rep, this action gives nothing
        // Trait modifiers can raise the ceiling by up to +4 for exhibitionist tendencies
        if (c.slut_rep_gain_max_rep > 0) {
            int effectiveCap = c.slut_rep_gain_max_rep + slutRepGainCeilingBonus(c.path_traits);
            if (state.slut_rep >= effectiveCap) {
                rawGain     = 0;
                surpriseRaw = 0;
            }
        }

        // Surprise gain = 50% of face value (floor — so raw 2 → 1, raw 1 → 0)
        // Proximity bonus: if accidental_threshold set and MC is well below it,
        // multiply surprise raw before flooring — more rep when exposure is far
        // outside her comfort zone.
        //   rep < threshold/3  → ×2  (way below: +2 from a normal +1 base)
        //   rep < threshold×⅔  → ×1  (below threshold: no bonus, normal half-rep)
        //   rep ≥ threshold     → ×½  (at or above: old hat, quarter-rep effective)
        if (surpriseRaw > 0 && c.accidental_threshold > 0) {
            int thresh = c.accidental_threshold;
            if      (state.slut_rep < thresh / 3)  surpriseRaw *= 2;
            else if (state.slut_rep >= thresh)      surpriseRaw = Math.max(0, surpriseRaw / 2);
        }
        int effectiveSurprise = (int) Math.floor(surpriseRaw * 0.5);

        int totalRaw = rawGain + effectiveSurprise;

        if (totalRaw > 0) {
            // Infer action type from path_traits if not explicit
            String actionType = c.slut_rep_action_type;
            if (actionType.isEmpty()) {
                boolean pub = c.path_traits.contains("Path_Trait_Public_Exhibitionist");
                boolean low = c.path_traits.contains("Path_Trait_Low_Risk_Exhibitionist");
                boolean har = c.path_traits.contains("Path_Trait_MC_Sees_Likely_Harassment");
                if      (har)        actionType = "public_act";
                else if (pub && low) actionType = "high_risk_flash";
                else if (pub)        actionType = "watched_flash";
                else if (low)        actionType = "low_risk_flash";
                else                 actionType = "public_act";
            }

            // Apply diminishing returns + lifetime cap per action type
            int gain = state.applySlutRepEarned(actionType, totalRaw);

            // Scene cap: max +2 per scene total
            int sceneRemaining = 2 - state.slutRepGainedThisScene;
            gain = Math.min(gain, Math.max(0, sceneRemaining));

            // Daily cap: max +5 per day across all scenes
            int dayRemaining = GameState.SLUT_REP_DAILY_CAP - state.slutRepGainedToday;
            gain = Math.min(gain, Math.max(0, dayRemaining));

            if (gain > 0) {
                state.slut_rep = Math.min(100, state.slut_rep + gain);
                state.slutRepGainedThisScene += gain;
                state.slutRepGainedToday     += gain;
            }
        }

        if (c.change_outfit != null && !c.change_outfit.isEmpty()) {
            ClothingData item = clothes.get(c.change_outfit);
            if (item != null) {
                switch (item.slot) {
                    case "upper":     state.outfitUpper     = c.change_outfit; break;
                    case "lower":     state.outfitLower     = c.change_outfit; break;
                    case "overcoat":  state.outfitOvercoat  = c.change_outfit; break;
                    case "bra":       state.outfitBra       = c.change_outfit; break;
                    case "underwear": state.outfitUnderwear = c.change_outfit; break;
                    case "socks":     state.outfitSocks     = c.change_outfit; break;
                    case "shoes":     state.outfitShoes     = c.change_outfit; break;
                }
            }
        }
        if (c.set_wet) state.isWet = true;
        if (c.set_dry) state.isWet = false;
        if (c.advance_cycle > 0) state.advanceCycle(c.advance_cycle);
        state.visitedScenes.add(state.currentScene);
        if (c.npc_decides) {
            state.currentScene = bar.rollNpcDecision();
        } else if ("__return__".equals(c.next)) {
            state.currentScene = null;  // signals ScenePanel to call onSceneComplete
        } else if ("__hub__".equals(c.next)) {
            state.currentScene = state.hubScene;  // returns to whichever hub opened this submenu
        } else if (c.next != null && !c.next.isEmpty()) {
            state.currentScene = c.next;
        }
        return c.result_text != null ? applyTextVars(c.result_text.trim()) : "";
    }

    /** Effective upper garment — overcoat > upper */
    public ClothingData effectiveUpper() {
        if (state.outfitOvercoat != null) return clothes.get(state.outfitOvercoat);
        return clothes.get(state.outfitUpper);
    }

    /** Effective lower garment — overcoat covers lower too; fills_lower dress covers lower */
    public ClothingData effectiveLower() {
        if (state.outfitOvercoat != null) return clothes.get(state.outfitOvercoat);
        if (state.outfitLower != null)    return clothes.get(state.outfitLower);
        if (state.outfitUpper != null) {
            ClothingData upper = clothes.get(state.outfitUpper);
            if (upper != null && upper.fills_lower) return upper;
        }
        return null;
    }

    /**
     * Weighted trigger resolution — same mechanic as work scene selection.
     *
     * Collects all triggers, sums their weights, rolls against
     * total_weight × nothing_multiplier. If the roll falls in a scene's
     * weight band, that scene fires. Otherwise nothing happens.
     *
     * When triggers have mixed nothing_multipliers, the pool uses the
     * minimum (most likely to fire something), giving urgent events
     * (×2) priority over standard events (×3).
     *
     * @param triggers  list of candidate TriggerData
     * @return          scene ID to fire, or null if nothing fires
     */
    public String resolveTriggers(java.util.List<game.data.TriggerData> triggers) {
        if (triggers == null || triggers.isEmpty()) return null;

        // Filter: only include triggers whose clothing/dynamic gate is satisfied
        // and whose cooldown (if any) has expired
        java.util.Set<String> dynamicTraits = state.computeDynamicTraits(clothes);
        java.util.List<game.data.TriggerData> eligible = new java.util.ArrayList<>();
        for (game.data.TriggerData t : triggers) {
            if (t.requires_dynamic_trait != null && !t.requires_dynamic_trait.isEmpty()) {
                if (!dynamicTraits.contains(t.requires_dynamic_trait.toLowerCase())) continue;
            }
            if (t.requires_flag != null && !t.requires_flag.isEmpty()) {
                if (!state.getBodyFlag(t.requires_flag)) continue;
            }
            // Cooldown check: skip if scene fired recently
            if (t.cooldown_days > 0 && !t.scene_id.isEmpty()) {
                Integer lastDay = state.sceneLastPlayedDay.get(t.scene_id);
                if (lastDay != null && (state.dayCount - lastDay) < t.cooldown_days) continue;
            }
            // SA content filter: skip SA-tagged triggers if player has disabled SA content
            if (t.requires_sa_enabled && settings != null && !settings.saContentEnabled) continue;
            eligible.add(t);
        }
        if (eligible.isEmpty()) return null;

        int totalWeight = 0;
        int nothingMult = Integer.MAX_VALUE;
        for (game.data.TriggerData t : eligible) {
            totalWeight += t.weight;
            nothingMult  = Math.min(nothingMult, t.nothing_multiplier);
        }
        if (nothingMult == Integer.MAX_VALUE) nothingMult = 3;

        int rollMax = totalWeight * nothingMult;
        int roll    = (int)(Math.random() * rollMax) + 1;

        if (roll > totalWeight) return null;

        int cursor = 0;
        for (game.data.TriggerData t : eligible) {
            cursor += t.weight;
            if (roll <= cursor) {
                // Record the play day for cooldown tracking
                if (t.cooldown_days > 0 && !t.scene_id.isEmpty()) {
                    state.sceneLastPlayedDay.put(t.scene_id, state.dayCount);
                }
                return t.scene_id;
            }
        }
        return null;
    }
}
