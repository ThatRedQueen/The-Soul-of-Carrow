package game;

import game.ArtworkHookManager;
import game.AudioManager;
import game.TextPoolRegistry;
import game.data.TraitCategoryData;
import game.ui.GameWindow;
import javax.swing.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        String base = System.getProperty("user.dir");

        GameSettings    settings        = new GameSettings();
        SettingsManager settingsMgr     = new SettingsManager(base, settings);
        settingsMgr.load();

        GameState       state           = new GameState();
        state.settings = settings; // inject multipliers
        // Install crash reporter FIRST — catches everything from this point on
        CrashReporter.install(base, state);
        // Starting conditions — floor mattress, bare apartment, 2 outfits
        state.addTrait("sleeping_on_floor");
        SceneLoader    sceneLoader    = new SceneLoader(base + "/scenes");
        NpcLoader      npcLoader      = new NpcLoader();
        ClothingLoader clothingLoader = new ClothingLoader();
        ActivityLoader activityLoader = new ActivityLoader();
        JobLoader      jobLoader      = new JobLoader();
        InterviewLoader interviewLoader = new InterviewLoader();

        npcLoader.loadAll(base + "/npcs");
        clothingLoader.loadAll(base + "/clothes");
        activityLoader.loadAll(base + "/activities");
        GameState.loadTaxes(base + "/gamedata");
        GameState.loadSeasons(base + "/gamedata");
        GameState.loadNeighbourhoods(base + "/gamedata");
        jobLoader.loadAll(base + "/jobs");
        HousingLoader housingLoader = new HousingLoader();
        housingLoader.loadAll(base + "/housing");
        interviewLoader.loadAll(base + "/interviews");

        List<TraitCategoryData> traitCats = TraitLoader.load(base + "/gamedata/traits.yml");
        Engine engine = new Engine(state, sceneLoader, npcLoader, clothingLoader);
        engine.setJobs(jobLoader); // gives bar system access to boss/coworker data for 5% filter

        try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
        catch (Exception ignored) {}

        // Load mods AFTER base loaders are ready — mods inject into existing loaders
        // Core mod support managers
        AssetManager      assetManager   = new AssetManager();
        ArtworkHookManager artworkManager = new ArtworkHookManager();
        artworkManager.setAssetManager(assetManager);
        AudioManager      audioManager   = new AudioManager();
        TextPoolRegistry  textPools      = new TextPoolRegistry();

        // ModSettings: persist enable/disable state across sessions
        game.mod.ModSettings modSettings = new game.mod.ModSettings(base);

        game.mod.ModLoader modLoader = new game.mod.ModLoader(base, sceneLoader, npcLoader, clothingLoader, jobLoader);
        modLoader.setModSettings(modSettings);
        modLoader.setAssetManager(assetManager);
        modLoader.setArtworkManager(artworkManager);
        modLoader.setAudioManager(audioManager);
        modLoader.setTextPoolRegistry(textPools);
        modLoader.loadAll();

        // Connect text pool registry to BarSystem so mod prose entries are picked
        engine.setTextPoolRegistry(textPools);

        game.SaveManager saveManager = new game.SaveManager(base, state);
        CrashReporter.setSaveManager(saveManager);
        CrashReporter.setAudioManager(audioManager);

        SwingUtilities.invokeLater(() -> {
            GameWindow w = new GameWindow(state, sceneLoader, npcLoader, engine,
                                          activityLoader, jobLoader, interviewLoader,
                                          clothingLoader, traitCats, assetManager,
                                          artworkManager, audioManager, textPools,
                                          modSettings);
            w.setVisible(true);
            w.showMainMenu(modLoader, saveManager, settingsMgr);
        });
    }
}
