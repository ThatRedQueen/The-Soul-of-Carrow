package game;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Global registry of named text pools.
 *
 * BarSystem, CafeSystem, and other prose systems contribute base entries.
 * Mods inject additional entries or suppress existing ones.
 *
 * POOL NAMING CONVENTION
 * ─────────────────────────────────────────────────────────────────────────────
 * Format:  system.context.subcontext
 *
 * Examples:
 *   bar.slow_dance.shy               – shy NPC slow dance prose
 *   bar.grope.breast.shy_mc          – breast grope, shy MC reaction
 *   bar.grope.breast.enjoy_mc        – breast grope, enjoying MC reaction
 *   bar.kiss.neck                    – neck kiss prose
 *   bar.npc_approach.sleazy          – Sleazy NPC approach lines
 *   bar.dirty_whisper.jerk           – Jerk NPC whisper lines
 *   cafe.top_shelf.stretch           – café shelf-reach prose
 *   scene.morning_routine            – morning routine text variants
 *
 * TEXT ENTRY FORMAT
 * ─────────────────────────────────────────────────────────────────────────────
 * Each entry is a {@link TextEntry} with:
 *   id       (optional) – stable identifier for suppression targeting
 *   text     – the prose string (may contain {npc_name} etc. tokens)
 *   weight   – selection weight (default 1); higher = more likely
 *   requires – list of traits/flags that must be present for this entry to qualify
 *   blocks   – list of traits/flags that must NOT be present
 */
public class TextPoolRegistry {

    /** A single entry in a text pool. */
    public static class TextEntry {
        public final String       id;
        public final String       text;
        public final int          weight;
        public final List<String> requires;   // traits/flags all required (AND)
        public final List<String> blocks;     // traits/flags any present = skip

        public TextEntry(String id, String text, int weight,
                         List<String> requires, List<String> blocks) {
            this.id       = id != null ? id : "";
            this.text     = text != null ? text : "";
            this.weight   = Math.max(1, weight);
            this.requires = requires != null ? Collections.unmodifiableList(requires) : Collections.emptyList();
            this.blocks   = blocks   != null ? Collections.unmodifiableList(blocks)   : Collections.emptyList();
        }

        public TextEntry(String text) { this("", text, 1, null, null); }
    }

    // pool name → ordered list of entries
    private final Map<String, List<TextEntry>> pools      = new ConcurrentHashMap<>();
    // suppressed entry IDs — entries with these IDs are skipped during selection
    private final Set<String>                  suppressed = ConcurrentHashMap.newKeySet();

    // ── Registration ──────────────────────────────────────────────────────────

    /** Register a single text entry into the named pool. */
    public void add(String poolName, TextEntry entry) {
        pools.computeIfAbsent(poolName, k -> Collections.synchronizedList(new ArrayList<>()))
             .add(entry);
    }

    /** Register a plain text string (id auto-generated, weight 1, no gates). */
    public void add(String poolName, String text) {
        add(poolName, new TextEntry(text));
    }

    /** Register multiple strings at once. */
    public void addAll(String poolName, List<String> texts) {
        texts.forEach(t -> add(poolName, t));
    }

    /**
     * Register entries from a mod YAML list.
     * Each item can be a String or a Map with keys: text, id, weight, requires, blocks.
     */
    @SuppressWarnings("unchecked")
    public void addFromYaml(String poolName, List<?> yamlList) {
        if (yamlList == null) return;
        for (Object item : yamlList) {
            if (item instanceof String) {
                add(poolName, (String) item);
            } else if (item instanceof Map) {
                Map<?,?> m = (Map<?,?>) item;
                String id   = str(m, "id");
                String text = str(m, "text");
                if (text.isEmpty()) continue;
                int weight  = intVal(m, "weight", 1);
                List<String> req = strList(m, "requires");
                List<String> blk = strList(m, "blocks");
                add(poolName, new TextEntry(id, text, weight, req, blk));
            }
        }
    }

    // ── Suppression ───────────────────────────────────────────────────────────

    /** Suppress an entry by stable ID. Has no effect if ID not present. */
    public void suppress(String entryId) {
        if (entryId != null && !entryId.isEmpty()) suppressed.add(entryId);
    }

    /** Suppress a list of entry IDs. */
    public void suppressAll(List<String> ids) {
        if (ids != null) ids.forEach(this::suppress);
    }

    // ── Selection ─────────────────────────────────────────────────────────────

    /**
     * Pick a random qualifying entry from the named pool.
     * Entries are filtered by suppression list and any requires/blocks gates
     * (gates checked against the provided trait/flag set).
     *
     * Returns null if the pool is empty or no entry qualifies.
     */
    public String pick(String poolName, Set<String> activeTraits, java.util.Random rng) {
        List<TextEntry> pool = pools.get(poolName);
        if (pool == null || pool.isEmpty()) return null;

        // Build weighted candidate list
        List<TextEntry> candidates = new ArrayList<>();
        int totalWeight = 0;
        for (TextEntry e : pool) {
            if (!e.id.isEmpty() && suppressed.contains(e.id)) continue;
            if (!qualifies(e, activeTraits)) continue;
            candidates.add(e);
            totalWeight += e.weight;
        }
        if (candidates.isEmpty()) return null;

        // Weighted random selection
        int roll = rng.nextInt(totalWeight);
        int cum  = 0;
        for (TextEntry e : candidates) {
            cum += e.weight;
            if (roll < cum) return e.text;
        }
        return candidates.get(candidates.size()-1).text;
    }

    /** Pick without gate checking (simpler call for systems that don't use trait gates). */
    public String pick(String poolName, java.util.Random rng) {
        return pick(poolName, Collections.emptySet(), rng);
    }

    /** Return all entries in a pool (including suppressed). Useful for debugging. */
    public List<TextEntry> getAll(String poolName) {
        List<TextEntry> pool = pools.get(poolName);
        return pool != null ? Collections.unmodifiableList(pool) : Collections.emptyList();
    }

    /** Number of entries across all pools. */
    public int totalEntryCount() {
        return pools.values().stream().mapToInt(List::size).sum();
    }

    public Set<String> poolNames() { return Collections.unmodifiableSet(pools.keySet()); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private boolean qualifies(TextEntry e, Set<String> active) {
        for (String req : e.requires)
            if (!active.contains(req.toLowerCase())) return false;
        for (String blk : e.blocks)
            if (active.contains(blk.toLowerCase())) return false;
        return true;
    }

    private String str(Map<?,?> m, String key) {
        Object v = m.get(key); return v == null ? "" : v.toString().trim();
    }
    private int intVal(Map<?,?> m, String key, int def) {
        Object v = m.get(key);
        if (v == null) return def;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return def; }
    }
    @SuppressWarnings("unchecked")
    private List<String> strList(Map<?,?> m, String key) {
        Object v = m.get(key);
        if (v instanceof List) {
            List<String> out = new ArrayList<>();
            for (Object o : (List<?>) v) if (o != null) out.add(o.toString());
            return out;
        }
        return Collections.emptyList();
    }
}
