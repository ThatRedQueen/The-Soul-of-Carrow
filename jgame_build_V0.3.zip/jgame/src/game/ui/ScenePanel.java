package game.ui;

import game.*;
import game.data.SceneData;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

public class ScenePanel extends JPanel {

    private final Engine         engine;
    private final GameState      state;
    private final ClothingLoader clothes;
    private final Consumer<Void> onChange;
    private Runnable             onSceneComplete;
    private game.GameSettings    settings; // optional — null = normal mode
    private AssetManager         assetManager;     // null = no mod images
    private ArtworkHookManager   artworkManager;   // null = no artwork hooks
    private AudioManager         audioManager;     // null = no soundtrack

    private final JTextArea textArea;
    private       JLabel    sceneImageLabel = null;   // null when no image active
    private       JPanel    imageWrapper    = null;
    private final JPanel    choicesPanel;

    // Track dynamic traits snapshot — detect mid-scene changes
    private java.util.Set<String> lastDynamicTraits = new java.util.HashSet<>();

    public ScenePanel(Engine engine, GameState state, ClothingLoader clothes, Consumer<Void> onChange) {
        this.engine   = engine;
        this.state    = state;
        this.clothes  = clothes;
        this.onChange = onChange;
        setBackground(Colors.BG);
        setLayout(new BorderLayout());

        textArea = new JTextArea();
        textArea.setEditable(false); textArea.setOpaque(false);
        textArea.setForeground(Colors.TEXT);
        textArea.setFont(settings != null
            ? new Font(settings.fontFamily, Font.PLAIN, settings.textSize)
            : new Font("Georgia", Font.PLAIN, 18)); // fallback if settings not yet injected
        textArea.setLineWrap(true); textArea.setWrapStyleWord(true);
        textArea.setBorder(BorderFactory.createEmptyBorder(30, 44, 20, 44));

        JScrollPane scroll = new JScrollPane(textArea);
        scroll.setOpaque(false); scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        choicesPanel = new JPanel();
        choicesPanel.setOpaque(false);
        choicesPanel.setLayout(new BoxLayout(choicesPanel, BoxLayout.Y_AXIS));
        choicesPanel.setBorder(BorderFactory.createEmptyBorder(8, 44, 28, 44));

        add(scroll,       BorderLayout.CENTER);
        add(choicesPanel, BorderLayout.SOUTH);
    }

    public void setOnSceneComplete(Runnable r) { this.onSceneComplete = r; }
    public void setAssetManager(AssetManager am)       { this.assetManager   = am; }
    public void setArtworkManager(ArtworkHookManager am) { this.artworkManager = am; }
    public void setAudioManager(AudioManager am)         { this.audioManager   = am; }
    public void setSettings(game.GameSettings s) {
        this.settings = s;
        if (s != null && textArea != null)
            textArea.setFont(new Font(s.fontFamily, Font.PLAIN, s.textSize));
    }



    public void showCurrentScene() {
        // Null guard — if no current scene, complete immediately
        if (state.currentScene == null || state.currentScene.isEmpty()
                || state.currentScene.startsWith("__")) {
            if (onSceneComplete != null) onSceneComplete.run();
            return;
        }
        SceneData scene;
        try {
            scene = engine.loadCurrent();
        } catch (Exception e) {
            game.CrashReporter.reportError("Failed to load scene: " + state.currentScene, e);
            if (onSceneComplete != null) onSceneComplete.run();
            return;
        }
        if (scene == null) {
            if (onSceneComplete != null) onSceneComplete.run();
            return;
        }
        engine.onSceneEnter(state.currentScene);
        // Snapshot current dynamic traits for mid-scene comparison
        lastDynamicTraits = new java.util.HashSet<>(state.computeDynamicTraits(clothes));
        textArea.setForeground(Colors.TEXT);
        textArea.setText(engine.resolveText(scene));
        textArea.setCaretPosition(0);
        // 1. Scene-specific image (from scene YAML image: field)
        // 2. Artwork hook image (from mod artwork.yml, state-driven)
        // Scene image takes priority if set; hooks fire when scene has no image
        if (scene.image != null && !scene.image.isEmpty()) {
            updateSceneImage(scene.image, scene.image_position, scene.image_height);
        } else {
            updateFromArtworkHook(state.currentScene);
        }
        // Update audio
        if (audioManager != null) {
            Set<String> activeFlags = buildActiveFlagSet();
            audioManager.update(activeFlags, state.currentScene);
        }
        buildChoices(engine.availableChoices(scene));
    }

    private void buildChoices(List<SceneData.ChoiceData> choices) {
        choicesPanel.removeAll();
        if (choices.isEmpty() && onSceneComplete != null) {
            // No choices — add a "Continue" button that returns to day planner
            JButton cont = makeBtn("Continue →");
            cont.addActionListener(e -> onSceneComplete.run());
            choicesPanel.add(Box.createVerticalStrut(7));
            choicesPanel.add(cont);
        } else {
            for (SceneData.ChoiceData choice : choices) {
                boolean isWip    = choice.wip;
                boolean isLocked = !isWip && (choice.show_when_locked && !engine.isChoiceVisible(choice));
                JButton btn = isWip || isLocked
                            ? makeGreyBtn(isWip ? "[WIP]  " + choice.text : "🔒  " + choice.text)
                            : makeBtn(choice.text);
                if (!isWip && !isLocked) {
                    btn.addActionListener(e -> handleChoice(choice));
                }
                // DEV mode: tooltip showing gates, stats, path types
                if (settings != null && settings.isDev()) {
                    btn.setToolTipText(buildDevTooltip(choice));
                }
                choicesPanel.add(Box.createVerticalStrut(7));
                choicesPanel.add(btn);
            }
        }
        choicesPanel.revalidate(); choicesPanel.repaint();
    }

    private void handleChoice(SceneData.ChoiceData choice) {
        String sceneBefore = state.currentScene;
        // Snapshot stats before applying choice for PLAYER/DEV diff
        int _snapHap=state.happiness, _snapConf=state.confidence, _snapWP=state.willpower;
        int _snapStr=state.stress, _snapAro=state.arousal, _snapFit=state.fitness;
        int _snapRep=state.reputation, _snapSlut=state.slut_rep, _snapMoney=state.money;

        String result = engine.applyChoice(choice);
        onChange.accept(null);

        // Check if arousal-based nipping crossed a threshold mid-scene
        String nippingNote = checkArousedNippingChange();

        String fullResult = result != null ? result.trim() : "";
        if (!nippingNote.isEmpty()) {
            fullResult = fullResult.isEmpty() ? nippingNote : fullResult + "\n\n" + nippingNote;
        }
        // PLAYER / DEV mode: append stat summary line
        if (settings != null && settings.isPlayer()) {
            String statLine = buildStatSummary(choice, _snapHap, _snapConf, _snapWP,
                _snapStr, _snapAro, _snapFit, _snapRep, _snapSlut, _snapMoney);
            if (!statLine.isEmpty())
                fullResult = (fullResult.isEmpty() ? "" : fullResult + "\n\n") + statLine;
        }

        // Did the choice route us to a genuinely different scene?
        boolean routedElsewhere = !state.currentScene.equals(sceneBefore);

        if (!fullResult.isEmpty()) {
            textArea.setForeground(Colors.RESULT);
            textArea.setText(fullResult);
            choicesPanel.removeAll();
            JButton cont = makeBtn("Continue →");
            cont.addActionListener(e -> {
                textArea.setForeground(Colors.TEXT);
                if (routedElsewhere) {
                    // next pointed to a different scene — load it
                    showCurrentScene();
                } else {
                    // Same scene or no next — this beat is done, advance
                    if (onSceneComplete != null) onSceneComplete.run();
                    else showCurrentScene();
                }
            });
            choicesPanel.add(Box.createVerticalStrut(7));
            choicesPanel.add(cont);
            choicesPanel.revalidate();
        } else {
            // No result text — advance immediately if scene didn't change
            if (routedElsewhere) {
                showCurrentScene();
            } else {
                if (onSceneComplete != null) onSceneComplete.run();
                else showCurrentScene();
            }
        }
    }

    /** Returns a note if arousal crossed the nipping threshold since last check. */
    private String checkArousedNippingChange() {
        java.util.Set<String> nowTraits = state.computeDynamicTraits(clothes);
        boolean wasNipping  = lastDynamicTraits.contains("arousal_nipping");
        boolean nowNipping  = nowTraits.contains("arousal_nipping");
        boolean wasPierced  = lastDynamicTraits.contains("pierced_nipping") ||
                              lastDynamicTraits.contains("pierced_nipping_prominent");
        boolean nowPierced  = nowTraits.contains("pierced_nipping") ||
                              nowTraits.contains("pierced_nipping_prominent");
        boolean nowProminent = nowTraits.contains("pierced_nipping_prominent");

        // Update snapshot
        lastDynamicTraits = new java.util.HashSet<>(nowTraits);

        if (!wasNipping && nowNipping) {
            // Arousal crossed threshold — subtle physical note
            if (state.arousal >= 75) {
                return "You're aware of the warmth in your skin. The fabric of your top feels a little thinner than it did.";
            } else {
                return "There's a faint awareness — the fabric pressing where it shouldn't quite be noticed.";
            }
        }
        if (!wasPierced && nowPierced) {
            return nowProminent
                ? "The jewelry catches against the fabric. Anyone looking would notice it."
                : "The jewelry catches slightly against the fabric. Noticeable if you know what to look for.";
        }
        return "";
    }

    private JButton makeBtn(String text) {
        // Special button variants
        boolean isContinue  = text.startsWith("Continue") || text.equals("Continue →");
        boolean isPushAway  = text.startsWith("Push away") || text.startsWith("End the dance")
                           || text.startsWith("End the night") || text.startsWith("Say goodnight");
        boolean isGoHome    = text.contains("head out") || text.contains("Go home")
                           || text.startsWith("🏠");

        // Emoji prefix for contextual buttons
        String display = text;
        if (isContinue && !text.contains("→"))   display = "Continue  →";
        if (isGoHome && !text.contains("🏠"))     display = "🏠  " + text;

        final boolean fin = isContinue;
        final boolean push = isPushAway;
        final String finalText = display;

        JButton btn = new JButton(finalText) {
            boolean hov = false;
            { addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent e) { hov = true;  repaint(); }
                public void mouseExited (java.awt.event.MouseEvent e) { hov = false; repaint(); }
            }); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg, border;
                if (fin) {
                    bg     = hov ? new Color(90, 70, 170) : new Color(70, 55, 140);
                    border = hov ? new Color(140, 120, 230) : new Color(100, 80, 180);
                } else if (push) {
                    bg     = hov ? new Color(62, 32, 38) : new Color(48, 24, 30);
                    border = hov ? new Color(180, 70, 90) : new Color(110, 50, 60);
                } else {
                    bg     = hov ? Colors.BG_BTN_HOV : Colors.BG_BTN;
                    border = hov ? Colors.ACCENT_LIT  : Colors.BORDER;
                }
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(border);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 8, 8);
                super.paintComponent(g);
            }
        };
        btn.setForeground(isPushAway ? new Color(220, 150, 160) : new Color(210, 200, 255));
        btn.setFont(settings != null
            ? new Font(settings.choiceFont, Font.PLAIN, settings.choiceSize)
            : Colors.SANS_PLAIN);
        btn.setContentAreaFilled(false); btn.setBorderPainted(false); btn.setFocusPainted(false);
        btn.setHorizontalAlignment(isContinue ? SwingConstants.CENTER : SwingConstants.LEFT);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        btn.setAlignmentX(LEFT_ALIGNMENT);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    /** Grey, non-clickable button for WIP or locked-but-visible choices. */
    private JButton makeGreyBtn(String text) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(38, 36, 44));          // very dark, near-invisible bg
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(new Color(70, 68, 78));          // dim border
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 8, 8);
                super.paintComponent(g);
            }
        };
        btn.setForeground(new Color(90, 85, 105));           // muted grey-purple text
        btn.setFont(settings != null
            ? new Font(settings.choiceFont, Font.PLAIN, settings.choiceSize)
            : Colors.SANS_PLAIN);
        btn.setContentAreaFilled(false); btn.setBorderPainted(false); btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        btn.setAlignmentX(LEFT_ALIGNMENT);
        btn.setEnabled(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
        return btn;
    }
    // ── Scene image + artwork hooks ──────────────────────────────────────────

    private void updateFromArtworkHook(String currentScene) {
        if (artworkManager == null) { updateSceneImage(null, "top", 0); return; }
        Set<String> flags = buildActiveFlagSet();
        int npcTier = state.currentNpcFrustration / 20; // rough tier from frustration
        ArtworkHookManager.EvalResult result = artworkManager.evaluate(state, flags, npcTier, currentScene);
        if (result != null) {
            // Show the artwork hook image
            updateSceneImageDirect(result.icon, result.imageHeight);
        } else {
            updateSceneImage(null, "top", 0); // clear
        }
    }

    /** Build the complete set of active body/game flags for artwork hook evaluation.
     *  Evaluates all 94 GameState.getBodyFlag() cases so mod hooks can use any flag. */
    private Set<String> buildActiveFlagSet() {
        Set<String> flags = new HashSet<>();
        // All known GameState.getBodyFlag() flag keys — generated from switch cases
        String[] allFlags = {
            "flag_alcoholic_craving","flag_ass_groped","flag_being_groped","flag_breast_groped",
            "flag_broke","flag_cafe_jump_flashed","flag_cafe_sleazy_visited","flag_cooked_tonight",
            "flag_cornered","flag_dance_locked","flag_deep_kissed","flag_drunk_tonight",
            "flag_fingered","flag_gloryhole_used","flag_grope_persisted","flag_happy",
            "flag_has_any_npc_trauma","flag_has_bookshelf","flag_has_coffee_maker",
            "flag_has_dresser","flag_has_dresser_basic","flag_has_dresser_nice",
            "flag_has_good_mattress","flag_has_mirror","flag_has_npc_number","flag_has_std",
            "flag_has_tv","flag_has_wardrobe","flag_high_lewdness","flag_high_stress",
            "flag_is_braless","flag_is_broken","flag_is_dating_npc","flag_is_hurt",
            "flag_is_living_together","flag_is_married_npc","flag_is_open_rel_npc",
            "flag_is_pregnant","flag_is_rattled","flag_is_shaken","flag_is_traumatised",
            "flag_kissed","flag_lives_house","flag_low_willpower","flag_neck_kissed",
            "flag_neighbourhood_caldwell","flag_neighbourhood_lanes","flag_neighbourhood_millgate",
            "flag_neighbourhood_narrows","flag_neighbourhood_premium","flag_neighbourhood_ravenshill",
            "flag_neighbourhood_thornwick","flag_nipping","flag_npc_calm","flag_npc_came",
            "flag_npc_can_finger","flag_npc_can_grope","flag_npc_can_sa","flag_npc_escalating",
            "flag_npc_peak","flag_npc_returning","flag_npc_sa_risk","flag_npc_sa_territory",
            "flag_npc_trauma_timer_active","flag_npc_traumatised_current","flag_npc_wanting",
            "flag_npc_wants_leave","flag_on_period","flag_owns_property","flag_owns_sneakers",
            "flag_pussy_groped","flag_season_autumn","flag_season_cold","flag_season_spring",
            "flag_season_summer","flag_season_warm","flag_season_winter",
            "flag_stage_high","flag_stage_low","flag_stage_mid",
            "flag_underdressed_for_winter","flag_very_high_lewdness","flag_wearing_dress",
            "flag_wearing_dress_or_skirt","flag_wearing_skirt","flag_wearing_thin_top",
            "flag_works_bar","flag_works_bookshop","flag_works_kitchen","flag_works_library",
            "flag_works_neon_fitness","flag_works_retail","flag_works_tattoo","flag_works_velvet_cafe"
        };
        for (String f : allFlags)
            if (state.getBodyFlag(f)) flags.add(f);
        // All active MC traits and timed traits
        for (String t : state.traits) flags.add(t.toLowerCase());
        for (String t : state.timedTraits.keySet()) flags.add(t.toLowerCase());
        return flags;
    }

    /** Show an ImageIcon directly (from artwork hook evaluation). */
    private void updateSceneImageDirect(javax.swing.ImageIcon icon, int heightCap) {
        if (imageWrapper != null) { remove(imageWrapper); imageWrapper = null; sceneImageLabel = null; }
        if (icon == null) { revalidate(); repaint(); return; }
        sceneImageLabel = new JLabel(icon);
        sceneImageLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        imageWrapper = new JPanel(new java.awt.BorderLayout());
        imageWrapper.setOpaque(false);
        imageWrapper.setBorder(javax.swing.BorderFactory.createEmptyBorder(8,44,4,44));
        imageWrapper.add(sceneImageLabel, java.awt.BorderLayout.CENTER);
        add(imageWrapper, java.awt.BorderLayout.NORTH);
        revalidate(); repaint();
    }

    // ── Scene image (from scene YAML) ─────────────────────────────────────────

    /**
     * Shows (or hides) a scene image above the text area.
     * Called each time the displayed scene changes.
     */
    private void updateSceneImage(String assetId, String position, int heightCap) {
        // Remove previous image wrapper if present
        if (imageWrapper != null) {
            remove(imageWrapper);
            imageWrapper    = null;
            sceneImageLabel = null;
        }
        if (assetManager == null || assetId == null || assetId.isEmpty()) {
            revalidate(); repaint(); return;
        }
        int maxH = (heightCap > 0) ? heightCap : AssetManager.MAX_SCENE_IMG_H;
        javax.swing.ImageIcon icon = assetManager.get(assetId, AssetManager.MAX_SCENE_IMG_W, maxH);
        if (icon == null) { revalidate(); repaint(); return; }

        sceneImageLabel = new JLabel(icon);
        sceneImageLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        imageWrapper = new JPanel(new java.awt.BorderLayout());
        imageWrapper.setOpaque(false);
        imageWrapper.setBorder(javax.swing.BorderFactory.createEmptyBorder(8, 44, 4, 44));
        imageWrapper.add(sceneImageLabel, java.awt.BorderLayout.CENTER);

        // Position: "top" (default) goes above text; "left"/"right" currently treated as top
        add(imageWrapper, java.awt.BorderLayout.NORTH);
        revalidate(); repaint();
    }

    private String buildStatSummary(game.data.SceneData.ChoiceData c,
            int h0, int conf0, int wp0, int str0, int aro0, int fit0,
            int rep0, int slut0, int money0) {
        java.util.List<String> parts = new java.util.ArrayList<>();
        appendDiff(parts, "happiness",  h0,     state.happiness);
        appendDiff(parts, "confidence", conf0,   state.confidence);
        appendDiff(parts, "willpower",  wp0,     state.willpower);
        appendDiff(parts, "stress",     str0,    state.stress);
        appendDiff(parts, "arousal",    aro0,    state.arousal);
        appendDiff(parts, "fitness",    fit0,    state.fitness);
        appendDiff(parts, "reputation", rep0,    state.reputation);
        appendDiff(parts, "slut rep",   slut0,   state.slut_rep);
        if (state.money != money0) {
            int d = state.money - money0;
            parts.add((d > 0 ? "+" : "") + "$" + d);
        }
        if (parts.isEmpty()) return "";
        return "[ " + String.join("  ", parts) + " ]";
    }

    private void appendDiff(java.util.List<String> parts, String name, int before, int after) {
        int d = after - before;
        if (d == 0) return;
        String sign = d > 0 ? "+" : "";
        parts.add(sign + d + " " + name);
    }


    private String buildDevTooltip(game.data.SceneData.ChoiceData c) {
        StringBuilder sb = new StringBuilder("<html><b>DEV INFO</b><br>");
        if (c.slut_rep_req > 0)           sb.append("slut_rep ≥ ").append(c.slut_rep_req).append("<br>");
        if (c.min_npc_rep > 0)            sb.append("npc_rep ≥ ").append(c.min_npc_rep).append("<br>");
        if (c.min_arousal > 0)            sb.append("arousal ≥ ").append(c.min_arousal).append("<br>");
        if (c.min_willpower > 0)          sb.append("willpower ≥ ").append(c.min_willpower).append("<br>");
        if (c.min_money > 0)              sb.append("money ≥ ").append(c.min_money).append("<br>");
        if (!c.requires_traits.isEmpty()) sb.append("requires: <i>").append(c.requires_traits).append("</i><br>");
        if (!c.requires_flag.isEmpty())   sb.append("flag: <i>").append(c.requires_flag).append("</i><br>");
        if (!c.blocks_if_flag.isEmpty())  sb.append("blocks if: <i>").append(c.blocks_if_flag).append("</i><br>");
        if (!c.path_traits.isEmpty())     sb.append("path: <i>").append(c.path_traits).append("</i><br>");
        if (!c.add_traits.isEmpty())      sb.append("adds: ").append(c.add_traits).append("<br>");
        if (!c.timed_traits.isEmpty())    sb.append("timed: ").append(c.timed_traits).append("<br>");
        if (!c.remove_traits.isEmpty())   sb.append("removes: ").append(c.remove_traits).append("<br>");
        if (!c.stat_changes.isEmpty()) {
            sb.append("stats: ");
            c.stat_changes.forEach((k,v) -> sb.append(k).append(v>0?"+":"").append(v).append(" "));
            sb.append("<br>");
        }
        if (c.money_change != 0) sb.append("money: ").append(c.money_change > 0 ? "+" : "").append(c.money_change).append("<br>");
        if (!c.path_types.isEmpty())     sb.append("path: ").append(c.path_types).append("<br>");
        // Settings multipliers active
        if (settings.slutRepMultiplier != 1.0f && c.stat_changes.containsKey("slut_rep")) {
            sb.append("<i>slut_rep ×").append(settings.slutRepMultiplier).append(" active</i><br>");
        }
        sb.append("</html>");
        return sb.toString();
    }


}
