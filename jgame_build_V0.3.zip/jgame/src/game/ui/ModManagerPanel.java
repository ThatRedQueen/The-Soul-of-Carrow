package game.ui;

import game.GameMeta;
import game.mod.*;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.concurrent.*;

/**
 * Mod Manager panel — full management UI for mods.
 *
 * Features:
 *  ─ List of all discovered mods with status badges (OK / PARTIAL / FAILED / DISABLED)
 *  ─ Compatibility status per mod (COMPATIBLE / OUTDATED / INCOMPATIBLE / UNKNOWN)
 *  ─ Enable / Disable toggle per mod (takes effect on next launch)
 *  ─ Suppress warnings toggle per mod
 *  ─ "Check Compatibility" button — runs one mod at a time, never crashes the app
 *  ─ Expandable error/warning log per mod
 *  ─ Changes auto-saved to mods/mods_settings.yml
 */
public class ModManagerPanel extends JPanel {

    // ── Status colours ────────────────────────────────────────────────────────
    private static final Color COL_OK           = new Color(60,  180, 100);
    private static final Color COL_PARTIAL       = new Color(220, 160, 60);
    private static final Color COL_FAILED        = new Color(200,  70, 70);
    private static final Color COL_DISABLED      = new Color( 80,  80,100);
    private static final Color COL_COMPAT_OK     = new Color( 60, 180, 100);
    private static final Color COL_OUTDATED      = new Color(220, 150, 50);
    private static final Color COL_INCOMPAT      = new Color(200,  70, 70);
    private static final Color COL_UNKNOWN       = new Color(100, 100, 120);
    private static final Color COL_FAILED_CHECK  = new Color(180,  80, 80);

    private final ModLoader   modLoader;
    private final ModSettings modSettings;
    private final Runnable    onBack;

    private JLabel     statusBarLabel;
    private JPanel     listPanel;
    private JButton    checkAllBtn;

    // Background executor for compatibility checks (single thread — sequential)
    private final ExecutorService checkThread = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "compat-checker");
        t.setDaemon(true);
        return t;
    });

    public ModManagerPanel(ModLoader modLoader, ModSettings modSettings, Runnable onBack) {
        this.modLoader   = modLoader;
        this.modSettings = modSettings;
        this.onBack      = onBack;
        setBackground(Colors.BG);
        setLayout(new BorderLayout());
        build();
    }

    // ── Build ─────────────────────────────────────────────────────────────────

    private void build() {
        add(buildHeader(), BorderLayout.NORTH);
        add(buildScrollList(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);
    }

    private JPanel buildHeader() {
        JPanel h = new JPanel(new BorderLayout(0, 6));
        h.setOpaque(false);
        h.setBorder(BorderFactory.createEmptyBorder(24, 48, 12, 48));

        JButton back = navBtn("← Back");
        back.addActionListener(e -> { modSettings.saveIfDirty(); onBack.run(); });

        JLabel title = new JLabel("Mod Manager");
        title.setFont(new Font("SansSerif", Font.BOLD, 32));
        title.setForeground(Colors.TEXT_HEAD);

        List<Mod> mods = modLoader.getMods();
        long ok   = mods.stream().filter(m -> m.status == Mod.Status.OK).count();
        long warn = mods.stream().filter(m -> m.status == Mod.Status.PARTIAL).count();
        long fail = mods.stream().filter(m -> m.status == Mod.Status.FAILED).count();
        long dis  = mods.stream().filter(m -> m.status == Mod.Status.DISABLED).count();

        String summary = mods.isEmpty()
            ? "No mods found in mods/ folder"
            : mods.size() + " mod" + (mods.size()==1?"":"s") + " found"
              + (ok>0   ? "  ·  " + ok   + " OK"       : "")
              + (warn>0 ? "  ·  " + warn + " partial"  : "")
              + (fail>0 ? "  ·  " + fail + " failed"   : "")
              + (dis>0  ? "  ·  " + dis  + " disabled" : "");

        JLabel sub = new JLabel(summary);
        sub.setFont(new Font("SansSerif", Font.PLAIN, 13));
        sub.setForeground(Colors.TEXT_DIM);

        JPanel titleBlock = new JPanel();
        titleBlock.setOpaque(false);
        titleBlock.setLayout(new BoxLayout(titleBlock, BoxLayout.Y_AXIS));
        title.setAlignmentX(LEFT_ALIGNMENT);
        sub.setAlignmentX(LEFT_ALIGNMENT);
        titleBlock.add(title);
        titleBlock.add(Box.createVerticalStrut(2));
        titleBlock.add(sub);

        checkAllBtn = actionBtn("Check Compatibility");
        checkAllBtn.setToolTipText("Validate each mod's version requirements and load state one by one");
        checkAllBtn.addActionListener(e -> runCompatibilityCheck());

        JPanel rightButtons = new JPanel();
        rightButtons.setOpaque(false);
        rightButtons.setLayout(new BoxLayout(rightButtons, BoxLayout.Y_AXIS));
        checkAllBtn.setAlignmentX(RIGHT_ALIGNMENT);
        rightButtons.add(checkAllBtn);

        h.add(back,         BorderLayout.WEST);
        h.add(titleBlock,   BorderLayout.CENTER);
        h.add(rightButtons, BorderLayout.EAST);

        // Status bar
        statusBarLabel = new JLabel(" ");
        statusBarLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
        statusBarLabel.setForeground(Colors.TEXT_DIM);
        statusBarLabel.setBorder(BorderFactory.createEmptyBorder(4, 0, 0, 0));

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.add(h, BorderLayout.CENTER);
        wrapper.add(statusBarLabel, BorderLayout.SOUTH);
        wrapper.setBorder(BorderFactory.createEmptyBorder(0, 48, 0, 48));

        JPanel outer = new JPanel(new BorderLayout());
        outer.setOpaque(false);
        outer.add(wrapper, BorderLayout.CENTER);

        // Divider
        JSeparator div = new JSeparator();
        div.setForeground(Colors.BORDER);
        outer.add(div, BorderLayout.SOUTH);
        return outer;
    }

    private JScrollPane buildScrollList() {
        listPanel = new JPanel();
        listPanel.setOpaque(false);
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
        listPanel.setBorder(BorderFactory.createEmptyBorder(12, 48, 24, 48));

        List<Mod> mods = modLoader.getMods();
        if (mods.isEmpty()) {
            JLabel empty = new JLabel(
                "<html><body style='color:#7070a0'>No mods found.<br><br>"
                + "Drop mod folders into the <b>mods/</b> directory next to the game.<br>"
                + "See <b>MOD_FULL_GUIDE.md</b> for how to create or install mods.</body></html>");
            empty.setFont(new Font("SansSerif", Font.PLAIN, 14));
            empty.setBorder(BorderFactory.createEmptyBorder(24, 0, 0, 0));
            listPanel.add(empty);
        } else {
            for (Mod mod : mods) {
                listPanel.add(buildModCard(mod));
                listPanel.add(Box.createVerticalStrut(10));
            }
        }

        JScrollPane scroll = new JScrollPane(listPanel);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        return scroll;
    }

    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        footer.setBorder(BorderFactory.createEmptyBorder(8, 48, 20, 48));

        JSeparator div = new JSeparator();
        div.setForeground(Colors.BORDER);
        footer.add(div, BorderLayout.NORTH);

        JLabel note = new JLabel(
            "Enable/disable changes take effect after restarting the game.  "
            + "Game version: " + GameMeta.versionString());
        note.setFont(new Font("SansSerif", Font.PLAIN, 11));
        note.setForeground(Colors.TEXT_DIM);
        note.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
        footer.add(note, BorderLayout.CENTER);
        return footer;
    }

    // ── Mod card ──────────────────────────────────────────────────────────────

    private JPanel buildModCard(Mod mod) {
        JPanel card = darkCard();
        card.setLayout(new BorderLayout(12, 0));

        // Left: status dot
        JLabel dot = new JLabel("●");
        dot.setFont(new Font("SansSerif", Font.PLAIN, 16));
        dot.setForeground(statusColour(mod.status));
        dot.setVerticalAlignment(SwingConstants.TOP);
        dot.setBorder(BorderFactory.createEmptyBorder(2, 0, 0, 6));

        // Centre: mod info
        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));

        // Name + version
        String nameText = (mod.name.isEmpty() ? mod.id : mod.name)
                        + (mod.version.isEmpty() ? "" : "  v" + mod.version);
        JLabel nameLbl = new JLabel(nameText);
        nameLbl.setFont(new Font("SansSerif", Font.BOLD, 14));
        nameLbl.setForeground(mod.enabled ? Colors.TEXT_HEAD : Colors.TEXT_DIM);
        nameLbl.setAlignmentX(LEFT_ALIGNMENT);
        info.add(nameLbl);

        // Author
        if (!mod.author.isEmpty()) {
            JLabel authorLbl = new JLabel("by " + mod.author);
            authorLbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
            authorLbl.setForeground(Colors.TEXT_DIM);
            authorLbl.setAlignmentX(LEFT_ALIGNMENT);
            info.add(authorLbl);
        }

        // Content counts
        String counts = buildCountLine(mod);
        if (!counts.isEmpty()) {
            JLabel countLbl = new JLabel(counts);
            countLbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
            countLbl.setForeground(new Color(100, 140, 100));
            countLbl.setAlignmentX(LEFT_ALIGNMENT);
            countLbl.setBorder(BorderFactory.createEmptyBorder(2, 0, 0, 0));
            info.add(countLbl);
        }

        // Status label
        String statusText = statusText(mod);
        JLabel statusLbl = new JLabel(statusText);
        statusLbl.setFont(new Font("SansSerif", Font.BOLD, 11));
        statusLbl.setForeground(statusColour(mod.status));
        statusLbl.setAlignmentX(LEFT_ALIGNMENT);
        statusLbl.setBorder(BorderFactory.createEmptyBorder(3, 0, 0, 0));
        info.add(statusLbl);

        // Compatibility badge
        if (mod.compatStatus != Mod.CompatStatus.UNKNOWN) {
            JLabel compatLbl = new JLabel("  " + compatIcon(mod.compatStatus)
                + "  " + compatLabel(mod.compatStatus));
            compatLbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
            compatLbl.setForeground(compatColour(mod.compatStatus));
            compatLbl.setAlignmentX(LEFT_ALIGNMENT);
            info.add(compatLbl);
        }

        // Errors/warnings summary
        int errs = (int)mod.errors.stream().filter(e -> e.level == Mod.ModError.Level.ERROR).count();
        int warns = (int)mod.errors.stream().filter(e -> e.level == Mod.ModError.Level.WARNING).count();
        if (!modSettings.isWarningsSuppressed(mod.id) && (errs > 0 || warns > 0)) {
            String errorSummary = (errs  > 0 ? errs  + " error" + (errs==1?"":"s")   : "")
                                + (errs > 0 && warns > 0 ? ", " : "")
                                + (warns > 0 ? warns + " warning" + (warns==1?"":"s") : "");
            JLabel errLbl = new JLabel("  ⚠  " + errorSummary + " — click to expand");
            errLbl.setFont(new Font("SansSerif", Font.ITALIC, 11));
            errLbl.setForeground(errs > 0 ? COL_FAILED : COL_OUTDATED);
            errLbl.setAlignmentX(LEFT_ALIGNMENT);
            errLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            // Expand/collapse error detail on click
            JPanel errorPanel = buildErrorPanel(mod);
            errorPanel.setVisible(false);
            errLbl.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    errorPanel.setVisible(!errorPanel.isVisible());
                    errLbl.setText(errorPanel.isVisible()
                        ? "  ▲  " + errorSummary + " — click to collapse"
                        : "  ⚠  " + errorSummary + " — click to expand");
                    card.revalidate(); card.repaint();
                }
            });
            info.add(errLbl);
            info.add(errorPanel);
        }

        // Compat message detail (if failed check or outdated)
        if (mod.compatStatus == Mod.CompatStatus.INCOMPATIBLE
         || mod.compatStatus == Mod.CompatStatus.CHECK_FAILED
         || (mod.compatStatus == Mod.CompatStatus.OUTDATED
             && !modSettings.isWarningsSuppressed(mod.id))) {
            JLabel compatDetail = new JLabel("<html><body style='width:380px;color:#c87830;'>"
                + mod.compatMessage.replace("\n","<br>") + "</body></html>");
            compatDetail.setFont(new Font("SansSerif", Font.PLAIN, 11));
            compatDetail.setAlignmentX(LEFT_ALIGNMENT);
            compatDetail.setBorder(BorderFactory.createEmptyBorder(3, 0, 0, 0));
            info.add(compatDetail);
        }

        // Right: controls
        JPanel controls = new JPanel();
        controls.setOpaque(false);
        controls.setLayout(new BoxLayout(controls, BoxLayout.Y_AXIS));

        // Enable/Disable toggle
        JToggleButton enableToggle = new JToggleButton(mod.enabled ? "Enabled" : "Disabled");
        enableToggle.setSelected(mod.enabled);
        enableToggle.setFont(new Font("SansSerif", Font.PLAIN, 11));
        enableToggle.setFocusPainted(false);
        updateToggleStyle(enableToggle, mod.enabled);
        enableToggle.addActionListener(e -> {
            boolean nowEnabled = enableToggle.isSelected();
            mod.enabled = nowEnabled;
            modSettings.setEnabled(mod.id, nowEnabled);
            modSettings.saveIfDirty();
            updateToggleStyle(enableToggle, nowEnabled);
            enableToggle.setText(nowEnabled ? "Enabled" : "Disabled");
            nameLbl.setForeground(nowEnabled ? Colors.TEXT_HEAD : Colors.TEXT_DIM);
        });
        enableToggle.setAlignmentX(RIGHT_ALIGNMENT);
        controls.add(enableToggle);
        controls.add(Box.createVerticalStrut(5));

        // Suppress warnings toggle (only show if has warnings)
        if (warns > 0 || mod.compatStatus == Mod.CompatStatus.OUTDATED) {
            boolean suppressed = modSettings.isWarningsSuppressed(mod.id);
            JToggleButton suppressToggle = new JToggleButton(suppressed ? "Warnings off" : "Warnings on");
            suppressToggle.setSelected(suppressed);
            suppressToggle.setFont(new Font("SansSerif", Font.PLAIN, 10));
            suppressToggle.setFocusPainted(false);
            suppressToggle.setForeground(suppressed ? Colors.TEXT_DIM : COL_OUTDATED);
            suppressToggle.setBackground(Colors.BG_BTN);
            suppressToggle.setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 10));
            suppressToggle.addActionListener(e -> {
                boolean isSuppressed = suppressToggle.isSelected();
                modSettings.setSuppressWarnings(mod.id, isSuppressed);
                modSettings.saveIfDirty();
                suppressToggle.setText(isSuppressed ? "Warnings off" : "Warnings on");
                suppressToggle.setForeground(isSuppressed ? Colors.TEXT_DIM : COL_OUTDATED);
                // Rebuild the card to show/hide warning labels
                SwingUtilities.invokeLater(this::rebuildList);
            });
            suppressToggle.setAlignmentX(RIGHT_ALIGNMENT);
            controls.add(suppressToggle);
        }

        card.add(dot,      BorderLayout.WEST);
        card.add(info,     BorderLayout.CENTER);
        card.add(controls, BorderLayout.EAST);
        return card;
    }

    private JPanel buildErrorPanel(Mod mod) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, Colors.BORDER),
            BorderFactory.createEmptyBorder(6, 0, 2, 0)));

        for (Mod.ModError err : mod.errors) {
            Color c = err.level == Mod.ModError.Level.ERROR ? COL_FAILED : COL_OUTDATED;
            String prefix = err.level == Mod.ModError.Level.ERROR ? "✗  " : "⚠  ";
            JLabel lbl = new JLabel("<html><body style='width:380px'><b>"
                + prefix + err.file + "</b><br>"
                + "<span style='color:#aaa'>" + err.message + "</span></body></html>");
            lbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
            lbl.setForeground(c);
            lbl.setAlignmentX(LEFT_ALIGNMENT);
            lbl.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
            p.add(lbl);
        }

        // Compat check result if available
        if (mod.compatStatus != Mod.CompatStatus.UNKNOWN
         && mod.compatStatus != Mod.CompatStatus.COMPATIBLE
         && !mod.compatMessage.isEmpty()) {
            JLabel compatLbl = new JLabel("<html><body style='width:380px;color:#c87830;'>"
                + "Compatibility: " + mod.compatMessage.replace("\n","<br>")
                + "</body></html>");
            compatLbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
            compatLbl.setAlignmentX(LEFT_ALIGNMENT);
            p.add(compatLbl);
        }
        return p;
    }

    // ── Compatibility check ───────────────────────────────────────────────────

    private void runCompatibilityCheck() {
        List<Mod> mods = modLoader.getMods();
        if (mods.isEmpty()) { setStatus("No mods to check."); return; }

        checkAllBtn.setEnabled(false);
        checkAllBtn.setText("Checking…");
        setStatus("Starting compatibility check…");

        checkThread.submit(() -> {
            CompatibilityChecker checker = modLoader.getChecker();
            checker.checkAll(mods, msg -> SwingUtilities.invokeLater(() -> setStatus(msg)));
            SwingUtilities.invokeLater(() -> {
                checkAllBtn.setEnabled(true);
                checkAllBtn.setText("Check Compatibility");
                long issues = mods.stream()
                    .filter(m -> m.compatStatus == Mod.CompatStatus.INCOMPATIBLE
                              || m.compatStatus == Mod.CompatStatus.CHECK_FAILED).count();
                long outdated = mods.stream()
                    .filter(m -> m.compatStatus == Mod.CompatStatus.OUTDATED).count();
                String result = "Check complete.";
                if (issues > 0)  result += "  " + issues + " incompatible.";
                if (outdated > 0) result += "  " + outdated + " outdated.";
                if (issues == 0 && outdated == 0) result += "  All mods compatible.";
                setStatus(result);
                rebuildList();
            });
        });
    }

    private void rebuildList() {
        listPanel.removeAll();
        for (Mod mod : modLoader.getMods()) {
            listPanel.add(buildModCard(mod));
            listPanel.add(Box.createVerticalStrut(10));
        }
        listPanel.revalidate();
        listPanel.repaint();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void setStatus(String msg) {
        if (statusBarLabel != null) statusBarLabel.setText(msg);
    }

    private String buildCountLine(Mod mod) {
        if (mod.status == Mod.Status.DISABLED) return "Not loaded (disabled)";
        if (mod.status == Mod.Status.PENDING)  return "";
        StringBuilder sb = new StringBuilder();
        if (mod.scenesLoaded  > 0) sb.append(mod.scenesLoaded).append(" scenes  ");
        if (mod.npcsLoaded    > 0) sb.append(mod.npcsLoaded).append(" NPCs  ");
        if (mod.clothesLoaded > 0) sb.append(mod.clothesLoaded).append(" clothing  ");
        if (mod.jobsLoaded    > 0) sb.append(mod.jobsLoaded).append(" jobs  ");
        if (mod.assetsLoaded  > 0) sb.append(mod.assetsLoaded).append(" images  ");
        if (mod.artworkHooks  > 0) sb.append(mod.artworkHooks).append(" art hooks  ");
        if (mod.textEntries   > 0) sb.append(mod.textEntries).append(" text entries  ");
        if (mod.audioTracks   > 0) sb.append(mod.audioTracks).append(" audio tracks  ");
        return sb.toString().trim();
    }

    private Color statusColour(Mod.Status s) {
        switch (s) {
            case OK:       return COL_OK;
            case PARTIAL:  return COL_PARTIAL;
            case FAILED:   return COL_FAILED;
            case DISABLED: return COL_DISABLED;
            default:       return COL_UNKNOWN;
        }
    }

    private String statusText(Mod.Status s) {
        switch (s) {
            case OK:       return "● Loaded OK";
            case PARTIAL:  return "◑ Loaded with issues";
            case FAILED:   return "✗ Failed to load";
            case DISABLED: return "○ Disabled";
            default:       return "○ Pending";
        }
    }
    private String statusText(Mod mod) { return statusText(mod.status); }

    private Color  compatColour(Mod.CompatStatus s) {
        switch (s) {
            case COMPATIBLE:   return COL_COMPAT_OK;
            case OUTDATED:     return COL_OUTDATED;
            case INCOMPATIBLE: return COL_INCOMPAT;
            case CHECK_FAILED: return COL_FAILED_CHECK;
            default:           return COL_UNKNOWN;
        }
    }
    private String compatIcon(Mod.CompatStatus s) {
        switch (s) {
            case COMPATIBLE:   return "✓";
            case OUTDATED:     return "⚠";
            case INCOMPATIBLE: return "✗";
            case CHECK_FAILED: return "!";
            default:           return "?";
        }
    }
    private String compatLabel(Mod.CompatStatus s) {
        switch (s) {
            case COMPATIBLE:   return "Compatible";
            case OUTDATED:     return "Outdated — may still work";
            case INCOMPATIBLE: return "Incompatible";
            case CHECK_FAILED: return "Check failed";
            default:           return "Not checked";
        }
    }

    private void updateToggleStyle(JToggleButton btn, boolean enabled) {
        btn.setBackground(enabled ? new Color(40, 80, 50) : new Color(50, 50, 70));
        btn.setForeground(enabled ? new Color(100, 200, 120) : Colors.TEXT_DIM);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(enabled ? new Color(60,120,70) : Colors.BORDER, 1),
            BorderFactory.createEmptyBorder(5, 12, 5, 12)));
    }

    private JPanel darkCard() {
        JPanel p = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Colors.BG_PANEL);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(Colors.BORDER);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 10, 10);
                super.paintComponent(g);
            }
        };
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        p.setAlignmentX(LEFT_ALIGNMENT);
        return p;
    }

    private JButton navBtn(String text) {
        JButton b = new JButton(text);
        b.setFont(Colors.LABEL);
        b.setForeground(Colors.TEXT_DIM);
        b.setBackground(Colors.BG);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private JButton actionBtn(String text) {
        JButton b = new JButton(text);
        b.setFont(new Font("SansSerif", Font.BOLD, 13));
        b.setForeground(Colors.TEXT_HEAD);
        b.setBackground(new Color(40, 36, 72));
        b.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Colors.BORDER, 1),
            BorderFactory.createEmptyBorder(8, 18, 8, 18)));
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { b.setBackground(new Color(55, 48, 100)); }
            public void mouseExited(MouseEvent e)  { b.setBackground(new Color(40, 36, 72)); }
        });
        return b;
    }
}
