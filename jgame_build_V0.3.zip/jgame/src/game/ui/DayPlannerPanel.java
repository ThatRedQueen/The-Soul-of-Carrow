package game.ui;

import game.*;
import game.data.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class DayPlannerPanel extends JPanel {

    private static final int TOTAL_BLOCKS = 8;
    private static final String[] BLOCK_TIMES = {
        "8:00 AM  –  10:00 AM",
        "10:00 AM  –  12:00 PM",
        "12:00 PM  –  2:00 PM",
        "2:00 PM  –  4:00 PM",
        "4:00 PM  –  6:00 PM",
        "6:00 PM  –  8:00 PM",
        "8:00 PM  –  10:00 PM",
        "10:00 PM  –  12:00 AM"
    };
    private static final String STAY_HOME = "stay_home";
    private static final String BLOCKED   = "__blocked__";

    private final GameState      state;
    private final ActivityLoader activities;
    private final JobLoader      jobs;
    private final BounceSystem   bounce;
    private final OutfitSystem   outfit;
    private final game.Engine    engine;
    private final Runnable       onDayEnd;

    private final String[]   slots   = new String[TOTAL_BLOCKS];
    private final JComboBox<String>[] combos = new JComboBox[TOTAL_BLOCKS];

    // activityId → ActivityData for quick lookup
    private Map<String, ActivityData> actMap = new LinkedHashMap<>();
    // display label → activityId
    private Map<String, String> labelToId = new LinkedHashMap<>();

    private JLabel dayLabel;
    private javax.swing.JToggleButton rebuyBtn;

    public DayPlannerPanel(GameState state, ActivityLoader activities,
                           JobLoader jobs, BounceSystem bounce, OutfitSystem outfit,
                           game.Engine engine, Runnable onDayEnd) {
        this.state      = state;
        this.activities = activities;
        this.jobs       = jobs;
        this.bounce     = bounce;
        this.outfit     = outfit;
        this.engine     = engine;
        this.onDayEnd   = onDayEnd;
        setBackground(Colors.BG);
        setLayout(new BorderLayout());
        initSlots();
        build();
    }

    // ── Slot init ────────────────────────────────────────────────
    private void initSlots() {
        // Start from last day's selections if available, else default to stay_home
        if (state.lastDaySlots != null && state.lastDaySlots.length == TOTAL_BLOCKS) {
            System.arraycopy(state.lastDaySlots, 0, slots, 0, TOTAL_BLOCKS);
        } else {
            Arrays.fill(slots, STAY_HOME);
        }
        // Always force work slots on work days regardless of last day
        if (state.currentJobId != null
                && jobs.isWorkDay(state.currentJobId, state.getDayShort())) {
            JobData job = jobs.get(state.currentJobId);
            if (job != null) {
                slots[0] = state.currentJobId;
                for (int i = 1; i < Math.min(job.slots_per_day, TOTAL_BLOCKS); i++)
                    slots[i] = BLOCKED;
            }
        } else {
            // Clear any job slots from yesterday if not a work day today
            for (int i = 0; i < TOTAL_BLOCKS; i++) {
                if (BLOCKED.equals(slots[i])) slots[i] = STAY_HOME;
                if (slots[i] != null && jobs.get(slots[i]) != null) slots[i] = STAY_HOME;
            }
        }
    }

    // ── Build UI ─────────────────────────────────────────────────
    private void build() {
        // Header
        JPanel header = new JPanel();
        header.setOpaque(false);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBorder(BorderFactory.createEmptyBorder(22, 48, 14, 48));

        dayLabel = new JLabel(state.getDayName() + "  —  Day " + state.dayCount);
        dayLabel.setForeground(Colors.TEXT_HEAD);
        dayLabel.setFont(new Font("SansSerif", Font.BOLD, 60));
        dayLabel.setAlignmentX(LEFT_ALIGNMENT);

        // Money + rent info line
        String moneyInfo = buildMoneyInfoLine();
        JLabel moneyLabel = new JLabel(moneyInfo);
        moneyLabel.setForeground(state.money < 300 ? new java.awt.Color(220,80,80)
                                : state.money < 600 ? new java.awt.Color(210,160,50)
                                : Colors.TEXT_DIM);
        moneyLabel.setFont(Colors.SANS_SMALL);
        moneyLabel.setAlignmentX(LEFT_ALIGNMENT);

        JLabel sub = new JLabel("Plan your day. Unscheduled blocks default to 🏠 Stay Home. Sleep fills after midnight.");
        sub.setForeground(Colors.TEXT_DIM);
        sub.setFont(Colors.SANS_SMALL);
        sub.setAlignmentX(LEFT_ALIGNMENT);

        header.add(dayLabel);

        // Context line: season · neighbourhood · job
        JLabel contextLbl = new JLabel(buildContextLine());
        contextLbl.setForeground(Colors.TEXT_DIM);
        contextLbl.setFont(new Font("SansSerif", Font.PLAIN, 12));
        contextLbl.setAlignmentX(LEFT_ALIGNMENT);
        header.add(contextLbl);

        // ── Auto-rebuy toggle ─────────────────────────────────────────
        rebuyBtn = new javax.swing.JToggleButton("🛍 Auto-rebuy off");
        rebuyBtn.setFont(Colors.SANS_SMALL);
        rebuyBtn.setFocusPainted(false);
        boolean initialRebuy = (state.settings != null && state.settings.autoRebuyClothing);
        rebuyBtn.setSelected(initialRebuy);
        rebuyBtn.setText(initialRebuy ? "🛍 Auto-rebuy ON" : "🛍 Auto-rebuy off");
        rebuyBtn.setToolTipText("When ON: clothing lost during the day is automatically repurchased overnight at store price.");
        rebuyBtn.addActionListener(e -> {
            boolean on = rebuyBtn.isSelected();
            if (state.settings != null) state.settings.autoRebuyClothing = on;
            rebuyBtn.setText(on ? "🛍 Auto-rebuy ON" : "🛍 Auto-rebuy off");
        });
        header.add(Box.createHorizontalStrut(12));
        header.add(rebuyBtn);
        header.add(Box.createVerticalStrut(3));
        header.add(moneyLabel);
        header.add(Box.createVerticalStrut(5));
        header.add(sub);
        add(header, BorderLayout.NORTH);

        // Block rows
        JPanel grid = new JPanel();
        grid.setOpaque(false);
        grid.setLayout(new BoxLayout(grid, BoxLayout.Y_AXIS));
        grid.setBorder(BorderFactory.createEmptyBorder(4, 48, 4, 48));

        for (int i = 0; i < TOTAL_BLOCKS; i++) {
            grid.add(buildBlockRow(i));
            if (i < TOTAL_BLOCKS - 1) {
                JSeparator sep = new JSeparator();
                sep.setForeground(Colors.BORDER);
                sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
                grid.add(sep);
            }
        }

        // Sleep row
        grid.add(buildSleepRow());

        JScrollPane scroll = new JScrollPane(grid);
        scroll.setOpaque(false); scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(12);
        add(scroll, BorderLayout.CENTER);

        // Footer
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footer.setOpaque(false);
        footer.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));
        footer.add(makeConfirmBtn());
        add(footer, BorderLayout.SOUTH);
    }

    private JPanel buildBlockRow(int i) {
        // Check if this is the primary work slot for today
        boolean isWorkSlot = i == 0
            && state.currentJobId != null
            && jobs != null
            && jobs.isWorkDay(state.currentJobId, state.getDayShort());

        JPanel outer = new JPanel();
        outer.setOpaque(false);
        outer.setLayout(new BoxLayout(outer, BoxLayout.Y_AXIS));

        JPanel row = new JPanel(new BorderLayout(16, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        row.setBorder(BorderFactory.createEmptyBorder(5, 0, isWorkSlot ? 2 : 5, 0));

        JLabel time = new JLabel(BLOCK_TIMES[i]);
        time.setForeground(Colors.TEXT_DIM);
        time.setFont(Colors.SANS_SMALL);
        time.setPreferredSize(new Dimension(200, 20));

        JComboBox<String> combo = buildCombo(i);
        combos[i] = combo;

        row.add(time,  BorderLayout.WEST);
        row.add(combo, BorderLayout.CENTER);
        outer.add(row);

        // Work mode selector — only on the primary work slot
        if (isWorkSlot) {
            outer.add(buildWorkModeStrip());
        }

        return outer;
    }

    private JPanel buildWorkModeStrip() {
        JPanel strip = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        strip.setOpaque(false);
        strip.setBorder(BorderFactory.createEmptyBorder(0, 200, 5, 0)); // align with combo

        JLabel modeLabel = new JLabel("Mode: ");
        modeLabel.setFont(Colors.SANS_SMALL);
        modeLabel.setForeground(Colors.TEXT_DIM);
        strip.add(modeLabel);

        String[] modes   = {"normal", "harder", "slack", "politics", "pranks"};
        String[] labels  = {"Normal", "Work Harder", "Slack Off", "Politics", "Pranks"};
        java.awt.Color[] colors = {
            new java.awt.Color(60, 90, 60),   // normal — green
            new java.awt.Color(80, 80, 140),  // harder — blue
            new java.awt.Color(100, 80, 40),  // slack — amber
            new java.awt.Color(80, 60, 100),  // politics — purple
            new java.awt.Color(120, 55, 55),  // pranks — red
        };

        ButtonGroup group = new ButtonGroup();
        for (int m = 0; m < modes.length; m++) {
            final String modeId = modes[m];
            boolean selected = modeId.equals(state.workMode);
            JToggleButton tb = new JToggleButton(labels[m], selected);
            tb.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 10));
            tb.setForeground(selected ? java.awt.Color.WHITE : Colors.TEXT_DIM);
            tb.setBackground(selected ? colors[m] : new java.awt.Color(30, 30, 42));
            tb.setFocusPainted(false);
            tb.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createLineBorder(new java.awt.Color(55, 55, 75), 1),
                javax.swing.BorderFactory.createEmptyBorder(2, 8, 2, 8)));

            final int mIdx = m;
            tb.addActionListener(e -> {
                state.workMode = modeId;
                // Update all button colours in this strip
                for (java.awt.Component c : strip.getComponents()) {
                    if (c instanceof JToggleButton) {
                        JToggleButton b = (JToggleButton) c;
                        boolean sel = modeId.equals(b.getActionCommand());
                        // ActionCommand not set — use selection state
                    }
                }
            });
            tb.setActionCommand(modeId);

            // Visual feedback on selection change
            tb.addItemListener(ev -> {
                boolean sel = tb.isSelected();
                tb.setForeground(sel ? java.awt.Color.WHITE : Colors.TEXT_DIM);
                tb.setBackground(sel ? colors[mIdx] : new java.awt.Color(30, 30, 42));
            });

            group.add(tb);
            strip.add(tb);
        }

        // Office rep + promotion progress compact display
        if (state.officeRep > 0 || state.promotionProgress > 0) {
            strip.add(javax.swing.Box.createHorizontalStrut(12));
            JLabel repLabel = new JLabel("Rep: " + state.officeRep
                + "  Promo: " + state.promotionProgress + "%");
            repLabel.setFont(Colors.SANS_SMALL);
            repLabel.setForeground(state.officeRep < 30
                ? new java.awt.Color(200, 80, 80)
                : new java.awt.Color(100, 160, 100));
            strip.add(repLabel);
        }

        return strip;
    }

    private JComboBox<String> buildCombo(int blockIdx) {
        JComboBox<String> combo = new JComboBox<>();
        styleCombo(combo);
        populateCombo(combo, blockIdx);

        combo.addActionListener(e -> {
            if (combo.getSelectedItem() == null) return;
            String selected = (String) combo.getSelectedItem();
            String actId = labelToId.get(selected);
            if (actId == null) return;

            // Check if it's a job
            JobData job = jobs.get(actId);
            ActivityData act = activities.get(actId);
            int slotsNeeded = (job != null) ? job.slots_per_day
                            : (act != null) ? act.slots : 1;

            // Clear downstream blocked slots
            for (int j = blockIdx + 1; j < TOTAL_BLOCKS; j++) {
                if (BLOCKED.equals(slots[j])) slots[j] = STAY_HOME; else break;
            }

            slots[blockIdx] = actId;

            // Block subsequent slots if multi-block
            for (int j = 1; j < slotsNeeded && (blockIdx + j) < TOTAL_BLOCKS; j++) {
                slots[blockIdx + j] = BLOCKED;
            }

            refreshCombos();
        });

        return combo;
    }

    private void populateCombo(JComboBox<String> combo, int blockIdx) {
        combo.removeAllItems();

        if (BLOCKED.equals(slots[blockIdx])) {
            combo.addItem("↑  continuing...");
            combo.setEnabled(false);
            return;
        }
        combo.setEnabled(true);

        // Build item list grouped by category
        List<ActivityData> available = activities.availableAt(blockIdx + 1, state);

        // Always show Stay Home first
        String stayLabel = "🏠 Stay Home";
        labelToId.put(stayLabel, STAY_HOME);
        combo.addItem(stayLabel);

        // Group by category
        Map<String, List<ActivityData>> byCategory = new LinkedHashMap<>();
        for (ActivityData a : available) {
            if (a.id.equals(STAY_HOME)) continue;
            byCategory.computeIfAbsent(a.category, k -> new ArrayList<>()).add(a);
        }

        for (Map.Entry<String, List<ActivityData>> entry : byCategory.entrySet()) {
            combo.addItem("── " + entry.getKey() + " ──");
            for (ActivityData a : entry.getValue()) {
                String label = a.label + (a.slots > 1 ? " (" + a.slots * 2 + " hrs)" : "");
                labelToId.put(label, a.id);
                combo.addItem(label);
            }
        }

        // Add discovered locations as activity shortcuts
        if (!state.discoveredLocations.isEmpty()) {
            List<String> discLabels = new java.util.ArrayList<>();
            for (java.util.Map.Entry<String,String> e : DISCOVERABLE_ACTS.entrySet()) {
                String traitNeeded = e.getKey();   // e.g. "found_mall"
                String actId       = e.getValue(); // e.g. "go_to_mall"
                if (!state.hasTrait(traitNeeded)) continue;
                // Check the activity exists and fits in this slot
                game.data.ActivityData discAct = activities.get(actId);
                if (discAct == null || blockIdx + 1 < discAct.min_slot
                        || blockIdx + 1 > discAct.max_slot) continue;
                String lbl = "📍 " + discAct.label + (discAct.slots > 1 ? " (" + discAct.slots * 2 + " hrs)" : "");
                labelToId.put(lbl, actId);
                discLabels.add(lbl);
            }
            if (!discLabels.isEmpty()) {
                combo.addItem("── Discovered ──");
                for (String lbl : discLabels) combo.addItem(lbl);
            }
        }

        // Add timed event activities (disappear when trait expires)
        {
            java.util.List<String> evtLabels = new java.util.ArrayList<>();
            for (java.util.Map.Entry<String,String> e : TIMED_EVENTS.entrySet()) {
                if (!state.timedTraits.containsKey(e.getKey())) continue;
                game.data.ActivityData evtAct = activities.get(e.getValue());
                if (evtAct == null || blockIdx + 1 < evtAct.min_slot
                        || blockIdx + 1 > evtAct.max_slot) continue;
                int daysLeft = state.timedTraits.get(e.getKey()) - state.dayCount;
                String lbl = "⏳ " + evtAct.label + " (" + daysLeft + "d left)";
                labelToId.put(lbl, e.getValue());
                evtLabels.add(lbl);
            }
            if (!evtLabels.isEmpty()) {
                combo.addItem("── Limited ──");
                for (String lbl : evtLabels) combo.addItem(lbl);
            }
        }

        // Add job option in first block if it's a work day
        if (blockIdx == 0 && state.currentJobId != null) {
            JobData job = jobs.get(state.currentJobId);
            if (job != null && jobs.isWorkDay(state.currentJobId, state.getDayShort())) {
                combo.addItem("── Work ──");
                String payNote = job.under_the_table ? "cash $" + job.netPaycheck() : "+$" + job.netPaycheck() + " net";
                String jobLabel = job.label + " (" + (job.slots_per_day * 2) + " hrs, " + payNote + ")";
                labelToId.put(jobLabel, state.currentJobId);
                combo.addItem(jobLabel);
            }
        }

        // Select current slot value
        String currentId = slots[blockIdx];
        for (int i = 0; i < combo.getItemCount(); i++) {
            String item = combo.getItemAt(i);
            String mapped = labelToId.get(item);
            if (currentId.equals(mapped)) {
                combo.setSelectedIndex(i);
                break;
            }
        }
    }

    // Separator items not selectable
    private void styleCombo(JComboBox<String> combo) {
        combo.setBackground(new Color(32, 32, 52));
        combo.setForeground(Colors.TEXT);
        combo.setFont(Colors.SANS_PLAIN);
        combo.setBorder(BorderFactory.createLineBorder(Colors.BORDER, 1));
        combo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        combo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value,
                    int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                String s = value == null ? "" : value.toString();
                setBackground(isSelected ? Colors.ACCENT : new Color(32, 32, 52));
                setForeground(Colors.TEXT);
                if (s.startsWith("──") || s.startsWith("↑")) {
                    setForeground(Colors.TEXT_DIM);
                    setBackground(new Color(25, 25, 42));
                    setEnabled(false);
                }
                setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 10));
                return this;
            }
        });
        // Prevent selecting separator items
        combo.addActionListener(e -> {
            Object sel = combo.getSelectedItem();
            if (sel != null && (sel.toString().startsWith("──") || sel.toString().startsWith("↑"))) {
                combo.setSelectedIndex(0);
            }
        });
    }

    private void refreshCombos() {
        for (int i = 0; i < TOTAL_BLOCKS; i++) {
            populateCombo(combos[i], i);
        }
    }

    private JPanel buildSleepRow() {
        JPanel row = new JPanel(new BorderLayout(16, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        row.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));

        JLabel time = new JLabel("12:00 AM  –  8:00 AM");
        time.setForeground(new Color(55, 55, 80));
        time.setFont(Colors.SANS_SMALL);
        time.setPreferredSize(new Dimension(200, 20));

        JLabel sleep = new JLabel("  \uD83C\uDF19  Sleep");
        sleep.setForeground(new Color(55, 55, 80));
        sleep.setFont(Colors.SANS_SMALL);
        sleep.setBackground(new Color(22, 22, 35));
        sleep.setOpaque(true);
        sleep.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(35, 35, 55), 1),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)));

        row.add(time,  BorderLayout.WEST);
        row.add(sleep, BorderLayout.CENTER);
        return row;
    }

    // ── Process day ──────────────────────────────────────────────
    public List<String> processDay() {
        // Save today's selections so tomorrow pre-loads them
        state.lastDaySlots = Arrays.copyOf(slots, slots.length);
        List<String> scenes = new ArrayList<>();
        boolean jobDone         = false;
        boolean homeActivityDone = false; // first stay_home gets the activity menu; rest are silent

        for (int i = 0; i < TOTAL_BLOCKS; i++) {
            String id = slots[i];
            if (id == null || BLOCKED.equals(id)) continue;
            if (STAY_HOME.equals(id)) {
                ActivityData stayHome = activities.get(STAY_HOME);
                if (stayHome != null) {
                    for (Map.Entry<String,Integer> e : stayHome.stat_changes.entrySet())
                        state.changeStat(e.getKey(), e.getValue());
                    state.money += stayHome.money_change;
                }
                // First stay_home of the day gets the activity choice menu
                if (!homeActivityDone) {
                    scenes.add("home_activity_menu");
                    homeActivityDone = true;
                }
                // Subsequent stay_home slots: stats applied silently, no scene
                continue;
            }

            JobData job = jobs.get(id);
            if (job != null && !jobDone) {
                // Apply stat changes for working
                for (Map.Entry<String,Integer> e : job.stat_changes.entrySet())
                    state.changeStat(e.getKey(), e.getValue());

                // ── Work mode modifiers ─────────────────────────────────────
                switch (state.workMode) {
                    case "harder":
                        state.changeStat("stress",    4);
                        state.changeStat("willpower", -2);
                        state.changeStat("confidence", 1);
                        break;
                    case "slack":
                        state.changeStat("stress",    -5);
                        state.changeStat("happiness",  2);
                        break;
                    case "politics":
                        state.changeStat("stress",    2);
                        state.changeStat("confidence", 1);
                        break;
                    case "pranks":
                        state.changeStat("happiness",  4);
                        state.changeStat("stress",    -3);
                        break;
                }

                // Apply office rep and promotion progress
                if (state.currentJobId != null) {
                    int repDelta  = state.officeRepGainForMode();
                    boolean promo = state.applyPromotionGain(state.promotionGainForMode());
                    state.applyOfficeRepGain(repDelta);

                    // Promotion offered
                    if (promo) {
                        scenes.add("work_promotion_offered");
                        state.promotionProgress = 0;
                    }

                    // Work-mode specific scene chances
                    double modeChance = 0.18;
                    String modeScene  = pickWorkModeScene(state.workMode, id);
                    if (modeScene != null && Math.random() < modeChance)
                        scenes.add(modeScene);

                    // Monthly firing check — already inside currentJobId != null guard
                    if (state.isMonthlyRepCheckDue()) {
                        boolean lowRep     = state.officeRep < 20;
                        boolean trendBad   = state.monthlyRepGain <= -10;
                        if (lowRep || trendBad) scenes.add("work_hr_warning");
                        state.resetMonthlyRep();
                    }
                }

                // Record outfit worn today with boss
                if (job.boss_npc_id != null && !job.boss_npc_id.isEmpty()) {
                    state.setNpcMemory(job.boss_npc_id, "last_outfit", state.currentOutfitId());
                }

                // Track days worked toward paycheck
                state.daysWorkedThisPay++;

                // 1-in-5 chance of a work scene
                if (Math.random() < 0.20) {
                    String scene = pickWorkScene(id);
                    if (scene != null) scenes.add(scene);
                }

                // Determine if paycheck is due today
                boolean paydayToday = false;
                switch (job.pay_frequency.toUpperCase()) {
                    case "DAILY":
                        paydayToday = true;
                        break;
                    case "WEEKLY":
                        paydayToday = (state.daysWorkedThisPay >= job.daysPerWeek());
                        break;
                    case "BIWEEKLY":
                        paydayToday = (state.daysWorkedThisPay >= job.daysPerWeek() * 2);
                        break;
                    default:
                        paydayToday = (state.daysWorkedThisPay >= job.daysPerWeek());
                }

                if (paydayToday) {
                    // Base pay + any accumulated raise bonus
                    int effectivePayPerDay = job.pay_per_day + state.payPerDayBonus;
                    int daysInPeriod = state.daysWorkedThisPay; // about to be reset
                    // Recalculate net with raise applied
                    int gross = effectivePayPerDay * Math.max(1, daysInPeriod);
                    int tax   = job.under_the_table ? 0 : (int)Math.round(gross * taxRate(effectivePayPerDay * job.daysPerWeek() * 52));
                    state.money += Math.max(0, gross - tax);
                    state.daysWorkedThisPay = 0;
                    scenes.add("payday_notice"); // triggers a small payday notification scene
                }

                jobDone = true;
                continue;
            }

            ActivityData act = activities.get(id);
            if (act == null) continue;
            for (Map.Entry<String,Integer> e : act.stat_changes.entrySet())
                state.changeStat(e.getKey(), e.getValue());
            state.money += act.money_change;

            // Merge activity's declared triggers with bounce triggers into one pool.
            // Single roll — one event fires or nothing does.
            java.util.List<game.data.TriggerData> pool = new java.util.ArrayList<>(act.possible_triggers);
            pool.addAll(bounce.buildTriggers(id));
            pool.addAll(outfit.buildTriggers(id));

            if (!pool.isEmpty()) {
                String triggered = engine.resolveTriggers(pool);
                if (triggered != null) {
                    // Apply bounce stat effects only if a bounce scene won the roll
                    if (bounce.isBounceScene(triggered)) bounce.applyBounceStats();
                    scenes.add(triggered);
                }
            }

            // Legacy single trigger / special tokens
            if ("find_work".equals(id)) {
                scenes.add("__find_jobs__");
            } else if ("shopping".equals(id)) {
                scenes.add("__shopping__");
            } else if (act.triggers_scene != null && !act.triggers_scene.isEmpty()
                       && act.possible_triggers.isEmpty()) {
                scenes.add(act.triggers_scene);
            }
        }

        // ── Walking home at night ─────────────────────────────────────
        // Still handled structurally (checks last active slot time) but the
        // roll itself is driven by a trigger pool collected from late activities.
        int lastActiveSlot = -1;
        String lastActiveId = null;
        for (int i = 0; i < TOTAL_BLOCKS; i++) {
            String id = slots[i];
            if (id != null && !STAY_HOME.equals(id) && !BLOCKED.equals(id)) {
                lastActiveSlot = i;
                lastActiveId   = id;
            }
        }

        if (lastActiveSlot >= 5) {  // slot 6+ = 8pm or later
            boolean goingHome = true;
            for (int i = lastActiveSlot + 1; i < TOTAL_BLOCKS; i++) {
                if (!STAY_HOME.equals(slots[i]) && !BLOCKED.equals(slots[i])) {
                    goingHome = false; break;
                }
            }
            if (goingHome && lastActiveId != null) {
                // Collect walking_home_night triggers from the last active activity
                ActivityData lastAct = activities.get(lastActiveId);
                if (lastAct != null) {
                    java.util.List<game.data.TriggerData> nightTriggers = new java.util.ArrayList<>();
                    for (game.data.TriggerData t : lastAct.possible_triggers) {
                        if ("walking_home_night".equals(t.scene_id)) nightTriggers.add(t);
                    }
                    // Fallback: if activity has no explicit walking_home_night trigger,
                    // use a default 30% chance (weight=3, mult=3 → 1 in 3 = 33%)
                    if (nightTriggers.isEmpty()) {
                        game.data.TriggerData def = new game.data.TriggerData();
                        def.scene_id = "walking_home_night";
                        def.weight   = 3;
                        def.nothing_multiplier = 3;
                        nightTriggers.add(def);
                    }
                    String nightScene = engine.resolveTriggers(nightTriggers);
                    if (nightScene != null) scenes.add(nightScene);
                }
            }
        }

        // Sleep scene is last — player may relieve arousal before
        // advanceDay() applies the arousal→stress conversion.
        // advanceDay() is called by GameWindow after home_sleep completes.
        scenes.add("home_sleep");
        return scenes;
    }

    private static final java.util.Map<String, String[]> WORK_SCENES = new java.util.HashMap<>();
    // Locations discovered by explore → activity they unlock
    private static final java.util.Map<String, String> DISCOVERABLE_ACTS = new java.util.LinkedHashMap<>();
    // Timed event traits → activity they temporarily unlock
    private static final java.util.Map<String, String> TIMED_EVENTS = new java.util.LinkedHashMap<>();
    static {
        DISCOVERABLE_ACTS.put("found_mall",     "go_to_mall");
        DISCOVERABLE_ACTS.put("found_library",  "visit_library");
        DISCOVERABLE_ACTS.put("found_bookshop", "visit_bookshop");
        DISCOVERABLE_ACTS.put("found_gym",      "visit_gym");
        DISCOVERABLE_ACTS.put("found_tattoo",   "visit_tattoo");
        DISCOVERABLE_ACTS.put("found_restaurant","visit_restaurant");
        DISCOVERABLE_ACTS.put("found_strip_club",  "visit_strip_club");
        DISCOVERABLE_ACTS.put("found_sex_shop",    "visit_sex_shop");
        DISCOVERABLE_ACTS.put("found_shoe_store",  "visit_shoe_store");
        DISCOVERABLE_ACTS.put("found_furniture",   "visit_furniture_store");
        DISCOVERABLE_ACTS.put("found_narrows_clinic", "visit_clinic");
        DISCOVERABLE_ACTS.put("found_club",        "visit_club");
        // Timed events
        TIMED_EVENTS.put("evt_whale_watch",     "whale_watching_trip");
        TIMED_EVENTS.put("evt_seasonal_rave",   "seasonal_rave");
    }
    static {
        WORK_SCENES.put("velvet_cafe",          new String[]{"velvet_cafe_coworker_chat", "velvet_cafe_equipment_mishap", "velvet_cafe_rush_hour", "velvet_cafe_slow_morning", "velvet_cafe_regular", "velvet_cafe_closing_shift", "velvet_cafe_walkout", "velvet_cafe_end_of_day", "velvet_cafe_tommy_banter"});
        WORK_SCENES.put("skyline_office",       new String[]{"skyline_coworker_chat", "skyline_printer_incident", "skyline_richard_visit", "skyline_dev_confession", "skyline_office_birthday", "skyline_stay_late", "skyline_richard_expectant", "skyline_richard_expectant_cold", "skyline_dev_confession_b"});
        WORK_SCENES.put("neon_fitness",         new String[]{"neon_member_complaint", "neon_equipment_mishap", "neon_cover_shift", "neon_cam_vents", "neon_jake_feedback", "neon_medical_scare", "neon_member_number", "neon_fitness_keisha_advice"});
        WORK_SCENES.put("library",              new String[]{"library_quiet_hour", "library_difficult_patron", "library_grace_chat", "library_school_visit", "library_find_rare_book", "library_sam_recommendation"});
        WORK_SCENES.put("bookshop",             new String[]{"bookshop_slow_morning", "bookshop_difficult_customer", "bookshop_eli_b_recommendation", "bookshop_stock_day", "bookshop_saturday_rush", "bookshop_closing", "bookshop_petra_chat"});
        WORK_SCENES.put("restaurant_kitchen",   new String[]{"kitchen_dinner_rush", "kitchen_antonio_teaches", "kitchen_after_service", "kitchen_food_waste", "kitchen_prep", "kitchen_service_rush", "kitchen_slow_service", "kitchen_rosa_moment"});
        WORK_SCENES.put("tattoo_studio",        new String[]{"tattoo_studio_quiet_day", "tattoo_studio_nervous_client", "tattoo_studio_violet_shows_work", "tattoo_studio_consultation", "tattoo_studio_end_of_day", "tattoo_kai_consultation"});
        WORK_SCENES.put("bar_staff",            new String[]{"bar_staff_friday_night", "bar_staff_awkward_patron", "bar_staff_slow_tuesday", "bar_staff_regular_patron", "bar_staff_staff_meeting", "bar_staff_end_shift"});
        WORK_SCENES.put("cafe",                 new String[]{"cafe_morning_rush", "cafe_regular_patron", "cafe_equipment_problem", "cafe_coworker_chat", "cafe_difficult_order"});
        WORK_SCENES.put("cafe_morning",       new String[]{"cafe_morning_rush", "cafe_morning_slow", "cafe_morning_freya_chat"});
        WORK_SCENES.put("retail",               new String[]{"retail_saturday", "retail_difficult_return", "retail_end_of_day", "retail_inventory", "retail_awkward_coworker", "retail_awkward_customer", "retail_good_day"});
        WORK_SCENES.put("office_admin",         new String[]{"office_admin_inbox", "office_admin_scheduling_crisis", "office_admin_helen_chat", "office_admin_nina_project", "office_admin_filing", "office_admin_difficult_email", "office_admin_front_desk", "office_admin_end_of_day"});
    }

    private String pickWorkScene(String jobId) {
        String[] pool = WORK_SCENES.get(jobId);
        if (pool == null || pool.length == 0) return null;

        // Filter to scenes not yet seen for this job
        java.util.List<String> unseen = new java.util.ArrayList<>();
        for (String s : pool) {
            if (!state.visitedScenes.contains(s)) unseen.add(s);
        }

        // All scenes seen — reset this job's visited set and use full pool
        if (unseen.isEmpty()) {
            for (String s : pool) state.visitedScenes.remove(s);
            for (String s : pool) unseen.add(s);
        }

        String scene = unseen.get((int)(Math.random() * unseen.size()));

        // Richard visit — check NPC memory for expectant behaviour
        if ("skyline_richard_visit".equals(scene)) {
            if (state.hasNpcMemory("richard", "flashed_boss")) {
                boolean hasBra  = state.outfitBra != null;
                boolean hasTop  = state.outfitUpper != null || state.outfitOvercoat != null;
                boolean conservative = hasBra && hasTop;
                return conservative ? "skyline_richard_expectant_cold" : "skyline_richard_expectant";
            }
        }
        return scene;
    }

    public void resetForNewDay() {
        dayLabel.setText(state.getDayName() + "  —  Day " + state.dayCount + "  " + state.getSeasonEmoji() + " " + state.getSeasonName());
        initSlots();
        refreshCombos();
    }

    private String pickWorkModeScene(String mode, String jobId) {
        switch (mode) {
            case "harder":
                // 50% generic, 50% job-specific harder scene
                if (Math.random() < 0.5) return "work_mode_harder_praised";
                return null;
            case "slack":
                double r = Math.random();
                if (r < 0.30) return "work_mode_slack_caught";    // caught!
                if (r < 0.55) return "work_mode_slack_close_call"; // nearly caught
                return null;
            case "politics":
                double p = Math.random();
                if (p < 0.35) return "work_mode_politics_favor";
                if (p < 0.55) return "work_mode_politics_gossip";
                return null;
            case "pranks":
                return Math.random() < 0.5 ? "work_mode_prank_small" : "work_mode_prank_backfire";
            default:
                return null;
        }
    }


    private String buildMoneyInfoLine() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("💰  $%,d", state.money));
        if (state.rent > 0) {
            int dailyRent = (int) Math.round(state.rent / 30.0);
            sb.append(String.format("  ·  Rent $%d/mo (~$%d/day)", state.rent, dailyRent));
        }
        if (state.money < 300) sb.append("  ⚠ Low funds");
        return sb.toString();
    }

    /** Compact context line: season · neighbourhood · job · promotion */
    private String buildContextLine() {
        java.util.List<String> parts = new java.util.ArrayList<>();
        // Season + emoji
        parts.add(state.getSeasonEmoji() + " " + state.getSeasonName());
        // Neighbourhood
        if (state.currentNeighbourhood != null && !state.currentNeighbourhood.isEmpty())
            parts.add(state.currentNeighbourhood);
        // Job + pay bonus
        if (state.currentJobId != null) {
            game.data.JobData job = jobs.get(state.currentJobId);
            String jobName = job != null ? job.label : state.currentJobId.replace("_"," ");
            String extra = state.payPerDayBonus > 0 ? " (+" + state.payPerDayBonus + "/day raise)" : "";
            parts.add("📋 " + jobName + extra);
            // Promo progress if non-zero
            if (state.promotionProgress > 0)
                parts.add("⬆ Promo " + state.promotionProgress + "%");
        } else {
            parts.add("Unemployed");
        }
        return String.join("  ·  ", parts);
    }

    // ── Confirm button ───────────────────────────────────────────
    private JButton makeConfirmBtn() {
        JButton btn = new JButton("✅  Confirm Day") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(85, 65, 165));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                super.paintComponent(g);
            }
        };
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 42));
        btn.setContentAreaFilled(false); btn.setBorderPainted(false); btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(12, 44, 12, 44));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> onDayEnd.run());
        return btn;
    }
    private double taxRate(int annualGross) {
        return game.GameState.taxRateForAnnual(annualGross);
    }

}
