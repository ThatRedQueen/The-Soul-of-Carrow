package game;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Central registry for mod-supplied image and animation assets.
 *
 * Supported formats: PNG, JPG/JPEG, GIF (including animated GIFs).
 *
 * Asset IDs are scoped by mod: "mod_id:asset_id"
 * but scenes can reference them without the mod prefix if unambiguous.
 *
 * A mod declares assets in mod.yml:
 *   assets:
 *     scene_image_bar_night: images/bar_night.png
 *     character_portrait:    images/mc_portrait.png
 *     sidebar_background:    images/sidebar_bg.png
 *     animation_walk:        images/walk.gif
 *
 * A scene can then reference an asset via:
 *   image: scene_image_bar_night
 *   image_position: top    # top | left | right (default: top)
 *   image_height: 200      # optional pixel height cap
 */
public class AssetManager {

    // ── Sidebar config keys (set by mods) ─────────────────────────────────────
    /** Image shown behind the stats sidebar. Null = no image. */
    public ImageIcon sidebarBackground   = null;
    /** Character portrait shown at the top of the sidebar. */
    public ImageIcon characterPortrait   = null;
    /** Accent color for sidebar headers (CSS hex string, or null for theme default). */
    public String    sidebarAccentColor  = null;
    /** If true, sidebar is partially transparent (requires sidebarBackground). */
    public boolean   sidebarTransparent  = false;

    // ── Image cache ───────────────────────────────────────────────────────────
    private final Map<String, ImageIcon> cache      = new ConcurrentHashMap<>();
    private final Map<String, String>    assetPaths = new LinkedHashMap<>();   // assetId → absolute file path
    private final Set<String>            failed     = new HashSet<>();

    // Max image dimensions (prevent giant images from wrecking the layout)
    public static final int MAX_SCENE_IMG_W = 800;
    public static final int MAX_SCENE_IMG_H = 400;
    public static final int MAX_PORTRAIT_W  = 200;
    public static final int MAX_PORTRAIT_H  = 280;
    public static final int MAX_SIDEBAR_W   = 240;
    public static final int MAX_SIDEBAR_H   = 600;

    // ── Registration ──────────────────────────────────────────────────────────

    /**
     * Register an asset from a mod.
     * @param modId    the mod's folder name (namespace)
     * @param assetId  the key declared in mod.yml assets block
     * @param filePath absolute path to the image file
     */
    public void register(String modId, String assetId, String filePath) {
        // Store under both namespaced and bare key (bare wins last-write)
        String nsKey   = modId + ":" + assetId;
        String bareKey = assetId;
        assetPaths.put(nsKey,   filePath);
        assetPaths.put(bareKey, filePath);
        // Invalidate cache entry if previously loaded
        cache.remove(nsKey);
        cache.remove(bareKey);
        failed.remove(nsKey);
        failed.remove(bareKey);
    }

    /**
     * Apply sidebar config from a mod's sidebar.yml.
     * Keys understood:
     *   background_asset: id    → sets sidebarBackground
     *   portrait_asset:   id    → sets characterPortrait
     *   accent_color:     #rrggbb
     *   transparent:      true/false
     */
    public void applySidebarConfig(Map<String, Object> cfg) {
        if (cfg == null) return;
        Object bg = cfg.get("background_asset");
        if (bg != null) sidebarBackground  = get(bg.toString(), MAX_SIDEBAR_W, MAX_SIDEBAR_H);
        Object portrait = cfg.get("portrait_asset");
        if (portrait != null) characterPortrait = get(portrait.toString(), MAX_PORTRAIT_W, MAX_PORTRAIT_H);
        Object accent = cfg.get("accent_color");
        if (accent != null) sidebarAccentColor = accent.toString().trim();
        Object trans = cfg.get("transparent");
        if (trans != null) sidebarTransparent = Boolean.TRUE.equals(trans)
                                              || "true".equalsIgnoreCase(trans.toString());
    }

    // ── Retrieval ─────────────────────────────────────────────────────────────

    /**
     * Get a cached ImageIcon by asset ID, scaled to fit within maxW × maxH.
     * Returns null if the asset ID is not registered, the file is missing, or the format is unsupported.
     */
    public ImageIcon get(String assetId, int maxW, int maxH) {
        if (assetId == null || assetId.isEmpty()) return null;
        String cacheKey = assetId + "@" + maxW + "x" + maxH;
        ImageIcon cached = cache.get(cacheKey);
        if (cached != null) return cached;
        if (failed.contains(assetId)) return null;

        String filePath = assetPaths.get(assetId);
        if (filePath == null) return null;   // not registered

        File file = new File(filePath);
        if (!file.exists()) {
            System.err.println("[AssetManager] Missing file for asset '" + assetId + "': " + filePath);
            failed.add(assetId);
            return null;
        }

        try {
            ImageIcon icon = loadImage(file, maxW, maxH);
            if (icon != null) {
                cache.put(cacheKey, icon);
                return icon;
            }
        } catch (Exception e) {
            System.err.println("[AssetManager] Failed to load '" + assetId + "': " + e.getMessage());
        }
        failed.add(assetId);
        return null;
    }

    /** Convenience: get scene image at standard scene dimensions. */
    public ImageIcon getSceneImage(String assetId) {
        return get(assetId, MAX_SCENE_IMG_W, MAX_SCENE_IMG_H);
    }

    /** True if the ID is registered (file may still fail to load). */
    public boolean has(String assetId) {
        return assetId != null && assetPaths.containsKey(assetId);
    }

    // ── Image loading ─────────────────────────────────────────────────────────

    private ImageIcon loadImage(File file, int maxW, int maxH) throws IOException {
        String name = file.getName().toLowerCase();

        // Animated GIFs — load via ImageIcon directly to preserve animation frames.
        // ImageIcon(URL) loads asynchronously; we wait for it with MediaTracker.
        if (name.endsWith(".gif")) {
            ImageIcon raw = new ImageIcon(file.toURI().toURL());
            // Wait for image data to be available (non-blocking with timeout)
            java.awt.MediaTracker tracker = new java.awt.MediaTracker(new java.awt.Canvas());
            tracker.addImage(raw.getImage(), 0);
            try { tracker.waitForID(0, 3000); } catch (InterruptedException ignored) {}
            if (raw.getIconWidth() <= 0) return null;
            return scaledIcon(raw, maxW, maxH);
        }

        // Static images (PNG, JPG, JPEG, BMP, WEBP if supported)
        BufferedImage img = ImageIO.read(file);
        if (img == null) return null;
        Image scaled = scaleImage(img, maxW, maxH);
        return new ImageIcon(scaled);
    }

    private Image scaleImage(BufferedImage img, int maxW, int maxH) {
        int w = img.getWidth();
        int h = img.getHeight();
        if (w <= maxW && h <= maxH) return img;   // already fits
        double scale = Math.min((double) maxW / w, (double) maxH / h);
        int nw = Math.max(1, (int)(w * scale));
        int nh = Math.max(1, (int)(h * scale));
        return img.getScaledInstance(nw, nh, Image.SCALE_SMOOTH);
    }

    /**
     * Scale an ImageIcon to fit within maxW × maxH.
     * For GIFs: uses SCALE_DEFAULT to preserve animation frame timing.
     * If already fits, returns the icon unchanged.
     */
    private ImageIcon scaledIcon(ImageIcon raw, int maxW, int maxH) {
        int w = raw.getIconWidth();
        int h = raw.getIconHeight();
        if (w <= maxW && h <= maxH) return raw;  // already fits, no scaling needed
        double scale = Math.min((double) maxW / w, (double) maxH / h);
        int nw = Math.max(1, (int)(w * scale));
        int nh = Math.max(1, (int)(h * scale));
        // SCALE_DEFAULT preserves GIF animation frames (SCALE_SMOOTH breaks animation)
        Image scaled = raw.getImage().getScaledInstance(nw, nh, Image.SCALE_DEFAULT);
        return new ImageIcon(scaled);
    }

    // ── Debug ─────────────────────────────────────────────────────────────────

    public int registeredCount() { return assetPaths.size() / 2; }  // /2 for bare+ns keys

    public void dump() {
        System.out.println("[AssetManager] Registered assets: " + registeredCount());
        for (Map.Entry<String, String> e : assetPaths.entrySet())
            if (!e.getKey().contains(":"))   // bare keys only
                System.out.println("  " + e.getKey() + " → " + e.getValue());
    }
}
