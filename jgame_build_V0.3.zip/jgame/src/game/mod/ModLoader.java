package game.mod;

import game.CrashReporter;
import game.SceneLoader;
import game.NpcLoader;
import game.ClothingLoader;
import game.JobLoader;
import game.data.*;
import game.AssetManager;
import game.ArtworkHookManager;
import game.AudioManager;
import game.TextPoolRegistry;
import org.yaml.snakeyaml.Yaml;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Discovers mods in the mods/ directory and injects their content
 * into the game's loaders. Reports detailed errors per mod.
 *
 * Load order: mods are loaded alphabetically. Later mods override
 * earlier ones on ID collision (last-write-wins), with a warning.
 *
 * Thread safety: call from main thread before game starts.
 */
public class ModLoader {

    /**
     * Returns true if the given file is safely inside the expected root directory.
     * Prevents symlink attacks and path traversal (../../etc/passwd style).
     */
    private static boolean isSafeModPath(File root, File file) {
        try {
            String rootCanon = root.getCanonicalPath();
            String fileCanon = file.getCanonicalPath();
            return fileCanon.startsWith(rootCanon + File.separator) || fileCanon.equals(rootCanon);
        } catch (java.io.IOException e) {
            return false; // if we can't resolve it, don't trust it
        }
    }

    private final File              modsDir;
    private final SceneLoader       scenes;
    private final NpcLoader         npcs;
    private final ClothingLoader    clothes;
    private final JobLoader         jobs;
    private final List<Mod>         loaded      = new ArrayList<>();
    private final java.util.Set<String> loadedIds  = new java.util.HashSet<>();
    private final Set<String>       allSceneIds;
    private       AssetManager      assetManager    = null;
    private       ArtworkHookManager artworkManager = null;
    private       AudioManager      audioManager    = null;
    private       TextPoolRegistry  textPools       = null;  // existing scene IDs before mod load

    public ModLoader(String gameDir, SceneLoader scenes, NpcLoader npcs,
                     ClothingLoader clothes, JobLoader jobs) {
        this.modsDir  = new File(gameDir, "mods");
        this.scenes   = scenes;
        this.npcs     = npcs;
        this.clothes  = clothes;
        this.jobs     = jobs;
        this.allSceneIds = new HashSet<>(scenes.allIds());
    }

    /** Inject ModSettings so enabled/disabled state is respected at load time. */
    public void setModSettings(ModSettings s) { this.settings = s; }

    /** Inject the AssetManager so mods can register image assets. */
    public void setAssetManager(AssetManager am) { this.assetManager = am; }
    public void setArtworkManager(ArtworkHookManager am) { this.artworkManager = am; }
    public void setAudioManager(AudioManager am)         { this.audioManager   = am; }
    public void setTextPoolRegistry(TextPoolRegistry tp) { this.textPools       = tp; }

    /** Discover and load all mods. Returns list of loaded mods (with status). */
    public List<Mod> loadAll() {
        if (!modsDir.exists() || !modsDir.isDirectory()) {
            System.out.println("[ModLoader] No mods/ directory found — skipping.");
            return loaded;
        }

        File[] modFolders = modsDir.listFiles(File::isDirectory);
        if (modFolders == null || modFolders.length == 0) {
            System.out.println("[ModLoader] No mods found.");
            return loaded;
        }

        Arrays.sort(modFolders, Comparator.comparing(File::getName));

        for (File folder : modFolders) {
            // Detect modpack: a folder containing modpack.yml acts as a container
            // of sub-mods rather than being a mod itself
            File modpackYml = new File(folder, "modpack.yml");
            if (modpackYml.exists()) {
                loadModpack(folder, modpackYml);
                continue;
            }
            // Check if mod is disabled before doing any loading work
            String modId = folder.getName();
            boolean isEnabled = (settings == null) || settings.isEnabled(modId);
            if (!isEnabled) {
                // Create a stub Mod for display in the Mod Manager — don't load its content
                Mod stub = new Mod();
                stub.id      = modId;
                stub.name    = modId;
                stub.folder  = folder;
                stub.enabled = false;
                stub.skipped = true;
                // Still read metadata so the name/author/version show in Mod Manager
                File stubMeta = new File(folder, "mod.yml");
                if (stubMeta.exists()) readMeta(stub, stubMeta);
                stub.finaliseStatus();
                loaded.add(stub);
                System.out.printf("[ModLoader] %s — DISABLED (skipped)%n", stub);
                continue;
            }
            try {
                Mod mod = loadMod(folder);
                if (!loadedIds.add(mod.id)) {
                    mod.addWarning("mod.yml", "Mod ID '" + mod.id + "' already loaded — this mod overrides the earlier one.");
                    System.out.printf("[ModLoader] WARNING: duplicate mod ID '%s' — overriding previous%n", mod.id);
                }
                loaded.add(mod);
                System.out.printf("[ModLoader] %s — scenes:%d npcs:%d clothes:%d jobs:%d assets:%d art:%d text:%d audio:%d errors:%d%n",
                    mod, mod.scenesLoaded, mod.npcsLoaded, mod.clothesLoaded, mod.jobsLoaded,
                    mod.assetsLoaded, mod.artworkHooks, mod.textEntries, mod.audioTracks, mod.errors.size());
            } catch (Exception e) {
                Mod failed = new Mod();
                failed.id     = folder.getName();
                failed.name   = folder.getName();
                failed.folder = folder;
                failed.addError("(loader)", "Unexpected error: " + e.getMessage());
                failed.status = Mod.Status.FAILED;
                loaded.add(failed);
                CrashReporter.reportError("ModLoader failed on: " + folder.getName(), e);
            }
        }

        writeErrorLogs();
        return loaded;
    }

    public List<Mod> getMods() { return Collections.unmodifiableList(loaded); }

    // ── Per-mod loading ───────────────────────────────────────────────────────

    private Mod loadMod(File folder) {
        Mod mod  = new Mod();
        mod.id   = folder.getName();
        mod.name = folder.getName();
        mod.folder = folder;

        // 1. Read mod.yml metadata (optional but recommended)
        File metaFile = new File(folder, "mod.yml");
        if (metaFile.exists()) {
            readMeta(mod, metaFile);
        } else {
            mod.addWarning("mod.yml", "No mod.yml found. Add one for name, author, version info.");
        }

        // 2. Load scenes
        File scenesDir = new File(folder, "scenes");
        if (scenesDir.exists()) loadScenes(mod, scenesDir);

        // 3. Load NPCs
        File npcsDir = new File(folder, "npcs");
        if (npcsDir.exists()) loadNpcs(mod, npcsDir);

        // 4. Load clothing
        File clothesDir = new File(folder, "clothes");
        if (clothesDir.exists()) loadClothes(mod, clothesDir);

        // 5. Load jobs
        File jobsDir = new File(folder, "jobs");
        if (jobsDir.exists()) loadJobs(mod, jobsDir);

        // 6. Load assets (images, sprites, animations) + sidebar config
        if (assetManager != null) {
            loadAssets(mod, folder);
            File sidebarYml = new File(folder, "sidebar.yml");
            if (sidebarYml.exists()) loadSidebarConfig(mod, sidebarYml);
        }

        // 7. Artwork hooks (dynamic state-based images)
        File artworkYml = new File(folder, "artwork.yml");
        if (artworkYml.exists()) loadArtwork(mod, artworkYml);

        // 8. Text pool additions/suppressions
        File textPoolsDir = new File(folder, "text_pools");
        if (textPoolsDir.isDirectory()) loadTextPools(mod, textPoolsDir);

        // 9. Soundtrack
        File soundtrackYml = new File(folder, "soundtrack.yml");
        if (soundtrackYml.exists()) loadSoundtrack(mod, soundtrackYml);

        // 6. Post-load validation
        ModValidator.validate(mod, scenes, npcs);

        mod.finaliseStatus();
        return mod;
    }

    @SuppressWarnings("unchecked")
    private void readMeta(Mod mod, File file) {
        try (InputStream is = new FileInputStream(file)) {
            Map<String, Object> raw = (Map<String, Object>) new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions())).load(is);
            if (raw == null) { mod.addWarning("mod.yml", "Empty mod.yml"); return; }
            mod.name              = str(raw, "name",              mod.id);
            mod.author             = str(raw, "author",             "");
            mod.version            = str(raw, "version",            "");
            mod.description        = str(raw, "description",        "");
            mod.game_version_min   = str(raw, "game_version_min",   "");
            mod.game_version_max   = str(raw, "game_version_max",   "");
            mod.compatibility_note = str(raw, "compatibility_note", "");
        } catch (Exception e) {
            mod.addError("mod.yml", "Parse error: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void loadScenes(Mod mod, File dir) {
        for (File f : allYaml(dir)) {
            String relPath = "scenes/" + f.getName();
            if (!isSafeModPath(mod.folder, f)) {
                    System.err.println("[ModLoader] Skipping unsafe path: " + f.getPath());
                    continue;
                }
                try (InputStream is = new FileInputStream(f)) {
                Yaml yaml = new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions()));
                for (Object doc : yaml.loadAll(is)) {
                    if (!(doc instanceof Map)) continue;
                    Map<String, Object> raw = (Map<String, Object>) doc;
                    String id        = str(raw, "id", "");
                    String patchTarget = str(raw, "patch_scene", "");

                    if (!patchTarget.isEmpty()) {
                        // ── Patch mode: extend an existing scene ──────────
                        boolean ok = scenes.applyModPatch(raw, mod.id);
                        if (ok) mod.scenesLoaded++;
                        else    mod.addWarning(relPath,
                            "Patch targets unknown scene '" + patchTarget + "' — skipped.");
                        continue;
                    }

                    if (id.isEmpty()) {
                        mod.addWarning(relPath, "Scene missing 'id' or 'patch_scene' field — skipped.");
                        continue;
                    }
                    if (allSceneIds.contains(id)) {
                        mod.addWarning(relPath, "Scene '" + id + "' overrides a base game scene.");
                    }
                    // Inject into SceneLoader
                    boolean ok = scenes.injectModScene(raw, mod.id);
                    if (ok) { mod.scenesLoaded++; allSceneIds.add(id); }
                    else    mod.addError(relPath, "Failed to inject scene '" + id + "'");
                }
            } catch (Exception e) {
                mod.addError(relPath, "YAML parse error: " + e.getMessage());
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void loadNpcs(Mod mod, File dir) {
        for (File f : allYaml(dir)) {
            String relPath = "npcs/" + f.getName();
            if (!isSafeModPath(mod.folder, f)) {
                    System.err.println("[ModLoader] Skipping unsafe path: " + f.getPath());
                    continue;
                }
                try (InputStream is = new FileInputStream(f)) {
                Map<String, Object> raw = (Map<String, Object>) new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions())).load(is);
                if (raw == null) { mod.addWarning(relPath, "Empty NPC file."); continue; }

                String id = str(raw, "id", "");
                if (id.isEmpty()) {
                    mod.addError(relPath, "NPC missing required 'id' field.");
                    continue;
                }
                String type = str(raw, "type", "");
                if (type.isEmpty()) {
                    mod.addError(relPath, "NPC '" + id + "' missing 'type' (MALE/FEMALE).");
                    continue;
                }
                if (!type.equalsIgnoreCase("MALE") && !type.equalsIgnoreCase("FEMALE")) {
                    mod.addError(relPath, "NPC '" + id + "' has invalid type '" + type + "' — must be MALE or FEMALE.");
                    continue;
                }
                if (str(raw, "intro", "").isEmpty()) {
                    mod.addWarning(relPath, "NPC '" + id + "' has no intro text — bar description will be generic.");
                }

                boolean ok = npcs.injectModNpc(raw, mod.id);
                if (ok) mod.npcsLoaded++;
                else    mod.addError(relPath, "Failed to inject NPC '" + id + "'");

            } catch (Exception e) {
                mod.addError(relPath, "YAML parse error: " + e.getMessage());
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void loadClothes(Mod mod, File dir) {
        for (File f : allYaml(dir)) {
            String relPath = "clothes/" + f.getName();
            if (!isSafeModPath(mod.folder, f)) {
                    System.err.println("[ModLoader] Skipping unsafe path: " + f.getPath());
                    continue;
                }
                try (InputStream is = new FileInputStream(f)) {
                Map<String, Object> raw = (Map<String, Object>) new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions())).load(is);
                if (raw == null) { mod.addWarning(relPath, "Empty clothing file."); continue; }

                String id   = str(raw, "id", "");
                String slot = str(raw, "slot", "");
                if (id.isEmpty())   { mod.addError(relPath, "Clothing missing 'id' field."); continue; }
                if (slot.isEmpty()) { mod.addError(relPath, "Clothing '" + id + "' missing 'slot' (upper/lower/shoes/bra/underwear)."); continue; }
                List<String> validSlots = Arrays.asList("upper","lower","shoes","bra","underwear");
                if (!validSlots.contains(slot.toLowerCase())) {
                    mod.addWarning(relPath, "Clothing '" + id + "' slot '" + slot + "' is non-standard.");
                }

                boolean ok = clothes.injectModClothing(raw, mod.id);
                if (ok) mod.clothesLoaded++;
                else    mod.addError(relPath, "Failed to inject clothing '" + id + "'");

            } catch (Exception e) {
                mod.addError(relPath, "YAML parse error: " + e.getMessage());
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void loadJobs(Mod mod, File dir) {
        for (File f : allYaml(dir)) {
            String relPath = "jobs/" + f.getName();
            if (!isSafeModPath(mod.folder, f)) {
                    System.err.println("[ModLoader] Skipping unsafe path: " + f.getPath());
                    continue;
                }
                try (InputStream is = new FileInputStream(f)) {
                Map<String, Object> raw = (Map<String, Object>) new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions())).load(is);
                if (raw == null) { mod.addWarning(relPath, "Empty job file."); continue; }

                String id = str(raw, "id", "");
                if (id.isEmpty()) { mod.addError(relPath, "Job missing 'id' field."); continue; }
                if (!raw.containsKey("pay_per_day")) {
                    mod.addWarning(relPath, "Job '" + id + "' has no pay_per_day — will default to 0.");
                }

                boolean ok = jobs.injectModJob(raw, mod.id);
                if (ok) mod.jobsLoaded++;
                else    mod.addError(relPath, "Failed to inject job '" + id + "'");

            } catch (Exception e) {
                mod.addError(relPath, "YAML parse error: " + e.getMessage());
            }
        }
    }

    // ── Modpack loading ───────────────────────────────────────────────────────

    /**
     * A modpack folder contains modpack.yml and one or more sub-mod folders.
     * Each sub-folder with a mod.yml is loaded as an independent mod.
     * Sub-folders without mod.yml are skipped with a warning.
     */
    @SuppressWarnings("unchecked")
    private void loadModpack(File packFolder, File modpackYml) {
        String packName = packFolder.getName();
        System.out.println("[ModLoader] Loading modpack: " + packName);
        File[] subFolders = packFolder.listFiles(File::isDirectory);
        if (subFolders == null || subFolders.length == 0) {
            System.out.println("[ModLoader]   (empty modpack)");
            return;
        }
        Arrays.sort(subFolders, Comparator.comparing(File::getName));
        int count = 0;
        for (File sub : subFolders) {
            // Safety: ensure sub-folder is actually inside the pack folder
            if (!isSafeModPath(packFolder, sub)) {
                System.err.println("[ModLoader] Skipping unsafe sub-mod path: " + sub.getPath());
                continue;
            }
            // Each sub-folder that has a mod.yml (or any recognised content) is a mod
            // Allow sub-folders without mod.yml but with content (auto-named)
            File subMeta = new File(sub, "mod.yml");
            if (!subMeta.exists()) {
                // Check if it has any content worth loading
                boolean hasContent = new File(sub,"scenes").exists()
                    || new File(sub,"npcs").exists()
                    || new File(sub,"clothes").exists()
                    || new File(sub,"artwork.yml").exists()
                    || new File(sub,"soundtrack.yml").exists()
                    || new File(sub,"text_pools").exists();
                if (!hasContent) continue;
            }
            try {
                Mod mod = loadMod(sub);
                String subName = mod.name.isEmpty() ? mod.id : mod.name;
                mod.name = packName + " / " + subName;
                if (!loadedIds.add(mod.id)) {
                    mod.addWarning("mod.yml", "Mod ID '" + mod.id + "' already loaded.");
                }
                loaded.add(mod);
                count++;
            } catch (Exception e) {
                System.err.println("[ModLoader] Error loading sub-mod " + sub.getName()
                    + " in pack " + packName + ": " + e.getMessage());
            }
        }
        System.out.printf("[ModLoader] Modpack '%s' — loaded %d sub-mod(s)%n", packName, count);
    }

    // ── Artwork hook loading ───────────────────────────────────────────────────

    /**
     * Load artwork.yml from a mod folder.
     * artwork.yml declares condition-based hooks that show images based on game state.
     */
    @SuppressWarnings("unchecked")
    private void loadArtwork(Mod mod, File artworkYml) {
        if (artworkManager == null) return;
        try (InputStream is = new FileInputStream(artworkYml)) {
            Map<String,Object> raw = (Map<String,Object>) new Yaml(
                new org.yaml.snakeyaml.constructor.SafeConstructor(
                    new org.yaml.snakeyaml.LoaderOptions())).load(is);
            if (raw == null) return;
            Object hooks = raw.get("hooks");
            if (hooks instanceof List) {
                int before = artworkManager.hookCount();
                artworkManager.loadFromYaml((List<?>)hooks);
                mod.artworkHooks = artworkManager.hookCount() - before;
                System.out.printf("[ModLoader] %s — artwork: %d hook(s)%n", mod.id, mod.artworkHooks);
            }
        } catch (Exception e) {
            mod.addError("artwork.yml", "Failed to load artwork hooks: " + e.getMessage());
        }
    }

    // ── Text pool loading ──────────────────────────────────────────────────────

    /**
     * Load all YAML files from a mod's text_pools/ directory.
     *
     * Each file declares additions and suppressions for named pools:
     *
     *   pool: bar.grope.breast.shy_mc
     *   add:
     *     - id: shy_mc_grope_v1
     *       text: "You go rigid. His hand is — that's — you keep moving."
     *       weight: 2
     *     - "Your breath catches. You don't look at him."
     *   suppress:
     *     - shy_mc_grope_old_v3
     */
    @SuppressWarnings("unchecked")
    private void loadTextPools(Mod mod, File textPoolsDir) {
        if (textPools == null) return;
        int addCount = 0; int supCount = 0;
        for (File f : allYaml(textPoolsDir)) {
            String relPath = "text_pools/" + f.getName();
            try (InputStream is = new FileInputStream(f)) {
                Map<String,Object> raw = (Map<String,Object>) new Yaml(
                    new org.yaml.snakeyaml.constructor.SafeConstructor(
                        new org.yaml.snakeyaml.LoaderOptions())).load(is);
                if (raw == null) continue;
                String poolName = str(raw, "pool", "");
                if (poolName.isEmpty()) {
                    mod.addWarning(relPath, "Missing 'pool:' key — file skipped.");
                    continue;
                }
                Object addList = raw.get("add");
                if (addList instanceof List) {
                    int before = addCount;
                    textPools.addFromYaml(poolName, (List<?>)addList);
                    addCount += ((List<?>)addList).size();
                }
                Object supList = raw.get("suppress");
                if (supList instanceof List) {
                    List<String> ids = new ArrayList<>();
                    for (Object o : (List<?>)supList) if (o != null) ids.add(o.toString());
                    textPools.suppressAll(ids);
                    supCount += ids.size();
                }
            } catch (Exception e) {
                mod.addError(relPath, "Failed to load text pool: " + e.getMessage());
            }
        }
        mod.textEntries = addCount;
        if (addCount + supCount > 0)
            System.out.printf("[ModLoader] %s — text pools: +%d entries, -%d suppressions%n",
                mod.id, addCount, supCount);
    }

    // ── Soundtrack loading ─────────────────────────────────────────────────────

    /**
     * Load soundtrack.yml from a mod folder.
     */
    @SuppressWarnings("unchecked")
    private void loadSoundtrack(Mod mod, File soundtrackYml) {
        if (audioManager == null) return;
        try (InputStream is = new FileInputStream(soundtrackYml)) {
            Map<String,Object> raw = (Map<String,Object>) new Yaml(
                new org.yaml.snakeyaml.constructor.SafeConstructor(
                    new org.yaml.snakeyaml.LoaderOptions())).load(is);
            if (raw == null) return;
            Object tracks = raw.get("tracks");
            if (tracks instanceof List) {
                // Pre-screen track file paths for safety before passing to AudioManager
                List<Object> safeTrackList = new java.util.ArrayList<>();
                for (Object item : (java.util.List<?>)tracks) {
                    if (!(item instanceof java.util.Map)) continue;
                    java.util.Map<?,?> t = (java.util.Map<?,?>)item;
                    Object filePath = t.get("file");
                    if (filePath == null) continue;
                    java.io.File trackFile = new java.io.File(mod.folder, filePath.toString());
                    if (!isSafeModPath(mod.folder, trackFile)) {
                        mod.addError("soundtrack.yml",
                            "Path traversal blocked for track file: " + filePath);
                        continue;
                    }
                    // Also check format
                    String lc = filePath.toString().toLowerCase();
                    if (!lc.endsWith(".wav") && !lc.endsWith(".aiff")
                     && !lc.endsWith(".au")  && !lc.endsWith(".aif")) {
                        mod.addWarning("soundtrack.yml",
                            "Unsupported audio format (WAV/AIFF/AU only): " + filePath);
                        continue;
                    }
                    safeTrackList.add(item);
                }
                if (!safeTrackList.isEmpty()) {
                    audioManager.loadFromYaml(safeTrackList, mod.folder.getAbsolutePath());
                    mod.audioTracks += safeTrackList.size();
                    System.out.printf("[ModLoader] %s — soundtrack: %d track(s)%n",
                        mod.id, safeTrackList.size());
                }
            }
        } catch (Exception e) {
            mod.addError("soundtrack.yml", "Failed to load soundtrack: " + e.getMessage());
        }
    }

    // ── Asset loading ─────────────────────────────────────────────────────────

    /**
     * Load mod assets declared in mod.yml under an 'assets:' block.
     * Each entry: "asset_id: relative/path/to/file.png"
     * Supported formats: PNG, JPG, JPEG, GIF (animated GIFs supported).
     */
    @SuppressWarnings("unchecked")
    private void loadAssets(Mod mod, File modFolder) {
        // Read the assets block from mod.yml (already parsed into mod metadata)
        File metaFile = new File(modFolder, "mod.yml");
        if (!metaFile.exists()) return;
        try (InputStream is = new FileInputStream(metaFile)) {
            Map<String,Object> raw = (Map<String,Object>) new Yaml(
                new org.yaml.snakeyaml.constructor.SafeConstructor(
                    new org.yaml.snakeyaml.LoaderOptions())).load(is);
            if (raw == null) return;
            Object assetsObj = raw.get("assets");
            if (!(assetsObj instanceof Map)) return;
            Map<?,?> assets = (Map<?,?>) assetsObj;

            // Allowed image extensions
            Set<String> ALLOWED_EXT = new HashSet<>(Arrays.asList(
                ".png",".jpg",".jpeg",".gif",".bmp"));

            int count = 0;
            for (Map.Entry<?,?> e : assets.entrySet()) {
                String assetId  = e.getKey().toString().trim();
                String relPath  = e.getValue().toString().trim();

                // Security: no path traversal
                File assetFile = new File(modFolder, relPath);
                if (!isSafeModPath(modFolder, assetFile)) {
                    mod.addError("assets/" + relPath, "Path traversal blocked: " + relPath);
                    continue;
                }
                // Only allow image formats
                String lc = relPath.toLowerCase();
                boolean allowed = false;
                for (String ext : ALLOWED_EXT) if (lc.endsWith(ext)) { allowed = true; break; }
                if (!allowed) {
                    mod.addWarning("assets/" + relPath, "Unsupported asset format: " + relPath + " (PNG/JPG/GIF only)");
                    continue;
                }
                if (!assetFile.exists()) {
                    mod.addWarning("assets/" + relPath, "Asset file not found: " + relPath);
                    continue;
                }
                assetManager.register(mod.id, assetId, assetFile.getAbsolutePath());
                count++;
                mod.assetsLoaded++;
            }
            if (count > 0)
                System.out.printf("[ModLoader] %s — registered %d asset(s)%n", mod.id, count);
        } catch (Exception e) {
            mod.addError("mod.yml", "Failed to load assets block: " + e.getMessage());
        }
    }

    /**
     * Load a mod's sidebar.yml to configure the stats sidebar appearance.
     * sidebar.yml keys:
     *   background_asset: asset_id      # full-panel background image
     *   portrait_asset:   asset_id      # character portrait at top of sidebar
     *   accent_color:     "#rrggbb"     # hex color for section headers
     *   transparent:      true          # make sidebar semi-transparent
     */
    @SuppressWarnings("unchecked")
    private void loadSidebarConfig(Mod mod, File sidebarYml) {
        try (InputStream is = new FileInputStream(sidebarYml)) {
            Map<String,Object> cfg = (Map<String,Object>) new Yaml(
                new org.yaml.snakeyaml.constructor.SafeConstructor(
                    new org.yaml.snakeyaml.LoaderOptions())).load(is);
            if (cfg == null) return;
            assetManager.applySidebarConfig(cfg);
            System.out.printf("[ModLoader] %s — sidebar config applied%n", mod.id);
        } catch (Exception e) {
            mod.addError("sidebar.yml", "Failed to load sidebar config: " + e.getMessage());
        }
    }

    // ── Error log writing ─────────────────────────────────────────────────────

    private void writeErrorLogs() {
        for (Mod mod : loaded) {
            if (mod.errors.isEmpty()) continue;
            File logFile = new File(mod.folder, "mod_errors.log");
            try (PrintWriter pw = new PrintWriter(logFile)) {
                pw.println("=== Mod Error Log: " + mod.name + " ===");
                pw.println("Generated: " + new java.util.Date());
                pw.println("Status: " + mod.status);
                pw.println();
                for (Mod.ModError e : mod.errors) {
                    pw.println("[" + e.level + "] " + e.file);
                    pw.println("  → " + e.message);
                    pw.println();
                }
            } catch (Exception e) {
                System.err.println("[ModLoader] Could not write error log for " + mod.id + ": " + e.getMessage());
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private List<File> allYaml(File dir) {
        List<File> result = new ArrayList<>();
        collectYaml(dir, result);
        result.sort(Comparator.comparing(File::getName));
        return result;
    }

    private void collectYaml(File dir, List<File> result) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory())               collectYaml(f, result);
            else if (f.getName().endsWith(".yml")) result.add(f);
        }
    }

    private String str(Map<String, Object> m, String key, String def) {
        Object v = m.get(key);
        return (v == null) ? def : v.toString().trim();
    }
}
