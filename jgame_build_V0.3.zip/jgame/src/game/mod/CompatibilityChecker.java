package game.mod;

import game.GameMeta;
import java.io.*;
import java.util.*;
import java.util.function.Consumer;

/**
 * Checks each mod's declared version requirements against the running game version.
 * Runs one mod at a time, fully isolated in try/catch so a broken mod can never
 * crash the checker.
 *
 * Results are written to each Mod's compatStatus and compatMessage fields.
 *
 * Compatibility is determined by:
 *   1. Version range (game_version_min / game_version_max in mod.yml)
 *   2. Required files present (declared in mod.yml under requires_files)
 *   3. Required game features (declared in mod.yml under requires_features)
 *
 * KNOWN FEATURES (declared by the game, mods may require):
 *   text_pools       – TextPoolRegistry (added in 0.1.0)
 *   artwork_hooks    – ArtworkHookManager (added in 0.1.0)
 *   audio            – AudioManager (added in 0.1.0)
 *   mod_assets       – AssetManager (added in 0.1.0)
 *   mod_sidebar      – sidebar.yml support (added in 0.1.0)
 *   modpacks         – modpack.yml support (added in 0.1.0)
 */
public class CompatibilityChecker {

    /** Features the current game version supports. */
    private static final Set<String> SUPPORTED_FEATURES = new HashSet<>(Arrays.asList(
        "text_pools", "artwork_hooks", "audio", "mod_assets", "mod_sidebar", "modpacks",
        "scenes", "npcs", "clothes", "jobs"
    ));

    private final String gameVersion;

    public CompatibilityChecker() {
        this.gameVersion = GameMeta.VERSION;
    }

    /**
     * Check all mods, one by one. Calls {@code onProgress} after each check.
     * Never throws — each mod is checked in its own try/catch.
     *
     * @param mods       the mods to check
     * @param onProgress called after each mod with a status string for UI updates
     */
    public void checkAll(List<Mod> mods, Consumer<String> onProgress) {
        for (Mod mod : mods) {
            String name = mod.name.isEmpty() ? mod.id : mod.name;
            if (onProgress != null) onProgress.accept("Checking: " + name + "…");
            try {
                checkOne(mod);
            } catch (Exception e) {
                mod.compatStatus  = Mod.CompatStatus.CHECK_FAILED;
                mod.compatMessage = "Compatibility check crashed: " + e.getMessage();
                System.err.println("[CompatChecker] Failed for " + mod.id + ": " + e.getMessage());
            }
            if (onProgress != null) onProgress.accept("Checked: " + name);
        }
        if (onProgress != null) onProgress.accept("Done.");
    }

    /** Check a single mod. Never throws. */
    public void checkOne(Mod mod) {
        try {
            List<String> issues   = new ArrayList<>();
            List<String> warnings = new ArrayList<>();

            // 1. Disabled mods — mark but don't block
            if (!mod.enabled || mod.skipped) {
                mod.compatStatus  = Mod.CompatStatus.COMPATIBLE; // no verdict on disabled mods
                mod.compatMessage = "Mod is disabled — not loaded.";
                return;
            }

            // 2. Version range check
            if (!mod.game_version_min.isEmpty()) {
                if (Mod.compareVersions(mod.game_version_min, gameVersion) > 0) {
                    issues.add("Requires game version ≥ " + mod.game_version_min
                             + " (current: " + gameVersion + ")");
                }
            }
            if (!mod.game_version_max.isEmpty()) {
                if (Mod.compareVersions(mod.game_version_max, gameVersion) < 0) {
                    warnings.add("Designed for game version ≤ " + mod.game_version_max
                              + " (current: " + gameVersion + ") — may work but untested");
                }
            }

            // 3. Required features
            Object rf = mod.folder != null
                ? readModYmlField(mod.folder, "requires_features") : null;
            if (rf instanceof List) {
                for (Object feat : (List<?>)rf) {
                    String f = feat.toString().trim().toLowerCase();
                    if (!SUPPORTED_FEATURES.contains(f)) {
                        issues.add("Requires game feature '" + f
                                 + "' which is not available in this version");
                    }
                }
            }

            // 4. Required files present (mod declares external dependencies)
            Object reqFiles = mod.folder != null
                ? readModYmlField(mod.folder, "requires_files") : null;
            if (reqFiles instanceof List) {
                for (Object fileObj : (List<?>)reqFiles) {
                    String relPath = fileObj.toString().trim();
                    File f = new File(mod.folder, relPath);
                    if (!f.exists()) {
                        warnings.add("Declared required file missing: " + relPath);
                    }
                }
            }

            // 5. Mod folder health — check key files exist if declared in mod.yml
            if (mod.folder == null || !mod.folder.exists()) {
                issues.add("Mod folder not found: " + (mod.folder != null ? mod.folder.getPath() : "null"));
            }

            // 6. Load errors already detected
            int errorCount = (int) mod.errors.stream()
                .filter(e -> e.level == Mod.ModError.Level.ERROR).count();
            int warnCount  = (int) mod.errors.stream()
                .filter(e -> e.level == Mod.ModError.Level.WARNING).count();
            if (errorCount > 0) issues.add(errorCount + " load error(s) detected");
            if (warnCount > 0)  warnings.add(warnCount + " load warning(s) detected");

            // ── Determine result ──────────────────────────────────────────────
            if (!issues.isEmpty()) {
                mod.compatStatus  = issues.stream().anyMatch(s -> s.contains("Requires game version"))
                                  ? Mod.CompatStatus.OUTDATED : Mod.CompatStatus.INCOMPATIBLE;
                mod.compatMessage = String.join("\n", issues);
                if (!warnings.isEmpty()) mod.compatMessage += "\n" + String.join("\n", warnings);
            } else if (!warnings.isEmpty()) {
                mod.compatStatus  = Mod.CompatStatus.OUTDATED;
                mod.compatMessage = String.join("\n", warnings);
            } else {
                mod.compatStatus  = Mod.CompatStatus.COMPATIBLE;
                mod.compatMessage = "Compatible with game version " + gameVersion;
                if (!mod.compatibility_note.isEmpty())
                    mod.compatMessage += "\n" + mod.compatibility_note;
            }
        } catch (Exception e) {
            mod.compatStatus  = Mod.CompatStatus.CHECK_FAILED;
            mod.compatMessage = "Check failed: " + e.getMessage();
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private Object readModYmlField(File modFolder, String key) {
        File metaFile = new File(modFolder, "mod.yml");
        if (!metaFile.exists()) return null;
        try (InputStream is = new FileInputStream(metaFile)) {
            Map<?,?> raw = (Map<?,?>) new org.yaml.snakeyaml.Yaml(
                new org.yaml.snakeyaml.constructor.SafeConstructor(
                    new org.yaml.snakeyaml.LoaderOptions())).load(is);
            return raw != null ? raw.get(key) : null;
        } catch (Exception e) {
            return null;
        }
    }
}
