package game;

import java.util.*;

public class GameState {

    public static final String[] DAY_NAMES      = {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
    public static final String[] DAY_SHORT      = {"MON","TUE","WED","THU","FRI","SAT","SUN"};

    public String playerName   = "Player";
    public int    money        = 1500;
    /** Injected at startup — applies multipliers for slut_rep, WP drain, stress. */
    public transient game.GameSettings settings = null;

    // ── City identity ──────────────────────────────────────────────────────
    /** The city. Manhattan, New York. */
    public static final String CITY_NAME    = "Carrow";
    public static final String CITY_TAGLINE = "You end up here. Then you stay.";

    /**
     * Neighbourhood the player is currently exploring.
     * Set when they pick a district from explore_district_hub.
     * Persists until next explore session.
     */
    public String currentNeighbourhood = ""; // e.g. "Lower East Side"

    /** Discovers a location by ID (e.g. "mall"). Idempotent. */
    public java.util.Set<String> discoveredLocations = new java.util.LinkedHashSet<>();

    // ── Clothing loss tracking (for auto-rebuy) ────────────────────────────
    public java.util.Set<String>  lostClothingToday  = new java.util.LinkedHashSet<>();
    public java.util.List<String> rebuyReceiptItems  = new java.util.ArrayList<>();
    public int                    rebuyReceiptTotal   = 0;

    public void loseClothingItem(String itemId) {
        if (ownedClothing.remove(itemId)) lostClothingToday.add(itemId);
    }
    public void clearLostClothingToday() { lostClothingToday.clear(); }

    // ── Seasons ──────────────────────────────────────────────────────────────
    /** 0=Spring 1=Summer 2=Autumn 3=Winter. Advances every 30 game days. */
    public int    currentSeason = 0;
    // Season data — loaded from gamedata/seasons.yml at startup, fallback hardcoded
    public static String[] SEASON_NAMES  = {"Spring","Summer","Autumn","Winter"};
    public static String[] SEASON_EMOJIS = {"🌸","☀️","🍂","❄️"};


    // ── Tax brackets — loaded from gamedata/taxes.yml ─────────────────────────
    /** Sorted list of [maxAnnual, rate] pairs. Last entry has maxAnnual = Integer.MAX_VALUE. */
    private static final java.util.List<int[]> TAX_BRACKETS = new java.util.ArrayList<>();
    private static final java.util.List<String> TAX_LABELS   = new java.util.ArrayList<>();
    static {
        TAX_BRACKETS.add(new int[]{15000, 10}); // 10%
        TAX_BRACKETS.add(new int[]{40000, 12}); // 12%
        TAX_BRACKETS.add(new int[]{85000, 22}); // 22%
        TAX_BRACKETS.add(new int[]{Integer.MAX_VALUE, 24}); // 24%
        TAX_LABELS.addAll(java.util.Arrays.asList("10%","12%","22%","24%"));
    }

    @SuppressWarnings("unchecked")
    public static void loadTaxes(String gameDataDir) {
        java.io.File f = new java.io.File(gameDataDir + "/taxes.yml");
        if (!f.exists()) return;
        try (java.io.InputStream is = new java.io.FileInputStream(f)) {
            org.yaml.snakeyaml.Yaml yaml = new org.yaml.snakeyaml.Yaml(
                new org.yaml.snakeyaml.constructor.SafeConstructor(
                    new org.yaml.snakeyaml.LoaderOptions()));
            java.util.Map<String,Object> raw = yaml.load(is);
            if (raw == null) return;
            java.util.List<java.util.Map<String,Object>> brackets =
                (java.util.List<java.util.Map<String,Object>>) raw.get("brackets");
            if (brackets == null || brackets.isEmpty()) return;
            TAX_BRACKETS.clear(); TAX_LABELS.clear();
            for (java.util.Map<String,Object> b : brackets) {
                Object maxRaw = b.get("max_annual");
                int max = (maxRaw == null) ? Integer.MAX_VALUE
                                           : Integer.parseInt(maxRaw.toString());
                int rate = (int)(Double.parseDouble(b.get("rate").toString()) * 100);
                TAX_BRACKETS.add(new int[]{max, rate});
                TAX_LABELS.add(b.getOrDefault("label","?").toString());
            }
            System.out.println("[GameState] Loaded " + TAX_BRACKETS.size() + " tax brackets.");
        } catch (Exception e) {
            System.err.println("[GameState] Could not load taxes.yml: " + e.getMessage());
        }
    }

    /** Tax rate (0.0-1.0) for a given annual gross income. */
    public static double taxRateForAnnual(int annualGross) {
        for (int[] bracket : TAX_BRACKETS)
            if (annualGross <= bracket[0]) return bracket[1] / 100.0;
        return 0.24;
    }

    /** Tax bracket label for display (e.g. "22%"). */
    public static String taxBracketLabel(int annualGross) {
        for (int i = 0; i < TAX_BRACKETS.size(); i++)
            if (annualGross <= TAX_BRACKETS.get(i)[0])
                return i < TAX_LABELS.size() ? TAX_LABELS.get(i) : "?";
        return "24%";
    }

    // ── Neighbourhood data — loaded from gamedata/neighbourhoods.yml ─────────────
    /** Maps flag suffix (e.g. "narrows") to display name (e.g. "The Narrows"). */
    public static final java.util.Map<String,String> NEIGHBOURHOOD_FLAGS = new java.util.LinkedHashMap<>();
    static {
        // defaults — overridden by loadNeighbourhoods() if file exists
        NEIGHBOURHOOD_FLAGS.put("narrows",    "The Narrows");
        NEIGHBOURHOOD_FLAGS.put("millgate",   "Millgate");
        NEIGHBOURHOOD_FLAGS.put("thornwick",  "Thornwick");
        NEIGHBOURHOOD_FLAGS.put("lanes",      "The Lanes");
        NEIGHBOURHOOD_FLAGS.put("caldwell",   "Caldwell");
        NEIGHBOURHOOD_FLAGS.put("ravenshill", "Ravenshill");
    }

    @SuppressWarnings("unchecked")
    public static void loadNeighbourhoods(String gameDataDir) {
        java.io.File f = new java.io.File(gameDataDir + "/neighbourhoods.yml");
        if (!f.exists()) return;
        try (java.io.InputStream is = new java.io.FileInputStream(f)) {
            org.yaml.snakeyaml.Yaml yaml = new org.yaml.snakeyaml.Yaml(
                new org.yaml.snakeyaml.constructor.SafeConstructor(
                    new org.yaml.snakeyaml.LoaderOptions()));
            java.util.Map<String,Object> raw = yaml.load(is);
            if (raw == null) return;
            java.util.List<java.util.Map<String,Object>> list =
                (java.util.List<java.util.Map<String,Object>>) raw.get("neighbourhoods");
            if (list == null) return;
            NEIGHBOURHOOD_FLAGS.clear();
            for (java.util.Map<String,Object> n : list) {
                String flag = n.getOrDefault("flag","").toString()
                               .replace("flag_neighbourhood_","");
                String name = n.getOrDefault("name","").toString();
                if (!flag.isEmpty() && !name.isEmpty()) NEIGHBOURHOOD_FLAGS.put(flag, name);
            }
            System.out.println("[GameState] Loaded " + NEIGHBOURHOOD_FLAGS.size() + " neighbourhoods.");
        } catch (Exception e) {
            System.err.println("[GameState] Could not load neighbourhoods.yml: " + e.getMessage());
        }
    }

    /** Call once at startup to load seasons from gamedata/seasons.yml if present. */    /** Call once at startup to load seasons from gamedata/seasons.yml if present. */
    @SuppressWarnings("unchecked")
    public static void loadSeasons(String gameDataDir) {
        java.io.File f = new java.io.File(gameDataDir + "/seasons.yml");
        if (!f.exists()) return;
        try (java.io.InputStream is = new java.io.FileInputStream(f)) {
            org.yaml.snakeyaml.Yaml yaml = new org.yaml.snakeyaml.Yaml(
                new org.yaml.snakeyaml.constructor.SafeConstructor(
                    new org.yaml.snakeyaml.LoaderOptions()));
            java.util.Map<String,Object> raw = yaml.load(is);
            if (raw == null) return;
            java.util.List<java.util.Map<String,Object>> list =
                (java.util.List<java.util.Map<String,Object>>) raw.get("seasons");
            if (list == null || list.isEmpty()) return;
            String[] names  = new String[list.size()];
            String[] emojis = new String[list.size()];
            for (java.util.Map<String,Object> s : list) {
                int idx = ((Number) s.getOrDefault("index", 0)).intValue();
                if (idx >= 0 && idx < list.size()) {
                    names[idx]  = s.getOrDefault("name",  "Season").toString();
                    emojis[idx] = s.getOrDefault("emoji", "").toString();
                }
            }
            SEASON_NAMES  = names;
            SEASON_EMOJIS = emojis;
            System.out.println("[GameState] Loaded " + list.size() + " seasons from seasons.yml");
        } catch (Exception e) {
            System.err.println("[GameState] Could not load seasons.yml: " + e.getMessage());
        }
    }

    public String  getSeasonName()        { return SEASON_NAMES[currentSeason];  }
    public String  getSeasonEmoji()       { return SEASON_EMOJIS[currentSeason]; }
    public boolean isSeason(String s)     { return getSeasonName().equalsIgnoreCase(s); }
    public boolean isWarmSeason()         { return currentSeason == 0 || currentSeason == 1; }
    public boolean isColdSeason()         { return currentSeason == 2 || currentSeason == 3; }

    /** Discover a location by ID (e.g. "mall"). Idempotent. */
    public void discoverLocation(String locId) {
        if (discoveredLocations.add(locId)) addTrait("found_" + locId);
    }

    public boolean hasDiscovered(String locId) { return discoveredLocations.contains(locId); }
    public int    rent         = 0;
    public int    fitness      = 50;
    public int    work_rep     = 0;     // workplace reputation (0=unknown, 100=mascot)
    public java.util.Map<String,Integer> npcReputation = new java.util.HashMap<>();  // per-NPC -100→+100, 0=neutral
    public int    happiness    = 40;
    public int    confidence   = 45;
    public int    willpower    = 35;
    public int    stress       = 50;    // starts high — floor mattress, new city, no furniture
    public int    slut_rep     = 0;     // 0=unknown, 100=propositioned daily
    public int    thrills      = 0;     // excitement from exhibitionist moments
    public int    arousal      = 0;     // daily arousal — checked mid-scene, decays each day
    public int    drunk        = 0;     // 0=sober, 15=blackout, 20=passed out — decays overnight
    public int    dayCount     = 1;
    public int    dayOfWeek    = 0;     // 0=Monday … 6=Sunday

    // Per-scene slut rep gain tracking — capped at +2 per scene
    public int    slutRepGainedThisScene = 0;
    /** Slut rep gained today across all scenes. Cleared on advanceDay(). Hard cap: 5. */
    public int    slutRepGainedToday     = 0;
    public static final int SLUT_REP_DAILY_CAP = 5;

    /**
     * Trait auto-acquisitions that happened during advanceDay() and need
     * to be surfaced to the player as scenes at the start of the next day.
     * Drained by GameWindow.onDayEnd() → added to pendingScenes.
     */
    public java.util.List<String> pendingTraitAcquisitions = new java.util.ArrayList<>();
    /** Last day's activity slot selection — pre-loaded into day planner each morning. */
    public String[] lastDaySlots = null;

    /**
     * Dance lock system — when MC is drunk (effWP < 25) AND enjoying the situation
     * (slut_rep puts her in "enjoy" tier), she cannot end the dance voluntarily.
     * She must cycle through 5 more dance turns before the exit unlocks.
     */
    public int     danceLockTurns  = 0;   // turns remaining before exit unlocks
    public boolean flagDanceLocked = false; // true while locked — gates YAML choices

    /**
     * Lifetime slut_rep earned broken out by action type.
     * Used for diminishing returns — each type has a lifetime cap from the spec table.
     *
     * Action types and lifetime caps:
     *   "low_risk_flash"   → cap 12  (flash with no real risk of being seen)
     *   "high_risk_flash"  → cap 16  (flash with high risk of being seen)
     *   "watched_flash"    → cap 20  (flash to someone actively watching)
     *   "public_act"       → cap 14  (generic public sexual act, not flash-specific)
     *
     * Diminishing returns formula (applied WITHIN lifetime cap):
     *   Earned 0–4   from type: full gain
     *   Earned 5–8   from type: gain halved (round up)
     *   Earned 9–12  from type: gain quartered (round up)
     *   Earned 12+   from type: 0 (at or past soft cap, hard cap from above enforces max)
     */
    public java.util.Map<String, Integer> slutRepEarnedByType = new java.util.LinkedHashMap<>();

    // Per-NPC memory — stores key events and last seen outfit
    // Keys: "npc_id:memory_key" → value (int or 0/1 for flags)
    public Map<String,String> npcMemory = new HashMap<>();

    /** Store a memory about an NPC. e.g. setNpcMemory("richard", "flashed_boss", "1") */
    public void setNpcMemory(String npcId, String key, String value) {
        npcMemory.put(npcId + ":" + key, value);
    }

    /** Get a memory about an NPC. Returns empty string if not set. */
    public String getNpcMemory(String npcId, String key) {
        return npcMemory.getOrDefault(npcId + ":" + key, "");
    }

    /** Check if a boolean NPC memory flag is set */
    public boolean hasNpcMemory(String npcId, String key) {
        return "1".equals(getNpcMemory(npcId, key));
    }

    public String currentJobId      = null;  // null = unemployed
    public int    daysWorkedThisPay = 0;    // tracks days toward next paycheck
    /** Cumulative pay raise in currency/day — stacks with job base pay. Persists. */
    public int    payPerDayBonus   = 0;

    // ── Work mode system ──────────────────────────────────────────────────────
    /** Current work mode for next shift. Persists until changed. */
    public String workMode          = "normal"; // normal/harder/slack/politics/pranks

    /** Standing with coworkers/management. Stay above 20 or face firing. */
    public int    officeRep         = 60;       // starts at 60 (decent standing)

    /** Progress toward next promotion. 0-100; resets to 0 when promotion offered. */
    public int    promotionProgress = 0;

    /** Net office rep change since month started — negative trend risks HR meeting. */
    public int    monthlyRepGain    = 0;

    /** Game day when current month tracking started. */
    public int    repMonthStart     = 1;

    // ── Work mode helpers ────────────────────────────────────────────────────

    /** Apply diminishing returns: full gain below threshold, scaled above. */
    public int workDiminishing(int current, int raw, int threshold) {
        if (raw < 0) return raw; // losses don't diminish
        if (current >= threshold + 15) return Math.max(0, (int)(raw * 0.25));
        if (current >= threshold)      return Math.max(0, (int)(raw * 0.55));
        return raw;
    }

    /** Office rep daily gain for current work mode (with diminishing returns). */
    public int officeRepGainForMode() {
        int raw;
        switch (workMode) {
            case "harder":   raw =  3; break;
            case "politics": raw =  1; break;
            case "slack":    raw = -5; break;
            case "pranks":   raw = -8; break;
            default:         raw =  2; break;
        }
        if (raw > 0) return workDiminishing(officeRep, raw, 70);
        return raw;
    }

    /** Promotion progress daily gain for current work mode. */
    public int promotionGainForMode() {
        int raw;
        switch (workMode) {
            case "harder":   raw =  8; break;
            case "politics": raw =  6; break;
            case "pranks":   raw = -3; break;
            case "slack":    raw =  0; break;
            default:         raw =  1; break;
        }
        if (raw > 0 && "harder".equals(workMode))
            return workDiminishing(promotionProgress, raw, 60);
        if (raw > 0 && "politics".equals(workMode))
            return workDiminishing(promotionProgress, raw, 70);
        return raw;
    }

    /** Clamp office rep 0-100. */
    public void applyOfficeRepGain(int delta) {
        officeRep      = clamp(officeRep + delta, 0, 100);
        monthlyRepGain += delta;
    }

    /** Clamp promotion progress 0-100. Returns true if hit 100 (promotion ready). */
    public boolean applyPromotionGain(int delta) {
        promotionProgress = clamp(promotionProgress + delta, 0, 100);
        return promotionProgress >= 100;
    }

    /** Reset monthly rep tracking for a new month. */
    public void resetMonthlyRep() {
        monthlyRepGain = 0;
        repMonthStart  = dayCount;
    }

    /** True if the monthly period (30 days) has elapsed. */
    public boolean isMonthlyRepCheckDue() {
        return (dayCount - repMonthStart) >= 30;
    }

    /** Apply a pay raise. Returns new effective pay per day. */
    public int applyRaise(int amountPerDay) {
        payPerDayBonus += amountPerDay;
        return payPerDayBonus;
    }

    /** Quit current job — clears ID, pay tracker. Stress bump from the decision. */
    public void quitJob() {
        currentJobId      = null;
        daysWorkedThisPay = 0;
        workMode          = "normal";      // reset for next job
        officeRep         = 60;            // fresh start
        promotionProgress = 0;
        payPerDayBonus   = 0;  // raises are per-job
        monthlyRepGain    = 0;
        repMonthStart     = dayCount;
        stress = clamp(stress + 10, 0, 100);
    }

    /** Fired from job — same as quit but larger stress hit and confidence loss. */
    public void fireFromJob() {
        currentJobId      = null;
        daysWorkedThisPay = 0;
        workMode          = "normal";
        officeRep         = 60;
        promotionProgress = 0;
        monthlyRepGain    = 0;
        repMonthStart     = dayCount;
        stress      = clamp(stress + 25, 0, 100);
        confidence  = clamp(confidence - 8, 0, 100);
        happiness   = clamp(happiness - 10, 0, 100);
    }

    /** NPC ID of current landlord — set when player selects housing. */
    public String currentLandlordNpc = null;

    // ── Housing modifiers — set on housing selection, persist for run ─────────
    /** Max willpower allowed. Starts at 70 (floor mattress, no housing chosen). */
    public int housingWillpowerCap      = 70;
    /** Willpower recovered each sleep. Starts at +8 (floor mattress). */
    public int housingWillpowerRecovery = 8;
    /** Stress points reduced each new day. Starts at 3 (floor mattress). */
    public int housingStressReduction   = 3;
    /** Minimum stress floor. Starts at 45 (floor mattress — hard to rest). */
    public int housingStressMin         = 45;

    public Set<String>         traits        = new LinkedHashSet<>();
    /**
     * Timed traits expire after a set number of days.
     * Key = trait name (lowercase), Value = day number when it expires.
     * Example: Neck_Hickey added on day 3 with duration 4 → expires after day 6.
     */
    public java.util.Map<String,Integer> timedTraits = new java.util.LinkedHashMap<>();
    public String              currentScene  = "housing";
    /** Last hub scene — used by bar_serious_talk and other submenu scenes to know where to return. */
    public String              hubScene      = "bar_with_npc";
    public Set<String>         visitedScenes = new HashSet<>();
    public Map<String,Integer> variables     = new HashMap<>();

    // ── Outfit slots ─────────────────────────────────────────────
    public String outfitBra        = "basic_bra";
    public String outfitUpper      = "white_tshirt";
    public String outfitLower      = "blue_jeans";
    public String outfitOvercoat   = null;            // trenchcoat etc — covers upper AND lower
    public String outfitUnderwear  = "basic_underwear";
    public String outfitSocks      = "ankle_socks";
    public String outfitShoes      = "sneakers";
    public boolean isWet           = false;

    /** True until player buys new clothes — limits outfit panel to starting items. */
    public boolean startingOutfitsOnly = true;

    /**
     * Owned clothing item IDs.
     * Starts with 2 outfits worth: everyday jeans+tshirt and a casual dress.
     * Undergarments and shoes included as minimums (can't go out without them).
     * Shopping unlocks additional items and clears startingOutfitsOnly.
     */
    public java.util.Set<String> ownedClothing = new java.util.LinkedHashSet<>(java.util.Arrays.asList(
        // Starting bra (one only)
        "basic_bra",
        // Starting underwear (one only)
        "basic_underwear",
        // Outfit 1: jeans + t-shirt
        "white_tshirt",
        "blue_jeans",
        // Outfit 2: casual dress
        "casual_dress",
        // Minimum footwear
        "sneakers",
        // Minimum socks
        "ankle_socks"
    ));

    /** Returns primary visible upper item ID for compat */
    public String currentOutfitId() {
        if (outfitOvercoat != null) return outfitOvercoat;
        return outfitUpper != null ? outfitUpper : "white_tshirt";
    }

    public boolean isBraless() { return outfitBra == null; }

    public boolean isTopless()  { return outfitUpper == null && outfitOvercoat == null; }
    public boolean isWearingThinTop() {
        if (outfitUpper == null) return false;
        String u = outfitUpper.toLowerCase();
        return u.contains("thin") || u.contains("sheer") || u.contains("mesh")
            || u.contains("sundress") || u.contains("crop") || u.contains("tank");
    }
    public int getCurrentLewdnessRating() {
        // Rough lewdness from clothing state
        int lwd = 0;
        if (isBraless())  lwd += 20;
        if (isTopless())  lwd += 50;
        if (outfitBra == null && outfitUnderwear == null) lwd += 15;
        if (outfitLower == null) lwd += 40;
        if (getBodyFlag("flag_wearing_skirt")) lwd += 10;
        if (getBodyFlag("flag_underdressed_for_winter")) lwd += 10;
        return Math.min(100, lwd);
    }

    /** True if lower body is covered — by lower slot, a fills_lower upper, or an overcoat */
    public boolean lowerCovered(game.ClothingLoader clothes) {
        if (outfitOvercoat != null) return true;
        if (outfitLower != null)    return true;
        if (outfitUpper != null) {
            game.data.ClothingData upper = clothes.get(outfitUpper);
            return upper != null && upper.fills_lower;
        }
        return false;
    }

    /** Can the player leave home in current outfit? */
    public boolean canGoOut(game.ClothingLoader clothes) {
        // Cannot go out commando while on period
        if (isOnPeriod() && outfitUnderwear == null) return false;
        // Overcoat alone is enough to go out
        if (outfitOvercoat != null) return true;
        // Otherwise need something on top AND something on bottom
        boolean hasTop    = outfitUpper != null || outfitBra != null;
        boolean hasBottom = lowerCovered(clothes);
        return hasTop && hasBottom;
    }

    // ── Dynamic trait cache ───────────────────────────────────────
    // Invalidated whenever outfit, arousal, or wet state changes
    private transient java.util.Set<String> _dynamicCache = null;
    private transient String _cacheKey = "";

    private String dynCacheKey() {
        return outfitBra + "|" + outfitUpper + "|" + outfitLower + "|" + outfitOvercoat
             + "|" + outfitUnderwear + "|" + outfitShoes + "|" + isWet + "|" + arousal;
    }

    public void invalidateDynamicCache() { _dynamicCache = null; }

    /** Compute dynamic temporary traits — cached per outfit/arousal state */
    public java.util.Set<String> computeDynamicTraits(game.ClothingLoader clothes) {
        String key = dynCacheKey();
        if (_dynamicCache != null && key.equals(_cacheKey)) return _dynamicCache;
        java.util.Set<String> dynamic = new java.util.LinkedHashSet<>();

        // Effective upper layer — overcoat beats upper
        game.data.ClothingData upper = outfitOvercoat != null
            ? clothes.get(outfitOvercoat) : clothes.get(outfitUpper);
        game.data.ClothingData bra = clothes.get(outfitBra);

        if (upper != null) {
            upper.is_wet = isWet;
            // braless=true means the item has built-in support — acts like a bra for nipping/exposure
            boolean itemHasBuiltInSupport = upper.braless;
            boolean braProtects  = itemHasBuiltInSupport || (bra != null && !bra.isNipRisk());
            boolean topIsThick   = "thick".equals(upper.thickness);
            boolean topIsThin    = "thin".equals(upper.thickness) || "diaphanous".equals(upper.thickness)
                                   || upper.seethrough;

            // ── Pierced nipples ────────────────────────────────────────
            // Jewelry shows through any non-thick top when unprotected by a real bra.
            // Thin fabric = prominent (hardware clearly visible).
            // Medium fabric = subtle (outline/bump detectable).
            if (hasTrait("Pierced_Nipples") && !braProtects && !topIsThick) {
                dynamic.add(topIsThin ? "pierced_nipping_prominent" : "pierced_nipping");
                dynamic.add("nipping"); // generic nipping always set alongside
            }

            // ── Standard fabric nipping ────────────────────────────────
            // Thin/diaphanous/seethrough tops nip when unprotected.
            if (upper.isNipRisk() && !braProtects && !dynamic.contains("nipping")) {
                dynamic.add("nipping");
            }

            // ── Exposure — sheer/diaphanous top with no bra at all ────
            if (upper.isExposureRisk() && outfitBra == null && !itemHasBuiltInSupport) {
                dynamic.add("exposed_breasts");
            }

            // ── Arousal-based nipping ──────────────────────────────────
            // Fires independently of piercing — arousal affects any unprotected top.
            if (!braProtects) {
                boolean mediumTight = "medium".equals(upper.thickness) && upper.tight;
                if (arousal >= 75) {
                    // Very aroused — shows through any top
                    if (!dynamic.contains("nipping")) dynamic.add("nipping");
                    dynamic.add("arousal_nipping");
                } else if (arousal >= 50 && mediumTight) {
                    // Moderately aroused + tight medium top
                    if (!dynamic.contains("nipping")) dynamic.add("nipping");
                    dynamic.add("arousal_nipping");
                }
            }
        }

        // Camel toe — thin + tight lower body + no underwear
        game.data.ClothingData lower = clothes.get(outfitLower);
        if (lower == null && outfitUpper != null) {
            game.data.ClothingData up = clothes.get(outfitUpper);
            if (up != null && up.fills_lower) lower = up;
        }
        if (lower != null && lower.tight && outfitUnderwear == null
                && ("thin".equals(lower.thickness) || "diaphanous".equals(lower.thickness))) {
            dynamic.add("camel_toe");
        }

        // Commando in skirt/dress — different from camel toe (no underwear + skirt)
        boolean wearingSkirt = false;
        if (lower != null && lower.is_skirt) wearingSkirt = true;
        if (outfitOvercoat == null && outfitUpper != null) {
            game.data.ClothingData up = clothes.get(outfitUpper);
            if (up != null && up.fills_lower && up.is_skirt) wearingSkirt = true;
        }
        if (wearingSkirt) {
            dynamic.add("wearing_skirt");
            if (outfitUnderwear == null && !isOnPeriod()) {
                dynamic.add("commando");
                dynamic.add("commando_in_skirt"); // composite — used by explore/go_out triggers
            }
        }

        // ── Clothing property flags ────────────────────────────────────────
        // These let scenes gate on what the MC is wearing without hardcoding item IDs.

        // Crop top — can ride up during stretching/exercise
        if (upper != null && upper.crop_top) {
            dynamic.add("wearing_crop_top");
        }

        // Off-shoulder — flash risk when combined with braless or loose fit
        if (upper != null && upper.off_shoulder) {
            dynamic.add("wearing_off_shoulder");
            boolean noBraProtection = outfitBra == null && !upper.braless;
            boolean loosFit = upper.loose;
            if (noBraProtection || loosFit) {
                dynamic.add("off_shoulder_flash_risk");
            }
        }

        // Buttons — pop risk with large chest + tight garment + no good bra
        if (upper != null && upper.has_buttons && upper.tight) {
            boolean largeChest = hasTrait("Breasts_D") || hasTrait("Breasts_DD") ||
                                 hasTrait("Breasts_E") || hasTrait("Breasts_F");
            boolean braProtects = outfitBra != null &&
                                  clothes.get(outfitBra) != null &&
                                  !"thin".equals(clothes.get(outfitBra).thickness) &&
                                  !"diaphanous".equals(clothes.get(outfitBra).thickness);
            if (largeChest && !braProtects) {
                dynamic.add("button_pop_risk");
            }
        }

        // Loose garment — can shift more dramatically during movement
        if (upper != null && upper.loose) {
            dynamic.add("wearing_loose_top");
        }

        // bounce_prone_N — directly maps to cup size when braless (1=A, 2=B, 3=C, 4=D, 5=DD, 6=E, 7=F)
        // Each level also sets all lower levels so scenes can gate on minimums.
        // Generic bounce_prone only set for B cup and above — A cup has no actual movement.
        // All require bra to be absent (or thin enough to not suppress).
        int cupLevel = 0;
        if (outfitBra == null) {
            if      (hasTrait("Breasts_F"))  cupLevel = 7;
            else if (hasTrait("Breasts_E"))  cupLevel = 6;
            else if (hasTrait("Breasts_DD")) cupLevel = 5;
            else if (hasTrait("Breasts_D"))  cupLevel = 4;
            else if (hasTrait("Breasts_C"))  cupLevel = 3;
            else if (hasTrait("Breasts_B"))  cupLevel = 2;
            else if (hasTrait("Breasts_A"))  cupLevel = 1;
        }
        if (cupLevel > 0) {
            for (int lvl = 1; lvl <= cupLevel; lvl++) {
                dynamic.add("bounce_prone_" + lvl);
            }
            if (cupLevel >= 2) dynamic.add("bounce_prone"); // actual movement — B cup and above
        }

        // Heels worn
        if (outfitShoes != null) {
            game.data.ClothingData shoes = clothes.get(outfitShoes);
            if (shoes != null) {
                if ("high".equals(shoes.heel_type))   dynamic.add("wearing_high_heels");
                else if ("low".equals(shoes.heel_type)) dynamic.add("wearing_low_heels");
            }
        }

        // Sock discomfort
        if (outfitSocks == null && outfitShoes != null) {
            game.data.ClothingData shoes = clothes.get(outfitShoes);
            if (shoes == null || !shoes.sandals) dynamic.add("uncomfortable_feet");
        }

        // ── Trauma tier: forces shy paths, suppresses assertive ones ─────────────
        // Broken > Shaken > Hurt: all three collapse the MC into withdrawn/shy behaviour.
        // Broken is total — no confident paths at all.
        // Shaken and Hurt force shy paths but with differing suppression depth.
        if (hasTrait("Broken") || hasTrait("Shaken") || hasTrait("Hurt") || hasTrait("Rattled")) {
            dynamic.add("shy");
            dynamic.add("conflict_avoidant");
            dynamic.add("shaken_suppresses_assertive"); // used by Engine.visible()
            if (hasTrait("Broken")) {
                dynamic.add("broken_suppresses_all");   // Engine can use for extra suppression
            }
        }

        _dynamicCache = dynamic;
        _cacheKey = key;
        return dynamic;
    }

    // ── Bar state ────────────────────────────────────────────────
    /** NPCs currently present in the bar. Populated by BarSystem on bar entry. */
    public List<String> currentBarNpcs        = new ArrayList<>();
    /** The NPC currently approaching the MC in the bar. Set by BarSystem, cleared after scene. */
    public String       currentApproachingNpc = "";
    /** True when the NPC chose the current activity via dice roll (not MC-initiated). */
    public boolean      npcInitiatedActivity  = false;

    // ── NPC session stats (current bar encounter only) ────────────
    // All clear at bar exit unless walk-home happens (not yet implemented).
    // Routed via changeStat("npc_frustration", n) etc. in YAML stat_changes.
    /** NPC frustration — +5 per turn in bar_with_npc, -1 on let-them-decide. High = more pushy. */
    public int currentNpcFrustration = 0;
    /** NPC arousal — modified by dialogue choices. Affects walk-home roll weighting. */
    public int currentNpcArousal     = 0;
    /** NPC liking gain this session — adds to npc_rep at bar exit (small, mostly flavor). */
    public int currentNpcLiking      = 0;
    // ── Drunk tracking for Alcoholic trait acquisition ──────────────────────
    /** Set true on any game day where drunk reaches 13+. Cleared on advanceDay(). */
    public boolean wasDrunk13Today     = false;
    /** How many days this week drunk hit 13+. Resets each 7-day week. */
    public int     drunk13DaysThisWeek = 0;
    /** How many consecutive weeks had 3+ drunk-13 days. */
    public int     heavyWeeksInARow    = 0;
    /** Day counter for week boundary tracking. */
    public int     dayOfWeek           = 0; // 0-6

    /** Increments each time bar_slow_dance loads this session. Continuation text fires at 2+. */
    public int slowDanceCount        = 0;
    /** Tracks which DanceMoment ids have already fired this session — prevents repeats. */
    public Set<String> usedDanceMoments = new java.util.LinkedHashSet<>();

    // ── Body state flags (scene cross-referencing) ────────────────
    // Set via stat_changes: "flag_breast_groped: 1" etc.
    // Cleared on bar exit or dance end.
    // Lets scenes reference what has already happened this encounter.
    public boolean flagBreastGroped  = false;
    public boolean flagAssGroped     = false;
    public boolean flagPussyGroped   = false;
    public boolean flagFingered      = false;
    public boolean flagKissed        = false;
    public boolean flagNeckKissed    = false;
    public boolean flagDeepKissed    = false;
    public boolean flagCornered      = false;
    public boolean flagCookedTonight = false;  // cooked food for NPC this session — 1x gate
    public boolean flagNpcCame         = false;  // NPC orgasmed
    public boolean flagGloryHoleUsed     = false;  // visited gloryhole in bathroom
    public boolean flagCafeJumpFlashed    = false;  // jump dice rolled a flash this session
    public boolean flagCafeSleazyVisited  = false;  // sleazy guy has helped before — routes to Branch 7
    public SexState sexState = new SexState();

    // ── Cycle ────────────────────────────────────────────────────
    public int cycleDay    = 14;
    public int cycleLength = 28;

    public void advanceCycle(int days) { cycleDay = ((cycleDay - 1 + days) % cycleLength) + 1; }
    public boolean isOnPeriod()        { return cycleDay >= 1  && cycleDay <= 5;  }
    public boolean isFertileWindow()   { return cycleDay >= 11 && cycleDay <= 17; }
    public boolean isOvulating()       { return cycleDay == 14; }

    public double pregnancyChance() {
        if (hasTrait("Infertile"))           return 0.0;
        if (hasTrait("On_The_Pill"))         return 0.01;
        if (!isFertileWindow())              return hasTrait("Extremely_Fertile") ? 0.05 : 0.01;
        double base;
        if      (hasTrait("Extremely_Fertile")) base = 0.90;
        else if (hasTrait("Fertile"))           base = 0.60;
        else if (hasTrait("Less_Fertile"))      base = 0.25;
        else                                    base = 0.60;
        if (isOvulating()) base = Math.min(1.0, base * 1.3);
        return base;
    }

    public String cycleStatus() {
        if (isOnPeriod())      return "Period (Day " + cycleDay + ")";
        if (isOvulating())     return "Ovulating (\u26a0 Day 14)";
        if (isFertileWindow()) return "Fertile Window (Day " + cycleDay + ")";
        return "Day " + cycleDay + " of " + cycleLength;
    }

    /** Advance to next day */
    public void advanceDay() {
        dayCount++;
        // Expire timed traits
        // Track which timed traits expired this tick before clearing
        java.util.Set<String> expiredTraits = new java.util.HashSet<>();
        timedTraits.entrySet().removeIf(e -> {
            if (dayCount > e.getValue()) { expiredTraits.add(e.getKey()); return true; }
            return false;
        });
        for (String expired : expiredTraits) onTimedTraitExpired(expired);

        // ── Drunk-13 tracking for Alcoholic trait acquisition ──────────────
        if (wasDrunk13Today) drunk13DaysThisWeek++;
        wasDrunk13Today = false; // reset for new day

        dayOfWeek = (dayOfWeek + 1) % 7;
        if (dayOfWeek == 0) { // new week
            if (drunk13DaysThisWeek >= 3) {
                heavyWeeksInARow++;
                if (heavyWeeksInARow >= 2 && !hasTrait("Alcoholic")) {
                    addTrait("Alcoholic");
                    pendingTraitAcquisitions.add("trait_acquired_alcoholic");
                }
            } else {
                heavyWeeksInARow = 0;
            }
            drunk13DaysThisWeek = 0;
        }

        advanceCycle(1);
        // Deduct daily rent (monthly rent / 30, rounded)
        if (rent > 0) money -= Math.round(rent / 30.0);

        // ── Furniture passive bonuses ─────────────────────────────────────────
        // Willpower recovery — housing base + optional furniture bonuses
        int wpRecovery = housingWillpowerRecovery;
        if (hasTrait("has_good_mattress")) wpRecovery += 5;
        // Bed type bonuses (own bed beats floor, better beds = better recovery)
        if      (hasTrait("has_king_bed"))   { wpRecovery += 7; happiness = clamp(happiness + 1); }
        else if (hasTrait("has_double_bed")) { wpRecovery += 5; }
        else if (hasTrait("has_single_bed")) { wpRecovery += 3; }
        else if (hasTrait("has_bunk_bed"))   { wpRecovery += 2; }
        if (hasTrait("has_bookshelf"))     wpRecovery += 2;
        willpower = Math.min(housingWillpowerCap, willpower + wpRecovery);

        // Stress reduction — housing base + optional furniture bonuses
        int stressReduce = housingStressReduction;
        if (hasTrait("has_tv"))            stressReduce += 3;
        if (hasTrait("has_coffee_maker"))  stressReduce += 2;
        stress = Math.max(housingStressMin, stress - stressReduce);

        // Confidence — mirror and dresser give small passive lift
        int confBonus = 0;
        if      (hasTrait("has_ornate_mirror")) confBonus += 3;
        else if (hasTrait("has_large_mirror"))  confBonus += 2;
        else if (hasTrait("has_mirror"))        confBonus += 1;
        else if (hasTrait("has_small_mirror"))  confBonus += 0; // exists for flag purposes
        if (hasTrait("has_dresser_nice"))  confBonus += 1;
        if (hasTrait("has_wardrobe"))      confBonus += 2;
        if (confBonus > 0) confidence = clamp(confidence + confBonus);

        // Happiness — feeling organised and settled
        int happBonus = 0;
        if (hasTrait("has_dresser_basic")) happBonus += 1;
        if (hasTrait("has_dresser_nice"))  happBonus += 1;
        if (hasTrait("has_wardrobe"))      happBonus += 1;
        if (happBonus > 0) happiness = clamp(happiness + happBonus);
        // Arousal naturally decays each day — sleep resets it somewhat
        // If MC goes to bed aroused: arousal drops 50%, half of that drop goes to stress,
        // 1/10th of the drop lowers confidence.
        // e.g. arousal=40 → drops 20 → +10 stress, -2 confidence
        if (arousal >= 35) {
            int drop = arousal / 2;
            int stressGain  = drop / 2;
            int confPenalty = drop / 10;
            arousal    = clamp(arousal - drop);
            stress     = Math.min(100, stress + stressGain);
            confidence = clamp(confidence - confPenalty);
        } else {
            arousal = clamp(arousal - 20);
        }
        // Thrills decay slowly
        thrills = clamp(thrills - 5);
        // Drunk mostly clears overnight — sleep off about 8 points (0-20 scale)
        drunk = clampDrunk(drunk - 8);
        // Reset per-scene slut rep tracker each day
        slutRepGainedThisScene = 0;
        slutRepGainedToday     = 0;
        // Low money warning
        if (money < 200 && money >= 0 && dayCount > 1) {
            pendingTraitAcquisitions.add("low_money_warning");
        }
        // Period start notification — fires on cycle day 1
        if (cycleDay == 1) {
            pendingTraitAcquisitions.add("period_start_notice");
        }

        // Note: clearLostClothingToday() is called at end of this method after rebuy

        // Season advances every 30 days (120-day full year)
        int newSeason = (dayCount / 30) % 4;
        if (newSeason != currentSeason) {
            currentSeason = newSeason;
            pendingTraitAcquisitions.add("season_change_" + SEASON_NAMES[newSeason].toLowerCase());
        }
        // Landlord rent check — every 30 days when rent is due and player is short
        if (dayCount > 1 && (dayCount % 30) == 1
                && currentLandlordNpc != null && !currentLandlordNpc.isEmpty()
                && money < rent) {
            pendingTraitAcquisitions.add("landlord_rent_shortage");
        }

        // ── Trait passive effects ─────────────────────────────────────────────
        // ── STD treatment completion ───────────────────────────────────────────
        // Track weeks of completed treatment. Treatment traits are weekly timed traits.
        // When a week expires, increment completed-weeks counter.
        if (hasTrait("std_treatment_minor_week") && !hasTimedTrait("std_treatment_minor_week")) {
            // Week expired — increment counter (stored as a trait std_treatment_minor_wN)
            int weeksCompleted = getStdTreatmentWeeks("minor") + 1;
            removeTrait("std_treatment_minor_week");
            if (weeksCompleted >= 2) {
                // 2 weeks complete — infection cleared
                removeTrait("STD_minor");
                removeTrait("STD_treatment_active");
                pendingTraitAcquisitions.add("std_cleared_minor");
            }
        }
        if (hasTrait("std_treatment_serious_week") && !hasTimedTrait("std_treatment_serious_week")) {
            int weeksCompleted = getStdTreatmentWeeks("serious") + 1;
            removeTrait("std_treatment_serious_week");
            if (weeksCompleted >= 4) {
                // 4 weeks complete — infection managed
                removeTrait("STD_serious");
                removeTrait("STD_treatment_active");
                addTrait("STD_managed");
                pendingTraitAcquisitions.add("std_cleared_serious");
            }
        }

        // ── STD passive effects (reduced if treatment active) ──────────────────
        boolean treatmentActive = hasTrait("STD_treatment_active");
        if (hasTrait("STD_serious")) {
            // Active infection: passive daily drain (halved during treatment)
            int mult = treatmentActive ? 1 : 2;
            happiness = clamp(happiness - (treatmentActive ? 1 : 3));
            stress    = clamp(stress    + (treatmentActive ? 2 : 4));
            willpower = clamp(willpower - (treatmentActive ? 1 : 2));
        } else if (hasTrait("STD_minor")) {
            stress    = clamp(stress + (treatmentActive ? 1 : 2));
        } else if (hasTrait("STD_managed")) {
            // Managed but not cleared — minor ongoing passive
            stress = clamp(stress + 1);
        }
        // ── Trauma passive daily effects ─────────────────────────────────────────
        if (hasTrait("Broken")) {
            stress    = clamp(stress    + 5);
            willpower = clamp(willpower - 2);
        } else if (hasTrait("Shaken")) {
            stress    = clamp(stress    + 3);
        } else if (hasTrait("Hurt")) {
            stress    = clamp(stress    + 1);
        }

        // Reset daily clothing loss tracker (rebuy runs in GameWindow before this)
        clearLostClothingToday();

        // NPC text message — ~15% chance per day when any NPC has your number
        // Uses currentApproachingNpc to identify who texts; pick a random numbered NPC
        if (dayCount > 2 && Math.random() < 0.15) {
            String texterNpc = findRandomNumberedNpc();
            if (texterNpc != null && !texterNpc.isEmpty()) {
                currentApproachingNpc = texterNpc;
                // 30% chance they ask to meet (higher threshold), 70% morning message
                String textScene = (Math.random() < 0.30 && getNpcRep(texterNpc) >= 25)
                    ? "npc_text_asking_out" : "npc_text_morning_message";
                pendingTraitAcquisitions.add(textScene);
            }
        }
    }

    /** Counts completed STD treatment weeks for the given type (minor/serious). */
    public int getStdTreatmentWeeks(String type) {
        // Count trait markers std_treatment_{type}_done_N
        int count = 0;
        for (String t : traits) {
            if (t.startsWith("std_treatment_" + type + "_done_")) count++;
        }
        return count;
    }

    /** Days remaining for a timed trait. Returns 0 if not active. */
    public int getTimedTraitDaysLeft(String trait) {
        Integer expiryDay = timedTraits.get(trait.toLowerCase());
        if (expiryDay == null) return 0;
        return Math.max(0, expiryDay - dayCount);
    }

    /** Find a random NPC who has the player's number. Returns null if none. */
    public String findRandomNumberedNpc() {
        java.util.List<String> candidates = new java.util.ArrayList<>();
        for (java.util.Map.Entry<String,String> e : npcMemory.entrySet()) {
            // Keys are "npcId:has_number" → "true"
            if (e.getKey().endsWith(":has_number") && "true".equals(e.getValue())) {
                candidates.add(e.getKey().replace(":has_number",""));
            }
        }
        if (candidates.isEmpty()) return null;
        return candidates.get((int)(Math.random() * candidates.size()));
    }

    /** Get the rep for a given NPC, defaulting 0. */
    public int getNpcRep(String npcId) {
        return npcRep.getOrDefault(npcId, 0);
    }

    /** Call at end of any bar session where drunk peaked. Tracks daily drunk flag. */
    public void recordPeakDrunk(int peakDrunk) {
        if (peakDrunk >= 13) wasDrunk13Today = true;
    }

    public String getDayName()  { return DAY_NAMES[dayOfWeek]; }
    public String getDayShort() { return DAY_SHORT[dayOfWeek]; }
    public boolean isWeekend()  { return dayOfWeek == 5 || dayOfWeek == 6; }

    public boolean hasTrait(String t)   { 
        String k = t.toLowerCase();
        return traits.contains(k) || timedTraits.containsKey(k); 
    }
    public void    addTrait(String t)   { traits.add(t.toLowerCase()); }
    public void    removeTrait(String t){ 
        String k = t.toLowerCase();
        traits.remove(k); 
        timedTraits.remove(k);
    }
    /** Adds a trait that expires after the given number of in-game days. */
    public void addTimedTrait(String t, int days) {
        timedTraits.put(t.toLowerCase(), dayCount + days);
        onTimedTraitAdded(t.toLowerCase(), days);
    }

    /**
     * Side effects when a timed trait expires naturally.
     * Shaken expiry: removes Conflict_Avoidant only if Shaken added it (not original personality).
     */
    private void onTimedTraitExpired(String trait) {
        switch (trait) {
            case "rattled":
                removeTrait("Rattled");
                break;
            case "hurt":
                removeTrait("Hurt");
                break;
            case "shaken":
                removeTrait("Shaken");
                if (hasTrait("Shaken_Added_CA")) {
                    removeTrait("Conflict_Avoidant");
                    removeTrait("Shaken_Added_CA");
                }
                break;
            case "broken":
                removeTrait("Broken");
                if (hasTrait("Shaken_Added_CA")) {
                    removeTrait("Conflict_Avoidant");
                    removeTrait("Shaken_Added_CA");
                }
                break;
        }
    }

    /**
     * Side effects when a timed trait is applied.
     * Shaken temporarily adds Conflict_Avoidant (if MC didn't already have it)
     * and is tracked by Shaken_Added_CA so it can be removed cleanly on expiry.
     */
    /**
     * Immediate effects when a trauma trait is applied.
     * Also handles diminishing returns — getting hit while already traumatised escalates the tier.
     */
    private void onTimedTraitAdded(String trait, int days) {
        switch (trait) {
            case "rattled":
                // Lightest tier. Rattled while anything worse → no escalation.
                if (hasTrait("Broken") || hasTrait("Shaken") || hasTrait("Hurt")) return;
                // Rattled while Rattled → escalate to Hurt
                if (hasTrait("Rattled")) {
                    removeTrait("Rattled"); removeTimedTrait("rattled");
                    addTimedTrait("hurt", traumaDuration(5)); return;
                }
                changeStat("slut_rep",    -5);
                changeStat("confidence",  -3);
                changeStat("stress",      +5);
                break;

            case "hurt":
                // Hurt while Shaken/Broken → no escalation
                if (hasTrait("Broken") || hasTrait("Shaken")) return;
                // Hurt while Hurt → escalate to Shaken
                if (hasTrait("Hurt")) {
                    removeTrait("Hurt"); removeTimedTrait("hurt");
                    addTimedTrait("shaken", traumaDuration(3)); return;
                }
                // Clear Rattled (Hurt is worse)
                if (hasTrait("Rattled")) { removeTrait("Rattled"); removeTimedTrait("rattled"); }
                changeStat("slut_rep",    -10);
                changeStat("confidence",   -5);
                changeStat("stress",      +10);
                changeStat("happiness",    -5);
                break;

            case "shaken":
                // Shaken while Broken → no escalation
                if (hasTrait("Broken")) return;
                // Shaken while Shaken → escalate to Broken
                if (hasTrait("Shaken")) {
                    removeTrait("Shaken"); removeTimedTrait("shaken");
                    addTimedTrait("broken", traumaDuration(2)); return;
                }
                // Clear Hurt if present (Shaken is worse)
                if (hasTrait("Hurt")) { removeTrait("Hurt"); removeTimedTrait("hurt"); }
                // Apply immediate Shaken hits
                changeStat("slut_rep",    -20);
                changeStat("confidence",  -10);
                changeStat("stress",      +20);
                changeStat("happiness",   -10);
                // Shaken→CA: add Conflict_Avoidant temporarily if not original
                if (!hasTrait("Conflict_Avoidant")) {
                    addTrait("Conflict_Avoidant");
                    addTrait("Shaken_Added_CA");
                }
                break;

            case "broken":
                // Already Broken: no escalation beyond max
                if (hasTrait("Broken")) return;
                // First-time Broken acquisition: slut_rep penalty
                // Broken represents genuine trauma — it pulls back progression.
                // Only fires once per acquisition (guard above prevents repeat hits).
                changeStat("slut_rep", -10);
                // Clear lesser tiers
                if (hasTrait("Shaken")) {
                    if (hasTrait("Shaken_Added_CA")) {
                        removeTrait("Conflict_Avoidant"); removeTrait("Shaken_Added_CA");
                    }
                    removeTrait("Shaken"); removeTimedTrait("shaken");
                }
                if (hasTrait("Hurt")) { removeTrait("Hurt"); removeTimedTrait("hurt"); }
                // Apply immediate Broken hits
                changeStat("slut_rep",    -40);
                changeStat("confidence",  -20);
                changeStat("stress",      +30);
                changeStat("happiness",   -15);
                changeStat("willpower",   -15);
                // Broken also adds CA
                if (!hasTrait("Conflict_Avoidant")) {
                    addTrait("Conflict_Avoidant");
                    addTrait("Shaken_Added_CA");
                }
                break;
        }
    }

    /** Duration for trauma traits adjusted by personality. Min 1 day. */
    private int traumaDuration(int base) {
        boolean fragile = hasTrait("Fragile_Ego") || hasTrait("Conflict_Avoidant") || hasTrait("Shy");
        boolean resilient = hasTrait("Iron_Will") || hasTrait("Self_Assured") || hasTrait("Driven");
        if (fragile)   return base + 1;
        if (resilient) return Math.max(1, base - 1);
        return base;
    }

    /** Removes a timed trait from the timer map without triggering expiry hooks. */
    private void removeTimedTrait(String trait) {
        timedTraits.remove(trait.toLowerCase());
    }

    /** Returns true if player has any of the given traits */
    public boolean hasAnyTrait(String... ts) {
        for (String t : ts) if (hasTrait(t)) return true;
        return false;
    }

    // ── Breast descriptor pool ────────────────────────────────────
    // Rotates through options by dayCount so the same word doesn't repeat every scene.
    // Add or replace entries freely — each array is the full pool for that cup size.
    private static final String[][] BREAST_POOLS = {
        // A cup
        { "perky breasts", "small, perky breasts", "slight breasts", "neat breasts" },
        // B cup
        { "soft breasts", "gentle breasts", "soft, modest breasts", "light breasts" },
        // C cup
        { "full, soft breasts", "rounded breasts", "warm, full breasts", "soft, full breasts" },
        // D cup
        { "full breasts", "generous breasts", "heavy, full breasts", "substantial breasts" },
        // DD cup
        { "heavy breasts", "generous, heavy breasts", "full, heavy breasts", "weighty breasts" },
        // E cup
        { "large, heavy breasts", "heavy, generous breasts", "full, considerable breasts", "substantial, heavy breasts" },
        // F cup
        { "large breasts", "very full breasts", "heavy, large breasts", "considerable breasts" },
    };

    /** Returns a size-appropriate breast descriptor. Rotates by dayCount for variety. */
    public String breastDescriptor() {
        int cup = 0; // 0=A through 6=F
        if      (hasTrait("breasts_f"))  cup = 6;
        else if (hasTrait("breasts_e"))  cup = 5;
        else if (hasTrait("breasts_dd")) cup = 4;
        else if (hasTrait("breasts_d"))  cup = 3;
        else if (hasTrait("breasts_c"))  cup = 2;
        else if (hasTrait("breasts_b"))  cup = 1;
        // breasts_a → 0 (default)
        String[] pool = BREAST_POOLS[cup];
        return pool[dayCount % pool.length];
    }

    // ── Sexual disposition helpers ────────────────────────────────
    public boolean isPrude()             { return hasTrait("Prude"); }
    public boolean isDemure()            { return hasTrait("Demure"); }
    public boolean isModest()            { return hasTrait("Modest"); }
    public boolean isProvocativeSexual() { return hasTrait("Provocative_Sexual") || hasTrait("Provocative"); }
    public boolean isSlut()              { return hasTrait("Slut"); }
    public boolean isWhore()             { return hasTrait("Whore"); }
    public boolean isSexuallyOpen()      { return isProvocativeSexual() || isSlut() || isWhore(); }
    public boolean isSexuallyConservative() { return isPrude() || isDemure() || isModest(); }

    /**
     * Applies trait-based modifiers to a stat change amount before it's applied.
     * Centralises all "Shaken halves happiness" / "STD_serious drains energy" logic.
     */
    private int applyTraitStatMods(String stat, int amount) {
        // Tiered trauma system — Broken > Shaken > Hurt (most restrictive wins)
        boolean broken = hasTrait("Broken");
        boolean shaken = hasTrait("Shaken");
        boolean hurt   = hasTrait("Hurt");
        boolean anyTrauma = broken || shaken || hurt;

        if (!anyTrauma) return amount;

        boolean rattled = hasTrait("Rattled");

        switch (stat) {
            case "happiness":
                if (amount > 0) {
                    if (broken)  return 0;
                    if (shaken)  return Math.max(1, amount / 2);
                    if (hurt)    return Math.max(1, amount * 3 / 4);
                    if (rattled) return Math.max(1, amount * 9 / 10);
                }
                break;
            case "willpower":
                if (amount > 0) {
                    if (broken)  return 0;
                    if (shaken)  return Math.max(1, amount / 2);
                    if (hurt)    return Math.max(1, amount * 3 / 4);
                    if (rattled) return Math.max(1, amount * 9 / 10);
                }
                break;
            case "stress":
                if (amount > 0) {
                    if (broken)  return amount * 3;
                    if (shaken)  return amount * 2;
                    if (hurt)    return amount + (amount / 2);
                    if (rattled) return amount + (amount / 4);
                }
                break;
            case "slut_rep":
                if (amount > 0) {
                    if (broken)  return 0;
                    if (shaken)  return Math.max(0, (int)(amount * 0.3));
                    if (hurt)    return Math.max(0, (int)(amount * 0.6));
                    if (rattled) return Math.max(0, (int)(amount * 0.85));
                }
                break;
            case "arousal":
                // Cap enforcement happens in changeStat after applying amount
                break;
            case "confidence":
                break;
        }
        return amount;
    }

    /** Returns the current trauma-enforced arousal cap. */
    public int traumaArousalCap() {
        if (hasTrait("Broken"))  return 30;
        if (hasTrait("Shaken"))  return 55;
        if (hasTrait("Hurt"))    return 75;
        if (hasTrait("Rattled")) return 90;
        return 100;
    }

    /** Returns the current trauma-enforced confidence cap. */
    public int traumaConfidenceCap() {
        if (hasTrait("Broken"))  return 25;
        if (hasTrait("Shaken"))  return 45;
        if (hasTrait("Hurt"))    return 65;
        if (hasTrait("Rattled")) return 82;
        return 100;
    }

    public void changeStat(String stat, int amount) {
        amount = applyTraitStatMods(stat, amount);
        // npc_rep_<id> keys route to per-NPC reputation
        // Special alias: npc_rep_bar_npc routes to whoever is currently approaching
        if (stat.toLowerCase().startsWith("npc_rep_")) {
            String npcId = stat.substring("npc_rep_".length());
            if ("bar_npc".equals(npcId) && currentApproachingNpc != null && !currentApproachingNpc.isEmpty())
                npcId = currentApproachingNpc;
            changeNpcRep(npcId, amount);
            return;
        }
        // npc_liking — shorthand for npc_rep on current NPC (approaching or dating partner)
        if (stat.equalsIgnoreCase("npc_liking")) {
            String target = currentApproachingNpc;
            // Fall back to any NPC we're dating if no approaching NPC
            if ((target == null || target.isEmpty()) && npcMemory != null) {
                for (java.util.Map.Entry<String,String> e : npcMemory.entrySet()) {
                    if (e.getKey().endsWith(":relationship") && "dating".equals(e.getValue())) {
                        target = e.getKey().replace(":relationship","");
                        break;
                    }
                }
            }
            if (target != null && !target.isEmpty()) changeNpcRep(target, amount);
            return;
        }
        // npc_give_number — records that MC exchanged numbers with current NPC
        if (stat.equalsIgnoreCase("npc_give_number")) {
            if (currentApproachingNpc != null && amount > 0)
                giveNpcNumber(currentApproachingNpc);
            return;
        }
        // npc_relationship_<status> — sets relationship status with current NPC
        if (stat.toLowerCase().startsWith("npc_relationship_")) {
            if (currentApproachingNpc != null) {
                String status = stat.substring("npc_relationship_".length());
                setRelationshipStatus(currentApproachingNpc, amount > 0 ? status : "");
            }
            return;
        }
        // npc_living_together — sets cohabitation flag
        if (stat.equalsIgnoreCase("npc_living_together")) {
            if (currentApproachingNpc != null)
                setNpcMemory(currentApproachingNpc, "living_together", amount > 0 ? "true" : "");
            return;
        }
        switch (stat.toLowerCase()) {
            case "money":      money      = Math.max(-999, money + amount); break;
            case "rent":       rent       = Math.max(0, rent + amount); break;
            case "fitness":    fitness    = clamp(fitness    + amount); break;
            case "work_rep":
            case "reputation": work_rep   = clamp(work_rep  + amount); break;
            case "happiness": {
                // Shaken halves positive gains; STD_serious adds ambient unhappiness via advanceDay
                int ha = (amount > 0 && hasTrait("Shaken")) ? Math.max(1, amount / 2) : amount;
                happiness = clamp(happiness + ha); break;
            }
            case "confidence": {
                int cap = traumaConfidenceCap();
                confidence = Math.min(cap, clamp(confidence + amount)); break;
            }
            case "willpower":  { int _a=(settings!=null&&amount<0)?settings.applyWPDrain(amount):amount; willpower=Math.min(housingWillpowerCap,clamp(willpower+_a)); break; }
            case "stress":     { int _a=(settings!=null&&amount>0)?settings.applyStress(amount):amount; stress=Math.max(housingStressMin,clamp(stress+_a)); break; }

            // stress_sexual — stress from uncomfortable/unwanted sexual situations.
            // Scales automatically by arousal level, MC path trait, and slut_rep.
            // amount is the BASE stress at zero arousal, shy, low rep.
            //
            // Arousal scale (lower arousal = more uncomfortable):
            //   0–24:  ×1.00   25–49:  ×0.60   50–74:  ×0.20   75+:  ×−0.25 (relief)
            //
            // Path trait modifier (added to arousal scale):
            //   Shy:          +0.30   Demure:       +0.15   Exhibitionist: −0.35
            //
            // Slut_rep modifier (comfort with sexual situations grows over time):
            //   0–15:  +0.20   16–40: ±0.00   41–70: −0.20   71+:  −0.35
            case "stress_sexual": {
                // Arousal factor
                double scale;
                if      (arousal >= 75) scale = -0.25;
                else if (arousal >= 50) scale =  0.20;
                else if (arousal >= 25) scale =  0.60;
                else                    scale =  1.00;

                // Path trait modifier
                if (hasTrait("Shy"))
                    scale += 0.30;
                else if (hasTrait("Demure"))
                    scale += 0.15;
                if (hasTrait("Public_Exhibitionist") || hasTrait("Path_Trait_Public_Exhibitionist"))
                    scale -= 0.35;
                else if (hasTrait("Low_Risk_Exhibitionist") || hasTrait("Path_Trait_Low_Risk_Exhibitionist"))
                    scale -= 0.15;

                // Slut_rep comfort modifier
                if      (slut_rep >= 71) scale -= 0.35;
                else if (slut_rep >= 41) scale -= 0.20;
                else if (slut_rep <= 15) scale += 0.20;

                // Apply — floor at 0 for relief scale, respect housing stress floor
                int delta = (int) Math.round(amount * scale);
                stress = Math.max(housingStressMin, clamp(stress + delta));
                break;
            }
            case "slut_rep":   { int _a=(settings!=null)?settings.applySlutRepMult(amount):amount; slut_rep=clamp(slut_rep+_a); break; }
            // Surprise/involuntary rep gain — 50% of the amount, min 1 if amount >= 2
            case "slut_rep_surprise": {
                int reduced = Math.max(amount >= 2 ? 1 : 0, (int) Math.round(amount * 0.5));
                slut_rep = clamp(slut_rep + reduced);
                break;
            }
            case "thrills":          thrills    = clamp(thrills    + amount); break;
            // "arousal" — passive sources (dancing, being groped).
            // Diminishing returns by tier, hard cap at 80:
            //   0-25: full gain
            //  25-50: -1 drag (need +2 to gain +1)
            //  50-75: -2 drag (need +3 to gain +1)
            //  75+:   -3 drag (need +4 to gain +1), hard cap 80
            case "arousal": {
                int gain = amount - arousaldrag();
                int aCap = Math.min(80, traumaArousalCap());
                arousal = Math.min(aCap, clamp(arousal + gain));
                _dynamicCache = null;
                break;
            }
            // "arousal_direct" — MC actively participating (groping him, direct stimulation).
            // Same drag scale but cap at 90 instead of 80.
            case "arousal_direct": {
                int gain = amount - arousaldrag();
                arousal = Math.min(90, clamp(arousal + gain));
                _dynamicCache = null;
                break;
            }
            case "drunk":            drunk      = clampDrunk(drunk + amount); break;
            // drunk_drink applies Alcoholic (−1) / Lightweight (+1) modifier before adding
            // Both traits cancel each other. Displays modified amount in drink text.
            case "drunk_drink": {
                int mod   = drunkMod();
                int final_ = Math.max(0, amount + mod);
                drunk = clampDrunk(drunk + final_);
                break;
            }
            case "npc_frustration":  currentNpcFrustration = Math.max(0, currentNpcFrustration + amount); break;
            case "npc_arousal":      currentNpcArousal     = Math.max(0, currentNpcArousal     + amount); break;
            case "npc_liking":       currentNpcLiking      = Math.max(0, currentNpcLiking      + amount); break;
            case "flag_breast_groped": flagBreastGroped  = amount > 0; break;
            case "flag_ass_groped":    flagAssGroped     = amount > 0; break;
            case "flag_pussy_groped":  flagPussyGroped   = amount > 0; break;
            case "flag_fingered":      flagFingered      = amount > 0; break;
            case "flag_kissed":        flagKissed        = amount > 0; break;
            case "flag_neck_kissed":   flagNeckKissed    = amount > 0; break;
            case "flag_deep_kissed":   flagDeepKissed    = amount > 0; break;
            case "flag_cornered":         flagCornered         = amount > 0; break;
            case "flag_cooked_tonight":   flagCookedTonight    = amount > 0; break;
            case "flag_npc_came":        flagNpcCame         = amount > 0; break;
            case "flag_gloryhole_used":    flagGloryHoleUsed     = amount > 0; break;
            case "flag_cafe_jump_flashed":    flagCafeJumpFlashed   = amount > 0; break;
            case "flag_cafe_sleazy_visited":  flagCafeSleazyVisited = amount > 0; break;
            
            case "timed_neck_hickey":  addTimedTrait("Neck_Hickey", amount); break;
            case "timed_neck_hickey_faint": addTimedTrait("Neck_Hickey", 1); break;
        }
    }

    public void setStat(String stat, int value) {
        switch (stat.toLowerCase()) {
            case "money":      money      = value; break;
            case "rent":       rent       = Math.max(0, value); break;
            case "fitness":    fitness    = clamp(value); break;
            case "work_rep":
            case "reputation": work_rep   = clamp(value); break;
            case "happiness":  happiness  = clamp(value); break;
            case "confidence": confidence = clamp(value); break;
            case "willpower":                willpower              = Math.min(housingWillpowerCap, clamp(value)); break;
            case "stress":                   stress                 = Math.max(housingStressMin, clamp(value)); break;
            case "slut_rep":                 slut_rep               = clamp(value); break;
            case "thrills":                  thrills                = clamp(value); break;
            case "arousal": {
                int cap = traumaArousalCap();
                arousal = Math.min(cap, clamp(arousal + amount)); break;
            }           case "drunk":                    drunk                  = clampDrunk(value); break;
            case "housing_willpower_cap":    housingWillpowerCap      = value; break;
            case "housing_willpower_recovery": housingWillpowerRecovery = value; break;
            case "housing_stress_reduction": housingStressReduction   = value; break;
            case "housing_stress_min":       housingStressMin         = value; break;
        }
    }

    /**
     * Effective willpower after accounting for drunkenness.
     * Scales proportionally: sober = full willpower, blackout (15) = 25% of max willpower,
     * passed out (20) = 0. Formula: willpower × (20 - drunk) / 20
     * Used to gate paths where MC needs backbone to stand up for herself.
     */
    public int effectiveWillpower() {
        return (int)(willpower * (20.0 - drunk) / 20.0);
    }

    /**
     * Effective willpower with an arousal-drain penalty applied.
     * For every 10 arousal above the given threshold, subtract 2.
     * Represents losing resolve as attraction/arousal builds.
     *
     * Example: threshold=50, arousal=70 → base WP minus 4 (on top of drunk penalty).
     * Used for the bar walk-home check and similar resist scenarios.
     */
    public int effectiveWillpowerForCheck(int arousalThreshold) {
        int base = effectiveWillpower();
        if (arousalThreshold > 0 && arousal > arousalThreshold)
            base -= ((arousal - arousalThreshold) / 10) * 2;
        base -= slut_rep / 5;
        return Math.max(0, base);
    }

    /** Looks up a body-state flag by the stat_changes key name. */
    public boolean getBodyFlag(String key) {
        switch (key) {
            case "flag_breast_groped":    return flagBreastGroped;
            case "flag_ass_groped":       return flagAssGroped;
            // ── Composite grope flags ────────────────────────────────────────────
            // True when any groping is actively happening — drives "ask to stop" choice
            case "flag_being_groped":     return flagBreastGroped || flagAssGroped || flagPussyGroped;
            // True after he was told to stop and kept going — drives scream/hard push choices
            case "flag_grope_persisted":  return hasTrait("grope_persisted");
            case "flag_pussy_groped":     return flagPussyGroped;
            case "flag_fingered":         return flagFingered;
            case "flag_kissed":           return flagKissed;
            case "flag_neck_kissed":      return flagNeckKissed;
            case "flag_deep_kissed":      return flagDeepKissed;
            case "flag_cornered":         return flagCornered;
            case "flag_cooked_tonight":   return flagCookedTonight;
            case "flag_npc_came":         return flagNpcCame;
            case "flag_gloryhole_used":   return flagGloryHoleUsed;
            case "flag_cafe_jump_flashed":    return flagCafeJumpFlashed;
            case "flag_cafe_sleazy_visited":  return flagCafeSleazyVisited;
            case "flag_works_velvet_cafe":    return "velvet_cafe".equals(currentJobId)
                                               || "cafe".equals(currentJobId)
                                               || "cafe_morning".equals(currentJobId);
            case "flag_owns_sneakers":        return hasTrait("owns_sneakers") || ownedClothing.contains("sneakers");
            case "flag_dance_locked":     return flagDanceLocked;
            // ── NPC frustration tier flags — computed from currentNpcFrustration ────
            // Used to gate groping escalation choices in YAML
            case "flag_npc_calm":       return currentNpcFrustration < 20;
            case "flag_npc_wanting":    return currentNpcFrustration >= 40;  // tier 2 threshold
            case "flag_npc_escalating": return currentNpcFrustration >= 60;  // tier 3 (fingering)
            case "flag_npc_peak":       return currentNpcFrustration >= 80;  // tier 4
            case "flag_npc_sa_territory": return currentNpcFrustration >= 92; // tier 5 SA
            // ── NPC capability flags — set by BarSystem based on NPC trait ──────────
            // npc_can_grope: NPC type allows groping (Sleazy/Jerk/Alcoholic/Confrontational/Outgoing)
            case "flag_npc_can_grope":  return hasTrait("npc_can_grope");
            // npc_can_finger: NPC type allows fingering (Sleazy/Alcoholic/Confrontational)
            case "flag_npc_can_finger": return hasTrait("npc_can_finger");
            // npc_can_sa: NPC type + frustration allows SA (Sleazy/Alcoholic tier 5 only)
            case "flag_npc_can_sa":     return hasTrait("npc_can_sa");
            // npc_sa_risk: frustration >= 85, Sleazy/Alcoholic — imminent SA territory
            case "flag_npc_sa_risk":    return hasTrait("npc_can_sa") && currentNpcFrustration >= 85;
            // npc_wants_leave: NPC at peak frustration and wants to leave
            case "flag_npc_wants_leave": return hasTrait("npc_wants_leave");
            // npc_returning_to_dance: NPC frustration dropped, going back to normal
            case "flag_npc_returning":  return hasTrait("npc_returning_to_dance");
            // Furniture ownership flags — backed by traits
            
            case "flag_season_spring": return currentSeason == 0;
            case "flag_season_summer": return currentSeason == 1;
            case "flag_season_autumn": return currentSeason == 2;
            case "flag_season_winter": return currentSeason == 3;
            case "flag_season_warm":   return isWarmSeason();
            case "flag_season_cold":   return isColdSeason();
            // Neighbourhood flags
            case "flag_neighbourhood_narrows":    return "The Narrows".equals(currentNeighbourhood);
            case "flag_neighbourhood_millgate":   return "Millgate".equals(currentNeighbourhood);
            case "flag_neighbourhood_thornwick":  return "Thornwick".equals(currentNeighbourhood);
            case "flag_neighbourhood_lanes":      return "The Lanes".equals(currentNeighbourhood);
            case "flag_neighbourhood_caldwell":   return "Caldwell".equals(currentNeighbourhood);
            case "flag_neighbourhood_ravenshill": return "Ravenshill".equals(currentNeighbourhood);
            // Clothing + season combination flags
            case "flag_is_rattled":   return hasTrait("Rattled");
            // ── Game stage tiers for variant gating ─────────────────────────────────
            // Low: inexperienced, first-time feel — full shock and shame
            // Mid: some experience — uncomfortable, pushes back, still affected
            // High: desensitised — anger or numbness over devastation
            case "flag_stage_low":    return slut_rep < 30;
            case "flag_stage_mid":    return slut_rep >= 30 && slut_rep < 65;
            case "flag_stage_high":   return slut_rep >= 65;
            case "flag_npc_traumatised_current":
                // True when the currently approaching NPC has a permanent trauma link
                return !currentApproachingNpc.isEmpty()
                    && hasTrait("npc_trauma_" + currentApproachingNpc);
            case "flag_npc_trauma_timer_active":
                // True while the acute trauma timer is still running for current NPC.
                // Drives intense scared reactions. After expiry, residual mild flash takes over.
                return !currentApproachingNpc.isEmpty()
                    && hasTimedTrait("npc_trauma_timer_" + currentApproachingNpc);
            case "flag_has_any_npc_trauma": {
                // True permanently once any NPC trauma link exists.
                // Drives the residual Rattled-level flash even after all tiers clear.
                for (String trait : traits) {
                    if (trait.startsWith("npc_trauma_") && !trait.startsWith("npc_trauma_timer_"))
                        return true;
                }
                return false;
            }
            case "flag_is_broken":    return hasTrait("Broken");
            case "flag_is_shaken":    return hasTrait("Shaken");
            case "flag_is_hurt":      return hasTrait("Hurt");
            case "flag_is_traumatised": return hasTrait("Broken") || hasTrait("Shaken") || hasTrait("Hurt");
            case "flag_has_std":      return hasTrait("STD_minor") || hasTrait("STD_serious");
            case "flag_is_braless":   return isBraless();
            case "flag_nipping":      return isBraless() && isWearingThinTop();
            case "flag_wearing_thin_top": {
                game.data.ClothingData upper = null; // resolved via outfit upper
                // Simplified: check outfitUpper item thickness via a dedicated helper
                return isWearingThinTop();
            }
            case "flag_high_lewdness": return getCurrentLewdnessRating() >= 60;
            case "flag_very_high_lewdness": return getCurrentLewdnessRating() >= 85;
            case "flag_wearing_dress": {
                String lower = outfitLower != null ? outfitLower.toLowerCase() : "";
                return lower.contains("dress") || lower.contains("sundress");
            }
            case "flag_wearing_skirt": {
                String lower = outfitLower != null ? outfitLower.toLowerCase() : "";
                return lower.contains("skirt");
            }
            case "flag_wearing_dress_or_skirt": {
                String lower = outfitLower != null ? outfitLower.toLowerCase() : "";
                return lower.contains("dress") || lower.contains("sundress") || lower.contains("skirt");
            }
            case "flag_underdressed_for_winter":
                return isColdSeason() && outfitOvercoat == null && (
                    (outfitLower != null && (outfitLower.toLowerCase().contains("dress")
                        || outfitLower.toLowerCase().contains("skirt")
                        || outfitLower.toLowerCase().contains("sundress")))
                    || isBraless()
                );
            
            
            
            
            
            
            
            
            case "flag_has_npc_number":    return currentApproachingNpc != null && hasNpcNumber(currentApproachingNpc);
            case "flag_is_dating_npc":
                // True if actively dating the current bar NPC, OR if player is dating anyone
                if (currentApproachingNpc != null && isDating(currentApproachingNpc)) return true;
                for (java.util.Map.Entry<String,String> e : npcMemory.entrySet())
                    if (e.getKey().endsWith(":relationship_status") && isDating(e.getKey().replace(":relationship_status",""))) return true;
                return false;
            case "flag_is_married_npc":    return currentApproachingNpc != null && isMarried(currentApproachingNpc);
            case "flag_is_open_rel_npc":   return currentApproachingNpc != null && isOpenRelationship(currentApproachingNpc);
            case "flag_is_living_together":return currentApproachingNpc != null && isLivingTogether(currentApproachingNpc);
            case "flag_is_pregnant":       return isPregnant();
            case "flag_alcoholic_craving":    return hasTrait("Alcoholic");
            case "flag_on_period":           return isOnPeriod();
            // Job perk flags — for discounts at visitable locations
            case "flag_works_library":       return "library".equals(currentJobId);
            case "flag_works_bookshop":      return "bookshop".equals(currentJobId);
            case "flag_works_kitchen":       return "restaurant_kitchen".equals(currentJobId);
            case "flag_works_tattoo":        return "tattoo_studio".equals(currentJobId);
            case "flag_works_neon_fitness":  return "neon_fitness".equals(currentJobId);
            case "flag_works_bar":           return "bar_staff".equals(currentJobId);
            case "flag_works_retail":        return "retail".equals(currentJobId);
            // Wellbeing flags
            case "flag_high_stress":         return stress >= 70;
            case "flag_low_willpower":       return willpower <= 25;
            case "flag_drunk_tonight":       return drunk >= 11;
            case "flag_happy":               return happiness >= 70;
            case "flag_broke":               return money < 300;
            case "flag_owns_property":         return hasTrait("owns_property");
            case "flag_neighbourhood_premium": return hasTrait("neighbourhood_premium");
            default:
                // Dynamic neighbourhood flags from neighbourhoods.yml
                if (key.startsWith("flag_neighbourhood_")) {
                    String suffix = key.substring("flag_neighbourhood_".length());
                    String name   = NEIGHBOURHOOD_FLAGS.get(suffix);
                    if (name != null) return name.equals(currentNeighbourhood);
                }
            case "flag_lives_house":           return hasTrait("lives_house");
            // Furniture / item ownership flags
            case "flag_has_tv":           return ownedClothing.contains("furniture_tv")       || hasTrait("has_tv");
            case "flag_has_bookshelf":    return ownedClothing.contains("furniture_bookshelf") || hasTrait("has_bookshelf");
            case "flag_has_mirror":       return ownedClothing.contains("furniture_mirror")    || hasTrait("has_mirror");
            case "flag_has_coffee_maker": return ownedClothing.contains("furniture_coffee")    || hasTrait("has_coffee_maker");
            case "flag_has_good_mattress":return ownedClothing.contains("furniture_mattress")  || hasTrait("has_good_mattress");
            case "flag_has_wardrobe":     return ownedClothing.contains("furniture_wardrobe")  || hasTrait("has_wardrobe");
            case "flag_has_dresser":      return ownedClothing.contains("furniture_dresser")   || hasTrait("has_dresser")
                                              || ownedClothing.contains("furniture_dresser_nice");
            case "flag_has_dresser_basic":return ownedClothing.contains("furniture_dresser")   || hasTrait("has_dresser");
            case "flag_has_dresser_nice": return ownedClothing.contains("furniture_dresser_nice") || hasTrait("has_dresser_nice");
            // NPC / social flags
            
            
            
            
            default: return false;
        }
    }


    private int clamp(int v)     { return Math.max(0,   Math.min(100, v)); }
    private int clampDrunk(int v){ return Math.max(0,   Math.min(20,  v)); }

    /**
     * Diminishing returns drag on arousal gains.
     * Returns how many points to subtract from any incoming arousal delta.
     *   0–25:  drag 0  (full gain)
     *  25–50:  drag 1  (need +2 to gain +1)
     *  50–75:  drag 2  (need +3 to gain +1)
     *  75+:    drag 3  (need +4 to gain +1)
     */
    private int arousaldrag() {
        if (arousal >= 75) return 3;
        if (arousal >= 50) return 2;
        if (arousal >= 25) return 1;
        return 0;
    }

    /**
     * Lifetime cap per action type (from spec table).
     */
    public static int slutRepLifetimeCap(String actionType) {
        switch (actionType) {
            // Breast flash tiers
            case "low_risk_flash":         return 12;
            case "high_risk_flash":        return 16;
            case "watched_flash":          return 20;
            // Lower body flash tiers — significantly more intimate
            case "low_risk_flash_lower":   return 28;
            case "high_risk_flash_lower":  return 38;
            case "watched_flash_lower":    return 48;
            // Generic
            case "public_act":             return 14;
            default:                       return 20;
        }
    }

    /**
     * Applies diminishing returns to a slut_rep gain based on how much
     * has already been earned from this action type over the game lifetime.
     *
     * Formula:
     *   Earned 0–4:   full gain
     *   Earned 5–8:   ceil(gain / 2)
     *   Earned 9–12:  ceil(gain / 4), minimum 0
     *   Earned 12+:   0 (soft cap reached)
     *
     * Also enforces the hard lifetime cap for the type.
     * Returns the effective gain (may be 0).
     */
    public int applySlutRepEarned(String actionType, int baseGain) {
        int cap    = slutRepLifetimeCap(actionType);
        int earned = slutRepEarnedByType.getOrDefault(actionType, 0);

        if (earned >= cap) return 0; // hard lifetime cap

        // Diminishing returns — thresholds scale with lifetime cap so higher-cap
        // action types (watched_flash cap=20) allow proportionally more total gain
        // than lower-cap types (low_risk_flash cap=12).
        //
        // Thresholds at cap * [0.25, 0.50, 0.75]:
        //   low_risk  (cap=12): full <3, half <6, quarter <9, zero 9+
        //   high_risk (cap=16): full <4, half <8, quarter <12, zero 12+
        //   watched   (cap=20): full <5, half <10, quarter <15, zero 15+
        //   public_act(cap=14): full <4, half <7, quarter <11, zero 11+
        int q1 = cap / 4;
        int q2 = cap / 2;
        int q3 = (cap * 3) / 4;

        int dimGain;
        if      (earned < q1) dimGain = baseGain;
        else if (earned < q2) dimGain = Math.max(1, (int) Math.ceil(baseGain / 2.0));
        else if (earned < q3) dimGain = Math.max(0, (int) Math.ceil(baseGain / 4.0));
        else                  dimGain = 0;

        // Don't exceed remaining lifetime cap
        int remaining = cap - earned;
        int effective = Math.min(dimGain, remaining);

        if (effective > 0) {
            slutRepEarnedByType.put(actionType, earned + effective);
        }
        return effective;
    }

    /**
     * Modifier applied to drink buzz.
     * Alcoholic: −1 per drink (tolerance — still feels less).
     * Lightweight: +1 per drink (goes faster).
     * Both: cancel out → 0.
     */
    public int drunkMod() {
        boolean alco = hasTrait("Alcoholic");
        boolean lite = hasTrait("Lightweight");
        if (alco && lite) return 0;
        if (alco)         return -1;
        if (lite)         return +1;
        return 0;
    }

    /** Get reputation with a specific NPC (defaults to 0 = neutral) */
    public int getNpcRep(String npcId) {
        return npcReputation.getOrDefault(npcId, 0);
    }

    /** Change reputation with a specific NPC (-100 hate … 0 neutral … +100 love) */
    public void changeNpcRep(String npcId, int amount) {
        int current = getNpcRep(npcId);
        npcReputation.put(npcId, clampNpc(current + amount));
    }

    /** Set reputation with a specific NPC */
    public void setNpcRep(String npcId, int value) {
        npcReputation.put(npcId, clampNpc(value));
    }

    private int clampNpc(int v) { return Math.max(-100, Math.min(100, v)); }

    // ── Per-NPC relationship helpers ─────────────────────────────────────────
    // Relationship statuses: "" (none), "dating", "partnered", "married",
    //                        "open_relationship", "friends_with_benefits"
    // Stored in npcMemory as npcId:relationship_status

    public boolean hasNpcNumber(String npcId) {
        return "true".equals(getNpcMemory(npcId, "has_number"));
    }
    public void giveNpcNumber(String npcId) {
        setNpcMemory(npcId, "has_number", "true");
    }

    public String getRelationshipStatus(String npcId) {
        return getNpcMemory(npcId, "relationship_status"); // "" = none
    }
    public void setRelationshipStatus(String npcId, String status) {
        setNpcMemory(npcId, "relationship_status", status);
    }
    public boolean isDating(String npcId) {
        String s = getRelationshipStatus(npcId);
        return "dating".equals(s) || "partnered".equals(s) || "married".equals(s)
            || "open_relationship".equals(s) || "friends_with_benefits".equals(s);
    }
    public boolean isMarried(String npcId) {
        return "married".equals(getRelationshipStatus(npcId));
    }
    public boolean isOpenRelationship(String npcId) {
        return "open_relationship".equals(getRelationshipStatus(npcId));
    }
    public boolean isLivingTogether(String npcId) {
        return "true".equals(getNpcMemory(npcId, "living_together"));
    }
    public boolean isPregnant() {
        return hasTrait("Pregnant");
    }


}
