package game.data;

import java.util.*;

public class JobData {
    public String       id              = "";
    public String       label           = "";
    public String       description     = "";
    public int          pay_per_day     = 0;
    public int          slots_per_day   = 4;
    public List<String> work_days       = new ArrayList<>();
    public Map<String,Integer> stat_changes = new LinkedHashMap<>();
    public String       boss_npc_id     = "";
    public List<String> coworker_npc_ids = new ArrayList<>();

    // Pay schedule: DAILY, WEEKLY, BIWEEKLY
    public String       pay_frequency   = "WEEKLY";

    // Under the table = no tax deducted
    public boolean      under_the_table = false;

    /** Days worked per week based on work_days list */
    public int daysPerWeek() { return work_days.size(); }

    /** Gross pay per paycheck before tax */
    public int grossPaycheck() {
        int perDay = pay_per_day;
        switch (pay_frequency.toUpperCase()) {
            case "DAILY":    return perDay;
            case "WEEKLY":   return perDay * daysPerWeek();
            case "BIWEEKLY": return perDay * daysPerWeek() * 2;
            default:         return perDay * daysPerWeek();
        }
    }

    /** Net pay after tax (or gross if under the table) */
    public int netPaycheck() {
        if (under_the_table) return grossPaycheck();
        return grossPaycheck() - taxAmount();
    }

    /** Tax deducted per paycheck */
    public int taxAmount() {
        if (under_the_table) return 0;
        // Annualize income to find bracket
        int annualGross = pay_per_day * daysPerWeek() * 52;
        double rate;
        if      (annualGross <= 15000) rate = 0.10;
        else if (annualGross <= 40000) rate = 0.12;
        else if (annualGross <= 85000) rate = 0.22;
        else                           rate = 0.24;
        // Apply rate to this paycheck
        return (int) Math.round(grossPaycheck() * rate);
    }

    public String taxBracketLabel() {
        if (under_the_table) return "Untaxed";
        int annual = pay_per_day * daysPerWeek() * 52;
        if      (annual <= 15000) return "10%";
        else if (annual <= 40000) return "12%";
        else if (annual <= 85000) return "22%";
        else                      return "24%";
    }

    public String payFrequencyLabel() {
        switch (pay_frequency.toUpperCase()) {
            case "DAILY":    return "daily";
            case "WEEKLY":   return "weekly";
            case "BIWEEKLY": return "every two weeks";
            default:         return "weekly";
        }
    }
}
