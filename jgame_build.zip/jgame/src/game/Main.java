package game;

import game.data.TraitCategoryData;
import game.ui.GameWindow;
import javax.swing.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        String base = System.getProperty("user.dir");

        GameSettings    settings        = new GameSettings();
        SettingsManager settingsMgr     = new SettingsManager(base, settings);
        settingsMgr.load();

        GameState       state           = new GameState();
        state.settings = settings; // inject multipliers
        // Install crash reporter FIRST — catches everything from this point on
        CrashReporter.install(base, state);
        // Starting conditions — floor mattress, bare apartment, 2 outfits
        state.addTrait("sleeping_on_floor");
        SceneLoader    sceneLoader    = new SceneLoader(base + "/scenes");
        NpcLoader      npcLoader      = new NpcLoader();
        ClothingLoader clothingLoader = new ClothingLoader();
        ActivityLoader activityLoader = new ActivityLoader();
        JobLoader      jobLoader      = new JobLoader();
        InterviewLoader interviewLoader = new InterviewLoader();

        npcLoader.loadAll(base + "/npcs");
        clothingLoader.loadAll(base + "/clothes");
        activityLoader.loadAll(base + "/activities");
        jobLoader.loadAll(base + "/jobs");
        interviewLoader.loadAll(base + "/interviews");

        List<TraitCategoryData> traitCats = TraitLoader.load(base + "/gamedata/traits.yml");
        Engine engine = new Engine(state, sceneLoader, npcLoader, clothingLoader);
        engine.setJobs(jobLoader); // gives bar system access to boss/coworker data for 5% filter

        try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
        catch (Exception ignored) {}

        // Load mods AFTER base loaders are ready — mods inject into existing loaders
        game.mod.ModLoader modLoader = new game.mod.ModLoader(base, sceneLoader, npcLoader, clothingLoader, jobLoader);
        modLoader.loadAll();

        game.SaveManager saveManager = new game.SaveManager(base, state);

        SwingUtilities.invokeLater(() -> {
            GameWindow w = new GameWindow(state, sceneLoader, npcLoader, engine,
                                          activityLoader, jobLoader, interviewLoader,
                                          clothingLoader, traitCats);
            w.setVisible(true);
            w.showMainMenu(modLoader, saveManager, settingsMgr);
        });
    }
}
