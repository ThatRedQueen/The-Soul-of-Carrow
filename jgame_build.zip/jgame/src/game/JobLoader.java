package game;

import game.data.JobData;
import org.yaml.snakeyaml.Yaml;
import java.io.*;
import java.util.*;

public class JobLoader {
    private final Map<String, JobData> jobs = new LinkedHashMap<>();

    @SuppressWarnings("unchecked")
    public void loadAll(String dir) {
        File folder = new File(dir);
        if (!folder.exists()) return;
        Yaml yaml = new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions()));
        File[] _files = folder.listFiles(); if (_files == null) return; for (File f : _files) {
            if (!f.getName().endsWith(".yml")) continue;
            try (InputStream is = new FileInputStream(f)) {
                Map<String,Object> raw = yaml.load(is);
                if (raw == null) continue;
                JobData j = parseJob(raw);
                if (j != null && !j.id.isEmpty()) jobs.put(j.id, j);
            } catch (Exception e) { System.err.println("Error loading job " + f.getName() + ": " + e.getMessage()); }
        }
    }

    public JobData get(String id)       { return jobs.get(id); }
    public Collection<JobData> getAll() { return jobs.values(); }
    public boolean isWorkDay(String jobId, String dayName) {
        JobData j = get(jobId);
        return j != null && j.work_days.stream().anyMatch(d -> d.equalsIgnoreCase(dayName));
    }

    private String str(Map<String,Object> m, String k) { Object v = m.get(k); return v == null ? "" : v.toString(); }
    private int intVal(Map<String,Object> m, String k, int def) {
        Object v = m.get(k); if (v == null) return def;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return def; }
    }
    private boolean boolVal(Map<String,Object> m, String k, boolean def) {
        Object v = m.get(k); return v == null ? def : Boolean.parseBoolean(v.toString());
    }
    /** Inject a job from a mod. Returns true on success. */
    @SuppressWarnings("unchecked")
    JobData parseJob(java.util.Map<String, Object> raw) {
        if (raw == null) return null;
        JobData j = new JobData();
        j.id              = str(raw, "id");
        j.label           = str(raw, "label");
        j.description     = str(raw, "description");
        j.pay_per_day     = intVal(raw, "pay_per_day",   0);
        j.slots_per_day   = intVal(raw, "slots_per_day", 4);
        j.boss_npc_id     = str(raw, "boss_npc_id");
        Object cw = raw.get("coworker_npc_ids");
        if (cw instanceof List) for (Object o : (List<?>)cw) if (o != null) j.coworker_npc_ids.add(o.toString());
        j.pay_frequency   = str(raw, "pay_frequency");
        if (j.pay_frequency.isEmpty()) j.pay_frequency = "WEEKLY";
        j.under_the_table = boolVal(raw, "under_the_table", false);
        Object wd = raw.get("work_days");
        if (wd instanceof List) for (Object o : (List<?>)wd) if (o != null) j.work_days.add(o.toString().toUpperCase());
        Object sc = raw.get("stat_changes");
        if (sc instanceof Map) for (Map.Entry<?,?> e : ((Map<?,?>)sc).entrySet()) {
            try { j.stat_changes.put(e.getKey().toString(), Integer.parseInt(e.getValue().toString())); } catch (Exception ignored) {}
        }
        return j;
    }


    public boolean injectModJob(java.util.Map<String, Object> raw, String modId) {
        try {
            JobData j = parseJob(raw);
            if (j == null || j.id == null || j.id.isEmpty()) return false;
            jobs.put(j.id, j);
            return true;
        } catch (Exception e) {
            System.err.println("[JobLoader] injectModJob failed: " + e.getMessage());
            return false;
        }
    }

}
