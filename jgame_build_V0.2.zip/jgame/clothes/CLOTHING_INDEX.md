# Clothing Index

All items load automatically — drop any `.yml` anywhere in `clothes/`.
Subfolders: `shop/` = purchasable, `starting/` = starting wardrobe.

## bra
- `basic_bra` — Basic Cotton Bra lewdness:5
- `push_up_bra` — Push-Up Bra lewdness:35
- `shop_balconette_bra` — Balconette Bra ($48) lewdness:55
- `shop_lace_bra` — Lace Bralette ($38) lewdness:55
- `shop_sports_bra` — Sports Bra ($32) lewdness:10
- `strapless_bra` — Strapless Bra lewdness:10

## lower
- `black_leggings` — Black Leggings lewdness:20
- `blue_jeans` — Blue Jeans lewdness:5
- `denim_shorts` — Denim Shorts lewdness:25
- `grey_sweatpants` — Grey Sweatpants lewdness:20
- `shop_cargo_trousers` — Cargo Trousers ($62) lewdness:5
- `shop_maxi_skirt` — Floral Maxi Skirt ($45) lewdness:10
- `shop_mini_skirt` — Black Mini Skirt ($42) lewdness:50
- `shop_pencil_skirt` — Pencil Skirt ($58) lewdness:25
- `shop_pleated_skirt` — Pleated Mini Skirt ($44) lewdness:40
- `shop_wet_look_leggings` — Wet-Look Leggings ($48) lewdness:50
- `shop_yoga_leggings` — Yoga Leggings ($38) lewdness:35
- `yoga_pants` — Yoga Pants lewdness:30

## overcoat
- `shop_leather_jacket` — Leather Jacket ($120) lewdness:25
- `trenchcoat` — Trenchcoat lewdness:10

## shoes
- `heeled_boots` — Heeled Ankle Boots ($85) lewdness:30
- `heels` — Heeled Pumps ($70) lewdness:45
- `nice_flats` — Ballet Flats ($55) lewdness:5
- `sandals` — Simple Sandals
- `shop_ankle_boots` — Black Ankle Boots ($90) lewdness:15
- `shop_kitten_heels` — Kitten Heels ($65) lewdness:15
- `shop_platform_boots` — Platform Boots ($95) lewdness:30
- `shop_strappy_heels` — Strappy Heels ($70) lewdness:30
- `sneakers` — White Sneakers

## socks
- `ankle_socks` — Ankle Socks
- `opaque_tights` — Opaque Black Tights lewdness:10
- `sheer_tights` — Sheer Nude Tights lewdness:20
- `shop_thigh_highs_white` — White Thigh-High Stockings ($28) lewdness:70
- `thigh_highs` — Black Thigh-High Stockings lewdness:65

## underwear
- `basic_underwear` — Cotton Underwear lewdness:5
- `boyshorts` — Cotton Boyshorts lewdness:10
- `g_string` — Black G-String lewdness:75
- `shop_lace_underwear` — Lace Underwear ($24) lewdness:60
- `shop_micro_thong` — Micro Thong ($18) lewdness:85
- `thong` — Black Thong lewdness:40

## unknown
- `casual_outfit` — Casual Outfit lewdness:10
- `cocktail_dress` — Cocktail Dress lewdness:35
- `loose_top` — Loose Top lewdness:30
- `white_sundress` — White Sundress lewdness:25

## upper
- `black_dress` — Little Black Dress ($65) lewdness:55
- `camisole` — Silk Camisole lewdness:35
- `casual_dress` — Casual Sundress lewdness:20
- `fitted_tshirt` — Fitted T-shirt ($22) lewdness:15
- `flannel_shirt` — Flannel Shirt lewdness:10
- `hoodie` — Oversized Hoodie lewdness:5
- `shop_bodycon_dress` — Bodycon Dress ($85) lewdness:60
- `shop_button_shirt` — Oxford Button Shirt ($55) lewdness:10
- `shop_corset_top` — Corset Top ($78) lewdness:65
- `shop_crop_hoodie` — Crop Hoodie ($52) lewdness:30
- `shop_crop_top_black` — Black Crop Top ($28) lewdness:45
- `shop_off_shoulder_top` — Off-Shoulder Top ($38) lewdness:30
- `shop_ribbed_tank` — Ribbed Fitted Tank ($22) lewdness:35
- `shop_sheer_blouse` — Sheer Button Blouse ($58) lewdness:60
- `shop_sheer_top` — Sheer Chiffon Top ($52) lewdness:65
- `shop_silk_blouse` — Silk Blouse ($65) lewdness:15
- `shop_wrap_dress` — Wrap Dress ($72) lewdness:25
- `summer_dress` — Summer Dress ($48) lewdness:25
- `tank_top` — White Tank Top lewdness:20
- `tube_top` — Black Tube Top lewdness:45
- `white_tshirt` — White T-Shirt lewdness:5

