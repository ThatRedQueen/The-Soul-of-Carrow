# Housing Index

Housing options are defined as scenes in `scenes/main/housing*.yml`.
Landlord NPCs are in `npcs/` — IDs referenced by the `_set_housing_` trait in scenes.

## Current Options

### housing.yml
  # Neighbourhood → Landlord:
  #   Respectable → landlord_1bed       (Robert Collins — professional)
  #   Middle      → landlord_shared_house (Dave — decent, reasonable)
  #   Rough       → landlord_studio     (Frank — cold, transactional)
  #   Slums       → landlord_basement   (Mitch — sleazy, will proposition on shortage)
  # _set_housing_ format: _set_housing_{landlord_npc_id}_{monthly_rent}
  You open a rental app and start browsing.
  # RESPECTABLE DISTRICT — Robert Collins (landlord_1bed)
  # Rent shortage = paperwork, not a conversation.
  in the morning. Your landlord is Robert Collins — property management company,
  rent: 1200
  - _set_housing_landlord_1bed_1200
  rent: 1600
  - _set_housing_landlord_1bed_1600
  result_text: "It's the best place you've ever rented. You're going to feel every dollar of this."
  rent: 1900
  - _set_housing_landlord_1bed_1900
  # MIDDLE DISTRICT — Dave (landlord_shared_house)
  Your landlord is Dave — genuinely friendly, won't make things weird if
  rent: 550
  - _set_housing_landlord_shared_house_550
  rent: 750
  - _set_housing_landlord_shared_house_750
  rent: 1100
  - _set_housing_landlord_shared_house_1100
  # LOW INCOME AREA — Frank (landlord_studio)
  Your landlord is Frank — not unkind, not warm. Rent is a transaction.
  rent: 350
  - _set_housing_landlord_studio_350
  rent: 400
  - _set_housing_landlord_studio_400
  rent: 550
  - _set_housing_landlord_studio_550
  rent: 750
  - _set_housing_landlord_studio_750
  rent: 700
  - _set_housing_landlord_studio_700
  # THE SLUMS — Mitch (landlord_basement)
  Your landlord is Mitch — he introduces himself with a nickname and a grin,
  rent: 175
  - _set_housing_landlord_basement_175
  rent: 250
  - _set_housing_landlord_basement_250
  rent: 400
  - _set_housing_landlord_basement_400
  rent: 600
  - _set_housing_landlord_basement_600
  rent: 500
  - _set_housing_landlord_basement_500

### housing_descriptions.yml
  This is the best place you've ever rented. It still doesn't feel
  The rent is the only thing that doesn't disappoint.
  adequate. The building smells like cooking from three different
  The rent is $400. You're here.
  No landlord. No rent day. You own this one in Carrow — that means something.

### housing_premium.yml
  # PREMIUM HOUSING — high-end rentals and buyable properties
  # Rentals: $2,000–$3,000/month with best modifiers
  # Buy: $350k–$700k — requires min_money, no monthly rent, best modifiers
  # Modifiers for premium rentals:
  You sign the lease feeling like a different version of yourself.
  rent: 2000
  - _set_housing_landlord_1bed_2000
  rent: 2500
  - _set_housing_landlord_1bed_2500
  rent: 3000
  - _set_housing_landlord_1bed_3000
  No landlord. No rent. Just a mortgage payment that's yours to
  rent: 0
  rent: 0
  rent: 0

### housing_search.yml
  # Shows current tenancy info, option to give notice, browse new listings
  You open the rental listings again.
  Your current place works, more or less. But more or less is only
  - text: Give notice on your current place and move.

## To Add Housing
1. Add landlord NPC to `npcs/landlord_name.yml`
2. Add choice to `scenes/main/housing.yml` with trait `_set_housing_npcid_rentamount`
3. Optionally add scenes to `scenes/main/` for move-in / arrival text
