# BRIEF: Sexual Assault Scene Writing — For Grok

## What this content is for

These scenes are not NSFW content in the same category as the rest of the game.
They are awareness content. The goal is empathy, not arousal.
A player who finishes these scenes should feel something difficult.
That is the point. Write toward that, not away from it.

---

## The design

**The incident:**
The NPC ignores a verbal no and continues.
The MC still has physical response options — she is not powerless.
But her "stop" was ignored and the player needs to feel that.

Options should include:
- Push him away / physically stop it (assertive, may succeed or may not depending on NPC state)
- Freeze — do nothing, body goes somewhere else (this is real, model it honestly)
- Go along with it to end it faster (this is also real, do not judge it in the text)

The game should NOT frame the NPC as dominant or exciting in this moment.
He is doing something wrong. The text should make that clear without editorialising —
show it through MC's inner state, not through a narrator telling the player how to feel.

**Verbal no ignored — the moment:**
When the player picks "say no" or "tell him to stop" and it doesn't work,
the result_text should capture the specific experience of being ignored.
Not melodrama. The specific, ordinary awfulness of it.
The way time moves differently. The way you're aware of the room.
The way part of you goes somewhere else.

---

## The aftermath — this is the important part

The incident scene matters less than what comes after.

**Immediate:**
- Leaving. The walk home. Night air and what just happened.
  Write this as a specific sensory experience, not summary.
- The flat. The door. The specific silence of the room after.

**The broken trait: `Shaken`**

A new timed trait lasting 5-7 days with real mechanical effects:

```yaml
# Applied via add_traits: [Shaken:7] in aftermath scene
# Timed trait — clears after 7 days
```

While Shaken is active:
- All happiness gains halved
- Stress gains doubled
- Willpower costs increased
- Special text_variants fire in morning_routine, home_quiet_evening,
  home_shower, home_phone_catch_up, home_read
- Bars are blocked (requires_not_trait: Shaken on bar_night)
  or a specific sad variant fires instead of normal bar content

**Morning after:**
A specific scene that fires the next morning when Shaken is active.
Not dramatic. Specific.
- Waking up
- The first few seconds before it comes back
- Then it comes back
- Getting up anyway

**The crying scene:**
A home scene that can fire during the Shaken window.
It doesn't have to be the player's choice — can fire as a possible_trigger
from stay_home at low probability while Shaken.

Write it as: it happens. Not as performance, not as breakdown.
The specific ordinary version of it — sitting somewhere, the thing surfacing,
crying because there's nowhere else for it to go.
Then it passes. You're still in the flat. The flat is the same.

**Text in Shaken morning_routine variant:**
Something like: you wake up and for three seconds it's a normal morning.
Then it isn't.
You get up. You do the things. Some of them feel far away.

**The recovery arc:**
Day 5-6 of Shaken: a scene where something small is okay.
Not recovered — just: something was okay today.
Day 7 when Shaken lifts: no fanfare. Just the morning feels slightly more like before.
The game should not make this feel like a resolution. It's just the next thing.

---

## What NOT to do

- Do not write the NPC as villainous in a cartoonish way — he's just someone who did this
- Do not have the MC narrate that what happened was assault — she may not name it
- Do not resolve it quickly or neatly
- Do not use this content as part of the rep/lewdness system — it is not exhibitionism content
- Do not write the incident scene as a build to climax — end it before that point
- Do not include the incident in go_out random triggers — it fires from a specific NPC path

---

## Where it sits in the game

- Fires from bar_night when: Alcoholic or Jerk NPC, MC drunk above 8, specific scene path
- Player chose to go home with this NPC or was in a situation that escalated
- Uses the existing drunk/NPC trait system but branches differently from consensual content
- The NPC is from the existing pool — not a special SA-only NPC
  (this matters: it makes it feel real rather than safely distant)

---

## The tag

Market with the Sexual Violence content tag.
Players who don't want this content will filter it or skip it.
Players who encounter it having opted in will encounter it honestly.
This is the correct approach. Most games that have this content don't tag it.
That's the actual problem.

---

## The writing standard

The rest of this game already does the internal monologue well.
Apply the same standard here but in the other direction —
not building arousal, building presence in a difficult moment.

The test for whether a scene is doing its job:
Does the player feel something they weren't expecting to feel in this genre?
Do they think about it after they close the game?
Does it change, even slightly, how they think about the real-world version of this?

If yes: the scene is doing what it's supposed to do.
If no: rewrite it until it does.

---

## Grok prompt structure for scene generation

When generating these scenes, prompt Grok with:

1. "Write the scene from the MC's perspective, present tense second person.
   She is not enjoying this. She is managing it. Show that difference specifically."

2. "The NPC should not be described in language that is attractive or dominant.
   He is ordinary. That's what makes it wrong."

3. "Include the specific physical sensory detail of dissociation if the player
   picks the freeze option — where attention goes when the body doesn't have
   anywhere to put what's happening."

4. "Write the morning after as: three seconds of normal, then remembering.
   Do not describe what she remembers. Describe what she does with her body
   in the next ten minutes."

5. "The crying scene: she doesn't decide to cry. It happens.
   Write from that position — not performing grief, just what the body does
   when it runs out of somewhere to put something."

---

## Final note

This content can make this game matter in a way most games in this genre never do.
Done wrong it's harmful. Done right it's one of the most valuable things
a game like this can contain.

Write it as if someone playing it might really need it to be true.
Because they might.
