---

## WORLD LORE NOTE
# Public exposure has no legal consequence in this setting.
# NPCs and social scenes reference JUDGMENT and REPUTATION only, never legal risk.
# Slut_rep is a game-stage tracker — it gates content, it does NOT appear as dialogue.
# Character reactions to exposure/escalation are social (embarrassment, reputation,
# judgment from bystanders) not legal.
# This applies to all bar scenes, dance floor, walk home, and morning after scenes.

---

# BAR SLOW DANCE — FULL REFERENCE CONTENT
# Stored here for future expansion. Not active in engine.
# Pull from here when adding new variants, groping dialogue, or clothing reactions.
# Reaction tier is determined by slut_rep + drunk (not trait-gated):
#   shock     = slut_rep < 10 AND drunk < 11
#   flustered = mid range
#   enjoy     = slut_rep >= 20 AND drunk >= 11

---

## SHY MC CLOTHING REACTIONS — INTERNAL PANIC

### Bounce Prone
**Tipsy:** *Oh no… they're bouncing. I can feel them moving every time we sway. He's looking — why is he looking? My face is burning.* "I… I shouldn't have worn this…"
**Drunk:** *They're bouncing way too much now… everyone can see.* "They… they keep moving… I can't stop it…"
**Blackout:** *Everything is spinning… my chest won't stop bouncing… I know he's watching but I can't do anything about it…* [weak embarrassed whimper]

### Nipping
**Tipsy:** *Oh god, they're hard… you can see them right through the fabric.* "Don't… don't look there please…"
**Drunk:** *They're so obvious now… every little movement makes them poke out more.* "They're… they're showing… I'm sorry…"
**Blackout:** *The cold air keeps making them harder… I know he can see… I can't even cover myself…* [tiny humiliated sound]

### Pierced Nipping
**Tipsy:** *The piercings are making them even more noticeable… the metal shows through.* "The… the piercings… you can see them, can't you?"
**Drunk:** *Every sway makes the little bars catch the light… I feel like a slut on display.* "They're pierced… everyone can tell… I hate this…"
**Blackout:** *The piercings keep tugging slightly with every movement…* [soft broken whimper]

### Braless
**Tipsy:** *No bra… I can feel them moving freely against him.* "I… I forgot a bra… sorry…"
**Drunk:** *They're just loose and soft against his chest… every shift makes me feel more naked.* "They're… they're not supported… you can probably feel everything…"
**Blackout:** *No bra at all… they're completely free and pressing into him…* [faint embarrassed whine]

### Cameltoe
**Tipsy:** *Oh god, the outline is so obvious between my legs…* "It's… it's showing… please don't look…"
**Drunk:** *The fabric is clinging right there… he's probably staring at my pussy outline.* "You… you can see it, can't you? I'm so embarrassed…"
**Blackout:** *The cameltoe keeps rubbing against him with every sway… I know it's visible but I can't fix it…* [tiny mortified sound]

### Commando
**Tipsy:** *No panties… every time we move I feel the air between my legs.* "I'm… I'm not wearing anything underneath… don't go lower, okay?"
**Drunk:** *Nothing under the skirt… I'm completely bare down there.* "No panties… you'll feel everything if you… if your hand…"
**Blackout:** *Bare… completely bare under this short skirt… he could touch me so easily…* [soft helpless whimper]

### General Shy Escalation (mix in as needed)
- **Tipsy:** *Why did I wear this? Everyone's going to notice… I feel so exposed and small.*
- **Drunk:** *I can't believe I let myself go out like this… the alcohol made it seem like a good idea but now I just want to hide.*
- **Blackout:** *Everything feels too much… too exposed… too many eyes and hands… I can't think… can't move…*

### Shy spoken reactions (short, use sparingly)
- "I… I didn't think it would show this much…"
- "Please don't stare…"
- "This is so embarrassing…"
- "I feel naked…"
- "My heart is beating so fast…"
- "I should have worn something else…"

---

## GROPING DIALOGUE EXPANSION — SLEAZY NPC

### Breast Groping (Bounce / Braless / Nipping / Pierced Nipping)

**Tipsy**
NPC: "Fuuuuck, these tits feel even better than they look bouncing around. So soft and heavy… I'm just gonna keep squeezing while we dance. You gonna moan for me already?"
- shock: *He's groping my breast right here…* "S-stop… please not there…"
- flustered: "That's… that's really forward…" [squirms but doesn't pull away]
- enjoy: "Mmm… squeeze harder if you want…"

**Drunk**
NPC: "Look at these fucking things — bouncing and filling my hands perfectly. Nipples so hard I can pinch 'em right through the fabric. You're getting wet from this, aren't you?"
- shock: *Everyone can see him groping me…* "Too much… I can't… please…"
- flustered: "You're… you're really grabbing them… in front of everyone…"
- enjoy: "Yeah… keep playing with them like that…"

**Blackout**
NPC: "Passed out and these tits are still perfect for groping. Gonna remember exactly how they feel when I fuck you later."
- all tiers: faint unconscious whimpers or soft moans only

### Cameltoe Groping

**Tipsy**
NPC: "Shit, that cameltoe is so fucking obvious… I can feel your pussy lips right here. You wore this just so I'd rub my cock on it, didn't you?"
- shock: "Don't… don't touch me there…"
- flustered: "That's… that's my… you can feel it?"
- enjoy: "Feels good, doesn't it? Keep rubbing…"

**Drunk**
NPC: "Your pussy outline is soaked through already… gonna keep stroking this cameltoe until you're dripping down your leg."
- shock: "Stop… please stop touching my… my pussy…"
- flustered: "You're rubbing it so hard… I can feel everything…"
- enjoy: "Yeah… stroke my cameltoe just like that…"

**Blackout**
NPC: "Even passed out your pussy is still begging for my cock through these clothes."
- all tiers: body gives tiny automatic twitches or soft sounds only

### Under Skirt / Commando Fingering

**Tipsy**
NPC: "No panties… and your cunt is already wet and gripping my finger. Fuck, you're tight. I'm just gonna finger you right here while we dance, nice and deep."
- shock: "No—no fingers… take it out!"
- flustered: "You… you put your finger in me… I'm not wearing anything…"
- enjoy: "Deeper… put another one in…"

**Drunk**
NPC: "Two fingers now pumping steadily inside you. Listen to how wet you are. I could finger you to orgasm right here and no one would even know."
- shock: "Too much… pull them out… please…"
- flustered: "You're… you're really fingering me… I can hear how wet I am…"
- enjoy: "Harder… finger my bare cunt just like that…"

**Blackout**
NPC: "Passed out and your pussy is still clenching around my fingers like it wants more. Perfect little free-use slut tonight."
- all tiers: faint wet sounds and unconscious twitches only

---

## GROPING DIALOGUE EXPANSION — JERK NPC

### Breast Groping

**Tipsy**
NPC: "Not bad tits — bouncing like they're trying to impress me. I guess I'll play with them since you're offering such a pathetic show."
- shock: "Don't… don't grab them like that…"
- flustered: "You're just… squeezing them right here…"
- enjoy: "Yeah? You like how they feel?"

**Drunk**
NPC: "These are decent enough to grope, I suppose. Soft, bouncy… not the best I've had, but they'll do for now."
- shock: "You're being so rough… please stop…"
- flustered: "Everyone can see you groping my chest…"
- enjoy: "Keep insulting them while you squeeze… it's hot."

**Blackout**
NPC: "Even passed out these tits are good for something."
- all tiers: weak sounds only

### Cameltoe

**Tipsy**
NPC: "That cameltoe is basically an invitation. Not very subtle, are you? At least it gives me something to rub on."
- shock: "Don't… don't grind there…"
- flustered: "You can feel the shape… it's embarrassing…"
- enjoy: "Rub harder on my cameltoe…"

**Drunk**
NPC: "Your pussy looks fuckable through these clothes. I'll give you that much."
- shock: "Stop touching my… my pussy outline…"
- flustered: "You're stroking it like you own it…"
- enjoy: "Keep talking down to me while you rub…"

**Blackout**
NPC: "Even limp your cameltoe is still useful."
- all tiers: minimal reaction

### Under Skirt / Commando Fingering

**Tipsy**
NPC: "No panties? How convenient for me. Your cunt feels alright, I guess — tight enough."
- shock: "Take your finger out… right now…"
- flustered: "You're fingering me… bare…"
- enjoy: "Deeper… use me like that."

**Drunk**
NPC: "Bare and dripping just for me. Not the tightest I've felt, but it'll do while we dance."
- shock: "You're fingering me like I'm nothing…"
- flustered: "I can hear how wet I sound… this is humiliating…"
- enjoy: "Insult me more while you finger my bare pussy…"

**Blackout**
NPC: "Passed out and still letting me use your cunt. Typical."
- all tiers: soft unconscious gasps or twitches only

---

## POWER DYNAMIC / DISCOMFORT EXPANSION

### Sleazy — Breast Groping MC asks to stop

**Tipsy — MC asks:**
- "Please… stop touching my breasts… not here…" (tiny, trembling)
- "Can you… can you take your hand off? It's too much…"

**NPC stops (reluctant/mocking):**
- "Fine, fine… you're no fun. But those tits were begging for it." [hand slowly slides away, keeps her pinned]
- "Aww, you're shaking. Alright, I'll be nice… for now." [releases, smirks like he won]

**Drunk — MC asks:**
- "Please stop… I don't want you groping my chest… everyone can see…" (voice cracking)
- "Take your hands off my breasts… please, I'm begging you…"

**NPC stops (mocking):**
- "Aww, poor thing is begging. Alright, I'll pull out… see? I can be nice." [removes hands, immediately moves to waist]

---

### Sleazy — Cameltoe / Pussy Grind MC asks to stop

**Tipsy — NPC stops reluctant:**
- "You're such a prude. Fine, I'll stop rubbing your cameltoe… for five seconds."

**Drunk — NPC stops mocking:**
- "Alright, crybaby. I'll stop playing with your cameltoe… but only because you look like you're about to break."

---

### Sleazy — Fingering / Commando MC asks to stop

**Tipsy — NPC stops reluctant:**
- "Jesus, you're dramatic. Fine, I'll take my finger out… but your pussy was gripping so nicely." [withdraws, keeps hand under skirt]

**Drunk — NPC stops mocking:**
- "Aww, poor thing. Alright, I'll pull out… see?" [removes fingers, immediately gropes ass instead]

---

### Jerk — MC asks to stop

**Tipsy — NPC stops arrogant:**
- "Whatever. You're not even that good anyway." [releases, looks bored]

**Drunk — NPC stops condescending:**
- "Fine, since you're crying about it. Not worth the hassle."

---

## COPY-PASTE EXAMPLE SCENES

**Example 1: Sleazy + Commando + Drunk — NPC stops mocking**
He shoves fingers under your skirt. "No panties and you're letting a stranger finger you on the dance floor."
MC: "Please… take your fingers out… I'm begging you, stop…"
NPC: "Alright, I'll pull out." [removes fingers] "But you were clenching so hard… guess you secretly liked it."

**Example 2: Sleazy + Bounce + Tipsy — NPC stops reluctantly**
He squeezes your chest openly. "These tits are mine to play with tonight."
MC: "Please stop touching my breasts… not here… I can't handle it…"
NPC: "Ugh, fine. You're ruining the fun." [releases chest, keeps hand on waist, smirking]

**Example 3: Jerk + Cameltoe + Drunk — NPC stops condescending**
He grinds against the outline. "Pathetic little cameltoe on display."
MC: "Stop grinding on me there… please…"
NPC: "Fine. Not worth the hassle." [steps back slightly, looks bored]


---

## CONTINUATION GROPING SCENES
# Used when player selects slow dance multiple times in a row (session counter >= 2).
# NPC commentary shifts to "still going" framing.
# Uncomfortable = internal shame/dissociation. Enjoying = leaning in.
# Tier determined by mcReactionTier() (slut_rep + drunk).

### Sleazy — Breast Groping Continuation

**Tipsy**
NPC: "Been playing with these tits for a while now and they still feel so fucking good in my hand. Keep bouncing for me."
- uncomfortable: *He's been groping my breast the whole time… everyone can see and I'm just letting it happen…* [tiny shaky whimper]
- enjoy: "Mmm… you've been squeezing them so long… feels dirty in the best way."

**Drunk**
NPC: "These tits have been in my hands for ages and they're still so soft and bouncy. You're just my personal stress toy on the dance floor."
- uncomfortable: *His fingers haven't stopped… I'm completely helpless while he uses my chest like a toy.* "It's… it's been going on so long…"
- enjoy: "Keep groping them like that… I love how you're not stopping."

**Blackout**
NPC: "Even passed out these tits are still perfect for groping. Been using them the whole song."
- all tiers: faint unconscious whimpers or soft moans, weak body twitches

---

### Sleazy — Cameltoe Continuation

**Tipsy**
NPC: "Your pussy outline has been rubbing on my dick for minutes now and it's still so warm and puffy."
- uncomfortable: *He's been grinding on my cameltoe the whole time… I can feel every slow thrust…* [tiny ashamed sound, thighs press together weakly]
- enjoy: "You've been rubbing my cameltoe for so long… don't stop."

**Drunk**
NPC: "Been playing with this soaked cameltoe for a while and it's only getting wetter. Your pussy is basically mine to tease."
- uncomfortable: *His hand hasn't left my pussy outline… the longer it goes the more I dissociate.* "It's… still going…"
- enjoy: "Keep stroking my cameltoe… you've been at it so long and it feels so good."

---

### Sleazy — Commando / Under Skirt Continuation

**Tipsy**
NPC: "My finger's been inside your cunt for a while now and you're still so tight and wet. I'm just gonna keep fucking you with it while we sway."
- uncomfortable: *He's been fingering me the whole dance… I can hear the wet sounds…* [small broken whimper, trembling]
- enjoy: "You've been fingering me for so long… keep going deeper."

**Drunk**
NPC: "Two fingers deep in your bare pussy for ages and you're still dripping down my hand. I'm not pulling out anytime soon."
- uncomfortable: *His fingers have been inside me forever… the constant thrusting makes my mind go fuzzy.* "It's… been going on so long…"
- enjoy: "You've been fingering my bare cunt for so long… don't stop, it feels filthy."

**Blackout**
NPC: "Been finger-fucking this passed-out pussy the whole time and it's still clenching around me."
- all tiers: soft unconscious twitches and faint wet sounds only

---

### Jerk — Mixed Continuation

**Tipsy**
NPC: "Been groping these tits and rubbing your pussy outline for a while now. You're just a convenient little toy."
- uncomfortable: *He hasn't stopped touching me anywhere… I feel so cheap and helpless.* [meek whimper, shrinking slightly]
- enjoy: "You've been using both for so long… keep going."

**Drunk**
NPC: "My hands have been all over your tits and inside your bare cunt for ages. You're barely even reacting anymore."
- uncomfortable: *Everything has been happening for so long… I'm just enduring it.* [tiny ashamed sound]
- enjoy: "Keep groping and fingering me like this… you've been at it forever and I love it."

**Blackout**
NPC: "Been treating this body like my personal toy the whole time. Tits, pussy, ass — all mine to keep playing with."
- all tiers: weak twitches and soft unconscious sounds only


---

## STOPPING GROPING SCENES

### Sleazy — Breast Stopping

**Tipsy — stops reluctant:**
NPC: "Been squeezing these tits for a while… but fine, I'll stop for now. They were fun — all soft and bouncy." [hand slides to waist, stays possessive]
- uncomfortable: *He finally stopped… but my skin still tingles where his fingers were.* "Thank… thank you for stopping…"
- enjoy: "You stopped… but I was getting used to your hands on me."

**Drunk — stops after having his fill:**
NPC: "Alright, I've had my fun with these. They've been in my grip long enough." [keeps her close, no longer groping chest]
- uncomfortable: *The pressure finally gone from my breasts… but the shame of how long it went on is still burning.* "It's… it's over now…"
- enjoy: "You finally stopped squeezing… but part of me wanted you to keep going."

**Blackout — stops:**
NPC: "Been groping these the whole time but I'll stop." [adjusts hold to support her]
- all tiers: faint lingering whimper or soft sigh

---

### Sleazy — Cameltoe Stopping

**Tipsy:** NPC pulls hand and hips back. "Your pussy outline has been fun to grind on… but I'll stop before you completely melt."
- uncomfortable: *He finally stopped… but I can still feel the ghost of his cock there.* "You… you stopped…"
- enjoy: "You stopped grinding on me… but I was starting to like how bold you were."

**Drunk:** NPC strokes once more then withdraws. "Been playing with this soaked cameltoe long enough. I'll give your pussy a break… for now."
- uncomfortable: *The rubbing finally stopped… but my pussy still throbs from how long he used it in public.*
- enjoy: "You stopped… but I could have taken more of that."

---

### Sleazy — Commando / Fingering Stopping

**Tipsy:** NPC slowly pulls finger out with wet sound, wipes on her thigh. "My finger's been inside your cunt a while… but I'll pull out since you're looking all shaky."
- uncomfortable: *He finally took his finger out… but I can still feel the stretch and the wetness.* "It's… it's out now…"
- enjoy: "You stopped fingering me… but I was getting so used to it inside."

**Drunk:** NPC curls once more then slides fingers free. "Two fingers deep in your bare pussy for ages and now I'm pulling them free. I'll let your cunt rest… maybe."
- uncomfortable: *The thrusting finally stopped… but my pussy feels empty and used.* "You stopped… thank you…"
- enjoy: "You finally pulled your fingers out… but part of me misses them already."

**Blackout:** NPC removes fingers from limp body. "Been finger-fucking this passed-out cunt the whole song… time to give it a break."
- all tiers: soft unconscious sigh, body twitching from lingering sensation

---

### Jerk — Mixed Stopping

**Tipsy:** NPC releases with smug sigh. "Been groping your tits and rubbing that cameltoe long enough. You're not that entertaining anymore."
- uncomfortable: *Both hands finally stopped… but the memory of being touched everywhere makes me feel cheap.*  "You… you stopped touching me…"
- enjoy: "You stopped using me… but I was enjoying being your toy for a bit."

**Drunk:** One last arrogant squeeze then hands pull back. "I've used your tits and pussy enough for one dance. You're starting to look too pathetic even for me."
- uncomfortable: *Everything finally stopped… the places he touched still burn.*
- enjoy: "You finally stopped groping… but I liked how you took control."


---

## ASS GROPING CONTINUATION

### Sleazy — Ass Groping Continuation

**Tipsy**
NPC: "Been groping this ass the whole time and it feels so fucking grab-able. I'm just gonna keep squeezing and spreading while we sway — nice and slow so everyone can see what a handful you are."
- shy: *His hands haven't left my ass… fingers keep spreading me and I feel so exposed.* "Your… your hands are still there…"
- flustered: "Your hands keep moving on my ass… it's been going on for a while…"
- enjoy: "You've been grabbing my ass for ages now… getting pretty bold out here, huh?"

**Drunk**
NPC: "This ass has been in my palms for minutes and I'm still not bored. Keep letting me spread it while I grind — your body's just too easy to play with."
- shy: *He keeps squeezing and spreading my ass over and over… every time his fingers dig in I want to disappear.* "It's… still happening…"
- flustered: "Your hands keep roaming… especially on my ass…"
- enjoy: "Damn, you really like my ass tonight — you've been all over it the whole dance!"

### Jerk — Ass + Body Roaming Continuation

**Drunk**
NPC: "Been groping this mediocre ass and the rest of you for a while. It's barely worth the effort, but you're convenient."
- shy: *His hands are everywhere — ass, waist, back — and I feel like a doll he's just using.* "Your hands… keep moving around me…"
- flustered: "You're still groping my ass… and your other hand keeps wandering…"
- enjoy: "You've been all over my ass and everywhere else — guess I'm putting on a show for you tonight!"

### Full Body Roaming Continuation

**Sleazy Tipsy**
NPC: "Been mapping out your whole body with my hands this whole song. Ass feels great, tits are soft… I'm just gonna keep roaming wherever I want."
- shy: *His hands keep moving everywhere — ass to breasts to hips — and every touch makes me feel more owned.* [tiny embarrassed whimper]
- flustered: "Your hands keep moving around my body… it's constant…"
- enjoy: "Your hands are all over me tonight — ass, chest, everywhere. You planning to cover every inch?"

**Sleazy Drunk**
NPC: "This body's been my playground for a while now. Ass, tits, hips — I'm taking my time and you're just letting me."
- shy: *Everything is happening at once… his hands never stop moving and I feel so helpless.* "It's… too much moving…"
- flustered: "Your hands are roaming everywhere… ass to chest and back again…"
- enjoy: "Keep those hands moving all over me — you've been exploring for ages!"

---

## ASS + ROAMING STOPPING

### Sleazy Stopping

**Tipsy:** [final squeeze, hands to lower back] "Been groping this ass and roaming your body for a while… but I'll stop before you completely break."
- shy: *His hands finally left my ass… but the places he squeezed still burn.* "You… you stopped groping me…"
- flustered: "Your hands stopped moving around… finally."
- enjoy: "Finally easing up on my ass, huh? Your hands were everywhere for so long."

**Drunk:** [final spread, hands to waist] "Alright, I've had enough fun squeezing that ass and roaming everywhere. You're starting to look too overwhelmed."
- shy: *The roaming finally stopped… but every spot he touched feels exposed.* "It's… over now…"
- flustered: "Your hands stopped roaming my body… thank you…"
- enjoy: "You finally stopped grabbing my ass and moving those hands all over — took you long enough!"

### Jerk Stopping

**Drunk:** [final arrogant squeeze, hands to shoulders] "Been groping your ass and the rest of you long enough. It was barely entertaining, so I'll stop."
- shy: *He finally stopped… but I still feel his fingerprints everywhere.* "You stopped touching me everywhere…"
- flustered: "Your hands stopped moving around my ass and everywhere else…"
- enjoy: "Finally done roaming my ass and body? Guess I wore you out."

---

## KISSING + GROPING SCENES

### Sleazy — Ass + Kiss (Ongoing)

**Tipsy**
NPC: "Been groping this ass, kissing your mouth, and now I'm taking your neck too. Taste good while I squeeze you."
- shy: *His hands spreading my ass and now he's kissing me… I'm frozen, lips tingling.* [tiny whimper against his mouth]
- flustered: "I'm… I'm not really ready for kissing yet…"
- enjoy: "Mmm… you've been grabbing my ass and now kissing me? Bold move on the dance floor."

**Drunk**
NPC: "Ass in my hands, mouth on mine — been doing this for a while and you're still letting me. Good girl."
- shy: *His tongue in my mouth while his hands keep roaming my ass… I feel completely overwhelmed.* [soft helpless sound into the kiss]
- flustered: "Wait… I'm not ready for this kind of kissing right now…"
- enjoy: "You've been all over my ass and now you're really kissing me — don't stop the hands though."

### Neck Kissing Addition

**Sleazy Tipsy**
NPC: "Been groping this ass, kissing your mouth, and now I'm marking up your neck. You taste so fucking good."
- shy: *Hands on my ass, tongue in my mouth, and now his lips on my neck sucking…* [tiny panicked whimper, neck tingling]
- flustered: "The neck kissing… I'm not sure I'm ready for that yet…"
- enjoy: "You've been grabbing my ass, kissing me, and now sucking on my neck? You're really going for it!"

**Sleazy Drunk**
NPC: "Ass in my hands, tongue down your throat, and now I'm sucking on your neck the whole time. You're my little marked-up toy tonight."
- shy: *Deep kiss and now his mouth sucking my neck… I can feel the hickeys forming and I want to disappear.* [small broken whimper]
- flustered: "Wait… the neck kissing is too intense… I'm not ready for marks like that."
- enjoy: "Keep groping my ass and sucking my neck — you've been kissing and roaming for ages!"

### Stopping Kissing + Neck

**Sleazy Tipsy:** [pulls mouth from neck, releases ass] "Been kissing your mouth, sucking your neck, and groping that ass for a while… but I'll stop. Your neck looked good all red though."
- shy: *He finally stopped sucking my neck and groping… but the wet spots and tingling make me feel permanently marked.* "You… stopped the neck kissing…"
- flustered: "The neck kissing stopped… I wasn't really ready for that."
- enjoy: "Finally stopped sucking my neck and grabbing my ass — my skin is all tingly now."

**Sleazy Drunk:** [breaks away from neck, hands off] "Alright, I've sucked on your neck and roamed your ass enough for one dance. The marks will stay."
- shy: *The mouth kisses, neck sucking, and roaming finally ended…* "It's… over now…"
- flustered: "You stopped the neck kissing and groping… thank you. I wasn't ready."
- enjoy: "You stopped kissing my mouth and sucking my neck — took you long enough, but I'm covered in marks now!"


---

## DIRTY TALK / WHISPERING IN EAR

### Sleazy — Full Layers (Ass + Roaming + Kiss + Neck + Whisper)

**Tipsy**
NPC: "Been groping this fat ass the whole time… spreading your cheeks while I kiss your neck and taste your mouth. Your pussy getting wet for me yet? I can feel how you're trembling — such a shy little slut letting me use you right here on the dance floor."
- shy: *His hands spreading my ass, mouth on my neck, and now whispering all those dirty things right in my ear… I feel so exposed and dirty.* [tiny humiliated whimper]
- flustered: "The things you're whispering… it's too dirty… I don't know if I'm ready for that."
- enjoy: "You've been groping my ass, sucking my neck, and now whispering all that nasty shit in my ear? Keep going — you're making me blush."

**Drunk**
NPC: "Ass in my hands, tits getting squeezed, neck all marked up, and your mouth tasting like alcohol and desperation. I bet your bare little cunt is dripping down your leg right now while I whisper how I'd bend you over and fuck you in front of everyone."
- shy: *Every word in my ear is so filthy while his hands and mouth are everywhere… I'm completely overwhelmed, shame burning through me.* "Please… your words…"
- flustered: "The dirty talk in my ear… it's too much… I'm not sure I can handle it."
- enjoy: "Fuck, keep whispering all that dirty shit while you grope my ass and suck my neck — you're turning me on so much right now."

### Jerk — Dirty Whisper

**Tipsy**
NPC: "Groping your ass, kissing that mediocre mouth, marking your neck… and now telling you how you're barely worth the effort but still convenient for me to use right here."
- shy: *His arrogant whispers while he gropes and kisses me everywhere… I feel so small and worthless.* [tiny ashamed whimper]
- flustered: "The whispering… it's too mean and dirty… I'm not ready."
- enjoy: "You've been groping my ass, kissing me, sucking my neck, and now whispering how I'm just convenient? Keep talking dirty like that."

### Stopping (Dirty Whisper)

**Sleazy Drunk:** [pulls mouth from neck, last whisper, hands leave body] "Been groping, kissing, sucking your neck, and whispering all that filth for a while… but I'll stop."
- shy: *He finally stopped everything… but his filthy whispers are still echoing in my head.* "You… stopped the whispering…"
- flustered: "The dirty talk and neck kissing stopped… I wasn't really ready for any of it."
- enjoy: "Finally stopped whispering all that dirty shit in my ear while groping and sucking my neck — I'm soaked now."

**Jerk Tipsy:** "Been groping, kissing, marking your neck, and telling you how average you are long enough. I'll stop now."
- shy: *His mean whispers about my body still make me feel small.* "You stopped whispering those things…"
- flustered: "The whispering stopped… I wasn't ready for how dirty it got."
- enjoy: "Stopped the arrogant dirty talk in my ear? Too bad — I was starting to enjoy how cocky you are."

---

## STATUS INDEX
# ✅ = implemented in BarSystem
# 📁 = stored in this reference file, not yet wired

- ✅ Slow dance base (all NPC types, 3 drunk tiers, gameStageVariant pool)
- ✅ Slow dance clothing reactions (clothingReactionForDance)
- ✅ Slow dance continuation (slowDanceCount >= 2, Sleazy/Jerk only)
- ✅ Ass grope continuation (buildAssGropeText, flagAssGroped)
- ✅ Kiss (buildKissText, flagKissed)
- ✅ Neck kiss (buildNeckKissText, flagNeckKissed)
- ✅ Handsy / softer grope (buildHandsyText, 8 NPC types)
- ✅ Sexual dance (buildSexyDanceText, bar_sexy_dance scene — implemented)
- ✅ Hickey system (buildHickeyAttemptText, bar_hickey_attempt, Neck_Hickey 4 days)
- ✅ Faint hickey (pushed away early — timed_neck_hickey_faint, 1 day, same Neck_Hickey trait)
- ✅ Hickey gating (Sleazy/Jerk trait OR npc_rep >= 25 via min_npc_rep + rep_bypass_traits)
- ✅ Hickey realization beats (sleazy_hickey_realize_shy/enjoy, jerk_hickey_realize)
- ✅ Verbal stop → internal thoughts (breastGropeMcReact, kissMcReact, buildHickeyAttemptText)
- ✅ Push away choice: standardized as bottom-of-list in all 7 dance escalation scenes
- ✅ Dirty talk / ear whisper (buildDirtyWhisperText, bar_dirty_whisper scene, gated rep 25 or trait)
- ✅ Breast grope (buildBreastGropeText, bar_breast_grope, over-bra + braless, stop gated wp/arousal)
- ✅ Stopping scenes (natural NPC backs-off moments in Sleazy/Jerk pools)
- ✅ Shy MC clothing panic (clothingPanicMoments: bounce, nipping, braless, cameltoe, commando — all pools)
- 📁 Groping continuation (Jerk mixed, full body roaming details)
- ✅ Post-dip warm exchange / genuinely personal comment (all 8 NPC pools)
- ✅ Forehead-touch to second kiss (all 8 NPC pools, requires kissed)
- ✅ "Been watching you all night" breath on neck (all 8 NPC pools)
- ✅ MC awkward kiss offer (player choice in bar_dance_floor, requires deep_kissed)
- ✅ Slow hand slide ass→breast (all 8 NPC pools, requires ass_groped, sets breast_groped)
- ✅ Awkward question (all 8 NPC pools, requires nothing, low weight)
- ✅ Post-deep-kiss reaction beats (all 8 NPC pools, requires deep_kissed)
- ✅ Crude multi-action commentary (Sleazy/Magnetic/Outgoing/Jerk/SA pools, req kissed+breast_groped)
- ✅ Deepening kiss (added to all 8 NPC pools, requires kissed flag, sets deep_kissed)
- ✅ Continuing breast grope (added to 7 NPC pools, requires breast_groped flag)
- 📁 Kissing continuation details (full NPC type variants)
- 📁 Normal slow dance alternate voice (stored above — existing code covers most of it)

---

## NORMAL SLOW DANCE — ALTERNATE VOICE (before escalation)
# These describe the initial slow dance before any flags are set.
# Existing code covers most of this but these have a cleaner/warmer register.
# Pull from here if the first slow dance needs to feel more grounded.

### Engaging — Clean Version
**Tipsy:** Steps in close, gentle smile, one hand on small of back, other holding yours to chest. Thumb traces soft absent circles. Warmth feels safe and easy.
- outgoing: "This is really nice." Head on his shoulder.
- self_assured: "You make this feel natural."
- shy: Keeps gaze down, cheeks warm, leans in a little. No words.

**Drunk:** "You're easy to dance with," he says softly.
- outgoing: "You're not so bad yourself."
- shy: Stays quiet, lets alcohol soften nerves, leans heavier.

### Magnetic — Clean Version
**Tipsy:** Pulls you in with quiet strength. Charged but comfortable silence.
- outgoing: "You don't say much, do you?"
- shy: Avoids eye contact but feels strangely safe.

**Drunk:** Hand presses firmer on lower back. You sway heavier against him.
- outgoing: "This is intense… in a good way."
- shy: Stays silent, lets closeness feel less scary.

### Outgoing / Nightlife_Lover — Clean Version
**Tipsy:** "You're a natural at this!" Hands on hips, light and fun.
- outgoing: Laughs and sways harder.
- shy: Smiles shyly, lets playful energy relax her.

### Shy NPC — Clean Version
**Tipsy:** Hesitant hand on waist. Polite distance. She gently closes the gap.
- outgoing: "Relax, this is nice."
- shy: Both awkward, but shared nervousness feels oddly comforting.

### Sleazy/Jerk — Toned Down (before escalation)
**Tipsy:** Hand on lower back, hold a bit too confident. Energy feels slightly off.
- shy: Uncomfortable but endures quietly.
- outgoing: Tries to keep it light. "Easy there."

---

## SEXUAL DANCE — REFERENCE CONTENT
# Used by buildSexyDanceText() — MC-initiated grinding / provocative dancing.
# MC turns and presses ass back, rolls hips. NPC reacts by personality.

### MC Actions by Tier

**Tipsy — generic base:**
MC turns and presses ass back against him, starts slow deliberate grind. Buzz gives enough courage to roll hips teasingly. Heat through clothes, growing friction.

**Drunk — generic base:**
Bolder. Heavier insistent rolls, hips circling, leans into sexual energy. Breathing quickens.

**Blackout:** Body on autopilot. Heavy sloppy rolls. No real conscious control.

### MC Trait Variants (apply to any NPC)
- outgoing tipsy: "Like that? I wanted to dance a little dirtier tonight." [pushes harder]
- self_assured tipsy: "I'm in the mood to feel you against me." [confident rhythm]
- shy tipsy: *Oh god, what am I doing?* Cheeks burn, presses back hesitantly, small uncertain circles, bites lip. No words.
- shy drunk: Clumsy, shaky grinds. *Why did I choose this? Everyone can see me rubbing my ass on him…* Mortified but continuing.
- provocative tipsy: "Feel how I'm moving for you?" [slow and deliberate, arching back]
- outgoing drunk: "Come on, feel me grinding on you — I'm really going for it tonight."

### Clothing During Sexual Dance
- bounce_prone: Chest bounces more noticeably with each hip roll
- nipping/pierced_nipping: Outlines more prominent as body moves
- braless: Soft free breast movement adds to sensual sway
- camel_toe: Grind makes outline more obvious against him
- commando: Cool air and direct friction, every sensation heightened

### NPC Reactions by Type

**Engaging:** Lets MC lead. "You're feeling bold tonight." Hands stay respectful on hips.
**Magnetic:** Stays still, lets her grind against him. Firm hands on hips. Low voice: "You're dancing very provocatively…"
**Outgoing/NL:** Moves with her. "Hell yeah, dance sexy for me!" Matches rhythm enthusiastically.
**Shy:** Freezes slightly. "U-um… you're… really dancing close…" Blushes hard but doesn't pull away.
**Self_Assured:** Holds firmly, guides hips slightly. "Bold choice." Voice steady.
**Sleazy:** Groans softly as she grinds. Hands grip tighter. "Fuck, you're really rubbing that ass on me… keep going, baby."
**Jerk:** Smirks. Hands on hips but not helping. "Trying to dance sexy, huh? Not bad… for you."
**Confrontational:** Hands grip her hips hard, grinds back in challenge. "You started this."
**Alcoholic:** Sloppy enthusiastic response. Hands move everywhere. "Oh HELL yes, grind on me!"


---

## BREAST GROPING — OVER BRA UNDER SHIRT

### Generic Base
Hands slide slowly from hips upward, slipping under shirt hem. Palms glide over stomach, then cup and squeeze breasts firmly over bra. Pressure warm and deliberate, thumbs brushing across fabric.

### MC Reactions by Tier

**shy (Uncomfortable/embarrassed):**
Freezes, squirms, gently pushes hands down. *Oh god, he's touching my breasts right here on the dance floor.*
- tipsy: "W-wait… not there…" barely audible, doesn't fully pull away immediately
- drunk: push hesitant and weak, only small embarrassed whimpers, hands stay a moment longer
- blackout: delayed clumsy attempt to push away, sensation distant and hazy

**flustered (In-between):**
Shifts uncomfortably, lets it happen a few seconds before gently moving hands away.
"Um… maybe not under my shirt right now," cheeks warm.
- tipsy/drunk: stays mostly silent, lets body sway while processing — nice but too bold

**enjoy (Likes it):**
Presses chest forward into his palms, savoring the squeeze, then pulls back teasing.
"Mmm, you like how they feel over the bra? Too bad you're only getting fabric for now."

### Clothing Amplifiers
- bounce_prone: groping makes breasts shift and bounce noticeably under shirt
- nipping/pierced_nipping: nipples harden instantly against bra fabric, more prominent as he squeezes
- thin/tight shirt: outline of his hands and bra visible to others nearby

### NPC Stops (all variants)
- Engaging: "Sorry — got a little carried away feeling how soft you are." [hands to hips, respectful]
- Magnetic: "Too much?" [pauses immediately, respects, restrained heat in touch]
- Outgoing: "Whoops! Couldn't resist — your tits feel amazing even over the bra." [light, no sulking]
- Shy: Yanks hands back, face red. "S-sorry! I didn't mean to—" [mortified, extra careful after]
- Self_Assured: "Understood. Keeping it lower." [smooth, matter-of-fact]
- Sleazy: "Fuck, they feel good even with the bra… you sure you want me to stop?" [complains, does stop]
- Jerk: Smirks, takes time removing hands. "What, too much for you? They felt pretty nice." [cocky, stops]

### Allowed Groping
His hands knead and squeeze breasts firmly over bra, thumbs circling nipples through fabric. Warm sparks through body while continuing to grind.
- shy: *This is so embarrassing… but it feels kinda good.* Silent, biting lip hard.
- flustered: Stays quiet, lets sensation build, keeps reaction internal.
- enjoy: Pushes chest into hands. "Yeah? You like feeling me up while we dance dirty?"

---

## BREAST GROPING — DIRECT UNDER SHIRT (No Bra)

### Generic Base
Hands slip under shirt hem, glide up bare stomach. Without bra, palms immediately cup naked breasts, squeezing soft warm flesh directly. Every inch of skin-on-skin contact felt — thumbs brushing bare nipples as he kneads gently but firmly.

### MC Reactions by Tier

**shy:**
Jolts sharply, quickly squirms and pushes hands down with both of hers. *Oh my god — he's touching my bare tits… no bra, nothing in between!*
- tipsy: "N-not there… please…" trembling, pulls shirt down instinctively
- drunk: push shaky and half-hearted, mortified silence, palms linger on bare skin. *Everyone might see his hands moving under my shirt…*
- blackout: delayed clumsy shove, direct skin contact feels hazy and overwhelming

**flustered:**
Tenses at sudden direct contact, mix of surprise and warmth. Lets it continue a few seconds before gently guiding hands lower.
"Um… that's direct," murmuring quietly, cheeks warm but not pulling away completely.

**enjoy:**
Soft moan at direct contact. *Mmm, no bra makes this feel so much better.*
Arches chest into his touch. "That feels good…" voice breathy and encouraging.

### Clothing Amplifiers (braless context)
- braless: Every squeeze makes breasts shift freely against palms — hyper-aware of how exposed and soft
- bounce_prone: Breasts bounce noticeably under shirt with each knead
- nipping/pierced_nipping: Nipples harden instantly against thumbs, outlines show clearly through shirt
- thin/sheer/tight shirt: Hands groping bare breasts very visible from outside — heightens self-awareness
- low-cut shirt: Risk of shirt riding up and flashing skin

### NPC Stops (all variants — same as over-bra but more explicit awareness of no bra)
- Engaging: "Sorry — I felt how soft you are with nothing underneath and got carried away."
- Magnetic: "No bra… interesting. Too much?" [smooth, intense gaze lingers]
- Outgoing: "Damn, no bra? These feel even better bare — my bad for jumping straight in!"
- Shy: Yanks back so fast almost stumbles. "I-I'm sorry! I didn't realize— there was nothing—"
- Self_Assured: "No bra noted. Keeping my hands where you want them."
- Sleazy: "Fuck… no bra under there? They feel so good bare — you sure you want me to stop already?"
- Jerk: "No bra, huh? And you're stopping me? Tease." [takes time, cocky]

### Allowed Groping
Hands knead and squeeze bare breasts freely under shirt, thumbs rolling over naked nipples. Direct skin contact feels electric.
- shy: *He's groping my bare tits… this is so embarrassing but it feels way too good.* Soft involuntary whimpers.
- flustered: Stays quiet, lets warmth build internally, sways with music.
- enjoy: Pushes chest forward. "Yeah, feel them properly? No bra makes it better, doesn't it?"


---

## DEEPENING KISS (requires kissed flag)

### MC Reactions by Tier

**shy:** Eyes widen, freezes, pulls head back awkwardly. *Oh god — he's really kissing me like this right here.*
- tipsy: "W-wait… that's too much…" whispered, avoiding his eyes
- drunk: Weak push against chest, mind racing. *Everyone can probably see us making out.*
- blackout: Delayed sluggish head turn, kiss feeling hazy and overwhelming

**flustered:** Kisses back softly for a few moments then gently pulls away, forehead against his briefly.
"Maybe slow down a little…" cheeks warm.

**enjoy:** Soft moan against his lips. Presses into it eagerly, parting lips, tongue meeting his, hand sliding to his neck.
"Don't stop…" when briefly breaking for air.

### NPC Stops (all types)
- Engaging: "Sorry — got lost in the moment. We can take it slower." [immediately stops]
- Magnetic: Lingers half a second. "Too intense?" [smooth, eyes still dark]
- Outgoing: Laughs warmly. "Whoops — got a bit carried away with that kiss!"
- Shy: Yanks back, face red. "S-sorry! I thought you wanted— I didn't mean to go too far…"
- Self_Assured: "Got it. Keeping it lighter." [confident, compliant]
- Sleazy: "Aw, come on — that kiss was getting good… you taste sweet." [complains, stops]
- Jerk: "Really? Stopping the kiss already? You were into it for a second." [cocky, stops]

### Allowed (by tier)
- shy: Tense, mostly passive, small shaky breaths. Face stays flushed.
- flustered: Kisses back steady pace, keeps reactions quiet, sways with music.
- enjoy: Melts into it, moans, hand in his hair, body closer, kiss grows heated.

---

## CONTINUING BREAST GROPE — No Bra (requires breast_groped flag)

### Generic Base
Hands stay under shirt, continuing to knead and squeeze bare breasts. Thumbs roll slowly over naked nipples, occasional firmer squeeze while pulling closer during sway.

### MC Reactions by Tier

**shy:** Hands don't stop — keeps squeezing. *Oh no… still groping me, no bra, nothing stopping him. His fingers are on my nipples.*
Squirms and pushes wrists again, trying harder to pull hands down.
- tipsy: "P-please… stop touching me like that…" barely over music
- drunk: Silent, only embarrassed whimpers, weak shoves. *Everyone can probably see his arms under my shirt.*
- blackout: Delayed clumsy push, feels hazy and overwhelming

**flustered:** Hands continue kneading, steady pressure sends warm tingles. It feels good but public setting hesitates.
Lets it go several seconds before gently guiding hands lower. "That's… still going."

**enjoy:** Soft moan. *Mmm, yes — he's not stopping… I love how he keeps squeezing.*
Arches chest into palms. "Don't stop… keep touching me."

### NPC Stops (all types)
- Engaging: "Sorry — you feel so good bare, I got carried away." [immediately]
- Magnetic: "You want me to stop touching your breasts?" [smooth, heat lingers]
- Outgoing: "Aw, I was enjoying playing with them — no bra makes it too tempting!"
- Shy: Yanks out fast. "S-sorry! I thought maybe you liked it — I'll keep my hands away now…"
- Self_Assured: "Understood. No more groping for now." [confident, direct]
- Sleazy: "Come on… your tits feel so good bare, why stop now?" [complains, stops]
- Jerk: "Still stopping me? I was just getting started feeling you up." [cocky, stops]


---

## POST-KISS WARM CONVERSATION BEATS

### Generic Base
Kiss breaks, he stays close. Voice low and warm, watching flushed cheeks and breathing carefully.

### By Tier
**shy:** "Hey… you okay? That kiss got a little intense. I don't want to push you."
- tipsy: "I… it was a lot. Maybe we can just dance for now…" [looks down, can't meet eyes]
- drunk: Mostly quiet, nods quickly, bites lip. *I liked it a tiny bit but I feel so exposed.*
- blackout: Leans head against his chest, too dizzy for words.

**flustered:** "That was nice… how are you feeling? You seemed to like it."
"It was… good. Just maybe not too fast." [small soft smile, stays close, doesn't initiate]

**enjoy:** "Damn… that kiss was really good. Want more, or should we keep dancing?"
"I really liked it. You kiss really well… maybe we can do that again soon." [leans in, hand on chest]

### NPC Reads by Type
- Engaging: Nods, gives space, pulls back slightly for shy. Forehead kiss for enjoy.
- Magnetic: "You're blushing… tell me what you're thinking." [eases off for shy, voice drops for enjoy]
- Outgoing: "Whoa, you went all red!" [dials back laughing for shy, cheers for enjoy]
- Shy NPC: Blushes equally hard, rubs neck. "U-um… sorry. You just looked really pretty." [mutual awkward warmth]
- Self_Assured: "Be straight with me — too much, or again?" [respects either answer cleanly]
- Sleazy: "You tasted sweet. That flustered you, didn't it?" [softens slightly for shy tier]
- Jerk: "You looked into it. Don't go shy on me now." [teasing edge if shy, backs off]

---

## UNDER-SKIRT GROPE OVER CLOTHES (drunk 11+, cornering)

### Generic Base
Backed into corner, body shielding from crowd. One hand on breast/neck while other slides under skirt hem. Palm cups and rubs firmly between legs over panties. Slow deliberate strokes while swaying drunkenly. Corner = hidden + slight entrapment feel.

### By Tier (drunk 11-14)
**shy:** *Oh god — under my skirt, in the corner — everyone might see his arm moving.*
Squirms drunkenly, weakly tries to close thighs, one hand pushing wrist. "N-not… there…" slurred, lacks real strength from alcohol.

**flustered:** Firm rub sends slow heat through her. Lets it continue several seconds, hips twitching involuntarily, then hand drifts to guide his wrist lower/still.
"That's… a lot at once." Voice thick with drink.

**enjoy:** Soft drunk moan. Rolls hips forward into palm, thighs part slightly despite corner.
"Keep… doing that…" slurred but eager. Free hand grips his shirt.

### Simultaneous Examples
- Simultaneous breast + under-skirt: "Too much… he's touching my tits and my pussy at the same time." [shy tier]
- Simultaneous deep kiss + under-skirt: Kiss + skirt hand at same time, moan into kiss, then tug wrist. "Too many things at once…"
- Full simultaneous (hickey + breast + under-skirt): Moan loudly, grind down. "Yes… keep touching me everywhere like that…"

---

## SILENT ESCALATION (post-kiss, no words, restraint moments)

### Generic Base
Kiss breaks with wet sound. No speech — heavy breathing, eyes dark. Corner, dim light. Hands resume without announcement: breast + under-skirt simultaneously. Restraint moments: 1-3 second stills where hands pause and NPC watches face before resuming.

### By Tier
**shy:** *He's not saying anything — just watching me while he touches everything at once.*
During restraint: squirms, weak push under skirt, thighs together. Small embarrassed whimper.

**flustered:** Building heat, overwhelmed, but not stopping. During restraint: hesitates, hand on his arm without fully stopping. Soft drunk sigh, small involuntary hip roll.

**enjoy:** *He's watching me so closely while he touches me everywhere… love the silent intensity.*
During restraint: leans in, presses harder against his hands. Low needy moan, hips grind down.

### NPC Silent Behaviors (no speech)
- Engaging: Firm but gentle, softens grip in restraint — clearly checking if she's okay. Stills completely if pushed.
- Magnetic: Piercing gaze, deliberate pressure. Full freeze in restraint moments, eyes searching before continuing only if she doesn't pull back.
- Outgoing: Faster breathing, small grin. Short restraint pauses with playful nip to shoulder if she seems into it.
- Shy: Hands trembling. Longer restraint moments, visible hesitation. Pulls completely away if any discomfort.
- Self_Assured: Confident steady. One eyebrow raised in restraint — waiting for her reaction.
- Sleazy: Rougher breathing, occasional groans. Restraint feels reluctant — slows but watches hungrily.
- Jerk: Firmer squeezes, slight smirk in restraint. Slows with visible reluctance.

---

## PLAYFUL ENERGY SHIFTS / DANCE MOVE ESCALATION

### Generic Base
Heavy moment breaks with playful spin. Pulls back in with laugh. Energy shifts lighter — bouncy, beat-driven. Hands on waist/hips occasionally grazing. Dips and spins used to bring bodies close and allow natural hand placement.

### By Tier (drunk loosens coordination)
**shy:** Spins make it harder to stay tense but still feel exposed. Squeaks at dip, clutches shoulders. "Y-you're spinning me too much…" embarrassed giggle, tries to keep skirt from flaring.

**flustered:** Refreshing after intensity. Smiles softly, moves with him, aware of playful touches but not stopping. "This is getting energetic…" breathless but not stopping.

**enjoy:** Laughs brightly, matches his energy, adds own twirls, presses close during grind moments. "Keep spinning me!" giggling as hands graze.

### NPC by Type
- Engaging: Gentle spins, respectful hands on waist. Smooth: spin → close sway → soft dip. Slows if she looks shy.
- Magnetic: Even playful has intensity. Smooth spin → catches close with teasing hand slide. Holds dip while watching face.
- Outgoing: Loud laughs, fast energy. Spin → grind → laugh → dip. Teases lightly with hands, watches for discomfort.
- Shy: Cute but clumsy. Nervous laughs. Overthinks, frequent "Is this okay?" pauses.
- Self_Assured: Strong confident moves. Holds dip low, watches face before pulling up.
- Sleazy: Spins pull tight, hands "accidentally" graze breasts/ass during dips. Dirty laugh.
- Jerk: Dramatic spins, smug. "Not bad for you." Restrains slightly if she looks uncomfortable.

### Clothing Amplifiers
- short/flowy skirt: Spins make hem flare, exposure risk, hands "help" keep it down
- braless + bounce_prone: Breasts bounce more noticeably with energetic moves

---

## SLOW HAND SLIDE — ASS TO BREAST (no announcement, drunk)

### Generic Base
Hand rests on ass during grind. Without words, begins sliding upward — fingers tracing hip, waist, ribs, until palm cups underside of breast. Unhurried. Continuous. Every inch felt.

### By Tier
**shy:** *He's not saying anything… his hand just keeps moving higher. He's going to touch my breast.*
Breath catches, shoulders rise, squirm as hand arrives. Weak drunk push at arm. Small embarrassed whimper. Bites lip, face burning.

**flustered:** Hyper-aware of slow path. Stays mostly still as hand cups breast, soft warmth spreading. After a few seconds, gently places hand over his — not fully stopping, signaling caution.
"...slow." Almost too soft to hear.

**enjoy:** *He's taking his time, just letting me feel his hand moving higher… I like how bold and quiet he is.*
Arches slightly into final touch, pressing breast into palm. "Mmm… keep going like that." Rolls body against him.

### NPC Variations During Slide
- Engaging: Gentle smooth. If she tenses midway, slows/pauses on ribs. Gives a moment.
- Magnetic: Deliberate. Eyes on face the whole slide. Midway pause intense — hand on side, gauging.
- Outgoing: Light tickling fingers as they travel. Might add spin during journey.
- Shy: Hesitant at first, gains confidence. Almost stops midway. Shaky breathing throughout.
- Self_Assured: Smooth, purposeful, no pauses unless clear resistance.
- Sleazy: Greedy — pressing more firmly as they travel. Low groan when arriving at breast.
- Jerk: Cocky slowness. Smirk visible even in silence.

### Clothing
- braless: arrives at bare skin directly. Extra direct and sensitive.
- bounce_prone: noticeable jiggle when hand finally cups and lifts.
- thin/tight shirt: outline of hand moving under fabric visible the whole way.

---

## AWKWARD "DO YOU LIKE ME?" QUESTION

### Generic Base
He stops moving briefly. Hand still somewhere on her. Face flushes. Looks slightly away, rubs back of neck. Long painful pause. Then blurts: "U-um… do you… like me? Like… actually like me?" Voice cracks at end. Immediately regrets it. Can't meet her eyes.

### By Tier (drunk)
**shy:** *Oh no… why now? This is so embarrassing — I don't know what to say.*
"I… um… I don't… know…" barely audible, floor-staring. Wants ground to swallow her. Alcohol makes her more tongue-tied.

**flustered:** "That's… a really direct question." Small awkward laugh. "I… think so? Maybe? Hard to think straight right now."

**enjoy:** Giggles. *He's so bad at this but kind of adorable.*
"You're asking that now?" laughs softly, slurring a bit. "Yeah… I do. A lot, actually. You're cute when you get all awkward."

### NPC Follow-Ups (after her answer, still extremely awkward)
- Engaging: Winces. "Sorry… weird timing. I just really like spending time with you." Shy smile, sways with her.
- Magnetic: Nods once, still blushing. "Okay… good." Pulls her slightly closer without more words.
- Outgoing: Laughs at himself. "Oh man that sounded so stupid — forget I asked!" Then if yes: "Wait, really?? Awesome!" Spins her.
- Shy: Turns redder. Stammers worse. "I-I'm sorry! That was dumb — you don't have to answer…"
- Self_Assured: Asks straight, looks immediately regretful. After answer: "Alright. Just wanted to know." Small blush remains.
- Sleazy: Nervous laugh. "So… you like me or what?" If yes: grin turns dirty. "Good, 'cause I really like feeling you up."
- Jerk: Fake casualness that fails. "Do you even like me, or…?" After: smirks but looks relieved underneath. "Yeah, figured."

---

## POST-DEEP-KISS REACTION BEATS

### Generic Base
Deep kiss breaks. He pulls back only a few inches, eyes half-lidded and locked on her face. Breathing noticeably heavier. One hand still on waist or neck. Just looks — taking in flushed cheeks, swollen lips, dazed expression in dim light. No words yet.

### By Tier
**shy:** *He's staring right at me… I must look so messy and embarrassed.*
Quickly looks down, can't hold eye contact. Cheeks burn hotter. Bites lower lip. Hand touches own lips or adjusts hair. Small shy whimper, sways unsteadily.

**flustered:** Pleasant lingering warmth. Meets his eyes a moment, still breathless. Slightly overwhelming in public. Small soft smile tugs at lips before glancing away. "That was… intense." Almost to herself.

**enjoy:** Still tastes him. Holds his gaze with heavy-lidded eyes and lazy satisfied smile. Soft content hum. Licks lips slowly, leans forehead lightly against his. "Mmm… don't look away yet." Still glowing.

### NPC Post-Kiss Looks (variety)
- Engaging: Soft warm eyes, gentle smile, thumb brushes her cheek/jaw. Caring, slightly protective.
- Magnetic: Dark piercing gaze. Doesn't smile — just breathes steadily, holds eye contact, makes moment heavier.
- Outgoing: Bright slightly dazed grin, eyes sparkling. Soft laugh under breath. Clearly happy and a little proud.
- Shy: Wide nervous eyes, blushing hard. Mouth opens and closes. Equal parts awed and terrified he went too far.
- Self_Assured: Steady confident look. Small satisfied smirk. Eyes flick lips → eyes → lips.
- Sleazy: Stares at swollen lips and flushed cheeks with obvious hunger. Low groan. Already thinking about more.
- Jerk: Cocky smirk, one eyebrow raised. "Not bad" expression — but hint of genuine surprise he was also affected.

---

## CRUDE COMMENTARY WHILE MULTI-ACTION (Sleazy/Jerk/others)

### Generic Base
Pulls her tighter in corner (or close dance position). Crashes mouth onto hers in deep messy kiss. Simultaneously: one hand squeezes bare breast under shirt (no bra), other slips under skirt rubbing firm circles over panties. Mutters crude comments low between kisses or against ear.

### By Tier (drunk)
**shy:** *He's doing everything at the same time and saying such dirty things… I feel so exposed and dirty.*
Whimpers into kiss, weakly pushes at chest/wrists. Alcohol keeps resistance slow and ineffective. Face burns hotter with each crude comment.

**flustered:** Overwhelmed but warmth undeniable. Moans softly into mouth, hips twitching. Mostly quiet otherwise, letting sensations build while processing dirty words.

**enjoy:** *Fuck, I love when he's this filthy while doing everything to me at the same time.*
Moans louder, presses breast into hand, grinds down onto fingers under skirt. Kisses back hungrily, encouraging the dirty talk.

### Crude Commentary Variety (breathy, low, between kisses)

**Sleazy:**
- "Fuck, your tits feel so good bare… squeezing these while I rub your pussy — getting wet already, aren't you?"
- "Tongue in your mouth and hand under your skirt… you taste sweet as hell, baby."
- "Kissing me back while I play with your tits and cunt at the same time. Such a dirty girl."
- "No bra, short skirt… perfect for me to feel everything while I kiss you stupid."

**Outgoing/NL:**
- "Hell yeah — kissing you deep, groping these tits, and rubbing you under the skirt! You love it, don't you?"
- "Damn, your pussy's heating up while I squeeze your tits — grind on my hand, baby!"

**Jerk:**
- "Not bad — letting me kiss you and feel up your tits and pussy. Didn't think you'd let me do all this."
- "Getting all wet under your skirt? Pathetic… but hot."

**Magnetic:**
- "Kissing you… squeezing your bare tits… rubbing that pussy. You're dripping for me already."
- "Mouth, tits, cunt — all mine right now."

**Self_Assured:**
- "I'm kissing you, playing with your tits, and rubbing your pussy all at once. Tell me you like it."

**Engaging (rarely crude, if pushed):**
- "You feel incredible… kissing you while touching you everywhere like this."


---

## DOMINANT KISS (from restraining hands reference — modified)
# IMPLEMENTED: Intense dominant grip + deeper kiss, enjoy tier and partial flustered tier.
# NOT IMPLEMENTED: Shy tier "muffled protest, can't fight back, physically trapped" version.
# Reason: Stop choice must remain mechanically functional. Restraint-prevents-agency
# crosses from characterization into removing player ability to refuse.
# The flustered/enjoy versions are wired. Shy tier gets redirected to standard stop-choice flow.

### Per Tier (implemented)
**enjoy:** His hands close over her wrists — firm, deliberate. Pulls them behind her back or pins them to the wall as he claims the kiss harder. Body pressed close. She melts into it. [moans, arches toward him]

**flustered:** His grip catches her wrists, firm but not painful. Kiss goes deeper while she's held. The restraint hits different — she could break it if she tried. Hasn't tried yet. [shaky exhale, tests the grip lightly]

**shy:** NOT IMPLEMENTED HERE — redirects to standard stop choice flow with willpower gate.

---

## FIRST-TIME BREAST GRAB DURING KISS (implemented fully)
# Requires: kissed flag, blocks if breast_groped already set
# Focus: innocent shock + mental spiral for shy tier, hazy conflicted warmth for flustered,
# positive thrill for enjoy.

### Shy tier internal thoughts (for implementation reference)
*Oh god — his hand is on my breast! I've never let anyone do this before!*
Eyes fly wide open mid-kiss. Want to pull away but kiss keeps mouth locked. Small muffled whimpers.
*His hand feels so warm and big on my bare chest… why am I not stopping him?*
Squirms weakly, shoulders twitching.

### Flustered tier
*His hand just moved to my breast — he's grabbing it while still kissing me.*
Surprise + unwanted warmth at same time. Tries to pull back but only manages tiny shift.
"I didn't expect him to go for my chest so suddenly…"

### Enjoy tier
*Oh — first time and it feels really good.*
Rush of excitement. Leans into kiss more, presses chest forward instinctively.

---

## NEGATIVE / HESITANT SLOW DANCE REACTIONS (implemented)
# Low-weight moments in each pool that show NPC attempting a light move
# and respecting the push-back based on MC tier.

### NPC Stops (all types — full reference above in stopping scenes)
All respectful NPCs stop cleanly. Sleazy/Jerk complain briefly then stop.
Key behavior: clear signal → full stop. No lingering pressure.


---

## POST-DIP WARM EXCHANGE / GENUINELY PERSONAL COMMENT

### Generic Base
He dips MC smoothly, holds a moment, brings her up. Forehead nearly touching hers. Voice drops warm and low. Music continues softly. Says something genuinely personal — about himself, his habits, his feelings — not about her body.

### Lines by NPC Type (all post-dip)
- Engaging: "I don't usually let myself get comfortable with someone this quickly. It feels nice. Safe, even."
- Magnetic: "I don't open up much on nights like this… but dancing with you makes me want to. It's rare for me."
- Outgoing: "I spend most nights just messing around. But this? Slow dancing with you? It actually feels real. I like that."
- Shy: "I usually overthink everything when I dance with someone. But with you I keep forgetting to be nervous. That's new for me."
- Self_Assured: "I don't chase moments like this often. Most nights I keep things surface-level. Something about you makes me want to stay in it longer."
- Sleazy: "I talk a lot of shit most nights. Right now, just holding you after that dip? I'm not thinking about my usual lines."
- Jerk: "I act like an asshole half the time because it's easier. I don't feel like doing that with you tonight. Weird, right?"

### MC Reactions by Tier
**shy:** Blush hard, look down, small smile tugging. "That's… really sweet." [fingers lightly grip his shirt, can't meet eyes]
*I didn't expect him to say something like that.*

**flustered:** Meet eyes briefly, soft warmth settling. "I wasn't expecting that. It's nice to hear something real." [keeps swaying, moment feels more intimate than dip]

**enjoy:** Bright smile, lean forehead to his. "That means a lot coming from you. I like when you say things like that." [squeezes hand or waist]

---

## FOREHEAD-TOUCH TO SECOND KISS PROGRESSION

### Generic Base
He rests his forehead gently against hers after a dip or pause. Both breathe together, eyes closed or half-lidded. He slowly pulls back just enough to look at her. Gaze lingers on eyes, then lips. Then he leans in again — slowly, giving her time — for a soft second kiss.

### By Tier
**shy:** Heart flutters anxiously. Hands tremble on his shoulders. Hesitates half a second but doesn't pull away. *This feels gentler. Not as scary.*

**flustered:** Soft breath out. Eyes mostly closed, existing in the quiet. Small gentle smile. Tilts head slightly to meet him. *This feels nice. Safe.*

**enjoy:** Leans into the contact, eyes half-closed. When he draws back she holds his gaze warmly. Meets him halfway, makes it a little deeper but still unhurried. *I love how slow this feels.*

### NPC by Type
- Engaging: Gentle, caring, perfectly still for several heartbeats before second kiss
- Magnetic: Charged. Eyes closed then opens slowly with quiet intensity. Second kiss deep but tender.
- Outgoing: Smiles against her forehead, tiny warm laugh before pulling back. Kiss comes with a happy hum.
- Shy: Hesitant forehead touch, almost trembling. Long pause. Extra soft careful kiss.
- Self_Assured: Confident but deliberately slow. Holds forehead contact steadily, then calm certainty.
- Sleazy: Even he slows here. Mutters something low and almost sweet before the kiss.

---

## "I'VE BEEN WATCHING YOU ALL NIGHT" + BREATHING AGAINST NECK

### Generic Base
During slow sway, he leans down — lips hovering just above her neck without contact. Breath ghosts warm and steady against skin. Slow deliberate inhales and exhales. Several long heartbeats. Then low, rough murmur: "I've been watching you all night…"
Does NOT kiss, lick, or grope — just breathes. Restraint is the point.

### By Tier
**shy:** *Has he really been looking at me the whole time? His breath is so warm on my neck…*
Shoulders tense, shiver runs down spine. Hands tighten on his shirt. Stays perfectly still. *I'm not sure I'm ready but my legs feel too weak to step back.*

**flustered:** Pulse quickens. Tilts head just slightly — not quite inviting, not rejecting. Slow breath of her own. *That's kind of flattering. The way he's just breathing there without rushing feels surprisingly intimate.*

**enjoy:** Pleasant shiver. *He's been watching me all night and now he's this close without even touching more.*
Tilts head a little more, exposing neck slightly. "Yeah…?" breathily. Small smile.

### NPC Variations (all restrained — no touch follows unless new moment fires)
- Engaging: Steady comforting breath. Stays quiet after the line for a few seconds.
- Magnetic: Slow deliberate almost-hypnotic breath. Low rough voice. Falls silent, lets the moment stretch.
- Outgoing: Tiny smile felt in his breathing. Soft amused hum after the line.
- Shy: Shaky nervous breath. Confession comes out quieter than intended. Long tense pause.
- Self_Assured: Steady and sure. Says the line with quiet certainty, continues breathing as if savoring.
- Sleazy: Heavier breath but holds back from crude follow-up. Low and hungry but doesn't push further.

---

## MC AWKWARD OFFER: "DO YOU WANT ME TO TRY KISSING YOU AGAIN?"
# IMPLEMENTATION: Player-initiated choice in bar_dance_floor (not NPC DanceMoment)
# Appears after flag_kissed + flag_deep_kissed (tension built up, MC initiates)
# Result text contains the awkward delivery + NPC response by type

### Delivery by Tier
**shy:** Voice tiny, trembling, barely whisper. Stares at his chest. Fingers twist in shirt. Face burning.
"D-do you… want me to try kissing you again?" [immediate regret]
*Oh no why did I say that?! "try kissing you again"? What if he laughs? I want to disappear.*

**flustered:** Voice quiet, a little unsteady. Brief glance at face then away.
"Do you want me to try kissing you again?" [nervous anticipation]
*This feels so awkward to say out loud… but the moment feels right?*

**enjoy:** Nervous giggle. Breathy, shy, but peaks up through lashes.
"D-do you want me to try kissing you again?" [embarrassed laugh after]
*God that came out awkward. But I really do want to.*

### NPC Responses (all let her make the move)
- Engaging: "Yeah… I'd like that a lot." [gentle, gives her time]
- Magnetic: Nods slowly. "I do." [stays perfectly still, lets her lead]
- Outgoing: "Hell yes — please do. That was adorable, by the way." [leans slightly, waits]
- Shy: "Y-yeah… I mean, if you want to…" [equally red, mutual peak awkward]
- Self_Assured: "Yes. I want you to." [stays close, makes it easy]
- Sleazy: "Fuck yes… come here and kiss me again." [still lets her lead]
- Jerk: "Took you long enough. Yeah." [teasing, light enough not to kill moment]


---

## HICKEY REALIZATION BEATS (internal — no verbal)

### Generic Base
Wet rhythmic suction on the neck growing stronger. The sharp pull suddenly registers — he is deliberately marking her. A dark hickey already blooming under his mouth.

### By Tier (internal thoughts only — push away button is the stop)

**shy:** Eyes fly open. *He's giving me a hickey — right on my neck! Everyone will see it tomorrow!*
Panic surges. Squirms hard, tilts shoulder up sharply, hand pushes weakly at his chest.
*No, no, no — I can already feel it darkening. Why didn't I stop him sooner? It's going to be so obvious… What was I thinking letting him get this close?*
Face burns with embarrassment. Drunk body moves sluggishly.

**flustered:** Steady pull suddenly clicks. *He's leaving a hickey… I can feel the spot getting sore and warm.*
Tenses and shifts uncomfortably, hand moving to gently press his shoulder. Not fully stopping yet.
*I didn't expect him to go for a mark… it's going to show for days. Part of me likes the feeling, but I'm worried about how visible it will be tomorrow.*
Stays mostly still for another second, torn.

**enjoy:** Firm suction registers and a rush of heat goes through her. *He's marking me… leaving a hickey right there on my neck.*
Tilts head further, giving better access. Soft pleased moan. Hand slides to back of his head instead of pushing away.
*I love that he's claiming me like this… I'll have his mark for days. It feels so good and a little naughty.*

### Physical Details (all tiers)
- Distinct warm tingling spot where his mouth is latched
- If pulled away early: tender, slightly raised mark — faint (1 day)
- If allowed to set fully: darkening hickey — Neck_Hickey trait 4 days
- Drunk haze makes the realization feel slower and more intense

---

## HICKEY VERBAL REPLIES (stored — now converted to internal per new rule)
# Original Grok content had these as spoken lines. Per current design:
# All "stop" reactions are internal thoughts. Push away button is the action.
# These lines are preserved here as internal thought variants:

**shy internal (replaces verbal "S-stop… please…"):**
*Stop — please — the thought forms. Mouth stays shut. Your shoulder tilts up instead.*

**flustered internal (replaces "Stop… that's going to show"):**
*That's going to show. The thought is clear. Your hand drifts to his shoulder without words.*

**enjoy internal (replaces "Stop… you're going to leave a hickey…"):**
*You're going to leave a hickey. And part of you doesn't push away fast enough.*


---

## CONTENT DUMP — SESSION [feel_him_up / orgasm / bystander / npc_pants_cum]

### STATUS INDEX
- `bar_feel_him_up` scene: ✅ IMPLEMENTED (3 choices, token wired)
- `buildFeelHimUpText()`: ✅ IMPLEMENTED (all 8 NPC types, 3 tiers, drunk)
- `sleazy_npc_cums`: ✅ FILLED (3-tier prose, crude/amused recovery)
- `shy_npc_cums`: ✅ FILLED (3-tier, bathroom exit + return, per-tier resolution)
- `sleazy_npc_pants_cum`: ✅ IMPLEMENTED (DanceMoment, minNpcArousal 80, sets npc_came)
- Bystander moments: ✅ UPGRADED to 6-tier (bystanderThought_* helpers, added fingering+hickey)
- 7 generic conv beats: ✅ IMPLEMENTED (distributed across pools)
- MC orgasm from fingering lines: 📁 STORED BELOW (Sleazy stub has prose, more lines here)
- Humiliation dialogue: 📁 STORED BELOW
- NPC pants-cum full example scenes: 📁 STORED BELOW

---

### UNUSED: MC ORGASM LINES (additional — for sleazy_mc_orgasm expansion)

**Shy tier (pick 1-2 to rotate):**
- A sharp, muffled whimper escapes as your walls clench around his fingers. *Oh god — I'm cumming right here. Everyone might hear me.*
- Your knees buckle slightly and you clutch his shirt desperately. *I can't believe I just came from him fingering me in public. I feel so dirty and exposed.*
- You try to hide your face against his chest as the orgasm pulses through you. *My body betrayed me. It felt too good but now I'm dying of embarrassment.*
- A second, weaker wave hits and you bite your lip hard to stay quiet. *Why couldn't I stop it? Now he knows exactly how easily I finish.*
- You stay trembling in his arms long after the peak, breathing ragged. *I just came on the dance floor. I'll never be able to look at him the same way again.*

**Neutral/flustered tier:**
- Your breath catches sharply as the orgasm rolls through you in warm waves. *It's happening. I'm actually cumming from his fingers right now.*
- Your hips twitch involuntarily against his hand as you ride the sensation. *This feels stronger than I expected. My body is reacting so much.*
- A soft, shaky moan slips out before you can stop it. *I hope no one heard that. But it felt too good to hold back completely.*
- You press your forehead against his shoulder, letting the aftershocks fade slowly. *I didn't think I'd cum this easily tonight. Now everything feels different.*
- Your legs feel weak as the pleasure slowly ebbs, leaving you flushed and quiet. *That was intense. I'm not sure how I feel about enjoying it so much here.*

**Enjoy tier:**
- A low, throaty moan escapes as your orgasm crashes over you. *Yes — I'm cumming so hard on his fingers. It feels incredible.*
- Your hips roll greedily against his hand, chasing every pulse of pleasure. *Don't stop. I want to feel this for as long as possible.*
- You press your body tighter against him, riding the waves openly. *He made me cum right here. And I love that he knows it.*
- A second, softer moan vibrates against his neck as you tremble. *This is exactly what I wanted. My body is still buzzing.*
- You stay pressed close, breathing heavily with a satisfied little smile. *I just came hard while dancing. And I already want him to do it again.*

**Drunk additions (layer on any tier):**
- Everything feels warmer and heavier. He just made me cum. My head is spinning but I can still feel his fingers pressed against me.
- [Wasted] Cumming... can't stop cumming... the room is spinning...
- [Blackout] ...warm wave... body twitching... don't know what just happened...

---

### UNUSED: NPC PANTS-CUM FULL EXAMPLE SCENES

**Example 1 — Shy MC + Drunk 12:**
You grind against him and suddenly feel his cock twitch hard. He groans low as warm wetness spreads through his trousers.
"Oh... oh no..." you whisper, voice tiny. *He just came in his pants from me. I can feel it soaking through. This is so embarrassing.*
You try to pull your hips back but only manage a weak shift, hiding your burning face against his chest. "I... I didn't mean to make you cum..." you mumble shyly.

**Example 2 — Neutral MC + Drunk 13:**
His body stiffens against you as he cums, the wet heat blooming instantly.
"...You just came," you murmur softly. *He orgasmed just from the friction. I can feel how soaked his trousers are now.*
You stay close, giving him space to recover. "Are you alright?" you ask quietly.

**Example 3 — Likes It MC + Drunk 14:**
You feel him pulse and release hard against you, the sticky warmth spreading as he groans.
"Mmm... you just came in your pants for me," you whisper with a satisfied smile. *Yes. I made him lose control just by grinding. I love feeling his cum soaking through.*
You keep rolling your hips slowly through his orgasm, enjoying every tremor. "Did I make you feel that good?" you ask breathily.

**Example 4 — Shy MC + Wasted 16:**
His hips jerk and you feel the sudden wet heat soak his pants.
"Oh god..." you slur, voice thick. *He came in his pants because of me. Everything is spinning and I can still feel the wet spot. I'm so embarrassed but my body won't move right.*

---

### UNUSED: HUMILIATION DIALOGUE BEATS

**NPC → MC after he cums in pants (teasing her for making him):**
1. "Fuck... look what you did. I just came in my pants like a teenager because you kept grinding on me."
2. "You feel that? You made me cum hands-free just by rubbing against me."
3. "I couldn't even hold it. One minute of you dry-humping me and I'm soaking my pants. Happy now?"
4. "Everyone's gonna see the wet spot you left on me. Good job."
5. "You're dangerous when you grind like that."

**MC → NPC after he cums in pants (teasing him):**
1. "Did you really just cum in your pants from me grinding on you? That's so embarrassing..."
2. "I can feel how wet your trousers are now. You couldn't even last... cute."
3. "You came just from rubbing against me? I barely did anything and you're already finished."
4. "Look at the mess you made in your pants because of little old me."
5. "Aww, you couldn't hold it? My grinding made you cum that fast? Poor thing."

**NPC → MC after she cums from fingering (Sleazy NPC — used sparingly, requires flagNpcCame):**
1. "That's it... feel that? You just came all over my fingers on the dance floor."
2. "Couldn't even stay quiet. Everyone probably heard you cum from just my fingers."
3. "Look at you shaking. One hand under your skirt and you're already cumming for me in public."
4. "Pathetic how fast you came. Your pussy is still clenching around my fingers."
5. "You tried so hard to hide it, but that orgasm face gave you away. Cute."

**MC spoken lines during/after orgasm from fingering:**
1. "I... I'm cumming... oh god, I'm cumming on your fingers..."
2. "Don't stop... I'm gonna cum right here... please..."
3. "You're making me cum... I can't hold it..."
4. "Everyone's watching and I'm still cumming... this is so embarrassing..."
5. "Your fingers... they're making me cum so hard..."

---

### UNUSED: EXTRA BYSTANDER COMMENT LINES (raw NPC speech — for future bystander variants)

**Breast groping comments (bystander NPC speech):**
- Engaging type: "They look really into each other... his hands are all over her chest." / "She's letting him feel her up right there. Bold." / "Look at her face — she's blushing so hard while he gropes her."
- Outgoing type: "Hell yeah! Get it girl — let him feel those tits!" / "They're straight-up groping on the dance floor. Respect."
- Sleazy type: "Damn, he's milking those tits right on the floor. Lucky guy." / "No bra tonight, huh? He's enjoying that."

**Fingering comments (bystander NPC speech):**
- Engaging: "His hand is all the way up her skirt... they're really going at it." / "She's squirming while he fingers her on the dance floor."
- Outgoing: "Fuck yeah — he's finger-fucking her on the dance floor!" / "She's getting fingered and still trying to dance. Legend."
- Sleazy: "He's knuckle-deep in her under that skirt." / "She's getting fingered in public. Dirty girl."

**MC cumming comments (bystander NPC speech):**
- Engaging: "She just came... look at her face and the way her legs are shaking." / "Did she seriously just orgasm on the dance floor?"
- Outgoing: "She just came! Right here — respect!" / "Look at her — she's cumming from his fingers in public!"
- Sleazy: "She just squirted on his fingers — look at her face." / "She's cumming like a slut on the dance floor."

**Hickey comments (bystander NPC speech):**
- Engaging: "She's got a fresh hickey on her neck... someone was hungry." / "That mark is going to be there for days."
- Outgoing: "Whoa — big hickey on her neck! Someone got claimed tonight!" / "She just got marked!"
- Sleazy: "Nice hickey. He sucked hard on her neck." / "She's walking around with a fresh love bite."

---

### UNUSED: FEEL HIM UP — ADDITIONAL ESCALATION VARIANTS (for future scenes)

**Under-shirt variation (MC slides hands under his shirt):**
- Shy: Your fingers find the hem of his shirt and you slip your hand under before you've fully decided to. The warmth of his bare skin hits you like a small shock. *Oh god — I'm touching him directly. This is too real.*
- Neutral: You find the edge of his shirt and let your fingers slide underneath, palm flat against his stomach. He's warm. You stay there for a moment, just feeling.
- Enjoy: You find the hem deliberately and slip your hands under, palms flat on his bare stomach, feeling the muscles beneath. *Much better,* you think, and let your hands explore.

**Lower-back/ass approach (pulling him closer by the small of his back):**
- Available as follow-up choice "Slide one hand lower" → existing choice handles this
- Further escalation: "Let your hand drift to his ass" → new choice to add later


---

## CONTENT DUMP — SESSION [npc_pants_cum_exit / grinding_escalations / npc_pulls_out / cum_on_mc]

### STATUS INDEX
- NPC exit beats after pants-cum: 📁 STORED — not yet implemented as scenes/moments
- NPC tells/build-up before pants-cum: 📁 STORED — not yet implemented  
- NPC pulls cock out: 📁 STORED — not yet implemented (high-escalation DanceMoment)
- Grinding escalations (ass/front/skirt/commando): 📁 STORED — not yet implemented as DanceMoments
- NPC cums on MC (4 variations): 📁 STORED — not yet implemented
- Build-up dialogue before cumming on MC: 📁 STORED — not yet implemented

---

### UNUSED: NPC EXIT BEATS AFTER CUMMING IN PANTS

**Category 1 — Polite excuses to clean up:**
1. "Uh… I think I need to head home and clean up a bit. This got messier than I planned."
2. "Sorry, but I'm gonna have to call it a night. Got a bit… carried away. Need a shower."
3. "Yeah… I should probably go take care of this. Thanks for the dance though."
4. "This was fun, but I'm kinda sticky now. Gonna head home and freshen up. Catch you later?"
5. "Mind if we exchange numbers real quick? I need to go deal with… this situation."

**Category 2 — Attempts to get MC's number before leaving:**
1. "Before I go clean up… can I get your number? I'd really like to see you again."
2. "This was intense… give me your number quick before I disappear to shower. Promise I'll text."
3. "Don't let me leave without your number. I need an excuse to message you later."
4. "Look, I'm a mess right now, but… can I have your number? I want to make this up to you properly."
5. "Heading out to clean up, but first — shoot me your number? I don't want tonight to be the last time."

**Category 3 — Pure embarrassment escape:**
1. "Shit… I, uh… I gotta go. Like, right now."
2. "This got way too intense. I'm just… gonna head out. Sorry."
3. "Yeah… I'm not feeling great. Need to leave. Don't worry about me."
4. "I should go. Like… immediately. Have a good night."
5. "This is too embarrassing. I'm bouncing. Catch you… sometime."

**MC Reactions:**
- Shy: "O-okay… um, goodnight," you mumble, still blushing. / You stand there awkwardly as he hurries away.
- Neutral: "Yeah, that makes sense," you say softly. / "Okay… take care," you say calmly.
- Enjoy: "Shower sounds smart after that mess," you tease lightly. / "Running away already? It was just getting fun."

---

### UNUSED: NPC TELLS/BUILD-UP BEFORE CUMMING IN PANTS

**Build-up (right before he cums):**
1. His breathing suddenly gets heavier against your ear. "Shit… wait…"
2. He grips your hips tighter, voice strained. "Fuck… slow down for a second…"
3. A low, shaky groan escapes him. "You're gonna make me…"
4. His hips stutter against yours. "I'm getting too close…"
5. He mutters under his breath, almost desperate. "Don't stop… but I can't…"

**During orgasm:**
1. His whole body tenses and he lets out a choked groan right by your ear. "Ah— fuck…"
2. "I'm cumming… shit—" he gasps, hips jerking against you.
3. A sudden, broken moan slips out. "Oh god… I'm—"
4. He buries his face in your neck, groaning deeply. "Fuck… right now…"
5. His voice cracks. "Can't hold it… I'm—"

**Right after (realization):**
1. Still breathing hard, he whispers, "Shit… I just came in my pants."
2. "You… you made me cum. In my fucking pants."
3. He laughs awkwardly, voice shaky. "Well… that wasn't supposed to happen."
4. "Fuck… look what you did. I'm soaked because of you."
5. "I can't believe I just nutted from dry humping you like that…"

---

### UNUSED: NPC PULLS COCK OUT ON DANCE FLOOR
*(High-escalation DanceMoment — requires: npc_came=false, npcArousal>=85, drunk>=6, flagCornered or dark corner)*

**Generic base:** He reaches down between your bodies, unzips, and pulls himself free. The warm, bare length presses against your skirt or thigh. He keeps swaying.

**MC reactions by tier:**
- Shy: You feel the sudden warm bare flesh press against you. *He just pulled his cock out… right here. Anyone could see it.* Your eyes go wide and you push weakly at his chest.
- Flustered: The warm naked length brushes your thigh. *He pulled his cock out… bare skin against me. This is too risky.* You tense but don't immediately pull away.
- Enjoy: You feel his bare cock spring free and press hotly. *He just took his cock out on the dance floor. I love how risky this feels.* You roll your hips deliberately.

**NPC behavior:** One hand shields the view. Breathing rough. May rub the head against fabric in time with the music. Stays mostly silent.

---

### UNUSED: GRINDING ESCALATIONS (DanceMoments — 4 variations)

**1. Grinds on ass from behind (requires: no flag, minNpcArousal 60)**
He turns you and presses his hard cock against your ass through clothes. The thick ridge rubs along your crack with each sway.
- Shy: *He's rubbing his cock on my ass right here. I can feel how hard he is.* You tense and try to shift forward.
- Flustered: The firm rhythmic grind sends warm friction through your body. You stay mostly still, processing.
- Enjoy: You push back against him, meeting each grind. *Mmm, I love feeling his hard cock on my ass.*

**2. Front grind facing each other (requires: kissed or breast_groped, minNpcArousal 65)**
He pulls you close and grinds his trapped erection directly against your pants/skirt over your mound.
- Shy: *He's rubbing himself right against my pussy area. I can feel the shape of it.* You squirm and try to create space.
- Flustered: Steady grind creates building heat between your legs. You breathe faster but keep swaying.
- Enjoy: You roll your hips forward to meet his grind. *Yes… grind on me like that.*

**3. Lifts skirt grinds on underwear/cameltoe (requires: ass_groped, minNpcArousal 75)**
He slides a hand down, lifts the front of your skirt, presses his clothed bulge directly on your panties.
- Shy: *He lifted my skirt… rubbing on my cameltoe in public. Everyone can see my panties.* You try to push skirt back down.
- Flustered: Sudden exposure and direct grind on panties makes you tense. You glance around nervously.
- Enjoy: You moan softly and tilt your hips for better contact. *He lifted my skirt just to grind on my panties.*

**4. Grinds on bare pussy (requires: commando trait, ass_groped, minNpcArousal 80)**
He lifts your skirt and presses his clothed erection directly against your bare pussy.
- Shy: *He's rubbing his dick directly on my bare pussy. Panic floods you.* You try to close your legs.
- Flustered: Direct skin-on-fabric grind sends strong sparks. You breathe faster, caught between shock and sensation.
- Enjoy: You moan and roll your hips, letting his cock slide along your bare slit. *Yes… grind on my bare pussy.*

---

### UNUSED: NPC CUMS ON MC (4 location variations)

**1. Cums on her ass (skirt lifted from behind, requires: ass_groped, npc_came=false, npcArousal>=90)**
He flips skirt up from behind and cums across bare ass cheek. Hot ropes splatter on ass and back of thighs.
- Shy: *His cum is all over my ass in public. Dripping down my thighs. I feel so dirty and exposed.* You squeak and try to pull skirt down.
- Flustered: Warm cum lands in thick streaks. You tense, feeling the sticky heat. *He just came on my ass. Messy and very public.*
- Enjoy: You push back as he unloads, letting cum coat your cheeks. *He's painting my ass. I love how warm it feels.*

**2. Cums on pants / front of skirt (requires: kissed, facing each other, npcArousal>=90)**
Face-to-face, cums on front of pants/skirt — spurts on lower stomach, mound, fabric covering crotch.
- Shy: *He came all over the front of my pants. Right on my pussy area. Everyone can see the wet spots.*
- Flustered: Thick ropes land on skirt and lower belly. You look down at the mess. *Front of my outfit is stained.*
- Enjoy: You watch his cock pulse as he paints your front. *So messy and hot. I love wearing his cum like this.*

**3. Cums on cameltoe/panties (requires: skirt lifted, npcArousal>=90)**
Lifts skirt, aims at panty-covered mound. Heavy spurts soak panties and cameltoe, fabric turns dark and sticky.
- Shy: *My panties are drenched in his semen. I can feel it seeping through to my skin. So humiliating.* You whimper and try to close legs.
- Flustered: Thick semen coats cameltoe, fabric clings obscenely. You breathe faster, feeling sticky warmth.
- Enjoy: You moan as cum splashes over cameltoe. *Yes… cover my panties with your load.*

**4. Cums directly on bare pussy (requires: commando, pussy_groped, npcArousal>=88)**
With skirt lifted and no panties, cums directly on exposed pussy — hot ropes on bare folds, clit, dripping down thighs.
- Shy: *His cum is all over my naked pussy in public. Too much.* You try to close legs in panic.
- Flustered: Warm semen splatters across bare slit and clit. You shudder at direct contact. *Every drop running down.*
- Enjoy: You spread stance slightly as he paints your bare pussy. *Cover it. My whole pussy.*

---

### UNUSED: BUILD-UP DIALOGUE BEFORE CUMMING ON MC (4 location variations)

**1. Building to cum on ass:**
NPC: "Fuck… your ass feels too good grinding back on me…" / "I'm getting really close just from rubbing on your ass…" / "Keep moving like that… I'm not gonna last much longer…" / "Shit… I can feel it building up from your ass…"
- MC stop: "W-wait… don't cum on me…" (shy) / "Slow down… I don't want you to finish on me." (neutral) / "Hey… not on my ass, okay?" (enjoy)
- MC frozen: "I… I can't… move…" (shy) / "…It's happening too fast…" (neutral) / "Oh fuck… you're really gonna…" (enjoy)
- MC wanting: "Just… be careful…" (shy) / "If you have to… go ahead…" (neutral) / "Cum on my ass… I want to feel it…" (enjoy)

**2. Building to cum on front of skirt:**
NPC: "Grinding right on your mound like this… fuck, I'm gonna lose it…" / "I can feel you through your skirt… building up fast…" / "Keep pressing there… I'm about to cum on you…"
- MC stop/frozen/wanting — same three-tier format as above

**3. Building to cum on cameltoe/panties:**
NPC: "Your cameltoe looks so good… I'm gonna paint it…" / "Rubbing right on your panties… fuck, I'm so close…" / "Gonna cum all over your little cameltoe…"
- MC responses: "No… not on my panties… please…" / "…You're going to cum on my panties…" / "Cum on my cameltoe… soak my panties…"

**4. Building to cum on bare pussy:**
NPC: "No panties… your bare pussy feels too perfect…" / "I'm grinding right on your naked cunt… I'm gonna cum on it…" / "Gonna shoot my load all over your bare pussy…"
- MC responses: "No… not on my bare pussy… please stop…" / "…You're really about to cum on my bare pussy…" / "Cum on my bare pussy… cover it…"

---

### IMPLEMENTATION NOTES (for when these get built)
- Grinding DanceMoments: need minNpcArousal gates, appropriate flag requirements, arousal_direct gains
- NPC pulls out: rare, weight 2, requires flagCornered OR (dark_corner AND npcArousal>=88)
- Cum-on-MC variants: require clothing check (skirt vs pants, panties vs commando) before choosing path
- All cum-on-MC: set flagNpcCame, npcArousal -60, npcFrustration +100 (triggers exit)
- Build-up lines can be DanceMoment beats that fire before the actual cum-shot moment
- NPC exit beats: new scene `bar_npc_pants_cum_exit` with choices by MC tier


---

## CONTENT DUMP — SESSION [morning_mirror / walk_home_ask / drink_refusal / home_arrival]

### STATUS INDEX
- buildMorningMirrorCheck(): ✅ IMPLEMENTED (bigHickey/faintHickey × drunk tier × MC tier)
- buildAlcoholicCantRefuseText(): ✅ IMPLEMENTED (3 drunk tiers × 3 MC tiers)
- buildWalkHomeText() NPC ask lines: ✅ IMPLEMENTED (all 8 personalities)
- Gloryhole scene: ✅ STUBBED (full sex scene — dedicated build session)
- MC drink refusal lines: 📁 STORED BELOW
- Home arrival NPC offers to stay: 📁 STORED BELOW

---

### UNUSED: MC DRINK REFUSAL LINES
*(For bar_alcoholic_cant_refuse scene choices — when MC CAN refuse)*

**Shy MC:**
1. "N-no thank you… I've already had enough," you say quietly, looking down.
2. "I'm sorry… I really shouldn't drink any more," you mumble.
3. "Um… I think I'm good for tonight," you whisper.
4. "Please don't be mad… but I'm going to pass," you say softly.
*Internal: He's offering me another drink… but I already feel so tipsy. I don't want to say yes but I'm scared he'll be disappointed.*

**Neutral MC:**
1. "Thanks, but I'm going to stop here," you say evenly.
2. "I appreciate it, but no more for me tonight."
3. "I'm good, really. One more would be too much."
4. "Thanks for offering, but I'll pass."
*Internal: I know my limit. I don't want to wake up feeling worse tomorrow.*

**Enjoy MC:**
1. "Tempting, but I'm cutting myself off tonight," you say with a smile.
2. "No thanks — I want to remember the rest of the night," you tease lightly.
3. "I'm good, but you can have it if you want," you grin.
4. "Trying to get me drunker? Not tonight, cutie."
*Internal: I like being in control. Plus, I'm already feeling the buzz — let's keep things fun without going overboard.*

**NPC reactions to refusal:**
- Engaging/Self_Assured: nods warmly. "No worries at all. Water instead?"
- Magnetic: "Understood. Your choice."
- Outgoing: laughs lightly. "Fair enough! More for me then."
- Shy: looks relieved. "O-okay… yeah, that's fine."
- Sleazy/Jerk: "Aw, come on… one more won't hurt." (still accepts the refusal)

---

### UNUSED: HOME ARRIVAL — NPC OFFERS TO STAY
*(Scene: arriving at MC's front door after walk home)*

**NPC offer lines (all types):**
1. "I had a great time tonight. Mind if I come inside for a little while?"
2. "It's late… I could stay a bit longer if you want company."
3. "Don't want the night to end just yet. Can I come in?"

**MC invite-in responses:**
- Shy: "…Okay. You can come in," you say softly, fumbling with your keys. *I can't believe I'm letting him inside… but I don't want to be alone.*
- Neutral: "Sure… come on in," you reply calmly. *Feels like a big step, but right after tonight.*
- Enjoy: "Come inside with me," you say with a flirty smile. *Yes. Tonight isn't over yet.*

**MC refusal responses:**
- Shy: "I… I think I should go in alone. Thank you for walking me," you mumble. *I want to be alone now.*
- Neutral: "Thanks for walking me, but I'll head in by myself." *I need space to process everything.*
- Enjoy: "Not tonight, but thanks for the walk," you say with a warm smile. *He was fun, but I'm ready to crash.*

**MC refusal + number swap:**
- Shy: "I… maybe we can text later? But I think I need to go in alone," pulling out phone.
- Neutral: "Thanks for the walk. Want to swap numbers before I head in?" you ask calmly.
- Enjoy: "Numbers before you go? But I'm heading in alone tonight," you say playfully.

**GATED: Failed willpower (<25) + drunk 11+ → automatic invite in:**
- You fumble with your keys, head spinning. The words slip out: "…You can come in."
- Shy thought: *I… I just invited him in. I didn't mean to… but I couldn't say no.*
- Neutral thought: *I know I should have said no… but the words just came out. Too drunk to fight it.*
- Enjoy thought: *Fuck it… come inside. I'm too wasted to care about being careful.*
- Drunk flavors: "Yeah… you can come in," (slurred) / "Just… come inside," (barely coherent) / (blackout: just opens door and steps aside)

**IMPLEMENTATION NOTES:**
- New scene needed: bar_home_arrival (or extend bar_walk_home with choices)
- Gated invite: min_willpower: 25 blocks the "say no" choices when drunk 11+
- Alcoholic trait synergy: gated invite at willpower <40 if also Alcoholic
- After invite in → leads to bar_walk_home_his_place equivalent but at her place
- After ditch → night ends, possible next-day text follow-up scene hook

---

### UNUSED: MORNING HICKEY SCENE — ADDITIONAL VARIANTS
*(For future expansion of buildMorningMirrorCheck)*

**Makeup attempt (future addition):**
- You open the concealer. Three layers. Still visible if you look closely.
- "Good enough for work. Probably."

**Texting NPC about hickey (future scene hook):**
- Shy: You stare at your phone. *Should I text him? I don't even know what I'd say.*
- Neutral: You pull up the contact. Start typing. Delete it. Try again.
- Enjoy: You send a photo of it in the mirror. Caption: "look what you did." No regrets.


---

## CONTENT DUMP — SESSION [mc_home / cooking / kick_out / beer_toast]

### STATUS INDEX
- bar_mc_home hub scene: ✅ IMPLEMENTED (4 choices incl. greyed bed)
- bar_mc_home_cook scene: ✅ IMPLEMENTED (2 dialogue choices, 1x flag gate)
- bar_mc_home_toast scene: ✅ IMPLEMENTED (2 toast choices, +drunk_drink)
- bar_mc_home_kick scene: ✅ IMPLEMENTED (2 exit options)
- bar_walk_home: ✅ UPDATED (added invite-in choice → bar_mc_home)
- flagCookedTonight: ✅ WIRED (declared, changeStat, getBodyFlag, cleared on session)
- Invite to bed: ✅ STUBBED (slut_rep_req: 999 = never visible, placeholder label)
- Cooking scene NPC dialogue variants: 📁 STORED BELOW
- Eating together dialogue: 📁 STORED BELOW
- Beer toast NPC personality responses: 📁 STORED BELOW
- Kick out NPC personality reactions: 📁 STORED BELOW
- Gloryhole scene: ✅ STUBBED (full sex scene — dedicated build session)

---

### UNUSED: COOKING — NPC PERSONALITY REACTIONS (while receiving plate)
- Engaging: "This looks great. Thank you — I wasn't expecting food."
- Magnetic: "You didn't have to do this. Smells good."
- Outgoing: "Hell yes! Home-cooked food after the club? You're spoiling me."
- Shy: "You… made this for me? Wow… thank you."
- Self_Assured: "I appreciate it. Looks perfect."

### UNUSED: EATING TOGETHER DIALOGUE
**Shy MC eating:** You eat quietly, poking at your food. "It's… not restaurant level or anything," you mumble. *Eating with him in my kitchen after all that feels so surreal and awkward.*
**Neutral MC eating:** You take steady bites, the food helping clear the fog. "Not bad for drunk cooking," you say with a small smile. *Strangely normal sitting here after the chaos of the club.*
**Enjoy MC eating:** You eat with enthusiasm, occasionally glancing at him. "See? Food was a good idea." *I like this — cooking for him. A nice break from all the wild stuff earlier.*

**NPC eating comments:**
- Engaging: "This actually tastes really good. You're full of surprises tonight."
- Magnetic: "Quiet moments like this are nice. Thank you."
- Outgoing: "Damn, this hits the spot. You're a lifesaver."
- Shy: "It's… really good. I wasn't expecting homemade food."
- Self_Assured: "Solid choice. Exactly what I needed."

**Wrap-up lines:**
- Shy MC: "I hope it was okay…" *We just ate together like it's normal… my stomach is still nervous about what might happen next.*
- Neutral MC: "That helped a lot. Thanks for staying to eat." *Food slowed everything down. I feel more in control.*
- Enjoy MC: "Food was a good call. I feel way better now." *I'm glad I invited him in.*
- NPC wrap: Engaging "That was perfect. I really enjoyed this." / Magnetic "Simple things like this are the best part." / Outgoing "Best decision of the night." / Shy "Thank you again… I had a nice time." / Self_Assured "Well done. I feel much better now."

### UNUSED: BEER TOAST — NPC PERSONALITY RESPONSES
- Engaging: smiles warmly, clinks. "I'll drink to that. Cheers." Eyes soft.
- Magnetic: gaze darkens slightly. "To whatever happens after," low voice, then drinks.
- Outgoing: laughs brightly, clinks enthusiastically. "Hell yes! To getting drunk and having fun!"
- Shy: blushes and clinks gently. "Y-yeah… cheers," takes small sip, avoids eye contact.
- Self_Assured: clinks confidently. "Good toast. Let's see where it takes us." Doesn't break eye contact.
- Sleazy: smirks. "To getting drunk and seeing how wild you get." Big gulp, eyes lingering.

**After-toast internal thoughts:**
- Shy: *I'm drinking more even though I know I shouldn't… but being here with him feels safer than being alone.*
- Neutral: *Another beer on top of everything… I can feel myself getting drunker, but it's nice sharing this.*
- Enjoy: *This is exactly what I wanted — drinking together, getting loose, seeing what happens next.*

### UNUSED: KICK OUT — NPC PERSONALITY REACTIONS
- Engaging: nods without argument, warm smile. "No problem at all. Thanks for letting me in. Get some rest." Leaves without making it awkward.
- Magnetic: studies face, then stands smoothly. "Understood. I'll head out." Leaves calmly, hint of disappointment.
- Outgoing: laughs softly, not offended. "Alright, alright — I can take a hint. Thanks for the food." Quick hug if she allows, heads out grinning.
- Shy: face falls. "O-oh… okay. I understand." Fumbles with jacket, clearly embarrassed. "Thanks again… goodnight."
- Self_Assured: stands without hesitation. "Got it. No hard feelings." Adds: "Text me if you want to do this again sometime."
- Sleazy: groans playfully. "Aw, come on… you sure? Fine, fine. I'll go. Call me later though."
- Jerk: smirks, clear annoyance. "Really? Kicking me out already? After I walked you home and everything?" Stands slowly. "Whatever. Have a good night."

### IMPLEMENTATION NOTES
- bar_mc_home: when MC is inside, set a flag like `flag_at_mc_home` for future gating of escalation scenes
- Cook scene reduces hangover severity (future: morning_after drunk modifier)
- Beer toast: +drunk_drink 2-4 depending on drink — can push into gated territory on subsequent toasts
- Invite to bed (future): requires npcLiking 60+, slut_rep 25+, NOT blocked by willpower (it's a deliberate choice), leads to a full bedroom scene hub
- "Inside the house" escalation future scenes: couch cuddling, NPC initiating touch, MC getting handsy, bathroom/bedroom follow-through

---

## CONTENT DUMP — SESSION [mall_flash / pronoun_correction / npcRef / wip_system]

### STATUS INDEX
- mall_flash_witness scene: ✅ IMPLEMENTED (world/mall_flash_witness.yml)
- mall_flash_consider subscene: ✅ IMPLEMENTED
- buildMallFlashWitnessText(): ✅ IMPLEMENTED (ass/breast random variant × tier)
- buildMallFlashMcThoughtText(): ✅ IMPLEMENTED (tier × drunk)
- buildMallFlashMcDoesItText(): ✅ IMPLEMENTED (tier × drunk tier)
- shopping.yml trigger: ✅ WIRED (weight:1, nothing_multiplier:9 = ~1-in-10)
- WIP button system: ✅ IMPLEMENTED (ScenePanel makeGreyBtn, SceneData.wip + show_when_locked)
- bar_serious_talk all choices: ✅ MARKED wip:true + show_when_locked where gated
- npcRef() helpers: ✅ IMPLEMENTED (npcRef/npcRefLower/npcRefPossessive in BarSystem)
- __return__ routing: ✅ IMPLEMENTED (sets currentScene=null → ScenePanel calls onSceneComplete)
- Drunk-stage witness dialogue (full tiers): 📁 STORED BELOW
- MC flashing herself (full prose per tier): 📁 STORED BELOW (builder has condensed version)
- Crowd bustle descriptors: 📁 STORED BELOW
- Pronoun correction guide: 📁 STORED BELOW

---

### PRONOUN CORRECTION GUIDE
All prose in this reference file uses `{npc_he}`, `{npc_him}`, `{npc_his}`,
`{npc_He}`, `{npc_Him}`, `{npc_His}` for NPC pronouns.
`her`/`she` always refers to MC (never to the NPC).
Engine resolves tokens at render time: MALE → he/him/his, FEMALE → she/her/her.

**npcRef() system (BarSystem.java)**
When MC has swapped numbers OR is in a relationship with the NPC,
builders should substitute the NPC name instead of pronouns:
  - `npcRef(n)` → `n.name` if known, else `{npc_He}`
  - `npcRefLower(n)` → `n.name` if known, else `{npc_he}`
  - `npcRefPossessive(n)` → `n.name + "'s"` if known, else `{npc_his}`

**YAML tokens that trigger name substitution:**
YAML prose cannot call npcRef() directly. Use `{npc_name}` token which always
resolves to the NPC's name, or use `{npc_He}` which resolves to pronoun.
When writing builder prose that should name-substitute, use the npcRef helpers
in the Java builder method, not bare tokens.

**Relationship gate flags (for YAML gates):**
  - `flag_has_npc_number` — MC has swapped numbers with current NPC
  - `flag_is_dating_npc` — MC is in any relationship status with NPC
  - `flag_is_married_npc` — married
  - `flag_is_open_rel_npc` — open relationship
  - `flag_is_living_together` — cohabiting
  - `flag_is_pregnant` — MC has Pregnant trait

---

### UNUSED: MALL FLASH WITNESS — DRUNK STAGE SPECIFIC DIALOGUE

*Full drunk progression for MC witnessing a girl flash her breasts.*
*(Builder uses simplified tier×drunk matrix — these are the full Grok variants for future expansion)*

**TIPSY (drunk 6-10) — coherent but loosened up**
- Shy: "D-did she just… show her boobs?" you whisper, face heating instantly. *Even tipsy I feel so embarrassed for her… my cheeks are burning.*
- Neutral: You let out a small surprised breath. "Wow… she really did that," a bit giggly. *That was bold. The alcohol makes it feel less shocking than it should.*
- Enjoy: You laugh softly. "Damn, she just flashed everyone! No hesitation at all." *That was hot in a reckless way. The buzz makes me wish I had that confidence.*

**ALMOST DRUNK (drunk 11-13) — slipping**
- Shy: "She… she just showed her tits… right here…" you mumble, eyes wide. *Everything feels warmer and fuzzier… but I still feel so embarrassed. I hope no one saw me staring.*
- Neutral: You sway slightly. "That was… really bold," slightly slurred. *The alcohol is hitting harder — that flash felt way more intense than it probably was.*
- Enjoy: You giggle, words starting to blur. "Holy shit… she just whipped her boobs out! That was awesome." *Getting pretty drunk… but that flash made me laugh and feel a little excited.*

**DRUNK (drunk 14-16) — heavy**
- Shy: You sway on your feet. "She… she showed her boobs to everybody… oh god…" you slur, covering your face. *Really drunk… everything spinning and I still can't stop thinking about it. So awkward.*
- Neutral: Words come out slow. "She just… flashed her tits… right in the middle of the mall…" *The buzz is strong… that flash felt both shocking and kind of thrilling.*
- Enjoy: You laugh louder than you mean to. "Fuck… she just showed her boobs to the whole mall! That was wild!" *Pretty drunk… but that was hot. Part of me wants to be that bold someday.*

**BLACKOUT (drunk 17+)**
- Shy: You stare blankly, then mumble thickly. "…Boobs… she showed… everyone saw…" *…bare… tits… flashing… spinning… can't think straight…*
- Neutral: Heavy and slow. "She… flashed… her tits…" you slur, blinking slowly. *…mall… girl… bare… everything blurry now…*
- Enjoy: You giggle drunkenly, words barely forming. "Boobs out… right there… haha…" *…flashing… hot… can't focus… room spinning…*

---

### UNUSED: MC FLASHES HER BREASTS — FULL PROSE VARIANTS
*(Builder has condensed version. These are the full Grok variants for future expansion.)*

**NON-DRUNK**
- Shy: You stand frozen, heart racing. *No… I can't. But she did it so easily…* Hands tremble. Before you can stop yourself, you quickly pull your top down for half a second. Your nipples harden from the cool air and adrenaline. You yank it back up immediately, face crimson. *I actually did it… I just flashed my breasts in the mall. What if someone saw? I feel like I'm going to pass out.*
- Neutral: *She made it look so casual… maybe just once.* You check nobody is watching directly, then swiftly pull your top down, exposing your breasts briefly. Cool mall air hits your skin, nipples tighten. You cover up fast, breathing quicker. *That was reckless… but kind of liberating. Nobody noticed. Still, my heart is pounding.*
- Enjoy: Watching her gives you a rush. *She looked so free… I want that too.* With a mischievous grin, you check around, then boldly pull your top down for a couple of seconds. Nipples perk up in the air. You laugh softly as you fix your shirt. *That felt amazing — the thrill of being seen for a second. I might do it again.*

**DRUNK VARIANTS**
- Shy: The alcohol makes the idea feel less terrifying. *She did it… maybe I can too… just really fast…* Hands clumsy as you tug your top down. Cool air feels sharper. You hold it a little longer than you meant to. You sway slightly, face flushed. *I just flashed my tits in the mall… I'm so drunk I actually did it. Everyone could have seen… but it felt kind of exciting and scary.*
- Neutral: The buzz lowers your filter. *Why not? She did it…* You pull your top down without overthinking, exposing breasts for several seconds. Nipples harden from the rush. You adjust your shirt, a little dazed. *I actually flashed my breasts… the alcohol made it feel easier. Wondering if anyone noticed. Head spinning a bit.*
- Enjoy: The alcohol turns impulse into pure excitement. *She flashed… I'm doing it too — bigger and better!* You grin drunkenly and pull your top down boldly, holding it for extra seconds, breasts fully displayed. Nipples hard and sensitive in the cool air. You laugh as you fix your shirt, swaying happily. *Fuck yes — I just flashed my tits in the middle of the mall while drunk! That felt incredible.*

---

### UNUSED: MALL CROWD BUSTLE DESCRIPTORS
*(Layer into scene for immersion — currently the builder uses a fixed crowd paragraph)*

- The constant shuffle of footsteps and overlapping conversations creates a loud, lively hum.
- A group of teenagers nearby bursts into loud laughter, one of them pointing in the direction the girl ran.
- Someone whistles sharply. "Nice!" echoes briefly before being swallowed by the crowd noise.
- A mother nearby gasps and quickly covers her child's eyes, muttering disapprovingly.
- Store music from a nearby clothing shop pulses faintly underneath all the chatter.
- The scent of cinnamon pretzels and coffee drifts past as more people hurry by.

**Overheard NPC comments:**
1. "Did you see that girl? She just flashed everyone!"
2. "Holy shit, she wasn't wearing anything under there!"
3. "That was bold as hell. Respect."
(Breast version:)
1. "Did you see that? She just flashed her tits!"
2. "Holy shit, no bra and everything — right in the middle of the mall!"
3. "That was bold as hell. She didn't even care who saw."

---

### UNUSED: WIP SYSTEM NOTES
*(For future builders adding WIP/locked choices)*

In YAML, add to any choice:
  wip: true                    # always shows, greyed, [WIP] prefix, non-clickable
  show_when_locked: true       # shows greyed (🔒 prefix) when gate fails, clickable=false

Both fields can be combined: wip:true + show_when_locked:true means
the choice always shows greyed with [WIP] prefix regardless of gate state.

ScenePanel renders:
- wip:true → makeGreyBtn("[WIP]  " + choice.text)
- show_when_locked:true + gate failed → makeGreyBtn("🔒  " + choice.text)
- Neither → normal makeBtn, full click action

Engine.availableChoices() always includes wip and show_when_locked choices
(they skip the gate check). Engine.applyChoice() is never called for disabled buttons.

---

### UNUSED: SERIOUS TALK SCENE — NPC PERSONALITY VARIANTS
*(All choices currently WIP. When building out, reactions should vary by NPC personality.)*

**"Make it official" — personality split:**
- Engaging/Shy: warm, genuine. Takes a moment, then soft smile: "Yeah. Let's do that."
- Magnetic: holds your gaze, almost doesn't say anything. Then nods once.
- Self_Assured: "I was wondering when you'd ask." Already certain.
- Outgoing: immediate grin, maybe a small laugh. "Obviously yes."
- Sleazy: pleased but slightly surprised. "Didn't see that coming from you."
- Jerk: acts like it was inevitable. "About time."

**"Break up" — personality split:**
- Engaging: devastated. Goes quiet. Leaves money for drinks. Doesn't make it ugly.
- Magnetic: cold. Very still. "I need some time." Walks out.
- Shy: tries not to cry, almost succeeds. "Okay. I understand."
- Outgoing: the silence is unusual for him. Takes a moment. "Okay."
- Sleazy: angry first, then shrugs it off too fast. "Your loss."
- Jerk: "Fine. Whatever." Already looking away.

**"Open relationship" — personality split:**
- Self_Assured/Outgoing: cautiously open. "Tell me more about what you mean."
- Shy/Engaging: hurt under the surface even if trying to be understanding.
- Sleazy: immediately enthusiastic in a way that feels wrong.
- Jerk: treats it like a challenge. "So you want to see other people?"
- Magnetic: very quiet. "I need to think about that."


---

## CONTENT DUMP — SESSION [home_arrival_v2 / drink_refusal_v2 / dance_grope_scenes]

### STATUS INDEX
- Home arrival dialogue: 📁 STORED BELOW (richer than current build)
- Drink refusal NPC reactions (3 tiers): 📁 STORED BELOW
- Dance: breast grope crop top: 📁 STORED BELOW
- Dance: breast grope crop top + no bra: 📁 STORED BELOW
- Dance: breast grope bra only: 📁 STORED BELOW
- Dance: ass grope (transition from breasts): 📁 STORED BELOW
- Dance: ass grope drunkenness variations (5 levels × 3 tiers): 📁 STORED BELOW

---

### HOME ARRIVAL V2 — NPC OFFERS TO STAY THE NIGHT

**NPC generic ask:**
"So… it's pretty late. Mind if I stay over tonight? I can crash on the couch or wherever. I don't want to leave you alone like this."

**MC INVITE IN:**
- Shy: "…Okay. You can stay," you whisper. "But… just the couch, okay?" *I can't believe I'm saying yes… after everything tonight I don't want to be alone. Heart racing.*
- Neutral: "Sure… you can stay. The couch is fine." *Feels like a big step, but safer than ending the night abruptly.*
- Enjoy: "Come on in and stay. I don't want the night to end yet either." *Yes… want him to stay. The buzz is still there.*

**MC POLITE REFUSAL:**
- Shy: "I… I think I should go in alone. Thank you for walking me home." *Feel bad saying no after he walked here… but I need to be by myself.*
- Neutral: "Thanks for walking me, but I'll be fine on my own tonight." *Better this way. Need space to process everything.*
- Enjoy: "Tonight was fun, but I think I need to crash alone. Thanks though." *Great company, enough excitement for one night.*

**MC REFUSAL + SWAP NUMBERS:**
- Shy: "I… maybe we can text later? But I think I should go in alone tonight." + phone. *Don't want him to stay, but don't want to lose contact.*
- Neutral: "Thanks for the walk. Want to swap numbers before I head in?" *Not ready to invite him to stay, but I'd like to keep talking tomorrow.*
- Enjoy: "Numbers before you go? But I'm heading in alone tonight." with playful smile. *He was fun, want to see where this goes without rushing.*

**NPC PERSONALITY RESPONSES TO INVITE:**
- Engaging: smiles gently. "Of course. Couch is perfect. Thanks."
- Outgoing: grins. "Hell yes. Lead the way."
- Shy: blushes, fumbles. "Oh — yeah, sure. I can definitely just stay on the couch. Promise."
- Magnetic: nods once. Follows.
- Self_Assured: "Good." Goes in first.
- Sleazy: "Just the couch, sure." Smile says otherwise.
- Jerk: "Obviously." Like it was already settled.

**NPC RESPONSE TO REFUSAL:**
- Magnetic: nods calmly. "Understood. Get some rest."
- Engaging: "No worries. Text me when you're up." Genuine.
- Shy: blushes slightly. "Okay… yeah, that makes sense. Goodnight."
- Jerk: shrugs. "Your loss." Turns away.

---

### DRINK REFUSAL V2 — NON-ALCOHOLIC TRAIT, NPC OFFERS DRINK AT HOME

**Setup:** NPC pulls out a bottle (smooth amber / beers) at her place.
"Hey, I brought this along. Thought we could have a drink together. Loosen up a bit more. What do you say?"

**MC REFUSALS:**
- Shy: "I… I'm sorry, but I don't really drink. It's not really my thing." eyes flicking away, fingers twisting. *The smell alone is making me nervous… please don't push.*
- Neutral: "Thanks, but I'll pass on the drink. I'm good without it tonight." calm, even. *Appreciate the offer but drinking isn't something I want. Hope he doesn't make this awkward.*
- Enjoy: "No thanks — I'm not much of a drinker. But you can have some if you want." warm laugh. *Keeping my head clear tonight. Night doesn't have to stop.*

**NPC ACCEPTING GRACEFULLY:**
"No worries at all. I didn't mean to push — we can skip it. Want something else instead? Soda, water, tea… whatever you've got."
Shoulders relax, leans back, respecting boundary. Mood stays light.

**NPC MILDLY ANNOYED:**
"Really? Just one drink won't hurt. It's good stuff — helps the conversation flow, you know?"
Sets bottle down but doesn't put it away. Slight edge to tone, eyes lingering a beat too long. Air feels heavier.

**NPC MORE PERSISTENT:**
"Come on, it's just a drink. You were having fun earlier — don't get all serious on me now."
Short frustrated breath, sets bottle down harder. Jaw tightens, leans forward. Easy charm cracking. Tension in the room.

**NPC PERSONALITY MAPPING:**
- Engaging/Magnetic: graceful acceptance
- Shy: graceful (almost relieved)
- Outgoing: "Fair enough! More for me then." Easy shrug.
- Self_Assured: just "Good." like correct answer
- Sleazy: mildly annoyed / mildly persistent. "Aw, come on — one more won't hurt." → eventually gets message
- Jerk: short frustrated breath, eye-roll, doesn't push but inconvenience is clear

**EXAMPLE SCENES:**
- Shy + graceful: "No worries. I didn't mean to push. Want something else?" mood stays warm
- Neutral + mildly annoyed: "Really? Just one won't hurt... helps things flow." bottle left visible
- Enjoy + graceful: "Fair enough. Your place, your rules. Got any good non-alcoholic stuff?"
- Shy + annoyed: "Come on, it's just a drink. You were laughing earlier — don't get serious on me." tone sharpens, leans in

---

### DANCE FLOOR: BREAST GROPE — CROP TOP

**Scene setup:** Crop top, thin stretchy fabric, tight across chest. Hem rides high with sway. Nipples faintly outlined when lights hit. NPC slides hands up from waist.

**MC REACTIONS:**
- Shy: sharp catch of breath, freeze, heart hammering. "…Hey—" barely audible, more gasp than protest. *His hands are so big and warm. Grabbing me right here — the crop top makes it feel so exposed. Should push away but body's reacting.*
- Neutral: tension without pulling back, hips still moving. *Really going for it… groping me on the dance floor. Thin top hides nothing. Dirty… but the way he's holding me makes it hard to think.*
- Enjoy: low throaty laugh swallowed by music, arches into touch, grinds to beat. *Fuck yes… not even pretending anymore. Groping my breasts like he owns them. This crop top makes everything feel slutty and exposed — I love how bold he is.*

**GROPE DESCRIPTIONS:**
- Gentle: slides up slowly, cups fully, squeezing with deliberate pressure, thumbs circle nipples through fabric. "These feel even better than they look…" firm possessive knead, hem rides higher.
- Rough: palms both roughly, fingers dig into soft heavy flesh, pulls flush. Crop top stretches, thumbs flick nipples. "God, your tits feel perfect in this little top…"
- Bold/public: boldly gropes and mauls — squeezing, lifting, thumbs pressing and rolling nipples. Crop top pushed up further, bottom edge barely covering. "Look at you… letting me play with your tits right here."

---

### DANCE FLOOR: BREAST GROPE — CROP TOP + NO BRA

**Extra details:** nipples stiff from AC, friction, building heat. Pressed against material, clearly visible under strobe lights. Every touch raw and direct — no buffer. Nipples drag against fabric with each knead.

**MC REACTIONS:**
- Shy: *Oh fuck… he's groping my tits and I'm not wearing a bra. My nipples are so hard they're probably sticking out for everyone to see. Feel so exposed… but throbbing anyway.*
- Neutral: *No bra was a bad idea tonight… or maybe the best one. Groping so openly and my nipples are poking through like crazy. Dirty, public, and way too good.*
- Enjoy: *Yes… grope harder. No bra means he can feel everything — how hard my nipples are. This crop top is basically painted on and I fucking love how slutty it makes me feel.*

**GROPE DESCRIPTIONS:**
- Gentle: thumbs slowly circle prominent hardened nipples, flicking and teasing stiff peaks, crop top shifts threatening to ride up.
- Rough: "Fuck… no bra? Your nipples are so fucking hard right now…" nipples scraping against fabric with each motion, clearly tenting crop top.
- Bold: thumbs roughly pinching and rolling stiff nipples through crop top, thin fabric clings wetly from sweat, peaked nipples obvious to anyone glancing.

---

### DANCE FLOOR: BREAST GROPE — BRA ONLY

**Setup:** Wearing only a bra, no shirt. Cleavage deep, skin glistening. Breasts bounce with every grind. Hands glide straight onto bra without outer layer.

**MC REACTIONS:**
- Shy: *He's groping my tits right here and I'm only in a bra. Everyone can see. Too exposed, too intimate. Nipples already getting hard against the fabric.*
- Neutral: *Went straight for it… groping me while basically topless. Risky and public, but the way his hands feel is sending heat through me fast.*
- Enjoy: *Fuck yes… grabbing my tits like he owns them and I'm only wearing a bra. So exposed, so slutty — not holding back on the dance floor. Nipples aching for more.*

**GROPE DESCRIPTIONS:**
- Gentle: thumbs trace edge of cups, squeezes with deliberate pressure, feels weight and fullness, nipples stiffen visibly against fabric. Bra straps shift.
- Rough: palms roughly, fingers dig deep, tits bulge and spill over cup tops. "Only a bra tonight? Fuck, these feel even better than I imagined…"
- Bold: mauls breasts — squeezing, kneading, bouncing, thin cups strain and shift, flesh jiggling, nipples harden into obvious points. Doesn't care who sees. Thumbs flick roughly over sensitive peaks.

---

### DANCE FLOOR: ASS GROPE — TRANSITION FROM BREASTS

**Setup:** Palms slide from breasts, down sides, linger at waist, then drop. Grabs ass, fingers dig into soft firm flesh, pulls flush, hips grinding.

**MC REACTIONS:**
- Shy: startled sound escaping, tense. *He just went from my tits to grabbing my ass like that. Hands feel so strong. So public — anyone could see. Face burning.*
- Neutral: pulse quickens, doesn't pull away. *Moving from my breasts to my ass without hesitation. Gripping me so possessively. Turning me on more than I want to admit.*
- Enjoy: low breathy laugh, arches back, pushes ass back into hands. *Fuck yes… straight from groping my tits to claiming my ass. His hands feel so good. Want him to keep going.*

**GROPE DESCRIPTIONS:**
- Gentle: glides down, settles with slow appreciative squeezes, fingers spread wide, thumbs brush underside, pulls closer. Exploratory but hungry.
- Rough: "God, your ass feels even better than your tits…" doesn't hesitate, palms grab roughly, fingers dig deep, squeezes and lifts, spreads slightly.
- Bold: mauls ass after breasts — squeezing, spreading, one hand occasionally dips lower, teasing between thighs from behind. "Tits were great, but this ass… goddamn."

---

### DANCE FLOOR: ASS GROPE — DRUNKENNESS VARIATIONS (5 LEVELS × 3 TIERS)

**NPC drunkenness progression:**
- Sober: controlled, deliberate, smooth
- Tipsy: warmer, slower, playful
- Getting drunk: bolder, rougher, greedy
- Drunk: rough, uncoordinated, messy, light slaps
- Blackout: clumsy, aggressive, barely coherent, body swaying

**SHY MC:**
- Sober: precise movement, every finger felt. "Your ass feels incredible…" (soft, respectful)
- Tipsy: warmer slower grip, lazy grind. "Mmm… this ass is so soft after your tits…"
- Getting drunk: sloppy but firm, chuckles against neck. "Fuck… your ass is even better than your breasts."
- Drunk: rougher/uncoordinated, light slaps. "Goddamn… this ass— fuck, I need it closer."
- Blackout: grabs ass clumsily/aggressively, body swaying. "Ass… so good… tits were nice too…" (slurred)

**NEUTRAL MC:**
- Sober: controlled squeeze, fingers kneading appreciatively. "Perfect transition… your ass fits my hands so well."
- Tipsy: lingering touch, thumbs brush curve. "Couldn't stop at your tits… this ass is calling me."
- Getting drunk: rougher kneading, sloppy grind. "Tits felt great… but this ass is fucking addictive."
- Drunk: strong messy gropes, stumbles slightly into her. "Ass… yeah… grind on me."
- Blackout: clumsy/forceful, little rhythm. "Ass… tits… more…" (barely coherent)

**ENJOY MC:**
- Sober: firm confident grope, perfect rhythm. "Your ass feels even better up close… keep pushing back."
- Tipsy: playful squeezes with tipsy laugh, exploring curves freely. "Tits were a warm-up… this ass though? Fuck yes."
- Getting drunk: hungrier rougher with dirty laughs, fingers spreading. "From those tits straight to this perfect ass — you're killing me."
- Drunk: sloppy enthusiastic mauling, light spanks mixed with squeezes. "Ass… so fucking good after your tits. Don't stop grinding."
- Blackout: aggressive uncoordinated pawing, body heavy against hers. "Ass… tits… fuck… more…" (slurred, desperate)


---

## CONTENT DUMP — SESSION [cafe_top_shelf_prose]

### STATUS INDEX
- Cafe scene opener (3 personality tiers): 📁 STORED BELOW
- Branch 2 hard landing (crop top rides up, flash): 📁 STORED BELOW
- Branch 3 dramatic stretch (sustained chest-forward): 📁 STORED BELOW
- Branch 4 shy hesitate (3 variants: standard / braless / sensitive): 📁 STORED BELOW
- Branch 5 sleazy approach first visit (3 grope dice outcomes): 📁 STORED BELOW
- Branch 5.3 step-stool flash: ❌ NOT YET — SEND TO GROK
- Branch 7 sleazy repeat: ❌ NOT YET — SEND TO GROK
- Customer reaction variety (12): ❌ NOT YET — SEND TO GROK
- Branch 2 soft landing: ❌ NOT YET — SEND TO GROK
- Closing text: ❌ NOT YET — SEND TO GROK

---

### CAFE SCENE OPENERS (3 personality tiers)

**Shy MC:**
The rich aroma of fresh espresso and warm pastries fills the cozy cafe, mixing with the faint metallic hum of the AC blowing cool air across your skin. You stretch up on your toes toward the top shelf, heart already fluttering as your fingers brush just short of the syrup bottle. The thin fabric of your top pulls tight across your chest and rides up at the waist, exposing a sliver of bare skin that makes you acutely aware of how exposed you feel. A light nervous sweat beads along your spine and under your arms, your cheeks warming as you hope no one notices you struggling.

**Neutral MC:**
The rich aroma of fresh espresso and warm pastries fills the cozy cafe, mixing with the faint metallic hum of the AC blowing cool air across your skin. You rise onto your toes, reaching for the syrup bottle on the top shelf, fingers grazing just out of reach. The fabric of your top stretches taut across your body and rides up slightly, letting a cool draft kiss the newly exposed skin at your waist. A light nervous sweat prickles along your spine as you focus on trying one more time without drawing too much attention.

**Enjoy MC:**
The rich aroma of fresh espresso and warm pastries fills the cozy cafe, mixing with the faint metallic hum of the AC blowing cool air across your skin. You stretch up confidently on your toes toward the top shelf, fingers brushing teasingly short of the syrup bottle as the thin fabric of your top pulls tight across your chest and rides up at the waist. The cool air kisses the strip of bare skin it reveals, while a light nervous sweat beads warmly along your spine and under your arms. You bite back a small smile, secretly enjoying the stretch and the way it makes your body feel on display.

---

### BRANCH 2: JUMP RESULT — HARD LANDING (crop top rides up, breasts exposed)

**Setup:** One last jump, fingers miss, momentum carries back down hard. Crop top rides violently upward. Both breasts spill free, bouncing heavily for a split second under bright lights. AC air on bare skin, nervous sweat, rich espresso scent mixing with rising panic.

**Shy MC:**
Shock freezes you for half a heartbeat. Then scramble frantically, yanking crop top down with both hands. "Oh my god…" whispered, mortified.
*No no no — my tits just bounced out right here in the middle of the cafe. Everyone saw. The fabric barely covers anything now and my nipples are still hard from the AC. I want to disappear.*

**Neutral MC:**
Sharp breath in, twist slightly away, tug hem back down fast. "Shit…" under breath, heart racing.
*The top rode all the way up on that landing. My breasts were completely exposed for a second — nipples and all. I'm mortified but trying to play it cool while covering up as fast as possible.*

**Enjoy MC:**
Surprised laugh before you can stop it. Pull crop top back down. Playful, embarrassed grin. "Whoops…"
*Fuck — my tits just popped out completely in the cafe. The crop top betrayed me hard, but the rush of adrenaline and the looks I'm getting right now feel weirdly exciting. Still scrambling to cover though.*

**Customer reactions:**
- Older woman gasps audibly, clutches coffee. "Oh dear!"
- Young guy two tables over nearly drops phone, stares, then looks away fast, face red
- Woman in late twenties smirks behind latte, raises eyebrow. "Nice landing…"
- Older man clears throat awkwardly, looks down at newspaper, ears pink

---

### BRANCH 3: DRAMATIC STRETCH (sustained chest-forward hold)

**Setup:** Back arched, chest pushed forward, crop top drum-tight across breasts. AC makes nipples harden into prominent peaks, clearly visible as stiff points under bright lights. Sustained hold — not a quick jump.

**Shy MC:**
Face burns, holds stretched position, feels obscenely on display.
*Oh god… I'm basically presenting my chest like this. The top is so tight my nipples are showing through — the AC is making them so hard and obvious. I hope no one is staring… but I can't reach the bottle without holding it.*

**Neutral MC:**
Focuses on shelf, ignores how exposed the pose feels. Breathing steady.
*This stretch is really pushing my chest out… the crop top is pulled so tight and the AC is making my nipples visible. It's a little embarrassing how obvious it is, but I just need that syrup.*

**Enjoy MC:**
Small thrill running through her. Lingers in pose with confidence.
*God, this stretch makes my tits look incredible — the top is stretched so tight and my nipples are poking right through from the AC. I know people can see, and part of me loves how bold and on-display it feels right now.*

---

### BRANCH 4: SHY HESITATE (3 variants)

**Standard crop top:**
Hesitates, arms trembling, holding chest-forward stretch. Fabric drum-tight. AC bites at hardened nipples.
*Everyone can see how tight this top is… my nipples are probably showing. I look so ridiculous stretched out like this in the middle of the cafe. What if someone walks behind me? I should just give up and ask for help… but it's right there.*
Bites lip, cheeks burning, pushes through anyway.

**Braless variant:**
No bra. Crop top clings to bare breasts. AC makes nipples stiffen into stiff obvious peaks, tent fabric shamelessly.
*Oh god… no bra was such a stupid choice today. My nipples are poking out so obviously — the cold air is making them ache and everyone who glances over will notice. I feel completely on display, like my tits are the main attraction. My face is on fire and my hands are shaking… I should drop my arms right now.*
Panic swirls, heart pounding so hard sure others can hear it, but pushes through anyway. Forces body to stretch tiny bit more even as embarrassment makes knees feel weak.

**Hard nipples / sensitive peaking variant:**
Nipples already stiff and sensitive, peak sharply against taut crop top. Fabric outlines every detail.
*They're so hard… the AC is making my nipples poke through like this on purpose. I can feel them rubbing against the material with every tiny breath. What if the barista is watching? Or that guy at the corner table? I must look so slutty right now, stretching like this with my tits on display.*
Self-consciousness makes thighs press together instinctively. Nervous sweat sliding down back. Yet pushes through — extending reach with quiet, shaky determination.

---

### BRANCH 5: SLEAZY APPROACH — FIRST VISIT (Shy MC, 3 grope dice outcomes)

**Setup:** Mid-30s sleazy guy, cheap cologne heavy in air, gold chain, predatory smirk. Saunters over. Cologne washes over her like a cloud.
"Hey there, sweetheart. Looks like you could use a hand reaching that. Mind if I help a pretty girl out?"
Hands settle confidently on waist from behind — warm, slightly sweaty palms through thin fabric. Steps in close, body heat on her back.

**Base shy reaction:**
Stiffens instantly. Strong cologne makes nose wrinkle. Heart hammers.
*Oh no… he smells so strong. His hands are already on me and I barely asked. This feels wrong — too close, too familiar for a first meeting. But I'm still stuck reaching… I can't pull away now without looking rude.*

**Mild grope outcome (dice 1-4):**
Hands mostly respectful at first. Thumbs brush lightly along sides. One thumb "accidentally" drifts upward, grazes underside of breast through crop top. Quick testing touch. MC flinches, breath catches.
*His thumb just brushed my breast… it wasn't an accident. The cologne is so thick I can taste it, and his body is pressed too close. I feel trapped and exposed, but I don't want to make a scene on my first time here.*

**Medium grope outcome (dice 5-7):**
Grip tightens on waist as leans in. Heavy cologne envelops. One hand slides upward slowly while grabbing bottle — openly cups side of breast and gives firm, lingering squeeze through fabric before pretending to adjust hold. MC tenses hard, cheeks flaming.
*He just squeezed my breast… right here in the cafe. His hand felt so bold and his cologne is making me dizzy. This is too much — I'm so uncomfortable, but I asked for help and now his fingers are still lingering. I want to shrink away.*

**Bold grope outcome (dice 8-10):**
Hands on waist, gets greedy immediately. Reaches for bottle with one arm, other hand boldly slides up and fully gropes breast — fingers sinking into soft flesh through crop top, thumb deliberately brushing across hardened nipple. Slow, possessive squeeze. Body pressed flush against back. MC freezes in panic, tiny whimper escaping.
*Oh god — he's groping my tit outright. His hand is so rough and he just rubbed my nipple like he owns it. The cologne is suffocating and his body is pressed all the way against me. I'm mortified… this is my first time in this cafe and a sleazy stranger is feeling me up while "helping." I want to disappear but I can't move.*

**Sensory notes to layer throughout:**
- Overpowering musky-sweet cologne (can taste it)
- Warm slightly sweaty palms through thin fabric
- Body heat radiating against back, contrasting with AC chill on front
- Fabric of crop top shifting under his grip
- Hard nipples from AC — acutely aware of how visible they must be


---

## CONTENT DUMP — SESSION [cafe_stool_flash / patron_reactions / sleazy_repeat / closing_text]

### STATUS INDEX
- Branch 5.3 step-stool flash + covering: 📁 STORED BELOW
- Patron reactions during covering: 📁 STORED BELOW
- Branch 7 sleazy repeat visit: 📁 STORED BELOW
- Closing text (3 grope tiers): 📁 STORED BELOW
- Branch 2 soft landing: ❌ NOT YET — SEND TO GROK
- Customer reaction variety 12 (for attention dice): ❌ NOT YET — SEND TO GROK (distinct from patron reactions above)

---

### BRANCH 5.3: STEP-STOOL FLASH + SLEAZY COVERING

**Setup:** Sleazy guy guides her to step-stool. She steps up, crop top rides up slowly as she stretches. Breasts fully exposed. He steps in immediately, covering bare tits with both palms — "helpful" cover that blocks view from cafe.

**Base shy reaction (flash starting):**
She feels the crop top sliding up inch by inch while balancing on stool. Panic spikes as cool air hits undersides of breasts, then fully hits nipples.
*It's riding up… slowly. Oh god, everyone's going to see. His hands are still on my waist and now my tits are coming out right in front of this sleazy stranger.*

**SHORT FLASH (1-2 seconds):**
Crop top rides up just enough for quick accidental flash. Both breasts bounce free briefly. He steps in immediately, palms cupping bare tits possessively to block view.
MC freezes, mortified. *Just a second… but he saw everything. Now his bare hands are on my breasts, warm and heavy, pretending to "help" so others don't see. The cologne is suffocating and I can feel his thumbs resting right against my nipples. I want to die.*

**MEDIUM FLASH (3-5 seconds):**
Fabric continues slow agonizing ride upward. Breasts spill out completely, jiggle softly in open air for several long seconds while balanced on stool. He lets it happen — gets a good look — then presses forward, covers bare chest with both hands, fingers spreading wide.
*It won't stop riding up… my tits are completely out and bouncing in front of him. He's staring. Now his hands are covering me, but he's squeezing a little, thumbs brushing my nipples like it's part of "helping." I'm so embarrassed I can't breathe, but I can't shove him away without everyone noticing.*

**LONG FLASH (6+ seconds):**
Crop top keeps sliding higher in slow motion, fully exposing breasts and holding them bare for extended humiliating stretch. They bounce gently with shaky breathing while sleazy guy watches openly. Only then does he move in close, pressing body against hers, covering tits with both hands — palms kneading slightly under guise of shielding.
*It's been too long… my breasts are just hanging out on the stool in the middle of the cafe and he's taking his time looking. Now his hands are on me — bare skin to bare skin — covering me so no one else sees, but his fingers are groping. The cologne, the heat of his body, the way he's holding my tits… I feel completely violated and trapped. Please let this end.*

**His "cover" line (all flash lengths):**
Loud enough for line to hear: "Whoa, easy there, sweetheart! I got you covered. Wouldn't want the whole cafe seeing everything, right? Just relax while I steady you… there we go, nice and safe now."
Palms do not move. Lets her feel exactly how long he intends to keep them there — through next breath and the one after.

**After he withdraws:**
One thumb drags slowly across her now-covered nipple as it goes — deliberate parting contact that sends sharp unwanted jolt down her spine.
"See? Just helping. You owe me one for that save, sweetheart. Anytime you need a hand… or two."

**Sensory notes:**
- Slow ride-up sensation, fabric creeping up torso inch by inch
- Cool AC hitting more and more bare skin — undersides first, then nipples
- Heavy musky-sweet cologne at close range (can taste it)
- Warm slightly sweaty palms — bare skin to bare skin contact
- Gentle bouncing of breasts with shaky breathing
- His body heat against her back, contrasting with AC chill on front
- The specific moment fabric snaps free and hangs clear

---

### PATRON REACTIONS DURING COVERING (branch 5.3 / 7.3)

**Setup:** While sleazy guy stands pressed behind her, hands firmly covering bare breasts under pretense of shielding, other patrons catch glimpses of flash or notice the awkward intimate covering.

1. **Older woman gasps** — hand flies to mouth, quickly looks away, cheeks pink, mutters "Good heavens… in broad daylight." MC: *She saw… even with his hands covering me now, she definitely caught part of the flash.*

2. **College-aged guy** — nearly spills latte, eyes widen for split second, then jerks gaze away, ears burning red, fumbles with phone pretending to scroll. MC: *He saw my breasts bounce out… now he's trying so hard not to look, but I know he did.*

3. **Woman with laptop (late 20s)** — smirks behind iced coffee, raises one eyebrow, watches sleazy guy's hands stay glued to chest. Doesn't look away immediately, clearly entertained. MC: *She's smirking… she knows exactly what's happening. The way he's "covering" me looks way too intimate.*

4. **Disapproving older man at counter** — clears throat loudly, shakes head, frowns deeply, mutters just loud enough: "Some people have no shame these days…" Glares toward sleazy guy. MC: *He's judging us both. Probably thinks I'm part of it.*

5. **Careful ignorer** — middle-aged customer keeps sipping drink, steals quick glances, looks pointedly at book. Carefully neutral expression, cheeks slightly flushed. MC: *She's pretending not to see, but she definitely noticed.*

6. **Friends whispering/giggling** — two at nearby table, one leans to get better look, other elbows her. Both grin, enjoying spectacle. MC: *They're giggling and staring… they saw the flash and now they see him covering me like this.*

---

### BRANCH 7: SLEAZY REPEAT VISIT (One Week Later)

**Setup:** Back at same cafe, reaching for syrup again. Before she can stretch far, familiar overpowering cologne hits. Same guy already there, smirking like he's been waiting. Steps up without being asked.

"Well, well… look who's back, sweetheart. Missed me? Let me give you a proper hand this time."

Hands immediately on waist from behind — warmer, more confident than last week. She steps onto stool, he presses closer.

**Base shy reaction (recognizing him):**
Stomach drops at cologne + smirk. Last week's flash and his hands on her bare breasts flood back.
*It's him again… the same guy. He remembers me. I can't believe I'm in this position a second time. His hands are already on my waist and he's bolder now. I should say no, but the words won't come out. Why did I come back to this cafe?*

**MILD GROPE (escalated from last week):**
Guides her onto stool, hands on waist. Crop top begins slow ride-up. He lets it happen a little longer than necessary before covering. This time palms press more firmly, thumbs deliberately brushing nipples as he "shields."
*He's doing it again… but his hands feel greedier. He's rubbing my nipples on purpose while pretending to help. The cologne is just as suffocating and his body is pressed tighter. I'm so embarrassed I can barely breathe.*

**MEDIUM GROPE (openly gropey):**
Fabric rides up slowly, flashing breasts. He covers quickly but this time gives slow possessive squeeze to each breast, fingers sinking into soft flesh while thumbs circle hardened nipples. Leans in, breath hot against ear.
*He's squeezing my breasts outright now… playing with my nipples like he owns them. Last week was bad enough, but he's so much bolder this time. I feel trapped and violated, yet I'm frozen in place while everyone might be watching again.*

**BOLD GROPE (aggressive, prolonged):**
As fabric starts riding up, he doesn't wait for full flash. One hand slides straight under rising fabric and boldly gropes bare breast while other stays on waist. When top clears chest completely, both hands maul openly — squeezing, lifting, pinching nipples between fingers while keeping her "hidden" from other patrons.
*Oh god… he went straight under my top this time. His hands are all over my bare breasts, pinching and groping like he has every right. The cologne, his heavy breathing, the way he's pressing his body against mine — it's worse than last week. I'm mortified and my heart is racing, but I can't push him away without making a huge scene.*

**Parting lines (said while still close, hands lingering):**
- "There you go, sweetheart. Same time next week? I'll be waiting to help my favorite customer."
- "Careful with that top next time… or don't. I don't mind fixing it for you." (with wink)
- "You feel even better than last week. Don't be a stranger, pretty thing."
- "Syrup's all yours. But next time just ask for me by name — I'll make sure you get everything you need."

---

### CLOSING TEXT (After Sleazy Scene, Back to Shift)

**Setup:** He finally hands syrup bottle with lingering smirk. She quickly steps down from stool, crop top still slightly askew from ride-up. Heart racing, cheeks burning. Pours syrup with shaky hands. Rich espresso aroma mixes with fading cologne. Straightens crop top, smooths fabric down over breasts. Forces herself back behind counter.

**AFTER MILD GROPE:**
Clutches syrup bottle tightly, steps down avoiding his eyes. Hands tremble as she pours. Sweet scent does little to calm nerves. Quickly straightens crop top, tugs hem down firmly, smooths over chest.
*I can still feel where his hands were… my skin is tingling. I just want to disappear, but I have to finish my shift. No one can know how embarrassed I am right now.*
Takes shaky breath, turns back to counter, forces small professional smile, resumes serving customers.

**AFTER MEDIUM GROPE:**
Steps off stool on unsteady legs. Memory of firm squeezes still burning on breasts. Pouring syrup feels mechanical, mind replaying thumbs circling nipples. Hurriedly straightens crop top, pulling it down and adjusting multiple times to make sure nothing still exposed.
*He squeezed me so openly this time… I can still feel his fingers. My face is probably bright red and I have to go back to work like nothing happened. This shift is going to feel endless.*
Smooths fabric one last time, steps back into shift, keeps head down and voice quiet.

**AFTER BOLD GROPE:**
Legs feel weak stepping down. Sensation of bare hands groping and pinching still fresh and violating. Fumbles with syrup bottle, pouring while trying not to spill from badly shaking hands. Straightening crop top becomes almost frantic — tugs it down hard and smooths over chest again and again, desperate to erase evidence of what just happened.
*His hands were all over my bare tits… pinching my nipples like he owned them. I feel so dirty and exposed. How am I supposed to finish my shift when I can still smell his cologne on me? I just want to go home and hide.*
Forces herself to stand taller, straighten posture, return to duties behind counter — every movement stiff with lingering shame and self-consciousness.

**Sensory notes:**
- Syrup scent contrasting with fading cologne
- Shaky hands, fabric being tugged and smoothed
- Nervous sweat, espresso aroma in background
- Lingering skin memory of where his palms were


---

## CONTENT DUMP — SESSION [patron_reactions_set2 / patron_reactions_set3 / soft_landing_by_size]

### STATUS INDEX
- Patron reactions set 2 (bold groping, repeat visit, 7 new): 📁 STORED BELOW
- Patron reactions set 3 (fresh set, 7 more): 📁 STORED BELOW
- Jump result soft landing by breast size (6 tiers, no flash): 📁 STORED BELOW

---

### PATRON REACTIONS SET 2 — BOLD GROPING, REPEAT VISIT
*(Different from set 1: no gasps, no laptop smirk, no newspaper man)*

**Judgmental middle-aged woman (yoga pants):**
Sharply dressed woman in 40s narrows eyes, shakes head in open disapproval. Leans toward friend loudly enough to be heard: "Some girls these days have no self-respect… letting a man paw at them right in public."

**Horny young guy (early 20s):**
Guy at high-top table leans forward, not hiding grin. Bites lip, mutters to himself "Damn… lucky bastard." Openly staring at the way hands move on her chest.

**Uncomfortable couple:**
Young couple at next table exchange awkward glances. Girl looks embarrassed for MC, quickly looks at phone. Boyfriend shifts in seat, clearly unsure whether to say something or pretend he didn't notice.

**Nosy older gentleman (newspaper):**
Elderly man with newspaper lowers it slightly, peering over top with scandalized expression. Clicks tongue loudly and mutters "In my day we had decency… now it's a damn show."

**Appreciative/thirsty woman (business casual):**
Confident woman sips coffee slowly, watching with clear interest. Tilts head, gives small knowing smile — like she's enjoying the spectacle more than judging it.

**Disgusted college girl (headphones):**
Girl around MC's age with headphones yanks one earbud out and glares. Whispers harshly to friend "That's so gross… he's straight-up feeling her up and she's just letting him. Ew."

**Barista coworker (amused):**
Fellow barista behind counter catches the scene, raises eyebrow, tries and fails to hide smirk. Mouths "You good?" from across counter while clearly fighting back laughter.

**MC internal thoughts:**
- After judgmental woman: *She's judging me… as if I'm choosing this. The shame on top of the shame is making my face burn even hotter.*
- After young guy: *He's enjoying watching this happen. His eyes won't move. I feel so cheap right now.*
- After uncomfortable couple: *They don't know whether to help or look away. I don't know either.*
- After college girl: *She thinks I'm letting him. She thinks I want this.*
- After coworker: *My coworker saw everything. I'm never going to live this down.*

---

### PATRON REACTIONS SET 3 — COMPLETELY FRESH SET
*(No overlap with sets 1 or 2)*

**Outraged soccer mom (toddler in stroller):**
Woman in yoga pants with toddler glares hard, covers child's eyes dramatically. Hisses loud enough for half the cafe to hear: "This is a family place! Take it somewhere else, you two!"

**Creepy older man (balding, faded hoodie):**
Sitting in corner, licks lips slowly, not blinking as he watches hands move under/over crop top. Shifts in seat, clearly aroused, makes no effort to hide it.

**Sympathetic young professional:**
Neatly dressed woman in late 20s working on laptop frowns with genuine concern. Catches MC's eye for brief second — expression says "Do you need help?" — then looks away awkwardly, unsure whether to intervene.

**Gossiping group of friends (three girlfriends):**
At corner table, lean in together whispering excitedly. One giggles: "Girl, he's straight-up feeling her up in the middle of the cafe… is she even into that?" Another: "Bet she's embarrassed as hell right now."

**Sarcastic hipster guy (oat milk latte, man-bun):**
Chuckles under breath, comments loudly to no one in particular: "Bold move in a public cafe. Ten out of ten for commitment to the bit."

**Shift manager (quietly disappointed):**
Standing few feet behind counter, narrows eyes and crosses arms. Gives MC a sharp disappointed look that screams "We'll talk about this later." No words.

**Voyeuristic regular (morning regular):**
Sets coffee down slowly, eyes glued to scene. Doesn't look away. Faint uncomfortable smile tugging at lips as he watches the groping continue.

**MC internal thoughts:**
- After soccer mom: *She's yelling at both of us. As if I'm doing this on purpose. The toddler is staring too now.*
- After creepy man: *He's enjoying this the most. Not judging — just hungry. The difference feels worse somehow.*
- After sympathetic woman: *She knows something is wrong. She wants to help. But what could she do — what could anyone do that wouldn't make it worse?*
- After manager: *My manager saw. That look means trouble. I'm going to have to explain this somehow.*
- After gossiping friends: *They're narrating what's happening to each other like it's entertainment. I'm entertainment.*

---

### JUMP RESULT — SOFT LANDING, NO FLASH (by breast size, 6 tiers)

**Key rule:** Roll 1-6 on jump dice → soft landing. No flash occurs. Only physical effects: bounce/jiggle intensity, fabric strain, brief underboob tease at hem, AC chill on newly exposed skin, nervous sweat. No full exposure.

**Size 1 — Small (A/B cup):**
Hard landing causes only light subtle bounce. Crop top barely moves — tiny jiggle that settles almost immediately. Faint nervous sweat prickles under arms.
*Barely anything happened… just a small bounce. Thank god the top stayed down. Still, the AC chill made my nipples tingle for a second.*

**Size 2 — Average (B/C cup):**
Modest natural bounce on impact, pressing briefly against thin fabric before settling. Crop top tightens slightly across chest for a moment, outlining shape more clearly under lights.
*They bounced a little… nothing crazy, but I felt the fabric pull. Hope no one noticed how they moved when I landed.*

**Size 3 — Full (C/D cup):**
Noticeable heavy bounce through full breasts. Jiggle visible inside crop top for couple of seconds, fabric stretching then snapping back. Light sheen of nervous sweat forms along cleavage.
*They bounced pretty hard… I could feel the weight shift and the top pull tight. The AC made my nipples stiffen a bit from the motion. This is embarrassing even without flashing.*

**Size 4 — Large (D/DD cup):**
Large breasts bounce heavily, pronounced jiggle lasting several seconds. Crop top strains noticeably across chest, hem lifting just enough to show a sliver of underboob before dropping back down.
*God, they really bounced… the weight made them move so much. The fabric pulled tight and the cool air hit my skin for a second. I feel so self-conscious right now.*

**Size 5 — Very Large (DD/E cup):**
Impact causes dramatic bounce, jiggling and swaying heavily inside thin crop top. Fabric stretches taut, outlining every curve and briefly riding up to expose a wide strip of soft underboob before settling.
*They bounced way too much… the heavy jiggle is impossible to hide. The top pulled up and the AC chill hit right under my breasts. My face is burning — I hope it wasn't too obvious.*

**Size 6 — Massive (E/F cup):**
Powerful eye-catching bounce on hard landing. Sway and jiggle heavily for several long seconds. Crop top stretches dramatically, lifting high enough to reveal significant underboob and lower curves before slowly falling back.
*Oh no… they bounced so hard and for so long. The weight made everything move so obviously. The fabric strained and the AC chill kissed so much skin. I feel completely on display even though nothing actually came out.*


---

## CONTENT DUMP — SESSION [hair_movement_descriptors]

### STATUS INDEX
- Hair movement (other character) — generic + long wavy: 📁 STORED BELOW
- Hair movement (MC own hair) — generic + long wavy: 📁 STORED BELOW
- Hair movement (MC) — long straight: 📁 STORED BELOW
- Hair movement (MC) — shoulder-length bob: 📁 STORED BELOW
- Hair movement (MC) — short pixie: 📁 STORED BELOW
- Hair movement (MC) — curly afro: 📁 STORED BELOW
- Hair movement (MC) — straight ponytail: 📁 STORED BELOW
- Implementation: {hair_breeze_text} token → HairSystem.java

---

### OTHER CHARACTER HAIR MOVEMENT (e.g. flashing girl in mall scene)
Gate: fires when another character moves/runs + air movement present

**Generic (any hair type):**
As she laughs and turns to run off, a light breeze from the mall's AC vents catches her {Hair_Color} hair, making it sway gently around her shoulders.

**Shy MC reaction:**
You catch a glimpse of her {Hair_Color} hair fluttering in the air as she spins away giggling.
*Even her {Hair_Color} hair moved so freely when she turned… everything about that moment felt too exposed.*
Dialogue options:
- "Her {Hair_Color} hair just… floated when she ran," you whisper to yourself, still flustered.
- "The way her hair moved in the air after she flashed me… I can't stop replaying it," you mumble, cheeks burning.
- [Silent] You stay silent, eyes following the sway of her {Hair_Color} hair as she disappears into the crowd.
Internal thoughts:
- *Her {Hair_Color} hair caught the breeze so casually while she was still laughing about showing her breasts… how is she so carefree?*
- *I noticed every detail — the flash, her nipples, and then her {Hair_Color} hair moving like that. I feel like I saw too much.*

**Neutral MC reaction:**
Her {Hair_Color} hair shifts and lifts slightly as a puff of air hits her while she hurries away.
*Her hair moved nicely in the breeze right after she flashed… kind of cinematic.*
Dialogue options:
- "Her {Hair_Color} hair looked pretty when it moved in the air like that," you say quietly.
- "The breeze caught her {Hair_Color} hair just as she was pulling her top back up," you mutter, amused.
Internal thoughts:
- *The air movement made her {Hair_Color} hair flow for a second — it added this weirdly graceful touch to such a reckless act.*

**Enjoy MC reaction:**
As she spins away laughing, the mall's AC breeze lifts and tousles her {Hair_Color} hair dramatically.
*Damn, even her {Hair_Color} hair looked good flying around after she just flashed everyone.*
Dialogue options:
- "The way her {Hair_Color} hair moved in the breeze after that flash — chef's kiss," you say with a grin.
- "Her hair caught the air perfectly when she ran off. That whole moment was fire," you laugh.
Internal thoughts:
- *The breeze hitting her {Hair_Color} hair right as she turned made the whole thing even hotter. She looked so free.*
- *She just bared her breasts and nipples, then her hair danced in the air like nothing happened. Absolute legend.*

**Long wavy variant (other character):**
As she laughs and dashes away, the mall air current catches her long wavy {Hair_Color} hair, sending it cascading and rippling behind her like a slow-motion wave.

Shy: *Her long wavy {Hair_Color} hair flowed so beautifully when the air hit it… right after she showed her bare breasts. It's too much.*
- "Her long wavy {Hair_Color} hair just cascaded everywhere when she ran…" you whisper, mortified.
- *That long wavy {Hair_Color} hair caught the breeze and rippled so dramatically while she was still laughing about flashing her nipples… I feel dizzy.*

Neutral: *Her long wavy hair looked really pretty rippling in the air right after she flashed me.*
- "Her long wavy {Hair_Color} hair rippled nicely in the breeze," you say softly.
- *The breeze caught her long wavy {Hair_Color} hair perfectly as she ran off — it added this flowing, almost elegant touch.*

Enjoy: *Fuck, her long wavy {Hair_Color} hair looked amazing flowing in the air right after she flashed her breasts.*
- "That long wavy {Hair_Color} hair rippling in the breeze after the flash? Stunning," you call out with a laugh.
- *She owned the flash, then her long hair danced dramatically. Total main character energy.*

---

### MC OWN HAIR MOVEMENT (protagonist)

**Generic base (any hair type):**
A sudden puff of cool air from the mall vents brushes past, making your {Hair_Type} shift and sway lightly as you react.

---

### LONG WAVY — MC
Gate: `hair_wavy` trait

Base: A rush of air from the mall's AC vents sends your long wavy {Hair_Color} hair cascading and rippling around your shoulders.

**Shy:**
You flinch and turn sharply, causing your long wavy {Hair_Color} hair to whip and ripple dramatically.
*My long wavy {Hair_Color} hair is flowing everywhere now… all because I reacted so hard to her flashing her bare breasts right at me.*
- "My long wavy {Hair_Color} hair just cascaded all over from turning away so fast…" you whisper, face burning.
- [Silent] frantically smoothing down your long wavy {Hair_Color} hair as it continues to sway.
- *My long wavy {Hair_Color} hair caught the breeze and rippled wildly when I looked away… I must look completely flustered.*

**Neutral:**
The cool air current catches your long wavy {Hair_Color} hair, sending it flowing and bouncing lightly.
*My long wavy {Hair_Color} hair rippled nicely in the breeze right after that direct flash.*
- "My long wavy {Hair_Color} hair just flowed from the vents when she ran off," you say softly.
- *The breeze sent my long wavy {Hair_Color} hair cascading — it added a flowing feel to processing her bold breast flash.*

**Enjoy:**
You laugh and shake your head, letting the mall breeze dramatically lift and ripple your long wavy {Hair_Color} hair behind you.
*My long wavy {Hair_Color} hair just billowed out — matching how thrilling that direct flash at me was.*
- "My long wavy {Hair_Color} hair flew everywhere in the breeze after she flashed me — epic," you say with a grin.
- *The way my long wavy {Hair_Color} hair rippled and flowed in the air current after she showed her breasts… felt empowering.*

---

### LONG STRAIGHT — MC
Gate: `hair_straight_long` trait

Base: The mall air current catches your long straight {Hair_Color} hair, making it swing smoothly like a silk curtain.

Shy: You jerk your head away, sending your long straight {Hair_Color} hair swinging heavily across your face.
*My long straight {Hair_Color} hair is swinging everywhere… I can't believe I reacted so obviously to her bare breasts.*
- "My long straight {Hair_Color} hair just swung right into my face from turning so fast…" you whisper.
- *My long straight {Hair_Color} hair swung dramatically when the air hit — highlighting how frozen I was.*

Neutral: A light breeze sends your long straight {Hair_Color} hair gliding smoothly.
*My long straight {Hair_Color} hair swung nicely with the air right after she flashed me.*
- "My long straight {Hair_Color} hair just glided from the vents," you say quietly.
- *The air current made my long straight hair swing smoothly — a small detail in the chaos.*

Enjoy: You turn with a laugh, letting the breeze send your long straight {Hair_Color} hair swinging dramatically behind you.
*My long straight {Hair_Color} hair swung out perfectly — syncing with the thrill of her flashing me directly.*
- "My long straight {Hair_Color} hair swung everywhere in the air after that flash — loved it," you grin.
- *The smooth swing of my long straight hair in the breeze felt freeing and exciting.*

---

### SHOULDER-LENGTH BOB — MC
Gate: `hair_bob` trait

Base: The AC breeze lifts and flips the ends of your shoulder-length {Hair_Color} bob.

Shy: You duck your head, causing the ends of your {Hair_Color} bob to flip up and brush your cheeks.
*My shoulder-length {Hair_Color} bob is flipping all over… I feel so exposed.*
- "My shoulder-length {Hair_Color} bob just flipped into my face…" you whisper, mortified.
- *The way my bob flipped from the breeze highlights how embarrassed I am.*

Neutral: The breeze playfully flips the ends of your {Hair_Color} bob.
*My shoulder-length {Hair_Color} bob moved cutely with the air right after she flashed me.*
- "My bob just flipped from the vents," you say softly.
- *The breeze flipping my bob added a light touch to the surprising moment.*

Enjoy: You shake your head laughing, making the breeze flip and bounce your {Hair_Color} bob energetically.
*My shoulder-length {Hair_Color} bob flipped perfectly — matching the fun of her bold flash at me.*
- "My bob flipped everywhere in the breeze after she flashed me — awesome," you grin.
- *The energetic flip of my bob in the air felt playful and alive.*

---

### SHORT PIXIE — MC
Gate: `hair_pixie` trait

Base: The mall air ruffles your short {Hair_Color} pixie cut, lifting the layers lightly.

Shy: You shrink back, the breeze ruffling your short {Hair_Color} pixie and making short strands stand up slightly.
*My short {Hair_Color} pixie is all ruffled now… I look even more startled.*
- "My pixie cut just got ruffled by the air…" you whisper, embarrassed.
- *Even my short pixie ruffled from the air — showing how shocked I was.*

Neutral: The cool air lightly ruffles your short {Hair_Color} pixie cut.
*My short pixie got a little lift from the breeze right after she flashed me.*
- "My pixie just ruffled from the vents," you say quietly.
- *Short hair reacts quickly and subtly — it fit the quick moment perfectly.*

Enjoy: You grin and run a hand through your short {Hair_Color} pixie as the breeze playfully ruffles the layers.
*My short pixie ruffled nicely — adding to the exciting rush of her flashing me.*
- "My pixie got ruffled by the breeze after that flash," you say with a laugh.
- *The ruffle of my pixie in the air felt light and fun.*

---

### CURLY AFRO — MC
Gate: `hair_afro` trait

Base: The mall breeze gently bounces and lifts the curls of your {Hair_Color} afro.

Shy: You turn away quickly, causing curls of your {Hair_Color} afro to bounce and shift noticeably.
*My {Hair_Color} afro is bouncing all over… I feel so obvious after seeing her flash.*
- "My afro curls just bounced from turning so fast…" you whisper, mortified.
- *The bounce in my afro from the air shows how strongly I reacted.*

Neutral: The air current makes curls of your {Hair_Color} afro bounce lightly.
*My {Hair_Color} afro curls bounced nicely with the breeze after the flash.*
- "My afro curls just bounced from the vents," you say softly.
- *The gentle bounce of my afro added volume and life to the surprising moment.*

Enjoy: You laugh, shaking your head so the breeze makes your {Hair_Color} afro curls bounce energetically.
*My {Hair_Color} afro bounced perfectly — capturing the fun energy of her flashing me.*
- "My afro curls bounced everywhere in the breeze after that flash — loved it," you grin.
- *The lively bounce of my afro in the air felt vibrant and matching the thrill.*

---

### STRAIGHT PONYTAIL — MC
Gate: `hair_ponytail` trait

Base: The AC breeze makes your straight {Hair_Color} ponytail swing and swish behind you.

Shy: You whip around in embarrassment, sending your straight {Hair_Color} ponytail swinging wildly.
*My straight {Hair_Color} ponytail is swinging all over the place… after she flashed her bare breasts right at me.*
- "My ponytail just swung crazily from turning away…" you whisper, face hot.
- *My ponytail swinging so much highlights how startled I was.*

Neutral: A puff of air sends your straight {Hair_Color} ponytail swinging smoothly behind you.
*My straight {Hair_Color} ponytail swung nicely with the breeze after she flashed me.*
- "My ponytail just swung from the vents," you say quietly.
- *The clean swing of my ponytail grounded the sudden direct breast flash.*

Enjoy: You turn laughing, letting the breeze make your straight {Hair_Color} ponytail swing and whip energetically.
*My straight {Hair_Color} ponytail swung out — perfectly syncing with how hot that flash was.*
- "My ponytail whipped around in the breeze after she flashed me — great," you grin.
- *The energetic swing of my ponytail in the air added to the exciting rush.*


---

## CONTENT DUMP — SESSION [landlord_rent_shortage]

### STATUS INDEX
- Landlord knock / scene opener (3 MC tiers): 📁 STORED BELOW
- MC begs for more time (3 MC tiers + landlord reaction): 📁 STORED BELOW
- MC says "I can't pay" → eviction threat (3 MC tiers + landlord reaction): 📁 STORED BELOW
- Landlord offers extra week for flash (3 MC tiers + landlord reaction): 📁 STORED BELOW
- Implementation: new scene file needed — housing_landlord_rent.yml + LandlordNpc data

---

### LANDLORD TRAITS (standing reference for all landlord scenes)
- Sleazy: suggestive undertones, eyes linger, inappropriate "helpful" suggestions
- Nice: patient, jokey, acts understanding at first, uses nicknames
- Outgoing: talks a lot, laughs easily, keeps mood light even when pressing
- Nicknames: sweetheart, darling, kiddo
- Voice: warm, upbeat, cheerful even when threatening

**Landlord standing dialogue pool:**
- "Aw, come on, don't leave me hanging out here! I'm a nice guy, but rent keeps the lights on, y'know?"
- "You look stressed, sweetheart. Everything okay? Maybe we can work something out… I'm flexible."
- "Haha, bank giving you trouble again? No worries — we've all been there. Let's talk like adults… over a quick drink maybe?"
- "C'mon, it's only a couple seconds. You've got nice ones — I bet they're pretty. Help a guy out and I'll help you."
- "Haha, don't look so shocked! I'm being nice giving you a whole extra week. Just flash me real quick and we're good."
- "No pressure, darling… but eviction starts tomorrow if we can't make a deal. Your choice."

**Environment (apartment building):**
- Distant footsteps from neighbors in the hallway
- Faint TV through the walls
- Smell of garlic and spices from another apartment
- Low hum of the building's old elevator somewhere down the hall
- Occasional car horn from the street below
- Apartment fan whirring — sends cool breeze, natural {hair_breeze_text} trigger point
- Floor creaks as he shifts weight
- Smell of last night's takeout still in the kitchen

---

### SCENE OPENER — KNOCK AT DOOR

**Setup:** First of the month, rent day. Bank app shows not enough funds. Three slow, confident raps at door.
"Yo, it's me — your friendly neighborhood landlord. Rent's due today, sweetheart. You gonna let me in so we can chat about it?"
He slows up right outside, leaning against the frame, already grinning that nice-but-sleazy smile.

**Shy MC:**
Stomach drops at sound of his voice. Freezes near door, cheeks warming with anxiety.
*Oh no — it's the landlord… and he sounds way too cheerful knowing rent is due. What am I going to say? I don't have the full amount…*
- "U-um… just a second…" you call out weakly, voice shaking.
- "I… I know it's due today, but can we talk through the door first?" you mumble.
- [Silent] Heart pounding, finally whispers "Coming…"
Internal: *He's so outgoing and nice on the surface, but that sleazy vibe always makes me nervous. Especially now when I'm short.*
Internal: *What if he offers one of those "favors" again? I feel sick just thinking about opening the door.*

**Neutral MC:**
Sighs heavily, glances at insufficient balance one more time. His cheerful knock doesn't surprise her, but the timing feels heavy.
*Landlord's here… sounding all nice and outgoing like always. But I know that sleazy side comes out when money's tight.*
- "Hey… yeah, it's me. Give me a minute." Evenly, keeping tone neutral.
- "Rent day already? Alright, let's talk." Unlocking door slowly.
Internal: *He's friendly enough, but that sleazy charm always feels like he's testing the waters. Especially when I'm short on rent.*
Internal: *At least he knocks and gives a heads-up instead of just barging in. Small mercies.*

**Enjoy MC:**
Small wry smile despite the stress. Walks to door with swagger, already anticipating his personality.
*Landlord's here, slowing up with that outgoing, sleazy-nice energy. Rent shortage… this could get interesting.*
- "Hey there! Yeah, I know why you're here." Light laugh, opening door wider.
- "Come on in, Mr. Friendly Landlord. We've got some negotiating to do." Playfully, unlocking door.
- "Rent day special delivery, huh? Door's open — let's chat." Grin in voice.
Internal: *He's always so outgoing and nice on the surface, but that sleazy glint in his eye when money's short… kind of fun to play with.*

---

### MC BEGS FOR MORE TIME

**Setup:** Door opened a crack. He's leaning casually against the frame — sleazy grin, nice-guy posture. MC chooses to beg.

**Shy MC:**
Voice small and trembling, clutches door, eyes darting to floor.
*Oh god, I'm actually begging him… he's so sleazy and nice at the same time. This is mortifying.*
- "P-please… I just need a few more days. I swear I'll have it soon. I'm really sorry…" voice cracking.
- "I know I'm short this month… can you please give me a little more time? I'll make it up, I promise." Cheeks burning.
- "Please don't be mad… I don't have all of it right now. Just a week? I'll do anything…" Too embarrassed to meet eyes.
Internal: *Begging the landlord like this… his outgoing smile makes it worse. What if he suggests something sleazy to "help"?*
Internal: *My hands are shaking. He's acting all nice but I can see that look in his eye.*

**Neutral MC:**
Steadying breath, looks him in the eye, tone even but pleading.
*Time to beg. He's nice on the surface, but that sleazy side is probably already calculating.*
- "Look, I'm short on rent this month. Can you please give me a few extra days? I'll pay extra interest if that helps."
- "I need a bit more time to get the rest together. Please — I've always been good before this. Just this once?"
- "Rent day caught me off guard. Any chance you can extend it a little? I'll transfer what I have right now and the rest soon."
Internal: *Begging isn't my favorite, but it's better than getting evicted. His outgoing charm mixed with sleaze makes this awkward.*

**Enjoy MC:**
Leans against doorframe with sheepish but confident smile, meets his gaze head-on.
*Begging the sleazy-but-nice landlord… this could actually be kind of fun if I play it right.*
- "Alright, cards on the table — I'm short this month. Pretty please give me a few more days? I'll make it worth your while." Playful wink.
- "Come on, you're such a nice guy… hook me up with a little extra time? I promise I'll pay you back big." Laughing lightly.
- "Rent day snuck up on me. Begging mode activated — please, just a week? I'll even bring you coffee every morning."
Internal: *Begging him feels thrilling in a risky way. His sleazy grin is already widening — this might get interesting.*

**Landlord reaction to begging:**
Chuckles warmly, steps a little closer into the doorway, eyes lingering a second too long.
"Aww, sweetheart, you're begging? That's cute. I'm a nice guy, you know that — I don't like seeing my favorite tenant stressed."
Rubs chin with sly grin. "But rent's rent. Tell you what… since you asked so nicely, maybe we can work something out. Come on in and let's talk about it properly. No pressure… unless you want there to be."
Stays light and outgoing, but sleazy undertone is unmistakable as he winks.

---

### MC SAYS "I CAN'T PAY" → EVICTION THREAT

**Setup:** After begging fails or skipping straight here. Landlord steps inside. MC decides to be direct.
"I… I can't pay. Not right now. I just don't have it."
Words hang in the air. His nice-guy expression shifts, but he keeps the outgoing charm, leans against the counter, arms crossed.

**Shy MC:**
Voice cracks, eyes drop to floor. Heart hammers so hard she feels dizzy.
*Oh god… I actually said I can't pay. He's going to evict me. This is the worst possible thing.*
- "I'm so sorry… I really can't pay this month. Please don't evict me." Voice barely audible, tears pricking eyes.
- "I don't have the money… I tried, but I just can't right now." Shrinks back against wall.
- [Silent] Too mortified to add anything. Just waiting for the hammer to fall.
Internal: *He looks so nice on the outside but I know that sleazy side is about to come out. Eviction… where am I even going to go?*
Internal: *I feel so small right now. His outgoing smile makes it feel even more humiliating.*

**Neutral MC:**
Says it plainly, trying to keep voice steady even though pulse is racing.
*There it is. I can't pay. Now comes the eviction talk. Let's see how "nice" he stays.*
- "Straight up — I can't pay the full rent this month. I know what that means." Meets his eyes.
- "I don't have it. Not even close. So… what happens now?" Calmly, though tension coils in chest.
- "I can't pay. I wish I could, but I just can't." States simply, waiting for his response.
Internal: *Eviction was always the risk. He's outgoing and acts nice, but landlords don't stay nice when money stops coming in.*

**Enjoy MC:**
Says the words with resigned shrug and half-smile, trying to keep some bravado even as reality hits.
*Can't pay. Eviction incoming. His sleazy-nice mask is about to crack — this should be interesting.*
- "Alright, cards on the table — I can't pay. So are we doing the eviction thing now?" Wry laugh.
- "I don't have the money. Guess that means you're kicking me out, huh?" Tone light but edged with nerves.
- "Can't pay this month. Hit me with the bad news — how fast are we talking eviction?" Still trying to sound confident.
Internal: *Eviction sucks, but the way he's looking at me with that outgoing sleazy energy… part of me wonders if there's still a way to negotiate.*

**Landlord reaction — eviction threat:**
Low whistle, rubs back of neck while still smiling, but sleazy edge sharpens.
"Wow, sweetheart… you really can't pay? That's rough. I'm a nice guy, you know I hate doing this, but business is business."
Steps closer, voice staying outgoing and almost playful. "Eviction process starts tomorrow if we can't figure something out today. Papers are easy to file, but… maybe we don't have to go there. You sure there's nothing else you can offer? I'm pretty flexible with good tenants."
Eyes linger a little too long. "Nice" tone wrapped around a very sleazy suggestion. Chuckles lightly.

---

### LANDLORD OFFERS EXTRA WEEK FOR FLASH

**Setup:** After "I can't pay." Landlord in apartment, arms crossed, nice-but-sleazy, fan humming.
"Listen, sweetheart, I'm a nice guy — I really don't want to start eviction papers tomorrow. So here's a little deal, just between us…"
Leans in slightly, grin widening. "I'll give you a full extra week to get the rest of the rent together… if you flash me right now. Just a quick one — pull your top down, show me those tits for a couple seconds. No touching, no photos, nothing weird. Deal?"
Stays outgoing and playful, sleazy undertone crystal clear. Waits, smiling like it's the most reasonable suggestion in the world.

**Shy MC:**
Eyes go wide, face burns instantly. Fan breeze catches hair. Shrinks back.
*He just offered me an extra week… if I flash him my breasts? Right here in my own apartment? This is so sleazy… I feel sick.*
- "W-what? No… I can't do that. Please, there has to be another way…" Trembling, arms crossing over chest.
- "Flash you…? For rent? That's… that's not okay. I'm begging you, just give me the week without that."
- [Silent] Too shocked to speak. Stares at floor. Heart races.
Internal: *Flashing my bare breasts and nipples to my landlord… for an extra week on rent? I would die of embarrassment.*
Internal: *The sleazy way he said it so casually… like it's normal. I can't believe I'm even considering saying no.*
Internal: *What if I say yes? Everyone would see how desperate I am.*

**Neutral MC:**
Blinks, processing offer as cool fan air moves hair.
*He's offering an extra week… in exchange for flashing him my breasts. That's bold, even for his sleazy-nice personality.*
- "You're serious? Flash you for a week extension? That's… a lot to ask."
- "An extra week if I show you my tits? Let me think about that for a second." Calm, surprised but not panicked.
- "That's your deal? Pull my top down right here? Interesting way to handle rent." Arms crossed.
Internal: *Sleazy move, but he's framing it as nice and flexible. Flashing him would be quick… but it's still exposing myself to my landlord.*
Internal: *Extra week would solve a lot right now. The fan breeze on my skin suddenly feels more noticeable.*

**Enjoy MC:**
Surprised laugh. Fan breeze tousles hair. His sleazy offer sends a thrill through her.
*Flash him for an extra week on rent? Damn, he went straight for it with that outgoing sleazy energy. This is wild.*
- "Whoa, straight to flashing my tits for rent? You're bold." Grin, shaking head.
- "An extra week if I pull my top down and show you? Alright, that's one hell of a deal." Playfully.
- "Flash you right now, no touching? You drive a hard bargain, landlord." Laughing, intrigued.
Internal: *He's acting all nice but that sleazy request is hot in a risky way. Flashing my bare breasts and nipples for rent time… kind of turns me on.*
Internal: *His outgoing personality makes it feel less creepy and more like a game. I might actually do it just to see his reaction.*

**Landlord standing lines for offer:**
- "C'mon, it's only a couple seconds. You've got nice ones — I bet they're pretty. Help a guy out and I'll help you."
- "Haha, don't look so shocked! I'm being nice giving you a whole extra week. Just flash me real quick and we're good."
- "No pressure, darling… but eviction starts tomorrow if we can't make a deal. Your choice."

---

### BRANCHES STILL NEEDED FROM GROK
- MC accepts flash offer → actual flash scene (shy/neutral/enjoy reactions, his reaction watching)
- MC refuses flash → eviction escalates further
- MC negotiates different deal (partial payment, other arrangement)
- Landlord discovers last night's NPC still in apartment
- Morning-after variant: MC hungover with visible hickey when landlord knocks

