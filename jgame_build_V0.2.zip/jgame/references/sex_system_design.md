# Sex System Design — The Soul of Carrow

Complete design document covering: condoms, STDs, pregnancy, NPC testing,
restraint descriptions, and SA scene exit guarantees.

This is a companion to sa_scene_brief.md. Both documents should be read
together before writing any scene in this system.

---

## Core principle

Sex in this game has consequences. Not as punishment — as reality.
The system models what actually exists: risk, precaution, communication gaps,
and the choices people make with imperfect information.

The point is not to make sex feel dangerous. It is to make it feel real.

---

## Condoms

**Ownership:**
Condoms are a purchasable item (pharmacy, mall, corner shop).
Stored as: `owns_condoms` trait, or as an inventory count.
If the player has condoms, the option to use one always appears before sex.

**The choice:**
Every sex scene that could result in pregnancy or STD transmission
should offer a condom choice before the act.

```
[ ] Use a condom
[ ] Don't bother
```

This is not locked behind rep or arousal. It is always available if owned.

**NPC response by trait:**
- `Prefers_Condoms` — actively prefers it, may suggest it themselves
- `Neutral_On_Condoms` — no reaction either way
- `Dislikes_Condoms` — negative reaction: "Do we have to?" or refuses entirely (their choice, player can decline the encounter)
- `Refuses_Condoms` — strong refusal, persistent; player cannot proceed with condom with this NPC

If an NPC refuses and player insists: scene ends, NPC frustrated, no sex.
If player backs down: sex without condom, full STD/pregnancy risk.

Neither choice is framed as correct by the game. Both have consequences.

**STD protection:**
- Condom used correctly: 85% STD reduction (not 100% — realistic)
- No condom: full risk applies

---

## STD system

**NPCs do not volunteer STD status.**

This is the rule. No NPC will say "by the way, I have X." 
Some may not know. Some may know and not say. Some may genuinely be clear.
The player cannot know without testing.

This is not to punish the player. It is to model reality.

**Transmission risk (no condom):**
- Sleazy/Jerk NPCs: higher base risk (10% minor, 3% serious)
- Outgoing/Nightlife_Lover NPCs: moderate risk (5% minor, 1% serious)
- Other NPCs: lower risk (2% minor, 0.5% serious)

**Transmission risk (with condom, correctly used):**
Multiply all risks by 0.15.

**STD traits:**
- `STD_minor` — chlamydia-equivalent. Mild symptoms. Treatable at clinic.
  Passive: +2 stress/day. Cost to clear: $85. Fully resolved.
- `STD_serious` — herpes-equivalent. Manageable, not cured.
  Passive: -3 happiness, +4 stress, -2 willpower per day.
  Cost to manage: $280. Becomes `STD_managed` — symptoms reduced, still present.
- `STD_managed` — ongoing management. Reduced passive effects: +1 stress/day.
  Requires periodic clinic visits.

---

## NPC testing

**How to ask:**
A conversation option available when rep >= 20 with an NPC.
"I'd like us both to get tested before we go further."

**NPC response by trait:**
- `Reliable` / `Caring` / `Warm`: agrees readily, follows through
- `Neutral`: agrees with mild awkwardness
- `Outgoing` / `Confident`: "Sure, not a big deal"
- `Sleazy` / `Jerk`: resists, makes it uncomfortable, may refuse
  ("What's your problem?" / "If you don't trust me, forget it")
- `Conflict_Avoidant`: agrees but may not follow through (see below)

**The 3-day wait:**
After asking, a timed event sets:
- `pending_npc_test_{npc_id}: 3` — counts down with days
- After 3 days: NPC result fires as a scene/message
- Results: clear (most likely) or a flag that NPC is infected

If NPC is infected and result comes back positive:
- A scene fires where NPC discloses (or doesn't — Sleazy/Jerk may ghost)
- Player can then get tested themselves
- No sex scene with this NPC can proceed without player choice

**NPC who agreed but didn't follow through:**
Some NPCs (Conflict_Avoidant, Unreliable) set the event but the result
never comes back. After 5 days: "Haven't heard back about that." — player
can press or let it go. Pressing requires higher rep.

---

## Pregnancy

**Risk:**
Applies when: sex scene completed, no condom used, player is in fertile window.
Fertile window: days 12-16 of cycle (tracked by existing cycle system).

**Base risk per encounter in fertile window: 15%**
Modified by:
- Unreliable NPC: no additional modifier (pregnancy doesn't care about NPC personality)
- Player trait `Fertile_Cycle_Aware`: player knows their window, can track it

**Outcome:**
A pending event set 14 days after risky encounter.
A scene fires: missed period, test, result.

This is not content that needs to be written in detail here.
It is a separate major arc requiring its own design document when the time comes.
Note it exists, plan for it, do not implement partially.

---

## Restraint — sensation descriptions

**When this appears:**
Restraint descriptions are part of the SA scene where the player does not
immediately exit (freeze response, or failed push away).

**What it is:**
A first-person sensation description of having arms held or restrained.
This is not erotica. It is a specific physical experience that conveys
the loss of control that is core to why the scene matters.

**Writing notes for Grok:**
"Describe the specific physical sensation of having your arms held.
Not what it looks like — what it feels like: the specific pressure,
the inability to move, what the body does when it realises it can't.
This is not sexy. Write it as the physical reality of restraint,
which is different from how restraint is described in consensual contexts."

**Implementation:**
A `{restraint_description}` token or inline text in the SA scene.
Multiple variants by MC personality:
- Fragile_Ego: dissociation, going somewhere else
- Confrontational: anger at the inability to move, the specific frustration
- Conflict_Avoidant: stillness, waiting for it to be over
- Default: the ordinary experience of being held down

---

## SA scene — exit guarantees

**Design rule, non-negotiable:**

At every stage of the SA scene, at least one of the following is always present
as a choosable option:

1. **Scream** — available unless NPC has covered mouth (a specific scene state).
   Risk: escalation, but always opens an exit path.
   Consequence: NPC stops (scared off), or someone hears, or nothing happens (worst case)
   — but the player had the option.

2. **Push away / physical resistance** — always available unless arms are restrained.
   Risk: NPC may overpower. But the player always has this option.
   Success rate modified by: drunk level, NPC size trait, MC willpower.

**If arms are restrained AND mouth is covered:**
Both primary exits are blocked — this is the worst-case branch.
In this case: a third option must exist.
- Bite (extreme, escalates, may stop it)
- Go somewhere else in your head (freeze/dissociate — not an exit, but a valid response)
- Wait for it to end (comply to end — exits the scene, specific aftermath)

**The rule behind the rule:**
The player must never feel that they had no option at all.
Even if all options are bad, the options must exist.
This is both ethical design and good writing — agency matters even when
all choices are constrained.

---

## What requires implementation now (engine level)

- [x] `owns_condoms` trait / ownership flag
- [x] Condom choice in sex scenes (requires owns_condoms)
- [x] NPC trait: `Dislikes_Condoms`, `Refuses_Condoms`
- [x] STD traits and passive effects (already built)
- [ ] STD transmission roll on sex scene completion
- [ ] Pregnancy risk roll on sex scene completion (fertile window check)
- [ ] Pending NPC test event system (3-day countdown)
- [ ] `pending_npc_test_{id}` timed event and result scene

---

## What requires scene writing

- [ ] Condom negotiation result_text variants (by NPC trait)
- [ ] NPC test request conversation scene
- [ ] NPC test result scene (positive / negative / ghosted)
- [ ] Pregnancy arc (major — separate doc needed)
- [ ] Restraint sensation variants (4 personality types)
- [ ] SA scene full implementation (see sa_scene_brief.md)
- [ ] SA scene exit: scream branch
- [ ] SA scene exit: push away (success and fail variants)
- [ ] SA aftermath morning scene
- [ ] Shaken recovery arc days 5-7

---

## Content tags for this system

When the full system is implemented, the game should carry:
- `Sexual Violence` — for SA content
- `Non-consensual themes` — for the verbal-no-ignored branch
- `Pregnancy themes` — when pregnancy arc is implemented

Players who wish to avoid any of these can filter them.
The opt-in nature of content tags is the correct approach.
Most games do not tag this content. This one will.
