# BAR DANCE GROPE REFUSAL — SCENE REFERENCE

Full reference for dance grope scenes. Use this when writing variants.
All in second-person. NPC never takes no as an answer (by design).
NPC stops only in the "finally stops" section — and reluctantly.

---

## THREE PATH ARCHITECTURE

Every dance scene has three MC response paths:

**Shy / Scared path** — avoidant, internal, freezes or complies
Used by: Shy, Conflict_Avoidant, Fragile_Ego, or flag_npc_traumatised_current
Choice text is hesitant. Internal thought is self-blaming or dissociated.

**Medium path** — pushes back once, doesn't escalate fully
Used by: default traits, Outgoing, most NPCs
Choice text is clear but not aggressive. Internal is shame + discomfort.

**Assertive path** — confrontational, loud, pushes hard
Used by: Confrontational, Self_Assured
May include blocks_if_trait: Shaken (trauma suppresses this path)

**Scared sub-path** — only fires when flag_npc_traumatised_current is true
This is the fourth path. Previous trauma with this specific NPC.
Extra fear, extra helplessness. Locks the assertive path out.

---

## 1. GROPING BREASTS — OVER SHIRT

**MC refusal:**
> You feel his palm cup and squeeze your breast firmly over your shirt,
> thumb brushing across your nipple.
> You tense and push his wrist. "Stop. Get your hand off my chest."

**NPC ignores (Sleazy/Jerk):**
> He smirks and squeezes harder. "Come on — no bra tonight. You wanted this."
> Fingers knead while he pulls you tighter.

**NPC ignores (Alcoholic — sloppy):**
> "Aww don't be like that, baby. Feels good, right?"
> Keeps palming, breath hot on your neck.

**MC internal — Shy/Conflict_Avoidant:**
> *He's still squeezing my tit right here on the dance floor...
> I said stop but he's not listening. Everyone can see.*

**MC internal — Fragile_Ego:**
> *He doesn't care what I said... He's just touching me anyway.
> Does this mean I'm nothing to him? Just a body?
> I hate how small this makes me feel.*

**MC internal — drunk (11-14):**
> *He's still groping my breast... words came out weak.
> Everything feels loose and wrong. Shame burning but can't pull away hard enough.*

**MC internal — blackout (15+):**
> *Hand on my chest. Squeezing. I said stop but... it's all blurry.
> Feels violating but I can't make my body react right.*

---

## 2. GROPING BREASTS — UNDER SHIRT / BARE SKIN

**MC refusal:**
> His hand slips under the hem of your shirt,
> fingers closing directly over bare skin and squeezing.
> You grab his arm. "Stop — I said no. Take your hand out from under my shirt."

**NPC ignores (Sleazy — crude):**
> He chuckles and pinches your nipple instead of pulling away.
> "Why? No bra means they're mine to play with. Feel how hard they are already."

**NPC ignores (Confrontational):**
> "Relax. You wore that top knowing this would happen."
> He doesn't remove his hand — squeezes again, daring you.

**MC internal — Shy/Conflict_Avoidant:**
> *His bare hand is on my tit, skin on skin, and he won't stop even after I begged.
> I feel so violated — like my body isn't mine anymore.
> Tears pricking. Can't cry here. Everyone will see what a weak pushover I am.*

**MC internal — Fragile_Ego:**
> *He ignored me completely... touching my bare breast like it's his right.
> I feel worthless. Why did I even come out tonight?*

---

## 3. RUBBING PUSSY — OVER CLOTHES

**MC refusal:**
> You feel his palm press between your legs, rubbing firmly through your skirt.
> You stiffen and shove at his chest. "Stop rubbing me there. Get your hand off."

**NPC ignores (Sleazy):**
> He leans in, rubbing slower but harder.
> "You're already getting wet — I can feel the heat. Just enjoy it."

**NPC ignores (Jerk):**
> "Don't act all innocent. You were grinding back a second ago."
> Keeps the rubbing going, smirking.

**MC internal:**
> *He's rubbing my pussy on the dance floor like it's nothing.
> The friction is making me sick to my stomach.
> Humiliated — like a toy for him to play with in public.
> Why can't I scream or run?*

**MC internal — drunk:**
> *The rubbing won't stop... I said no but my voice sounded pathetic.
> Shame feels distant but it's still there, eating at me.*

---

## 4. FINGERING — UNDER CLOTHES / SKIRT

**MC refusal:**
> His fingers push under your skirt, sliding directly against your pussy,
> trying to slip inside.
> You clamp your thighs and grab his wrist hard.
> "Stop! No — pull your hand out right now."

**NPC ignores (Sleazy — drunk escalation):**
> He doesn't pull back — pushes a finger in anyway, whispering,
> "You're soaked. Stop pretending you don't want it."
> His finger curls inside you while he holds you close so no one else sees.

**NPC ignores (Alcoholic):**
> "C'mon sweetheart, just a little. Feels good, don't it?"
> Keeps moving his finger slowly, ignoring your protest.

**MC internal — Shy/Conflict_Avoidant:**
> *Oh god his finger is inside me on the dance floor...
> I said stop and he just pushed in deeper.
> I feel so exposed and helpless.*

**MC internal — Confrontational (still bad):**
> *I told him to stop and he shoved his finger deeper.
> Rage and shame mixing — I feel powerless and disgusted with both of us.*

**MC internal — Fragile_Ego:**
> *His finger is inside me... after I explicitly said no.
> Violated and dirty in the worst way.
> This is assault and I'm just letting it happen because I'm too scared to make a scene.
> I hate myself right now.*

---

## 5. GRINDING

**MC refusal:**
> He presses his hard cock against your ass or front,
> grinding deliberately in slow circles.
> You try to pull away. "Stop grinding on me like that. Back off."

**NPC ignores (Sleazy/Confrontational):**
> He laughs softly and grinds harder, hands locking on your hips.
> "Why? You can feel how hard I am for you. Stop fighting it — move with me."

**NPC ignores (Jerk):**
> "Quit acting like you hate it. Your body's saying yes."
> Keeps the grinding rhythm, pulling you back every time you shift away.

**MC internal — conflicted (Provocative_Sexual):**
> *He's grinding his dick against me so obviously...
> I told him to stop but part of me is reacting anyway.
> The friction is making it hard to stay mad.*

**MC internal — shame:**
> *He's grinding his dick against me in public and won't stop.
> I feel like a piece of meat. The pressure is nauseating.*

---

## 6. COMBINED ESCALATION — MULTIPLE SIMULTANEOUSLY

**MC refusal (blackout):**
> Hand under your shirt on your bare breast.
> Other hand rubbing your pussy.
> His cock grinding against you.
> Slurring: "Stop... all of it. Get your hands off me."

**NPC ignores:**
> "You're too drunk to mean that. Just relax — let me feel everything."

**MC internal (Shy-adjacent, blackout):**
> *Hands everywhere. Can't tell what's happening.
> Told him to stop but... spinning... whatever.*

---

## MC CONFRONTATIONAL LINES (ready to paste)

> "Get your fucking hands off my tits/pussy right now or I'm walking off this floor."

> "I said stop touching me there. Move your hand or we're done."

> "Hey — hands off the goods. I said stop groping me."

> "Stop... or at least slow down. Fuck, you're really not listening." *(Provocative_Sexual — conflicted)*

---

## NPC STOPPING — BY TRAIT

**Engaging (stops quick, apologetic):**
> "Shit, sorry... I got carried away." Removes hands immediately, genuinely regretful.

**Self_Assured / Streetwise (stops clean):**
> "Fair enough." Pulls back smoothly, no argument.

**Shy NPC (stops awkwardly):**
> "Oh... sorry, I didn't mean to..." Yanks hands away like burned, face red.

**Sleazy/Jerk (stops reluctantly):**
> "Fine, whatever... you were into it a second ago." Sulks but complies.

**Confrontational (stops with insult):**
> "Fine, whatever... frigid bitch." Steps back sulking.

---

## AFTER HE STOPS — MC REACTION

**Generic:**
> *Finally... his hand is off. Relief floods me but the shame doesn't leave.
> I let him touch me too long before he listened.
> I feel dirty and exposed. My chest is still tingling.*

**Shy/Fragile_Ego:**
> *He stopped... finally. Relief is overwhelming but shame and violation are worse.
> I can still feel every place he touched.
> I feel dirty, used, and stupid for letting it go that far.*

**Fingering aftermath:**
> *The intrusion is gone... huge wave of relief, but violation stays burned in.
> I feel sore and dirty inside. Tears close but I can't cry here.*

**Blackout aftermath:**
> *The touching stopped... I think. Everything still gross and hazy.
> Something bad happened. I know that much.*

---

## SCARED PATH — NPC TRAUMA LINK

When `flag_npc_traumatised_current` is active (this NPC has a permanent trauma link):

**Opening variant addition:**
> You see {npc_name}.
> Something cold runs through you before you've processed why.
> Your body knew before your brain did.

**Scared choice text:**
> Stay far from him tonight. Don't make eye contact.
> Leave. You shouldn't be here if he's here.

**Internal during encounter:**
> *It's him. The floor doesn't feel safe anymore.
> The music is too loud. I don't want to be here.*

