# NSFW SENSATION REFERENCE — INTERNAL THOUGHTS & NPC LINES
# Game style: scene text is second-person present. Internal thoughts are *italicised first-person*.
# NPC dialogue is quoted. Short and specific — no purple prose.
# Adapted from Grok source blocks. Archived before implementation.
#
# DRUNK SCALE:  0–5 = sober  |  6–10 = tipsy  |  11–14 = drunk  |  15–19 = blackout
# PERSONALITY TRAITS: Shy, Conflict_Avoidant, Fragile_Ego, Prideful, Self_Assured,
#                     Outgoing, Confrontational, Provocative_Sexual, Nightlife_Lover
#
# SECTIONS:
#   I.   MC internal — braless/nipping (by personality)
#   II.  MC internal — commando/no underwear (by personality)
#   III. Physical sensation inserts (mix-and-match)
#   IV.  NPC looking — braless/nipping dialogue (by NPC type)
#   V.   NPC lines by NPC trait (two full variant sets)
#   VI.  MC response thoughts after NPC notices (by MC trait + drunk level)

---

## I. MC INTERNAL THOUGHTS — BRALESS / NIPPING

*Use as text_variants or result_text additions. Second-person context, first-person italic thought.*

### Shy / Uncomfortable

```
*No bra again. My breasts feel heavy and loose and every step makes them move.
My nipples are already hard against the fabric — sensitive enough that I notice
every tiny shift. Everyone must be able to see.*

*The cold air keeps catching my nipples through the top. They won't stop tightening.
I can feel them rubbing with every breath and I want to cross my arms
but that would just make it more obvious.*

*Braless was a mistake today. My chest feels exposed and the way the fabric sits —
my nipples are nipping right through and there's nothing I can do about it now.
I should have worn something else.*

*Without a bra my breasts pull slightly with every movement. My nipples have been
hard since I left the flat. I'm hyper-aware of them every time someone looks in
my direction.*

*The constant friction from the top against my bare nipples is distracting in
the worst way. Sensitive and obvious and I can't stop noticing it.*
```

### Neutral / In-Between

```
*No bra today. My breasts move freely and my nipples respond to the air —
that familiar tightening. Distracting but manageable.*

*Braless. The natural movement is noticeable and so are my nipples right now.
Part of the deal when you don't wear one.*

*I can feel my nipples hardening from the air conditioning — the thin fabric
isn't doing much to hide it. Not the worst thing.*

*The braless thing gives everything more sensitivity. My nipples are stiff
and I'm aware of them but not uncomfortable. Just — present.*

*No bra means my breasts sit differently. More mobile. My nipples have been
firm since I came in from outside and the fabric keeps reminding me.*
```

### Outgoing / Enjoys It

```
*Being braless today feels good. My breasts move the way they want to
and my nipples are hard against the fabric — that warm tingle.
I like how aware I am of them right now.*

*No bra and my nipples are nipping obviously. I felt someone look
the moment I walked in. I'm not minding.*

*The cool air on my nipples through the thin top — that slight ache
when they tighten. I've been enjoying this since I left the flat.*

*My breasts move freely when I walk and my nipples are getting harder.
The fabric keeps catching against them just right. This is the good version
of being this aware of my body.*

*Braless and nipping and I'm not hiding it. I can feel every look
and the attention makes my chest feel warmer, not colder.*
```

---

## II. MC INTERNAL THOUGHTS — COMMANDO / NO UNDERWEAR

### Shy / Uncomfortable

```
*No underwear and every step I take I can feel it — the fabric moving
directly against my skin. Too much contact, too much awareness.
I should not have left the flat like this.*

*Commando under a skirt. The air keeps finding its way and I'm
hyper-aware of how bare I am. Every time I sit I feel the material
press differently.*

*Going without underwear today was a choice I'm regretting.
The fabric sits against me with no barrier and I can't stop
noticing the direct friction.*

*Every movement down there is more obvious without underwear.
More air, more contact, more awareness. I'm embarrassed
by how much I'm noticing it.*
```

### Neutral / In-Between

```
*Commando today. The fabric moves differently against bare skin —
more friction, more air. I'm aware of it without being bothered.*

*No underwear means I feel the material directly. A little more
exposure than usual but nothing I can't manage.*

*The commando thing is always more present than I expect.
Cool air, direct contact — a constant low-level awareness.*

*I can feel the seam of my jeans / waistband of my skirt sitting
against bare skin. More noticeable than with underwear. Not bad.*
```

### Outgoing / Enjoys It

```
*No underwear today and I'm very aware of the specific freedom of it.
Every step, every breeze. I like this.*

*Commando under the skirt. The air movement is constant
and so is the awareness between my legs. I chose this intentionally
and I'm enjoying the choice.*

*Going without underwear makes the whole day feel different —
more exposed, more present. I've been thinking about it
since I left the flat and that's the point.*

*No underwear and someone's talking to me and all I can think about
is the fabric sitting against bare skin. I like the combination
of the mundane and the private.*
```

---

## III. PHYSICAL SENSATION INSERTS — MIX AND MATCH

*Short lines, drop into any result_text or text_variant. No attribution needed.*

### Braless sensations

```
A cool draft from the vent finds the thin fabric and does what cold air does.
Your nipples tighten further. The sensation is immediate and specific.

Every time you reach overhead or lean forward, your braless chest moves
in a way that's hard to ignore if anyone's watching. You're past
pretending not to know that.

The fabric is thin enough and your nipples firm enough that the combination
has been communicating something to anyone looking since you arrived.

The cold of the room settled around your chest early in the shift.
Your nipples have been hard since twenty minutes in. You've stopped waiting
for them to soften.

When you turn quickly the movement is there — unsupported, natural,
impossible to pretend is happening invisibly.
```

### Commando sensations

```
A breeze under the skirt. Brief, cool, specific. You keep your expression level.

Every time you sit down the material settles against bare skin
with more directness than you get used to quickly.

You've been aware of the no-underwear decision every few minutes
since you made it. It's that kind of awareness.

The seam is in the wrong place and there's no layer of fabric between it
and you. You adjust without drawing attention to the adjustment.
```

---

## IV. NPC DIALOGUE — BRALESS / NIPPING (by NPC type)

*Direct dialogue for NPC noticing braless state. Short, character-appropriate.*

### NPC type: Sleazy (crude, no filter)

```
"No bra. I can see everything — the shape of them, your nipples going hard.
You know exactly what that top does."

"God, those nipples are poking right through. No bra today?"
(Doesn't look away.) "You wearing that on purpose?"

"I can see your nipples through that. No bra at all."
(Steps slightly closer.) "Nice."
```

### NPC type: Sleazy, drunk escalation (MC drunk 11–14)

```
"No bra and half-cut? Those are gonna bounce so nice when I get you on the floor."

"You're drunk and I can see your nipples perfectly. Tonight's going well for me."
```

### NPC type: Sleazy, drunk escalation (MC blackout 15+)

```
"Wasted and braless. Perfect combination."
(Hand already moving.) "You won't remember this anyway."
```

### NPC type: Jerk (backhanded, arrogant)

```
"No bra. Desperate for attention or just forgot?"
(Eyes down.) "At least you've got the tits to pull it off."

"Coming out braless so everyone notices you? Points for commitment."
```

### NPC type: Alcoholic (sloppy, overly familiar)

```
"Hey — no bra, right? I can see your nipples from here, sweetheart."
(Breath warm, too close.) "Cold in here or are you just happy to see me."

"Whoa. No bra and those nipples are saying hi to the whole room."
```

### NPC type: Outgoing / Nightlife_Lover

```
"You went braless tonight? Respect. That top is doing a lot of work."
(Grinning.) "You're going to make half the bar forget their own names."

"Holy shit — no bra. That top is see-through when the light hits right."
(Thumbs-up, genuinely delighted.) "Power move."
```

### NPC type: Engaging (warm, genuine)

```
"I can tell you're not wearing anything under there."
(Eyes flick down once, come back up.) "Looks good on you. Natural."

"You're braless tonight, aren't you? The way the top's clinging."
(Soft smile.) "Confident look."
```

### NPC type: Magnetic (quiet, assured)

```
(Gaze drops, comes back up.) "No bra. Bold choice."
(Small pause.) "Suits you."

"No bra. I can see every curve when you breathe."
(Low, unhurried.) "You know that."
```

### NPC type: Self_Assured (direct, unbothered)

```
"No bra. I like it."
(Holds eye contact.) "Doesn't leave much to the imagination."

"No bra. I noticed the second you turned around."
(Completely calm.) "The fabric's thin enough that nothing's hidden."
```

### NPC type: Shy

```
(Glances, immediately away, face red.)
"Sorry — you're, um. You're not wearing a bra. I didn't mean to look."
(Quieter.) "You look nice though."

"I can see you're — sorry, braless. The top makes it obvious."
(Eyes anywhere else.) "Sorry."
```

### NPC type: Confrontational

```
"You came out without a bra on purpose, didn't you."
(Staring.) "Brave. Or hoping someone notices?"

"Came out braless and now everyone's looking. You planned that."
```

### NPC type: Streetwise (observant, cool)

```
(Clocks it immediately, small nod.)
"No bra. You know what that does in a place like this."
(Keeps voice low.) "Smart move if you're fishing."

"Braless, thin top, cold air in here. You're getting a reaction
from half the room already."
```

### NPC type: Boring

```
"Oh. You're not wearing a bra."
(Flat pause.) "The fabric's quite thin."

"You're braless. I can see the shape."
(Slight awkward pause.) "The lighting makes it very noticeable."
```

---

## V. NPC LINES — SECOND SET (different angles/focus)

*Alternative lines for the same traits — use to avoid repetition.*

### Engaging

```
"You're braless tonight, aren't you? The clinging top."
(Quick respectful glance.) "Confident. Works."
```

### Magnetic

```
(Eyes trace the soft outline.) "No bra. I can see every curve when you breathe."
(Low, no rush.) "You know that, right?"
```

### Outgoing / Nightlife_Lover

```
"You ditched the bra tonight. That top is see-through when the lights hit it."
(Ear-to-ear grin.) "You're making the rest of us look overdressed."
```

### Shy

```
(Blushes, eyes down then away.)
"Sorry — you're not wearing a bra, are you? It's kind of obvious. You look really pretty though."
```

### Self_Assured

```
"No bra. I noticed when you turned around."
(Calm.) "Nothing's left to the imagination with that fabric."
```

### Confrontational

```
"You came out braless. Those nipples are basically waving hello."
(Stares, no apology.) "You planned this."
```

### Boring

```
"You're not wearing a bra. I can see the shape of — everything."
(Flat.) "The lighting in here makes it very noticeable."
```

### Streetwise

```
"Braless. Thin top, cool air — you're getting a reaction from half the room."
(Low.) "You planned that, didn't you."
```

### Alcoholic

```
"Whoa, no bra? I can see your tits moving every time you shift."
(Too close.) "You cold or just showing off?"
```

### Sleazy (second set)

```
"No bra at all. I can see your nipples poking through like they're asking for it."
(Stares openly.) "You want guys staring, don't you."
```

**Drunk (11–14):**
```
"No bra and already tipsy. Those are gonna bounce nice when you dance."
```

**Blackout (15+):**
```
"Wasted and braless. Means I can slide my hands right under that top."
```

### Jerk (second set)

```
"No bra. Trying to make sure everyone knows what you've got?"
(Eyes down.) "At least they're worth looking at."
```

---

## VI. MC RESPONSE THOUGHTS — AFTER NPC NOTICES
*Insert immediately after NPC braless-noticing line. Scale by MC trait + drunk level.*

### Generic (no strong personality trait active)

**Tipsy (6–10)**
```
*He noticed. The way this top sits against my nipples right now —
I can feel them pointing through the fabric. Part of me likes the attention.
Part of me wants to cross my arms.*
```

**Drunk (11–14)**
```
*He's staring right at my chest and I know he can see everything.
Should care more. Everything feels warm and loose and I don't.*
```

**Blackout (15–19)**
```
*He's looking. Whatever. My chest feels heavy and tingly.
The room is moving.*
```

### Trait: Shy

**Tipsy**
```
*Oh — he's looking right there. My nipples are completely visible through
this and I can't do anything about it. Why didn't I wear a bra.
I feel so exposed.*
```

**Drunk**
```
*He can see my nipples. Everyone can. My chest is just out here
and I'm standing here letting it happen. Stomach twisting but I can't move.*
```

**Blackout**
```
*Someone's staring at my chest. I think. Everything's blurry.*
```

### Trait: Conflict_Avoidant

**Tipsy**
```
*He noticed I'm braless. I should say something or cover up
but I don't want to make it awkward. Just smile and let my nipples
stay on full display and pretend this is fine.*
```

**Drunk**
```
*He's commenting on my chest being visible and I'm not even pushing back.
I hate this but also don't want to cause a scene. Just let him look.*
```

### Trait: Fragile_Ego

**Tipsy**
```
*He noticed I'm braless. That means he's actually looking at me.
Really looking. My nipples are hard and visible and for once
someone's paying attention. That lands somewhere warm.*
```

**Drunk**
```
*He can see everything and he's still talking to me.
Maybe I'm not invisible tonight. The attention settles somewhere
in my chest even while my face heats up.*
```

### Trait: Prideful

**Tipsy**
```
*Yeah, he noticed. Good. These look better without a bra anyway.
I chose this top. I can handle a few looks.*
```

**Drunk**
```
*He's calling out that I'm not wearing a bra like it's an insult.
I look hot and I know it. Let the whole bar see.*
```

### Trait: Self_Assured

**Tipsy**
```
*He clocked the braless thing. Fine by me. The outline is obvious
and I'm not hiding it. If he's distracted, that's his problem.*
```

**Drunk**
```
*No bra, nipples showing, and he's looking. Exactly what I wanted
when I chose this top. I own the attention.*
```

### Trait: Outgoing

**Tipsy**
```
*He totally just noticed I'm braless. I can feel my nipples
brushing the fabric every time I breathe. Might as well lean into it.*
```

**Drunk**
```
*The whole bar can see I'm not wearing a bra and I'm grinning about it.
This top was a power move.*
```

### Trait: Confrontational

**Tipsy**
```
*He's staring at my chest. Call it out or let him squirm?
Either way I'm not covering up — I chose this.*
```

**Drunk**
```
*He just pointed out I'm braless like it's a clever observation.
I know exactly what this top does and I'm not ashamed of it.*
```

### Trait: Provocative_Sexual

**Tipsy**
```
*He noticed I'm braless. Good. I can feel my nipples getting harder
under his stare. This top is doing exactly what I wanted.*
```

**Drunk**
```
*No bra, nipples on full display, and he's losing his thread.
Heat pooling low already. I love when they can't stop looking.*
```

**Blackout**
```
*He's staring at my chest. Feels nice. Can't think straight enough
to do anything but enjoy the tingle.*
```

### SPECIAL: vs Sleazy or Jerk NPC (stronger reaction for shy-adjacent traits)

**Shy / Conflict_Avoidant / Fragile_Ego — Tipsy**
```
*He just said he can see my nipples. Blatantly. My whole chest is visible
and he's not pretending otherwise. Face burning, stomach in knots.
I'm frozen — can't even get my arms to cross.*
```

**Shy / Conflict_Avoidant / Fragile_Ego — Drunk**
```
*He's talking about my chest like he owns the view.
I know everything's visible but the buzz makes the humiliation
feel distant and warm instead of sharp.*
```

**Any trait — Blackout**
```
*He's saying something about my nipples. I think.
Everything's too heavy and blurry to process properly.*
```

---

## IMPLEMENTATION GUIDE

### Where these fit in the YAML:

**MC internal thought in result_text:**
```yaml
result_text: |
  He's registered the braless thing before he's processed the rest of you.

  *No bra and he's noticed. My nipples have been hard since I came in
  from outside. Part of me wants to cross my arms.*

  You let the moment sit.
```

**NPC line in text_variants:**
```yaml
text_variants:
  - requires_flag: flag_is_braless
    requires_trait: Sleazy
    text: |
      {npc_name} glances at your chest and stays there a beat too long.

      "No bra. I can see everything."
      (Doesn't look away.)
      "You know that, right?"
```

**Drunk-scaled MC thought (requires drunk trait check):**
```yaml
  - requires_flag: flag_is_braless
    requires_trait: Drunk
    text: |
      He noticed you're braless before he said anything.

      *He can see everything. Should care more.
      Everything feels warm and loose and I don't.*
```

### Priority scenes to add these:

**NPC dialogue lines:** bar_night (all NPC traits), bar_approach, bar_dance_with_npc,
  bar_slow_dance (if it exists), bar_staff_regular_patron, bar_staff_friday_night

**MC internal thoughts:** morning_routine, home_window_view, city_wander_park,
  city_wander_carrow_tram, exercise_run, neon_fitness_keisha_advice,
  landlord_flash_offer, city_wander_rain (post-soak version)

**Commando thoughts:** outfit_commando_skirt (already exists as a trigger scene),
  any skirt scene with flag_wearing_skirt

**Drunk-scaled:** all bar scenes, location_nightclub

---

## REP GATE CALIBRATION (REMINDER)
Daily cap = 5. Correct thresholds:
  Rep 0   = ambient text_variants only (no gate)
  Rep 5   = first passive awareness choice
  Rep 8   = active small choice / lean in
  Rep 12  = say something / deliberate escalation
  Rep 15  = more explicit comment or offer
  Rep 20  = flash-adjacent / show something
  Rep 30+ = explicitly sexual escalation
