# Bar System — Undocumented Methods Reference
_Auto-generated from BarSystem.java. Contains all methods built this session that were not in prior Grok reference files._

### buildPussyGropeText
```java
String buildPussyGropeText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hand slides under your skirt.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");

        state.flagPussyGroped = true;

        if (d.equals("blackout"))
            return "*Warm... between my legs under my skirt while we dance. Moving. The spinning room makes it hard to tell how it feels.*";

        // ── Physical description by NPC type ──────────────────────────────────
        String base;
        if (hasTrait(n, "Sleazy"))
            base = "While you are both swaying slowly to the music, {npc_his} hand slides down your back, "
                 + "slips under the hem of your skirt, and cups your pussy directly. "
                 + "Fingers press against your folds, pushing panties aside to rub bare skin. "
                 + "{npc_He} grinds {npc_his} palm slowly while holding you tight and continuing to move with the rhythm.";
        else if (hasTrait(n, "Jerk"))
            base = "While you are both slow dancing, {npc_he} smirks as {npc_his} hand dips under your skirt from behind, "
                 + "cupping your pussy possessively. {npc_His} fingers rub firmly, pushing panties aside to touch bare skin "
                 + "while {npc_he} grinds {npc_his} hips forward in time with the music.";
        else if (hasTrait(n, "Alcoholic"))
            base = "While you are both slow dancing, {npc_his} sweaty hand slips clumsily under your skirt and cups your pussy, "
                 + "fingers rubbing messily against your folds while {npc_he} sways heavily into you, breath boozy against your neck.";
        else if (hasTrait(n, "Confrontational"))
            base = "While you are both slow dancing, {npc_he} grips your waist first, then deliberately slides {npc_his} hand "
                 + "under your skirt from behind, cupping your pussy and rubbing firmly as if daring you to object "
                 + "while {npc_he} pulls you flush against {npc_him} in time with the music.";
        else
            base = "{npc_His} hand slides under your skirt while you both sway to the music, finding your pussy and rubbing slowly.";

        // ── MC reaction by tier and drunk ─────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*He's rubbing my pussy under my skirt while we're slow dancing after I told him to stop earlier. The violation still cuts through the haze.*";
            else if (tier.equals("enjoy"))
                mc = "*His hand under my skirt, touching my pussy while we dance feels dirty and hot. The alcohol makes me want to grind back against his palm.*";
            else
                mc = "*Something is happening between my legs under my skirt as we dance. It registers, but the buzz makes it feel distant and unimportant.*";
        } else {
            if (tier.equals("shy"))
                mc = "You feel his fingers push under your skirt and rub your bare folds while you both continue moving slowly together. The intrusion is sharp."
                   + "\n\n*His hand is between my legs under my skirt while we're slow dancing. The violation hits hard. I feel exposed and angry. This is crossing every line.*";
            else if (tier.equals("enjoy"))
                mc = "You feel his warm fingers slide under your skirt and rub your bare pussy while you both sway to the slow beat."
                   + "\n\n*His hand is under my skirt, touching my pussy while we dance. The bold strokes in time with the music feel risky and arousing. I'm getting wet despite the public setting.*";
            else
                mc = "His fingers slide under your skirt and rub your pussy while you both sway to the music."
                   + "\n\n*I feel his hand between my legs under my skirt as we dance. It registers, but I don't feel strongly about it either way.*";
        }
        return base + "\n\n" + mc;
    }
```

---

### buildFingeringContinuesText
```java
String buildFingeringContinuesText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} finger is still inside you.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");

        if (d.equals("blackout"))
            return "*Fingers... inside while we dance. Moving. The spinning room makes it hard to tell how it feels.*";

        // ── Physical description ───────────────────────────────────────────────
        String base;
        if (hasTrait(n, "Sleazy"))
            base = "While you are both swaying slowly to the music, {npc_his} finger is already inside you, curling and thrusting shallowly. "
                 + "{npc_He} keeps the slow rhythm of the dance, using the movement of your bodies to push {npc_his} finger deeper, "
                 + "adding a second finger as the song continues.";
        else if (hasTrait(n, "Jerk"))
            base = "While you are both slow dancing, {npc_his} finger is already inside you. "
                 + "{npc_He} smirks and adds a second finger, thrusting arrogantly in time with the music as {npc_he} pulls you tighter against {npc_him}.";
        else if (hasTrait(n, "Alcoholic"))
            base = "While you are both slow dancing, {npc_his} sweaty fingers are already inside you, "
                 + "thrusting clumsily and messily in time with {npc_his} heavy swaying.";
        else if (hasTrait(n, "Confrontational"))
            base = "While you are both slow dancing, {npc_his} finger is already inside you. "
                 + "{npc_He} adds a second finger challengingly, thrusting as if daring you to object while {npc_he} pulls you flush against {npc_him}.";
        else
            base = "{npc_His} finger keeps moving inside you while you both sway together.";

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*His fingers are inside me while we're slow dancing. The violation still cuts through the haze with every thrust.*";
            else if (tier.equals("enjoy"))
                mc = "*His fingers are inside me while we dance... stretching and moving with the rhythm. The alcohol makes it feel dirty and addictive.*";
            else
                mc = "*Something is thrusting inside me as we dance. It registers, but the buzz makes it feel distant and unimportant.*";
        } else {
            if (tier.equals("shy"))
                mc = "You feel his finger curl and thrust inside you while you both continue moving slowly together. A second finger pushes in."
                   + "\n\n*His fingers are inside me while we're slow dancing. He just added another one. The violation feels deeper and more humiliating with every thrust in time with the music.*";
            else if (tier.equals("enjoy"))
                mc = "You feel his finger curl and thrust inside you while you both sway to the slow beat. A second finger joins, stretching you."
                   + "\n\n*His fingers are inside me, thrusting slowly while we dance... the rhythm matches the song perfectly. The risk of being fingered on the dance floor makes it incredibly hot and intense.*";
            else
                mc = "His finger curls and thrusts inside you while you both sway to the music. A second finger joins."
                   + "\n\n*I feel his fingers moving inside me as we dance. It's happening, but I don't feel strongly about it either way.*";
        }
        return base + "\n\n" + mc;
    }
```

---

### buildThroughPantiesText
```java
String buildThroughPantiesText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hand presses over your panties.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean braless = state.hasTrait("exposed_breasts");
        boolean nipping = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");

        state.flagPussyGroped = true;

        if (d.equals("blackout"))
            return "*Hand... under my skirt, groping over my panties while we dance. The spinning room makes it hard to process.*";

        // ── Physical description by NPC type ──────────────────────────────────
        String base;
        if (hasTrait(n, "Sleazy"))
            base = "While you are both swaying slowly to the music, {npc_his} hand rests on your hip, "
                 + "then slides under the hem of your skirt. {npc_His} fingers press and rub over your panties, "
                 + "stroking the fabric against your bare folds and clit while you both continue moving together.";
        else if (hasTrait(n, "Jerk"))
            base = "While you are both slow dancing, {npc_he} grips your hip possessively, "
                 + "then smirks as {npc_his} hand slides under your skirt. {npc_His} fingers rub and press over your panties "
                 + "arrogantly, stroking the fabric against your pussy while {npc_he} pulls you flush in time with the music.";
        else if (hasTrait(n, "Alcoholic"))
            base = "While you are both slow dancing, {npc_his} sweaty hand slides clumsily under your skirt "
                 + "and begins rubbing over your panties with heavy, uncoordinated strokes while {npc_he} sways heavily into you.";
        else if (hasTrait(n, "Confrontational"))
            base = "While you are both slow dancing, {npc_he} grips your waist, "
                 + "then deliberately slides {npc_his} hand under your skirt, rubbing and pressing over your panties "
                 + "as if daring you to object while {npc_he} holds you close in time with the music.";
        else
            base = "{npc_His} hand slides under your skirt while you both sway, fingers rubbing over your panties slowly.";

        // ── Also note if under-shirt grope is happening simultaneously ─────────
        String combined = "";
        if (state.flagBreastGroped && braless)
            combined = "\n\nOne hand under your shirt on your bare breast" + (nipping ? ", thumb on your nipple" : "")
                     + ", the other rubbing over your panties while you dance. *I feel completely used and exposed.*";

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*He escalated to groping me through my panties while we're slow dancing. The violation still cuts through the haze.*";
            else if (tier.equals("enjoy"))
                mc = "*He's groping me through my panties while we dance... the constant rubbing feels so dirty and hot. The alcohol makes me grind into his touch.*";
            else
                mc = "*The shift under my skirt and over my panties as we dance registers, but the buzz makes it feel distant.*";
        } else {
            if (tier.equals("shy"))
                mc = "*He went under my skirt to grope me through my panties while we're slow dancing. The violation feels sneaky and humiliating. His fingers keep rubbing the fabric against me and I don't know how to make it stop.*";
            else if (tier.equals("enjoy"))
                mc = "*He's groping me through my panties while we dance... the pressure of the fabric against my bare folds feels teasing and good. The public risk is making everything more intense.*";
            else
                mc = "*The shift under my skirt and over my panties as we dance registers clearly. I feel it. I just don't feel strongly about it either way.*";
        }
        return base + combined + "\n\n" + mc;
    }
```

---

### buildInsidePantiesText
```java
String buildInsidePantiesText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} fingers slip inside your panties.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean braless = state.hasTrait("exposed_breasts");
        boolean nipping = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");

        state.flagPussyGroped = true;
        state.flagFingered    = true;

        if (d.equals("blackout"))
            return "*Hand... under my skirt and inside my panties, fingers inside me while we dance. The spinning room makes it hard to process.*";

        // ── Physical description by NPC type ──────────────────────────────────
        String base;
        if (hasTrait(n, "Sleazy"))
            base = "While you are both swaying slowly to the music, {npc_his} hand first rests on your hip, "
                 + "then slides under the hem of your skirt. {npc_His} fingers slip inside your panties, "
                 + "brushing bare folds before rubbing your pussy and pushing one or two fingers inside "
                 + "while you both continue moving together.";
        else if (hasTrait(n, "Jerk"))
            base = "While you are both slow dancing, {npc_he} grips your hip possessively, "
                 + "then smirks as {npc_his} hand slides under your skirt and slips inside your panties. "
                 + "{npc_His} fingers rub your pussy arrogantly before pushing inside "
                 + "while {npc_he} pulls you flush in time with the music.";
        else if (hasTrait(n, "Alcoholic"))
            base = "While you are both slow dancing, {npc_his} sweaty hand slides clumsily under your skirt "
                 + "and slips inside your panties. {npc_His} fingers rub messily before pushing inside "
                 + "while {npc_he} sways heavily into you.";
        else if (hasTrait(n, "Confrontational"))
            base = "While you are both slow dancing, {npc_he} grips your waist, "
                 + "then deliberately slides {npc_his} hand under your skirt and slips inside your panties, "
                 + "{npc_his} fingers pushing inside as if daring you to object "
                 + "while {npc_he} pulls you flush in time with the music.";
        else
            base = "{npc_His} hand slides under your skirt and inside your panties while you both sway, fingers pushing inside you.";

        // ── Combined note if breast also being groped ─────────────────────────
        String combined = "";
        if (state.flagBreastGroped && braless && nipping)
            combined = "\n\n{npc_His} other hand is still under your shirt, thumb on your hard nipple "
                     + "while {npc_his} fingers push inside your panties. *One hand under my shirt on my bare breast, "
                     + "the other now inside my panties fingering me while we dance... I feel completely used.*";
        else if (state.flagBreastGroped && braless)
            combined = "\n\n{npc_His} other hand remains under your shirt on your bare breast while {npc_his} fingers push inside your panties.";

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*He escalated to putting his hand inside my panties and fingering me while we're slow dancing. The violation still cuts through the haze.*";
            else if (tier.equals("enjoy"))
                mc = "*He went straight inside my panties and is fingering me while we dance... it feels so dirty and hot. The alcohol makes me clench around his fingers.*";
            else
                mc = "*The shift under my skirt and inside my panties as we dance registers, but the buzz makes it feel distant.*";
        } else {
            if (tier.equals("shy"))
                mc = "*He went from my hip to putting his hand inside my panties and fingering me while we're slow dancing. The violation feels deeply exposing and wrong. His fingers are inside me and I can't make the freeze end.*";
            else if (tier.equals("enjoy"))
                mc = "*He went under my skirt and inside my panties... his fingers are now inside me while we dance. The bold public escalation feels so risky and arousing.*";
            else
                mc = "*The shift under my skirt and inside my panties as we dance registers clearly. His fingers are inside me. I just don't feel strongly about it either way.*";
        }
        return base + combined + "\n\n" + mc;
    }
```

---

### buildUnderShirtGropeText
```java
String buildUnderShirtGropeText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hand slides under your shirt.";
        String d      = drunkTier();
        String tier   = gameStageVariant("breast_public");
        boolean braless = state.hasTrait("exposed_breasts");
        boolean nipping = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");

        state.flagBreastGroped = true;

        if (d.equals("blackout"))
            return braless
                ? "*Hand... under my shirt on my bare breast while we dance. The spinning room makes it hard to process.*"
                : "*Hand... under my shirt, groping my breast while we dance. Everything is hazy.*";

        // ── Physical description by NPC type ──────────────────────────────────
        String base;
        if (hasTrait(n, "Sleazy")) {
            base = braless
                ? "While you are both swaying slowly to the music, {npc_his} hand first rests on your waist, "
                  + "then slides upward under the hem of your top. {npc_His} fingers brush bare skin as they move higher, "
                  + "immediately cupping and squeezing your bare breast" + (nipping ? ", thumb brushing your hard nipple directly" : "") + "."
                : "While you are both swaying slowly to the music, {npc_his} hand rests on your waist, "
                  + "then slides under the hem of your top. {npc_His} fingers press over your bra, "
                  + "cupping and kneading your breast through the fabric.";
        } else if (hasTrait(n, "Jerk")) {
            base = braless
                ? "While you are both slow dancing, {npc_he} arrogantly slides {npc_his} hand under your top, "
                  + "fingers groping your bare breast with possessive entitlement while {npc_he} keeps you close."
                : "While you are both slow dancing, {npc_he} slides {npc_his} hand under your top "
                  + "and gropes your breast over your bra with cocky confidence.";
        } else if (hasTrait(n, "Alcoholic")) {
            base = braless
                ? "While you are both slow dancing, {npc_his} sweaty hand slides clumsily under your top, "
                  + "fingers groping your bare breast with heavy, uncoordinated squeezes."
                : "While you are both slow dancing, {npc_his} damp hand moves under your top "
                  + "and squeezes your breast over your bra heavily while {npc_he} sways into you.";
        } else if (hasTrait(n, "Confrontational")) {
            base = braless
                ? "While you are both slow dancing, {npc_he} slides {npc_his} hand challengingly under your top, "
                  + "fingers groping your bare breast as if daring you to say something."
                : "While you are both slow dancing, {npc_he} moves {npc_his} hand under your top "
                  + "and gropes your breast over your bra with a testing grip.";
        } else {
            base = braless
                ? "{npc_His} hand slides under your top while you both sway, fingers finding and cupping your bare breast."
                : "{npc_His} hand moves under your shirt while you both dance, groping your breast through your bra.";
        }

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc = breastGropeMcReact(tier, d, braless, nipping);

        String clothing = breastGropeClothing(braless);
        String result = base + "\n\n" + mc;
        if (!clothing.isEmpty()) result += "\n\n" + clothing;
        return result;
    }
```

---

### buildBreastToPussyTransitionText
```java
String buildBreastToPussyTransitionText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hand moves from your breast down under your skirt.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean braless = state.hasTrait("exposed_breasts");
        boolean nipping = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");

        state.flagBreastGroped = true;
        state.flagPussyGroped  = true;
        state.flagFingered     = true;

        if (d.equals("blackout"))
            return "*Hand... moving from chest to between my legs while we dance. Fingers inside. The spinning room makes it hard to process.*";

        String base;
        if (hasTrait(n, "Sleazy")) {
            base = braless && nipping
                ? "While you are both swaying slowly to the music, {npc_his} hand first cups your breast over your thin top, "
                  + "thumb circling your hard, visible nipple. After a few moments squeezing and playing with your nipple, "
                  + "{npc_his} hand slides down your body, slips under the hem of your skirt, and cups your pussy, "
                  + "fingers pushing panties aside to rub bare folds before pushing a finger inside."
                : "While you are both swaying slowly to the music, {npc_his} hand first cups your breast, "
                  + "then slides down your body, slips under the hem of your skirt, and cups your pussy, "
                  + "fingers pushing panties aside to rub bare folds before pushing a finger inside.";
        } else if (hasTrait(n, "Jerk")) {
            base = "While you are both slow dancing, {npc_he} first cups your breast possessively, thumb on your nipple, "
                 + "then smirks as {npc_his} hand slides down under your skirt. {npc_His} fingers rub your pussy "
                 + "arrogantly before pushing one or two inside while {npc_he} grinds forward in time with the music.";
        } else if (hasTrait(n, "Alcoholic")) {
            base = "While you are both slow dancing, {npc_his} sweaty hand first lands heavily on your breast, "
                 + "squeezing clumsily, then slides down under your skirt. {npc_His} fingers rub messily "
                 + "before pushing inside while {npc_he} sways heavily into you.";
        } else if (hasTrait(n, "Confrontational")) {
            base = "While you are both slow dancing, {npc_he} first grips your breast challengingly, thumb on your nipple, "
                 + "then deliberately slides {npc_his} hand under your skirt. {npc_His} fingers rub your pussy "
                 + "before pushing inside as if daring you to object while {npc_he} pulls you flush in time with the music.";
        } else {
            base = "While you are both swaying to the music, {npc_his} hand moves from your breast down under your skirt, "
                 + "fingers rubbing then pushing inside you.";
        }

        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*{npc_He} escalated from my breast to fingering me while we're slow dancing. The violation feels continuous and wrong even through the haze.*";
            else if (tier.equals("enjoy"))
                mc = "*{npc_He} went from my tits to fingering me while we dance... it feels so dirty and hot. The alcohol makes me clench around {npc_his} fingers.*";
            else
                mc = "*The shift from chest to inside me as we dance registers, but the buzz makes it feel distant.*";
        } else {
            if (tier.equals("shy"))
                mc = "You feel his hand cup and squeeze your breast, then it slides down under your skirt. "
                   + "{npc_His} fingers rub your pussy and one pushes inside while you both sway together."
                   + "\n\n*{npc_He} went from groping my breast to fingering me under my skirt while we're slow dancing. "
                   + "The violation feels even worse with the smooth transition. I feel exposed and powerless.*";
            else if (tier.equals("enjoy"))
                mc = "You feel {npc_his} hand on your breast, then it slides down under your skirt, "
                   + "{npc_his} fingers rubbing your bare pussy before one pushes inside while you both continue swaying."
                   + "\n\n*{npc_He} started with my breasts and now {npc_his} finger is inside me while we dance... "
                   + "the escalation feels so bold and arousing. The public risk is making me wetter.*";
            else
                mc = "{npc_His} hand moves from your breast down under your skirt, fingers rubbing then pushing inside "
                   + "while you both sway to the music."
                   + "\n\n*The shift from my breast to inside me as we dance registers, but I feel mostly detached about it.*";
        }
        return base + "\n\n" + mc;
    }
```

---

### buildFullEscalationText
```java
String buildFullEscalationText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hands have been everywhere.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean braless = state.hasTrait("exposed_breasts");
        boolean nipping = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");

        state.flagBreastGroped = true;
        state.flagAssGroped    = true;
        state.flagPussyGroped  = true;
        state.flagFingered     = true;

        if (d.equals("blackout"))
            return "*Hands moving... from chest to ass to inside while we dance. Warm. Spinning. Hard to tell what's happening.*";

        String base;
        if (hasTrait(n, "Sleazy")) {
            base = braless && nipping
                ? "While you are both swaying slowly to the music, {npc_his} hand first slides up and cups your breast over your thin top. "
                  + "Because you're braless, your hard nipples are clearly visible and poking through. "
                  + "{npc_His} thumb circles one stiff nipple, squeezing the soft flesh. "
                  + "After a few moments {npc_he} slides {npc_his} hand down your body, cups your ass firmly — fingers spreading and digging in — "
                  + "then continues lower, slipping under the hem of your skirt. "
                  + "{npc_His} fingers push your panties aside and rub your bare pussy before one finger slides inside you, "
                  + "curling slowly as you both keep moving together to the rhythm."
                : "While you are both swaying slowly, {npc_his} hand first cups your breast, then slides down to cup and squeeze your ass, "
                  + "then continues under your skirt — fingers rubbing your pussy before one slides inside while you keep moving together.";
        } else if (hasTrait(n, "Jerk")) {
            base = "While you are both slow dancing, {npc_he} first cups your breast possessively, thumb rolling your hard nipple. "
                 + "{npc_He} then slides {npc_his} hand down, cups and squeezes your ass like {npc_he} owns it, "
                 + "before slipping under your skirt. {npc_His} fingers rub your pussy arrogantly and push one or two inside "
                 + "while {npc_he} grinds forward in time with the music.";
        } else if (hasTrait(n, "Alcoholic")) {
            base = "While you are both slow dancing, {npc_his} sweaty hand lands on your breast, squeezing clumsily, "
                 + "then slides down to grab your ass, then slips under your skirt. "
                 + "{npc_His} fingers rub your pussy messily before pushing inside while {npc_he} sways heavily into you.";
        } else if (hasTrait(n, "Confrontational")) {
            base = "While you are both slow dancing, {npc_he} first grips your breast challengingly, "
                 + "then slides {npc_his} hand down to cup your ass, then deliberately moves under your skirt, "
                 + "{npc_his} fingers rubbing your pussy before pushing inside as if daring you to object.";
        } else {
            base = "While you are both swaying, {npc_his} hands move from your breast to your ass to under your skirt, "
                 + "fingers eventually pushing inside you.";
        }

        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*{npc_He} progressed from groping my breast to my ass to fingering me while we're slow dancing. "
                   + "The violation feels continuous and overwhelming with every movement.*";
            else if (tier.equals("enjoy"))
                mc = "*{npc_He} went from my tits to my ass to fingering me while we dance... "
                   + "it feels so dirty and hot. The alcohol makes me want to press into every touch.*";
            else
                mc = "*{npc_His} hand moved from my chest to my ass to inside me as we dance. It registers, but everything feels hazy and unimportant.*";
        } else {
            if (tier.equals("shy"))
                mc = "*{npc_He} went from groping my visible nipples to squeezing my ass to pushing {npc_his} finger inside me "
                   + "while we're slow dancing. The continuous violation feels overwhelming. "
                   + "I feel exposed and powerless with every sway.*";
            else if (tier.equals("enjoy"))
                mc = "*{npc_He} started with my breasts, playing with my hard nipples while we danced, "
                   + "then moved to squeezing my ass, and now {npc_his} finger is inside me... "
                   + "the smooth escalation while we sway feels so bold and arousing. "
                   + "The public risk is making me wetter with every move.*";
            else
                mc = "*{npc_His} hand moved from my breast to my ass to inside me while we dance. "
                   + "The progression registers, but I feel mostly detached as we keep swaying.*";
        }
        return base + "\n\n" + mc;
    }
```

---

### buildFingeringToOrgasmText
```java
String buildFingeringToOrgasmText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "The stimulation builds until your body gives.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");

        if (d.equals("blackout"))
            return "Something... inside while we dance. Cumming... The spinning room swallows everything.";

        String base;
        if (hasTrait(n, "Sleazy")) {
            base = "While you are both swaying slowly to the music, {npc_his} finger is already inside you, curling and thrusting shallowly. "
                 + "{npc_He} adds a second finger, stretching you, keeping the slow rhythm of the dance. "
                 + "{npc_His} thumb finds your clit and rubs in firm circles as the song continues. "
                 + "The stimulation builds steadily until you cum.";
        } else if (hasTrait(n, "Jerk")) {
            base = "While you are both slow dancing, {npc_his} fingers are inside you, thrusting arrogantly in time with the music. "
                 + "{npc_His} thumb presses firmly on your clit, rubbing with cocky confidence until you cum.";
        } else if (hasTrait(n, "Alcoholic")) {
            base = "While you are both slow dancing, {npc_his} sweaty fingers are inside you, thrusting messily. "
                 + "{npc_His} thumb rubs your clit clumsily but persistently until you cum.";
        } else if (hasTrait(n, "Confrontational")) {
            base = "While you are both slow dancing, {npc_his} fingers are inside you, thrusting challengingly. "
                 + "{npc_His} thumb presses on your clit as if daring you to cum while {npc_he} pulls you flush against {npc_him}.";
        } else {
            base = "{npc_His} fingers keep moving inside you while you both sway, thumb finding your clit, until the stimulation crests.";
        }

        String npcComment = "";
        if (hasTrait(n, "Jerk"))      npcComment = "\n\n\"You act like you don't want it. Feel that.\"";
        if (hasTrait(n, "Sleazy"))    npcComment = "\n\n\"There it is. Feel how good my fingers are inside you while we dance.\"";";
        if (hasTrait(n, "Alcoholic")) npcComment = "\n\n\"Aww, you're cumming on my fingers while we dance, sweetheart…\"";
        if (hasTrait(n, "Confrontational")) npcComment = "\n\n\"See? Your body says yes even while we dance.\"";

        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "Your body tenses and you cum against your will, thighs shaking as shame floods you."
                   + "\n\n*{npc_His} fingers are inside me while we're dancing and I'm cumming anyway. The violation feels even worse with the forced orgasm.*";
            else if (tier.equals("enjoy"))
                mc = "Your breath catches, thighs trembling as a powerful orgasm washes over you, clenching around {npc_his} fingers while you keep swaying."
                   + "\n\n*{npc_His} fingers inside me while we dance... I'm cumming so hard. The buzz makes it feel intense and addictive.*";
            else
                mc = "Your body tenses and releases in a quiet, detached orgasm while you both continue rocking to the music."
                   + "\n\n*The stimulation while we dance leads to an orgasm. It feels far away and unimportant.*";
        } else {
            if (tier.equals("shy"))
                mc = "Your body betrays you — thighs shaking as an intense, unwanted orgasm crashes through you, clenching around {npc_his} fingers while you try to stay upright."
                   + "\n\n*{npc_His} fingers are inside me while we're dancing... I don't want this but my body is cumming anyway. "
                   + "The shame is overwhelming. I feel violated and humiliated as the orgasm forces itself through me.*";
            else if (tier.equals("enjoy"))
                mc = "Your breath catches, thighs trembling as a powerful orgasm washes over you, clenching around {npc_his} fingers while you try to keep swaying normally."
                   + "\n\n*{npc_His} fingers inside me while we dance... the way {npc_he}'s rubbing my clit... I'm going to cum right here on the dance floor. "
                   + "The risk and the rhythm push me over the edge. The orgasm hits hard and leaves me shaking against {npc_him}.*";
            else
                mc = "Your body tenses and releases in a quiet, detached orgasm, clenching around {npc_his} fingers with minimal outward reaction."
                   + "\n\n*{npc_His} fingers are inside me as we dance... I feel the build-up and then the release. It happens, but everything feels distant and neutral.*";
        }
        return base + npcComment + "\n\n" + mc;
    }
```

---

### buildAboutToCumText
```java
String buildAboutToCumText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "The sensation is cresting. You're running out of time.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean commando = state.hasTrait("commando");
        boolean isShy    = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOut    = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");
        int roll = rng.nextInt(3);

        if (d.equals("blackout"))
            return "Something… building. About to… while we dance. Can't think clearly."
                 + (commando ? "\n\n*No panties… bare… close…*" : "");

        // ── Physical setup ────────────────────────────────────────────────────
        String setup = d.equals("drunk")
            ? "His fingers curl and stroke inside you while you both rock to the music. The edge suddenly rushes toward you."
            : "His fingers are pumping steadily inside you under your skirt while you both sway. The pressure builds relentlessly until it hits a tipping point.";

        // ── Commando note ─────────────────────────────────────────────────────
        String commandoNote = commando
            ? tier.equals("shy")
                ? "\n\n*Oh god, I'm not wearing anything underneath… if I cum everyone might see how wet I am. Panic surges.*"
                : tier.equals("enjoy")
                    ? "\n\n*Fuck… no panties and he's fingering me right here on the dance floor… I'm going to cum so hard if he doesn't stop.*"
                    : "\n\n*No panties… his fingers are inside me completely bare while we dance. Orgasm incoming.*"
            : "";

        // ── MC internal realisation by tier ───────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy")) {
                mc = isShy
                    ? "*No… I'm going to cum on his fingers while we're dancing… everyone might notice. The shame is overwhelming but I can't stop my body.*"
                    : "*No… if he keeps going I'm going to cum on the dance floor… everyone will see. Panic floods me but my body won't listen.*";
            } else if (tier.equals("enjoy")) {
                mc = "*Oh fuck… I'm going to cum right here while we slow dance… the alcohol makes the idea feel dangerously hot.*";
            } else {
                mc = "*I'm about to cum while we dance… the realization is there but the haze softens it.*";
            }
        } else {
            if (tier.equals("shy")) {
                mc = switch (roll) {
                    case 0 -> "*Oh no… if he doesn't stop I'm going to cum right here on the dance floor… everyone will know… I can't let this happen.*";
                    case 1 -> "*No… if he keeps going I'm going to cum on the dance floor… everyone will see. Panic floods me but my body won't listen.*";
                    default -> "*He's going to make me cum while we're still dancing… I can feel it building and I can't stop it.*";
                };
            } else if (tier.equals("enjoy")) {
                mc = switch (roll) {
                    case 0 -> "*Oh god… if he doesn't stop I'm going to cum right here while we're dancing… the thought is terrifying but so arousing.*";
                    case 1 -> "*He's going to make me cum while we're slow dancing… the public risk feels so dirty and exciting. I'm right on the edge.*";
                    default -> "*Fuck… I'm so close. If he keeps fingering me while we dance I'm going to cum in front of everyone.*";
                };
            } else {
                mc = switch (roll) {
                    case 0 -> "*If he doesn't stop soon I'm going to orgasm while we're still dancing. The realization is there but it feels distant.*";
                    case 1 -> "*The feeling is getting too strong… if he doesn't stop I'm going to cum while we dance.*";
                    default -> "*If this keeps going I'm going to cum while we dance… the thought registers but feels muted.*";
                };
            }
        }

        // ── Spoken line ───────────────────────────────────────────────────────
        String spoken;
        if (isShy)
            spoken = "\"Wait… I think I'm going to… please slow down…\" (tiny, trembling whisper)";
        else if (isOut)
            spoken = "\"Hey — slow down or I'm going to cum right here…\"";
        else
            spoken = "\"I… I think I'm getting close… can you stop for a second?\"";

        return setup + "\n\n" + mc + commandoNote + "\n\n" + spoken;
    }
```

---

### buildMcSaysStopFingeringText
```java
String buildMcSaysStopFingeringText() {
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean isShy = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOut = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");
        int roll = rng.nextInt(4);

        if (d.equals("blackout"))
            return "Your head spins as you barely manage to mumble against him. \"St… stop… 'm gonna…\"";

        String internal;
        String spoken;

        if (d.equals("drunk")) {
            if (tier.equals("enjoy")) {
                internal = "*Fuck… stop or I'm gonna cum all over his fingers while we dance…*";
                spoken = "\"Fuck… stop or I'm gonna cum all over your fingers while we dance…\"";
            } else if (tier.equals("shy") || isShy) {
                internal = "*Stop—please stop, I'm gonna cum… everyone will see…*";
                spoken = "\"Stop—please stop, I'm gonna cum… everyone will see…\"";
            } else {
                internal = "*Stop. Gonna cum soon.*";
                spoken = "\"…Stop. Gonna cum soon.\"";
            }
        } else {
            // sober/tipsy
            if (tier.equals("enjoy")) {
                spoken = isShy
                    ? "\"Mmm… stop, or I'm really going to cum right here…\"  (husky, half-hearted)"
                    : "\"Stop… or I'm really going to cum right here while we're dancing…\"";
                internal = "*I'm right on the edge. If he keeps going I'm cumming on the dance floor.*";
            } else if (isShy) {
                spoken = switch (roll) {
                    case 0 -> "\"P-please… stop…\" (barely a whisper, voice cracking, clutching his shirt)";
                    case 1 -> "\"Stop — you have to stop right now…\"";
                    case 2 -> "\"Please… I can't… stop…\"";
                    default -> "\"Please stop… I'm about to…\"";
                };
                internal = "*Oh god, I have to say it louder… but everyone might hear… but I can't cum here.*";
            } else if (isOut) {
                spoken = switch (roll) {
                    case 0 -> "\"Hey, stop fingering me or I'm going to cum right here on the dance floor.\"";
                    case 1 -> "\"Stop — I mean it. I'm right on the edge.\"";
                    case 2 -> "\"Stop fingering me right now or I'm cumming in front of everyone.\"";
                    default -> "\"He needs to hear it clear.\" \"Stop. Right now.\"";
                };
                internal = "*He needs to hear it clearly. I'm right on the edge.*";
            } else {
                spoken = switch (roll) {
                    case 0 -> "\"Um… can you stop? I think I'm… really close…\"";
                    case 1 -> "\"…You should stop. I'm getting too close.\"";
                    case 2 -> "\"I… I think I'm about to cum. Please stop.\"";
                    default -> "\"Can you stop? I'm about to…\"";
                };
                internal = "*I should tell him it's getting too intense.*";
            }
        }

        return "You grab at {npc_his} wrist while you both sway."
             + "\n\n" + internal
             + "\n\n" + spoken;
    }
```

---

### buildNpcRefusesStopText
```java
String buildNpcRefusesStopText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_He} keeps going.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        int roll = rng.nextInt(4);

        if (d.equals("blackout"))
            return "{npc_He} barely acknowledges your words, just keeps working {npc_his} fingers inside you as you sag against {npc_him}. \"Yeah… that's it. Just dance.\"";

        // ── NPC refusal line by trait and drunk level ─────────────────────────
        String npcLine;
        if (hasTrait(n, "Sleazy")) {
            npcLine = switch (roll) {
                case 0 -> d.equals("drunk")
                    ? "{npc_He} holds you tighter, fingers thrusting without pause. \"Shh, don't fight it. I'm not stopping until you cum right here on the dance floor.\""
                    : "{npc_He} leans in closer, lips brushing your ear as {npc_his} fingers keep pumping. \"Nah… you feel too good. Just keep dancing, baby. Let it happen.\"";
                case 1 -> "{npc_He} chuckles lowly, grip tightening on your waist while {npc_his} fingers curl deeper. \"Stop? Not a chance. You're soaking my hand… keep swaying and enjoy it.\"";
                case 2 -> "He tightens his hold on your waist, fingers not even slowing. \"Not a chance. You're clenching so tight — I want to feel you cum on my fingers while we dance.\"";
                default -> "{npc_He} smirks against your ear, fingers thrusting steady. \"Nah, you're not stopping me now. Just let go.\"";
            };
        } else if (hasTrait(n, "Jerk")) {
            npcLine = switch (roll) {
                case 0 -> "{npc_He} smirks and keeps going, fingers curling with deliberate slowness. \"Make me stop, then. Tell everyone what I'm doing to you if you want me to quit.\"";
                case 1 -> "{npc_He} grins against your ear. \"Too late for stop, sweetheart. Feel how wet you are? You're gonna cum for me right here.\"";
                case 2 -> "{npc_He} keeps thrusting without breaking the dance rhythm. \"You're soaked and you're begging me to stop. Pick one.\"";
                default -> "{npc_He} just laughs softly and presses deeper. \"Relax. I'll stop when you've cum.\"";
            };
        } else if (hasTrait(n, "Confrontational")) {
            npcLine = "{npc_He} grins and fingers you faster instead of slower. \"You say stop but you're clenching harder. Your body's decided for you.\"";
        } else if (hasTrait(n, "Alcoholic")) {
            npcLine = "\"Aww c'mon… feels good, right?\" {npc_He} slurs, fingers staying inside you while {npc_he} sways heavier against you.";
        } else {
            npcLine = "{npc_He} just hums and keeps the same rhythm, holding you close. \"No can do. Just sway with me… let it build.\"";
        }

        // ── MC reaction to being ignored ──────────────────────────────────────
        String mc;
        if (tier.equals("enjoy"))
            mc = "*{npc_His} refusal sends a fresh wave of heat through you. The risk of cumming publicly because {npc_he} won't listen is turning you on even more.*";
        else if (tier.equals("shy"))
            mc = "*Panic floods you as {npc_he} ignores your plea. You're trapped on the dance floor, about to orgasm in front of everyone and {npc_he} won't stop.*";
        else
            mc = "*The realisation that {npc_he}'s not stopping settles in dully. Your body is going to cum while you sway to the music, whether you protest or not.*";

        return npcLine + "\n\n" + mc;
    }
```

---

### buildMcSaysStopCumsText
```java
String buildMcSaysStopCumsText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "You say stop. The stimulation continues anyway.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        int roll    = rng.nextInt(3); // vary the specific version

        if (d.equals("blackout"))
            return "You mumble incoherently, \"St… stop…\" but the words dissolve. "
                 + "{npc_His} fingers keep thrusting inside you while you both move slowly together. "
                 + "The stimulation builds until your body tenses and releases in a hazy, overwhelming orgasm. "
                 + "You shudder against {npc_him}, barely aware of what's happening as the world spins."
                 + "\n\n*Fingers… inside while we dance… cumming… Everything is spinning and blurry.*";

        // ── MC refusal (drunk vs sober/tipsy) ────────────────────────────────
        String refusal;
        if (d.equals("drunk")) {
            refusal = switch (roll) {
                case 0 -> "You slur thicker, \"Stop… get your fingers out,\" and push weakly at {npc_his} arm under your skirt.";
                case 1 -> "You slur, \"Stop… not while we're dancing,\" but your hips keep moving with the music.";
                default -> "You grab at {npc_his} wrist under your skirt and mumble, \"Get your fingers out…\"";
            };
        } else {
            refusal = switch (roll) {
                case 0 -> "You gasp, \"Stop… please stop fingering me,\" and push at {npc_his} arm while you both sway to the music.";
                case 1 -> "You say clearly, \"Stop fingering me,\" and try to shift your hips away while you both continue moving together.";
                default -> "You mutter, \"Stop… not while we're dancing,\" and push weakly at {npc_his} wrist.";
            };
        }

        // ── NPC ignores and continues with dirty talk ─────────────────────────
        String npcIgnores;
        if (hasTrait(n, "Sleazy")) {
            npcIgnores = switch (roll) {
                case 0 -> "\"Shh, you say stop but your pussy is clenching so tight while we dance.\" {npc_He} chuckles low and keeps thrusting, thumb rubbing harder on your clit.";
                case 1 -> "\"You say stop but you're soaking my hand while we dance.\" {npc_His} fingers keep moving, curling deeper.";
                default -> "\"You say stop but you're creaming on my fingers while we dance.\" He laughs and pushes a second finger in.";
            };
        } else if (hasTrait(n, "Jerk")) {
            npcIgnores = switch (roll) {
                case 0 -> "\"You say stop but your pussy is milking my fingers while we dance.\" {npc_He} smirks and thrusts deeper.";
                case 1 -> "\"You say stop but you're cumming anyway while we dance. Pathetic.\" {npc_He} keeps thrusting arrogantly.";
                default -> "\"Feel that? You're cumming anyway while we dance.\" {npc_He} ignores you and keeps going.";
            };
        } else if (hasTrait(n, "Alcoholic")) {
            npcIgnores = switch (roll) {
                case 0 -> "\"Feels good though, don't it?\" {npc_He} slurs and keeps thrusting messily.";
                case 1 -> "\"Aww, don't be like that… you're cumming while we dance, sweetheart.\" {npc_His} hand lingers and keeps going.";
                default -> "\"Just a little more…\" {npc_He} mumbles, fingers still moving sloppily.";
            };
        } else if (hasTrait(n, "Confrontational")) {
            npcIgnores = switch (roll) {
                case 0 -> "\"You say stop but you're cumming while we dance.\" {npc_He} grins darkly and keeps thrusting.";
                case 1 -> "\"See? Your body says yes even if your mouth says no.\" {npc_He} keeps the rhythm going.";
                default -> "\"You're not stopping me, are you?\" {npc_He} thrusts deeper, daring you.";
            };
        } else {
            npcIgnores = "{npc_He} doesn't stop.";
        }

        // ── Orgasm ────────────────────────────────────────────────────────────
        String orgasm = d.equals("drunk")
            ? "Your body locks up and you cum violently, thighs shaking, pussy clenching around {npc_his} fingers while you both continue rocking to the music. A shaky gasp escapes as the orgasm rips through you."
            : "Your body betrays you — thighs trembling as a powerful orgasm crashes through you, clenching around {npc_his} fingers while you try to keep swaying normally. You bite your lip hard to stay quiet.";

        // ── MC internal ───────────────────────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*I told {npc_him} to stop and {npc_he}'s still fingering me while we're dancing. I'm cumming against my will. The violation and shame feel crushing.*";
            else if (tier.equals("enjoy"))
                mc = "*I said stop but I'm cumming so hard while we dance… {npc_his} fingers feel too good. The alcohol makes the pleasure overwhelming.*";
            else
                mc = "*I said stop but {npc_his} fingers kept going. I cum anyway while we sway. It feels far away and unimportant.*";
        } else {
            if (tier.equals("shy")) {
                mc = switch (roll) {
                    case 0 -> "*I said stop but his fingers feel too good while we dance… I'm cumming right here. The risk and his dirty words make the orgasm hit even harder.*";
                    case 1 -> "*I told him to stop and he's still fingering me while we're dancing. I'm cumming anyway. The shame is crushing.*";
                    default -> "*I said stop but his fingers kept moving. I cum anyway as we dance. It feels distant.*";
                };
                if (tier.equals("shy"))
                    mc = "*I said stop and {npc_he}'s still fingering me while we're dancing. I'm cumming against my will. "
                       + "The shame is overwhelming — my body betrayed me right here on the dance floor.*";
            } else if (tier.equals("enjoy")) {
                mc = switch (roll) {
                    case 0 -> "*I said stop but his fingers feel so good inside me while we dance… I'm cumming anyway. The risk and the rhythm make the orgasm hit even harder. I hate that I like it.*";
                    case 1 -> "*I told him to stop but I'm cumming so hard right now while we dance. The way he's fingering me makes it impossible to fight.*";
                    default -> "*I said stop but the orgasm came anyway while we sway. Part of me wanted it. Part of me hates that.*";
                };
            } else {
                mc = "*I said stop but {npc_his} fingers kept going while we sway. I cum anyway. It happens, but it feels distant and mechanical.*";
            }
        }

        return refusal + "\n\n" + npcIgnores + "\n\n" + orgasm + "\n\n" + mc;
    }
```

---

### buildOrgasmAftermathText
```java
String buildOrgasmAftermathText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "The orgasm passes. You both keep dancing.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean commando = state.hasTrait("commando");
        boolean braless  = state.hasTrait("exposed_breasts");

        if (d.equals("blackout"))
            return "Something intense just happened while we danced. Now it's fading. Still swaying. Can't think clearly.";

        // NPC comment as fingers withdraw
        String npcLine;
        if (hasTrait(n, "Sleazy"))
            npcLine = "{npc_He} slowly withdraws {npc_his} fingers, satisfied. \"Good girl… you just came all over my fingers while we were dancing.\"";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_He} smirks as your body stops shaking. \"See? You came anyway. Not so resistant after all.\"";
        else if (hasTrait(n, "Engaging"))
            npcLine = "{npc_He} holds you gently as you tremble, then carefully withdraws {npc_his} hand. \"You okay?\" {npc_He} asks softly.";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcLine = "{npc_He} laughs warmly as your body shakes. \"Damn, you just came on the dance floor! That was hot.\"";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "{npc_He} smirks and slowly withdraws. \"Body said yes even if your mouth didn't.\"";
        else
            npcLine = "{npc_His} fingers slowly withdraw as your shaking eases.";

        // Commando note
        String clothing = commando
            ? (tier.equals("shy")
                ? "\n\n*No panties... I just came and now I can feel it running down my leg while we dance. So exposed.*"
                : "\n\n*The wetness from cumming is running down my bare thigh while we keep swaying.*")
            : "";

        // MC internal aftermath
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*I came hard but now I just feel gross and used... the afterglow is gone and all that's left is humiliation and regret.*";
            else if (tier.equals("enjoy"))
                mc = "*He made me cum so hard while we were dancing... the alcohol turns the aftershocks into pure bliss. I'm still trembling.*";
            else
                mc = "*The release happened and now it's passing. We're still dancing. Everything feels hazy and emotionally flat.*";
        } else {
            if (tier.equals("shy"))
                mc = "Your body shudders as the unwanted orgasm passes, shame crashing in immediately."
                   + "\n\n*He fingered me until I came on the dance floor... I didn't want it but my body betrayed me. I feel dirty and violated.*";
            else if (tier.equals("enjoy"))
                mc = "A soft moan escapes before you can stop it as the pleasure crests and then subsides."
                   + "\n\n*He just made me cum while we were slow dancing... the intense release feels incredible, even in public. My legs are still shaking.*";
            else
                mc = "Your body trembles as the orgasm passes while you both sway to the music."
                   + "\n\n*The release happened, but I mostly feel empty and detached as we keep dancing.*";
        }

        return npcLine + "\n\n" + mc + clothing;
    }
```

---

### buildShakyLegsRecoveryText
```java
String buildShakyLegsRecoveryText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "Your legs shake. You both keep swaying.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean commando = state.hasTrait("commando");
        boolean braless  = state.hasTrait("exposed_breasts");
        boolean nipping  = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");

        if (d.equals("blackout"))
            return "Legs... shaking. He's holding you up while you sway. Everything is spinning and distant.";

        // NPC holds her through recovery
        String npcLine;
        if (hasTrait(n, "Sleazy"))
            npcLine = "{npc_He} keeps {npc_his} arm tightly around your waist, pulling you flush against {npc_him} as your legs shake, "
                    + "continuing to sway slowly with you. \"Your legs are shaking so much... you came hard for me, didn't you?\"";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_He} holds you possessively with one arm around your waist, smirking as your legs tremble while you both sway. "
                    + "\"Look at those shaky legs... you came anyway. Pathetic.\"";
        else if (hasTrait(n, "Engaging"))
            npcLine = "{npc_He} wraps {npc_his} arm securely around your waist, supporting your shaky legs gently while continuing to sway with you. "
                    + "\"I've got you... take your time.\"";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcLine = "{npc_He} laughs warmly and pulls you tighter against {npc_him} with both arms as your legs tremble. "
                    + "\"Whoa, shaky legs! That must've been a good one — I've got you!\"";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "{npc_He} keeps {npc_his} arm locked around your waist, smirking as your legs shake while you both sway together.";
        else
            npcLine = "{npc_He} keeps one arm around your waist, supporting you while your legs tremble and you both continue swaying.";

        // Clothing note
        String clothing = "";
        if (commando)
            clothing = tier.equals("shy")
                ? "\n\n*No panties... my legs are shaking and I can feel my own wetness running down my thighs while he keeps dancing with me. So humiliating.*"
                : "\n\n*The wetness from cumming is running down my bare thighs while we keep moving together.*";
        else if (braless && nipping && state.flagBreastGroped)
            clothing = tier.equals("enjoy")
                ? "\n\n*He's still touching my bare breast under my shirt while holding me through my shaky legs... the full-body afterglow feels intense.*"
                : "";

        // MC internal
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*My legs won't stop shaking and he's forcing us to keep dancing like nothing happened... I feel disgusting and used.*";
            else if (tier.equals("enjoy"))
                mc = "*My legs are so shaky from cumming hard while we danced, but he's holding me tight... the afterglow feels heavy and good.*";
            else
                mc = "*The shakiness is there, but we're still just dancing. The feeling fades into the haze.*";
        } else {
            if (tier.equals("shy"))
                mc = "Your legs shake uncontrollably after the orgasm, but he keeps swaying with you, arm locked around your waist."
                   + "\n\n*My legs are weak from cumming on his fingers and he's keeping us dancing... I feel trapped and humiliated while my body betrays me.*";
            else if (tier.equals("enjoy"))
                mc = "Your legs tremble as the aftershocks fade, but his arm around your waist keeps you steady while you both sway."
                   + "\n\n*My legs are shaking from cumming while we danced, but he's holding me and we're still dancing together... the support feels surprisingly intimate.*";
            else
                mc = "Your legs shake as the orgasm passes, but he continues swaying with you, arm supporting your weight."
                   + "\n\n*My legs are shaking, but we're still just dancing. The weakness feels distant and unimportant.*";
        }

        return npcLine + "\n\n" + mc + clothing;
    }
```

---

### buildCommandoDiscoveryText
```java
String buildCommandoDiscoveryText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hand finds bare skin instead of fabric.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean cameltoe   = state.hasTrait("camel_toe");
        boolean breastAlso = state.flagBreastGroped && state.hasTrait("exposed_breasts");

        state.flagPussyGroped = true;

        if (d.equals("blackout"))
            return "Hand... under my skirt. No panties. Bare. Fingers touching. Spinning. Hard to process.";

        // ── NPC discovery + first reaction ───────────────────────────────────
        String npcLine;
        if (hasTrait(n, "Sleazy"))
            npcLine = "{npc_His} fingers freeze for a second, then a low groan escapes against your ear. "
                    + "\"No fucking panties? You dirty little slut... you came out like this just for me?\" "
                    + "{npc_His} hand stays under your skirt, exploring openly.";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_He} smirks the second his fingers touch bare skin instead of fabric. "
                    + "\"No panties? Figures. Makes things easier for me.\" "
                    + "{npc_He} doesn't pull {npc_his} hand out.";
        else if (hasTrait(n, "Engaging"))
            npcLine = "{npc_His} hand pauses in surprise when {npc_his} fingers touch bare skin. "
                    + "{npc_He} gently strokes your bare skin while continuing to sway. "
                    + "\"You're not wearing anything underneath... that's bold. You okay with me touching you like this?\"";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcLine = "{npc_He} laughs warmly against your ear the moment {npc_his} fingers find bare skin. "
                    + "\"Whoa — no panties? You came ready to party! That's hot.\"";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "{npc_His} hand stops when it finds bare skin, then presses harder — deliberately. "
                    + "\"No panties. Good.\" Said like it was expected.";
        else if (hasTrait(n, "Alcoholic"))
            npcLine = "{npc_His} hand stops when it finds bare skin. "
                    + "\"Oh damn… nothing there…\" {npc_He} slurs, then starts rubbing sloppily.";
        else
            npcLine = "{npc_His} hand pauses when it finds bare skin instead of fabric, "
                    + "then resumes with noticeably more intent.";

        // ── Cameltoe note ─────────────────────────────────────────────────────
        String camelNote = cameltoe
            ? "\n\n*He could probably already see the outline... now his hand is confirming I'm bare underneath.*"
            : "";

        // ── Combined grope note ───────────────────────────────────────────────
        String combined = breastAlso
            ? "\n\n*One hand on my bare breast under my shirt, the other just found out I have no panties... the dual discovery feels overwhelming.*"
            : "";

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*{npc_He} just discovered I have no panties... his hand is now on my bare pussy while we're slow dancing. The violation feels even more intense.*";
            else if (tier.equals("enjoy"))
                mc = "*{npc_He} just realized I'm completely bare underneath... the surprised hunger in {npc_his} touch feels so dirty and hot. The alcohol makes me grind into {npc_his} fingers.*";
            else
                mc = "*The discovery that I'm commando registers, but the buzz makes the sensation feel distant.*";
        } else {
            if (tier.equals("shy"))
                mc = "His fingers brush upward along your thigh and suddenly touch bare skin with no fabric barrier. "
                   + "{npc_He} freezes for a split second, then presses against your naked pussy while you both continue swaying."
                   + "\n\n*{npc_He} just discovered I have no panties... his hand is now touching my bare pussy while we're slow dancing in public. I feel completely exposed.*";
            else if (tier.equals("enjoy"))
                mc = "His hand slides under your skirt and pauses when it reaches bare skin instead of panties. "
                   + "{npc_His} fingers press against your naked pussy while you both continue swaying."
                   + "\n\n*{npc_He} just found out I'm not wearing anything underneath... the surprise in {npc_his} touch feels thrilling and risky while we dance.*";
            else
                mc = "His hand slides under your skirt and pauses when it finds bare skin instead of panties. "
                   + "{npc_His} fingers rest against your naked pussy while you both sway."
                   + "\n\n*The discovery that I'm commando registers as {npc_his} hand touches me, but I feel mostly detached.*";
        }

        return npcLine + "\n\n" + mc + camelNote + combined;
    }
```

---

### buildCommandoReactionText
```java
String buildCommandoReactionText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_He} reacts to the bare skin.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");

        state.flagPussyGroped = true;

        if (d.equals("blackout"))
            return "Hand... under my skirt. No panties. Bare. He's rubbing. Spinning. Hard to process.";

        // ── Extended NPC action after discovery ───────────────────────────────
        String npcLine;
        if (hasTrait(n, "Sleazy"))
            npcLine = "{npc_He} groans loudly against your ear and immediately starts rubbing your bare pussy "
                    + "with greedy fingers while continuing to sway with you. "
                    + "\"No fucking panties? You dirty girl... you came out ready for this, didn't you?\" "
                    + "{npc_His} hand stays under your skirt, exploring openly.";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_He} smirks and presses {npc_his} fingers harder against your naked pussy, "
                    + "rubbing arrogantly while you both sway. "
                    + "\"No panties? Of course not. Makes things easier for me.\" "
                    + "{npc_He} doesn't pull {npc_his} hand out.";
        else if (hasTrait(n, "Engaging"))
            npcLine = "{npc_He} pauses in surprise when {npc_his} fingers touch bare skin, "
                    + "then gently strokes your naked pussy while continuing to sway with you. "
                    + "\"You're not wearing anything underneath... that's bold. "
                    + "You comfortable with me touching you like this?\" {npc_His} touch stays respectful but curious.";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcLine = "{npc_He} laughs warmly against your ear the moment {npc_he} discovers bare skin, "
                    + "then starts rubbing your naked pussy playfully while you both sway. "
                    + "\"Whoa — no panties? You really came ready to have fun tonight!\"";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "{npc_He} keeps {npc_his} hand there with deliberate pressure, "
                    + "fingers rubbing your bare pussy while you both sway together. "
                    + "\"No panties. Convenient.\" {npc_He} smirks like the answer to a question.";
        else if (hasTrait(n, "Alcoholic"))
            npcLine = "{npc_His} sweaty hand fumbles then starts rubbing your bare pussy sloppily "
                    + "while {npc_he} sways heavily into you. "
                    + "\"Damn… nothing there… nice…\" {npc_He} slurs against your neck.";
        else
            npcLine = "{npc_His} hand resumes with more intent now, fingers rubbing your bare pussy "
                    + "while you both continue swaying to the music.";

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*{npc_He} just discovered I have no panties and now {npc_he}'s groping my bare pussy while we're slow dancing. The violation feels even more intense.*";
            else if (tier.equals("enjoy"))
                mc = "*{npc_He} just found out I'm bare underneath... {npc_his} touch got so much hungrier the moment {npc_he} discovered it. The alcohol makes {npc_his} reaction feel hot and intense.*";
            else
                mc = "*The discovery and {npc_his} reaction are there, but his touching feels distant in the haze.*";
        } else {
            if (tier.equals("shy"))
                mc = "*{npc_He} discovered I have no panties... now {npc_he}'s groping my bare pussy while we're dancing. "
                   + "I feel like a toy {npc_he} just unlocked. The exposure is overwhelming.*";
            else if (tier.equals("enjoy"))
                mc = "*{npc_He} just found out I'm bare and {npc_his} touch changed completely the moment {npc_he} knew. "
                   + "The way {npc_he}'s reacting while we dance feels thrilling.*";
            else
                mc = "*The discovery that I'm commando and {npc_his} reaction register, but I feel mostly detached as we keep swaying.*";
        }

        return npcLine + "\n\n" + mc;
    }
```

---

### buildMidGropeMcStopText
```java
String buildMidGropeMcStopText() {
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean isShy      = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOutgoing = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");
        boolean fingered   = state.flagFingered;
        boolean pussy      = state.flagPussyGroped;
        boolean breast     = state.flagBreastGroped;
        int roll = rng.nextInt(4);

        if (d.equals("blackout"))
            return "Only a faint, broken sound escapes. \"...stop…\" — barely a whisper while your legs shake.";

        String spoken;
        if (d.equals("drunk")) {
            if (tier.equals("enjoy"))
                spoken = isShy ? "\"Slow down… too much…\"" : "\"Hey… ease up… it's a lot…\"";
            else if (tier.equals("shy") || isShy)
                spoken = switch (roll) {
                    case 0 -> "\"Please… take your hand out…\"";
                    case 1 -> "\"Stop… please stop touching me there…\"";
                    case 2 -> "\"I can't… stop…\"";
                    default -> "\"Don't… not like this…\"";
                };
            else
                spoken = isOutgoing
                    ? "\"Pull your hand back — too much.\"  "
                    : "\"Can you pull your hand out…? It's getting intense…\"";
        } else {
            // sober/tipsy
            if (tier.equals("enjoy"))
                spoken = "\"Wait… slow down a little…\"";
            else if (isShy)
                spoken = switch (roll) {
                    case 0 -> "\"Please… take it out…\"";
                    case 1 -> "\"Don't… not under my skirt…\"";
                    case 2 -> "\"Your hand… please remove it…\"";
                    default -> "\"I… I can't… stop…\"";
                };
            else if (isOutgoing)
                spoken = switch (roll) {
                    case 0 -> "\"Hey — hands out from under my skirt right now.\"";
                    case 1 -> "\"Slow down, that's too much. Pull your hand back.\"";
                    case 2 -> "\"I said stop — listen!\"";
                    default -> "\"Ease up under my clothes. Not cool.\"";
                };
            else
                spoken = switch (roll) {
                    case 0 -> "\"Can you… take your hand out? It's too much.\"";
                    case 1 -> "\"I'm not comfortable with your hand under my skirt…\"";
                    case 2 -> "\"Please stop… I don't want this right now.\"";
                    default -> "\"Your hand is under my clothes… can you move it?\"";
                };
        }

        // Internal thought
        String mc;
        if (tier.equals("shy"))
            mc = fingered
                ? "*{npc_His} fingers are still inside me while we dance… I said stop and he's still going. I feel so powerless.*"
                : "*{npc_His} hand is still there after I asked {npc_him} to stop… I don't know how to make {npc_him} listen.*";
        else if (tier.equals("enjoy"))
            mc = "*Even while protesting it still feels… something. I'm not sure if I mean the stop.*";
        else
            mc = pussy
                ? "*The touching is still happening under my skirt while we dance. I said stop.*"
                : "*My hand is under my clothes while we sway. I asked {npc_him} to stop.*";

        return "You grab at {npc_his} wrist and say, " + spoken
             + "\n\n" + mc;
    }
```

---

### buildHickeyPersistText
```java
String buildHickeyPersistText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_He} keeps sucking.";
        String d = drunkTier();
        boolean isShy      = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOutgoing = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");

        if (d.equals("blackout")) {
            state.addTimedTrait("Neck_Hickey", 4);
            return "You barely register the suction intensifying. "
                 + "By the time your body reacts, the mark is already there.";
        }

        // ── NPC-specific persistent action ────────────────────────────────────
        String npcLine;
        if (hasTrait(n, "Sleazy"))
            npcLine = "\"Just a little mark… it'll look hot on you.\" {npc_He} keeps sucking harder for a second, ignoring your first protest.";
        else if (hasTrait(n, "Jerk"))
            npcLine = "\"It's just a small mark. Don't be so uptight.\" {npc_He} keeps sucking until you physically pull away harder.";
        else if (hasTrait(n, "Magnetic"))
            npcLine = "{npc_He} pauses briefly when you protest but then continues with slower, deliberate suction. \"You don't want it? Too bad… it'll look good on you.\"";
        else if (hasTrait(n, "Self_Assured"))
            npcLine = "\"One small mark won't hurt.\" {npc_He} sucks a little longer, calm and certain.";
        else if (hasTrait(n, "Engaging"))
            npcLine = "\"Just a tiny one…\" {npc_He} sucks briefly after your first protest before catching himself.";
        else
            npcLine = "{npc_He} doesn't stop when you first try to pull away.";

        // ── MC reaction to NPC not stopping ───────────────────────────────────
        String mcReact;
        if (isShy) {
            mcReact = d.equals("drunk")
                ? "*He won't stop… the suction is getting stronger even though I'm trying to pull away. "
                  + "The shame is burning — I'm going to have a visible bruise.* "
                  + "You jerk your head back desperately, voice cracking, \"Please… stop now… I'm begging you not to leave a mark…\""
                : "*He's still sucking… I pulled away but he's not stopping. Everyone will see the mark tomorrow. I feel so powerless.* "
                  + "You yank your head back harder, voice small and trembling, \"Stop… please stop sucking my neck… I don't want a mark…\"";
        } else if (isOutgoing) {
            mcReact = d.equals("drunk")
                ? "You push at his shoulder lightly but firmly. \"I told you no — stop sucking my neck right now.\""
                : "You pull your neck away sharply and say firmly, \"Hey — I said no hickey. Stop it.\"";
        } else {
            mcReact = d.equals("drunk")
                ? "You hesitate, then pull away again. \"I'm not comfortable with a hickey… please stop…\""
                : "You shift uncomfortably and murmur, \"Can you… stop? I really don't want one there…\"";
        }

        return npcLine + "\n\n" + mcReact;
    }
```

---

### buildHickeyMarkLeftText
```java
String buildHickeyMarkLeftText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "A mark has formed on your neck.";
        String d = drunkTier();
        boolean isShy      = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOutgoing = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");

        state.addTimedTrait("Neck_Hickey", d.equals("drunk") ? 5 : 4);

        String size = d.equals("drunk") ? "noticeable small bruise" : "faint red spot";
        String sizeInternal = d.equals("drunk") ? "big… visible" : "faint… but there";

        String mcReact;
        if (isShy) {
            mcReact = d.equals("drunk")
                ? "*It's " + sizeInternal + "… I pushed as hard as I could but it's already there. "
                  + "How am I supposed to hide this?* "
                  + "You touch the spot with shaking fingers, whispering, \"It's already there… a big one…\""
                : "*Oh no… he left a mark. I can already feel it throbbing. How am I going to hide this?* "
                  + "You touch your neck self-consciously, face burning.";
        } else if (isOutgoing) {
            mcReact = d.equals("drunk")
                ? "You touch the spot and snap, \"You actually left a mark even after I pushed you away. Not cool.\""
                : "You pull away finally and touch your neck, voice annoyed. \"Great, now I have a hickey I didn't want.\"";
        } else {
            mcReact = d.equals("drunk")
                ? "You feel the spot and sigh. \"There's a pretty obvious mark now… I really didn't want that.\""
                : "You notice the warmth and touch the spot. \"I think you left a small mark…\"";
        }

        return "A " + size + " has already formed on your neck by the time you fully react.\n\n" + mcReact;
    }
```

---

### buildHickeyPushAwayText
```java
String buildHickeyPushAwayText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "You shove him away. A mark is left.";
        String d = drunkTier();
        boolean isShy      = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOutgoing = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");

        state.addTimedTrait("Neck_Hickey", d.equals("drunk") ? 5 : 4);

        // Push description
        String push = d.equals("drunk")
            ? "You shove against {npc_his} chest with both hands, forcing {npc_his} head back. "
              + "A noticeable bruise is already visible on your neck."
            : "You feel the strong suction and push firmly against {npc_his} chest, breaking the contact. "
              + "A small faint mark has already formed.";

        // MC reaction to discovering the mark
        String mcReact;
        if (isShy) {
            mcReact = d.equals("drunk")
                ? "*It's big… I pushed as hard as I could but he still managed to leave a huge mark. "
                  + "I want to disappear.* "
                  + "Tears prick your eyes as you whimper, \"It's already there… a big one…\""
                : "*I pushed him away but it's too late… I can feel the mark throbbing under my fingers. "
                  + "My heart is pounding.* "
                  + "You whisper shakily, barely audible, \"You left one anyway…\"";
        } else if (isOutgoing) {
            mcReact = d.equals("drunk")
                ? "You shove him back and say sharply, \"Look what you did — you left a hickey even after I pushed you!\""
                : "You push harder and touch your neck, voice annoyed. \"Great, you left a hickey even though I pushed you away.\"";
        } else {
            mcReact = d.equals("drunk")
                ? "You push him away and murmur uncomfortably, \"There's a pretty obvious mark now…\""
                : "You push him back and check your neck, quietly, \"There's already a mark… I can feel it.\"";
        }

        // NPC reaction after being pushed
        String npcAfter;
        if (hasTrait(n, "Sleazy"))
            npcAfter = "{npc_He} laughs crudely even after you shove him. \"Whoa, feisty. But look — you've got a nice hickey now anyway.\"";
        else if (hasTrait(n, "Jerk"))
            npcAfter = "{npc_He} smirks arrogantly after the push. \"Pushing me away and you still ended up with my mark. Cute.\"";
        else if (hasTrait(n, "Engaging"))
            npcAfter = "{npc_He} looks genuinely apologetic. \"Sorry — I got carried away. I didn't mean to leave a mark.\"";
        else if (hasTrait(n, "Magnetic"))
            npcAfter = "{npc_He} stops immediately but doesn't look sorry. {npc_His} gaze stays on the fresh mark. \"It looks good on you.\"";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcAfter = "{npc_He} laughs after the push. \"Whoa, you really shoved me! But hey — you've got a souvenir now!\"";
        else if (hasTrait(n, "Alcoholic"))
            npcAfter = "\"Didn't hear you over the music, babe.\" {npc_He} sways unsteadily, half-apologetic.";
        else
            npcAfter = "{npc_He} pulls back. The mark remains.";

        return push + "\n\n" + mcReact + "\n\n" + npcAfter;
    }
```

---

### buildAssGropeNpcStop
```java
String buildAssGropeNpcStop(NpcData n) {
        String tier = gameStageVariant();
        String npcLine;

        if (hasTrait(n, "Sleazy"))
            npcLine = "{npc_He} groans and slowly removes {npc_his} hands from your ass. "
                    + "\"Fuck, that ass is perfect… you sure?\""
                    + " {npc_He} does stop though, fingers trailing as they leave.";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_His} hand finally leaves your ass with a dismissive snort. \"Fine, whatever. You're no fun anyway.\"";
        else if (hasTrait(n, "Alcoholic"))
            npcLine = "{npc_His} sweaty hands pull away from your ass while {npc_he} sways into you. "
                    + "{npc_He} mumbles something half-formed and boozy.";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "{npc_He} finally removes {npc_his} hand from your ass with a challenging smirk. \"Fine. You're no fun tonight.\"";
        else if (hasTrait(n, "Engaging"))
            npcLine = "{npc_His} hand slides back up to your waist immediately. \"Sorry — went a bit far there.\"";
        else if (hasTrait(n, "Self_Assured"))
            npcLine = "{npc_His} hand moves back to your lower back cleanly. \"Fair enough.\"";
        else
            npcLine = "{npc_His} hand moves back to your waist.";

        String mcReact = tier.equals("enjoy")
            ? "*{npc_He} finally stopped... but the way {npc_he} was squeezing my ass while we danced felt good. I almost miss it.*"
            : tier.equals("flustered")
                ? "*The groping stopped. Everything feels neutral as we keep dancing.*"
                : "*Thank god {npc_he} finally stopped groping my ass while we were dancing. The violation still burns.*";

        return npcLine + "\n\n" + mcReact;
    }
```

---

### buildPussyGropeNpcStop
```java
String buildPussyGropeNpcStop(NpcData n) {
        String tier = gameStageVariant("finger_public");
        String npcLine;

        if (hasTrait(n, "Sleazy"))
            npcLine = "{npc_He} slowly withdraws {npc_his} hand from under your skirt, fingers trailing. "
                    + "\"You're soaked… sure you want me to stop? My fingers say different.\"";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_His} hand finally leaves from under your skirt with a dismissive snort. "
                    + "\"Fine, whatever. You were practically dripping.\"";
        else if (hasTrait(n, "Alcoholic"))
            npcLine = "{npc_His} sweaty hand pulls away from under your skirt clumsily. "
                    + "{npc_He} mumbles something boozy and sways heavier against you.";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "{npc_He} finally removes {npc_his} hand from under your skirt with a smirk. "
                    + "\"Fine. You're not stopping the dance though, are you?\"";
        else if (hasTrait(n, "Engaging"))
            npcLine = "{npc_His} hand slides out from under your skirt immediately. \"Way too far — I'm sorry.\"";
        else if (hasTrait(n, "Self_Assured"))
            npcLine = "{npc_His} hand withdraws from under your skirt cleanly. No comment. {npc_He} holds your waist.";
        else
            npcLine = "{npc_His} hand pulls away from under your skirt.";

        String mcReact = tier.equals("enjoy")
            ? "*{npc_He} finally stopped... but the way {npc_he} was touching me under my skirt while we danced felt so good. I almost wish {npc_he} hadn't stopped.*"
            : tier.equals("flustered")
                ? "*The touching under my skirt stopped. The sensation is fading as we keep dancing.*"
                : "*Thank god {npc_he} finally stopped. {npc_His} hand was under my skirt while we were dancing. "
                  + "The violation still burns — relief mixed with lingering shame.*";

        return npcLine + "\n\n" + mcReact;
    }
```

---

### sexyDanceMcAction
```java
String sexyDanceMcAction(String d, String tier) {
        boolean commando  = state.hasTrait("commando");
        boolean braless   = state.hasTrait("exposed_breasts");
        boolean cameltoe  = state.hasTrait("camel_toe");

        if (d.equals("blackout"))
            return "Your body moves on autopilot — heavy, sloppy rolls. No real conscious control. "
                 + (commando ? "The bare friction registers dimly." : "");

        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                return "The alcohol makes you bolder but it comes out clumsy — small shaky grinds, "
                     + "face burning. *Why did I choose this? Everyone can see me rubbing my ass on {npc_him}…* "
                     + "Mortified but continuing."
                     + (commando ? "\n\n*No panties... I'm grinding my bare ass on {npc_him} with nothing in between. The shame is overwhelming.*" : "");
            if (tier.equals("enjoy"))
                return "You grind your ass back harder against {npc_him} in heavy, deliberate rolls while you both rock slowly to the music."
                     + "\n\n*I'm really grinding on {npc_him} while we slow dance... it feels so dirty and hot. The alcohol makes me push back even more.*"
                     + (commando ? "\n\n*No panties — I can feel the direct friction on every roll.*" : "");
            // flustered/neutral drunk
            return "The alcohol carries you. You grind back with building heat, letting the rhythm take over."
                 + "\n\n*The grinding as we dance registers, but the buzz makes it feel hazy and distant.*";
        }

        // sober/tipsy
        if (tier.equals("shy"))
            return "You turn and press your ass back hesitantly, hips making small, uncertain rolls while you both sway."
                 + "\n\n*I'm trying to grind on {npc_him} but it feels so awkward... my face is burning and I feel ridiculous, but I keep moving.*"
                 + (commando ? " *Bare... nothing under my skirt and I'm still trying to grind on {npc_him}. The shame is overwhelming.*" : "");
        if (tier.equals("enjoy"))
            return "You press your ass back confidently and roll your hips in teasing circles while you both sway."
                 + "\n\n*I'm grinding my ass on {npc_him} while we dance... it feels powerful and sexy. I want {npc_him} to feel every deliberate movement.*"
                 + (commando ? "\n\n*No panties — I can feel every roll with nothing in the way. The raw contact feels so intense.*" : "");
        // flustered/neutral
        return "You turn and press your ass back, starting a slow deliberate grind while you both sway to the music."
             + "\n\n*The motion of grinding against {npc_him} as we dance registers, but I feel mostly detached.*"
             + (cameltoe ? "\n\n*The outline of my pussy is pressing right against {npc_him} with every roll.*" : "");
    }
```

---

### sexyDanceClothingNote
```java
String sexyDanceClothingNote() {
        boolean braless = state.hasTrait("exposed_breasts");
        boolean nipping = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");
        boolean bounce  = state.hasTrait("bounce_prone_4") || state.hasTrait("bounce_prone_5")
                       || state.hasTrait("bounce_prone_6") || state.hasTrait("bounce_prone_7");
        String tier = gameStageVariant();

        if (state.hasTrait("commando")) {
            return tier.equals("enjoy")
                ? "No panties — the direct skin-to-skin friction of your bare ass against {npc_him} with every grind feels raw and intense."
                : tier.equals("shy")
                    ? "No panties — you're grinding your bare ass directly on {npc_him} with nothing underneath. The exposure feels overwhelming."
                    : "The cool air and direct friction make every sensation sharper — nothing between you.";
        }
        if (state.hasTrait("camel_toe"))
            return tier.equals("shy")
                ? "Your cameltoe is pressing right against {npc_him} with every roll of your hips. Everyone might notice the shape."
                : "The grind makes the outline between your legs very obvious against {npc_him}.";
        if (bounce && braless && nipping)
            return "Your bare breasts bounce freely under your top with every movement, hard nipples pressing through the fabric.";
        if (bounce && braless)
            return "Your bare breasts move freely under your top, nothing to contain them with each hip roll.";
        if (bounce)
            return tier.equals("enjoy")
                ? "Your chest bounces noticeably with each hip roll — the whole motion feels sensual and bold."
                : "Your chest bounces noticeably with each hip roll.";
        if (braless && nipping)
            return "Your bare breasts shift under your top with the movement, hard nipples more visible with each grind.";
        if (braless)
            return tier.equals("shy")
                ? "No bra — your breasts are moving freely under your top while you grind. It feels too exposed."
                : "Your bare breasts move freely under your top with every grind.";
        return "";
    }
```
