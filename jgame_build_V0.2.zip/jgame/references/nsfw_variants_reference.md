# NSFW TEXT VARIANT REFERENCE
# Canonical blocks for sprinkling across scenes.
# Game style: present tense, sparse, observational. No purple prose.
# All blocks are `text_variants` entries or `slut_rep_req` choice additions.
#
# FLAG GATES AVAILABLE:
#   flag_is_braless         — outfitBra is null
#   flag_nipping            — braless + thin/sheer top
#   flag_wearing_thin_top   — thin/crop/tank/sheer/mesh/sundress
#   flag_wearing_skirt      — skirt lower item
#   flag_wearing_dress      — dress lower item
#   flag_underdressed_for_winter — cold season + no overcoat + dress/skirt
#   flag_high_lewdness      — lewdness rating ≥ 60
#   flag_very_high_lewdness — lewdness rating ≥ 85
#
# SLUT REP THRESHOLDS:
#   8-15  = awareness / mild lean-in
#   25-35 = deliberate flirt / escalation
#   50+   = explicit choices available

---

## A. NIPPING / BRALESS THIN TOP

### A1. Ambient text_variant — noticed, nothing said

```yaml
  - requires_flag: flag_nipping
    text: |
      The café / street / office / room is cool enough
      that you can feel it against your chest.

      You've been aware of it since you arrived.
      You're not the only one.
```

### A2. Variant — NPC reads it, says nothing

```yaml
  - requires_flag: flag_nipping
    text: |
      {npc_name} keeps their eyes level.
      Almost.

      There's a beat where they don't quite manage it —
      a glance that drops and comes back.
      Nothing is said. The air in the room shifts anyway.
```

### A3. Variant — Shy NPC trait, genuinely uncomfortable

```yaml
  - requires_flag: flag_nipping
    requires_trait: Conflict_Avoidant
    text: |
      {npc_name} notices and immediately doesn't notice.

      The conversation continues. Their eyes go everywhere
      except where they went. Your chest, your face,
      the middle distance — in that order, on a loop.
```

### A4. Variant — Outgoing NPC, can't help himself

```yaml
  - requires_flag: flag_nipping
    requires_trait: Outgoing
    text: |
      {npc_name} does a small double-take.

      Not exaggerated — just the involuntary version,
      the one that happens before the social edit kicks in.
      Then he's back. Professionally. Mostly.
```

### A5. Variant — Sleazy NPC, oblique comment

```yaml
  - requires_flag: flag_nipping
    requires_trait: Sleazy
    text: |
      {npc_name}'s gaze goes to your chest and stays there
      a full second longer than it should.

      "Cold in here today," he says pleasantly.

      It isn't particularly cold.
```

---

## B. BRALESS (ANY TOP) — natural movement, no nipping

### B1. Ambient — MC awareness

```yaml
  - requires_flag: flag_is_braless
    text: |
      You didn't think about it this morning.
      Now you're aware of it — the absence of structure,
      the way everything moves slightly differently
      without anything to hold it in place.
```

### B2. NPC observes movement

```yaml
  - requires_flag: flag_is_braless
    requires_trait: Outgoing
    text: |
      {npc_name} catches the movement as you reach for something —
      that small, unguarded moment where there's no denying
      you're not wearing a bra.

      Their eyes come back up. "Sorry — what were you saying?"
```

### B3. Sleazy — appreciative, not subtle

```yaml
  - requires_flag: flag_is_braless
    requires_trait: Sleazy
    text: |
      He notices the way your chest moves as you shift.
      The lack of a bra isn't invisible and he doesn't
      pretend it is.

      "Natural look today," he says with a small smile.
      The word *natural* doing more work than it appears.
```

### B4. Shy MC internal — discomfort

*For use in result_text blocks, Shy MC personality context:*
```
*No bra, and he's noticed. I can feel it —
the way he's adjusted where he's looking.
I should have worn something different today.*
```

### B5. Neutral MC internal — matter-of-fact

```
*He's clocked it. The braless thing shows more
than I'd planned in this light.
I'm not going to make it into a thing.*
```

### B6. Enjoy/Outgoing MC internal — positive

```
*He noticed I'm braless. Good.
That was the general idea.*
```

---

## C. HIGH LEWDNESS / REVEALING OUTFIT

### C1. Walking into a room — ambient shift

```yaml
  - requires_flag: flag_high_lewdness
    text: |
      You're aware of the room adjusting as you enter.
      Not dramatically — just the small recalibrations:
      conversations that pause, gazes that find you
      and stay a half-second too long before moving on.
```

### C2. Service is different at high lewdness

```yaml
  - requires_flag: flag_high_lewdness
    text: |
      The person at the counter is more attentive than usual.
      Your order is taken faster. The change comes back exact.

      None of this is accidental.
```

### C3. Very high lewdness — the room is very aware

```yaml
  - requires_flag: flag_very_high_lewdness
    text: |
      You walk in and the temperature of the room changes.

      Not everyone looks — but the ones who do
      don't look away quickly.
      You notice who they are.
```

### C4. NPC comment — technically about the outfit, not your body

```yaml
  - requires_flag: flag_high_lewdness
    text: |
      {npc_name} takes a moment longer than necessary.

      "That's a bold outfit," they say. The word *bold*
      landing somewhere between a compliment and an observation.
```

---

## D. OBLIQUE COWORKER / STRANGER COMMENTS
*Designed for work scenes and city encounters. One per scene max.*

### D1. Casual coworker — deniable, warm

> "New top? Works for the vibe in here."

> "You're getting a lot of attention on the floor today. Just so you know."

> "Bold choice for a Tuesday. Not a criticism."

### D2. Sleazy coworker — deniable, loaded

> "The AC must be hitting you differently today."

> "That outfit is doing a lot of work. I mean that respectfully."

> "Cold in here today, isn't it." *(said while not looking away)*

### D3. Stranger — oblique, no follow-up

> "Excuse me — " *(then just a look, then they keep walking)*

> "Nice. I mean — uh. Good morning."

> A stranger at the next table shifts their chair a few degrees in your direction without saying anything at all.

---

## E. SLUT-REP GATED CHOICE ADDITIONS
*Add to existing scenes as extra choice options.*

### E1. Gate: slut_rep_req: 10 — awareness / mild

```yaml
  - text: Let him look.
    slut_rep_req: 10
    result_text: |
      You don't cross your arms. Don't adjust.
      You let the moment sit where it is.

      Something in the room settles differently.
    stat_changes:
      arousal: 4
      confidence: 3
    next: __return__
```

### E2. Gate: slut_rep_req: 25 — deliberate lean-in

```yaml
  - text: Make it worse. Lean forward slightly when you reach.
    slut_rep_req: 25
    result_text: |
      You reach for something you don't particularly need.

      The movement does exactly what you knew it would.
      {npc_name} doesn't miss it.

      You straighten up. Neither of you mention it.
    stat_changes:
      arousal: 8
      slut_rep: 1
      confidence: 4
    next: __return__
```

### E3. Gate: slut_rep_req: 35 — say something

```yaml
  - text: Call it out. Make it comfortable.
    slut_rep_req: 35
    result_text: |
      "You noticed I'm braless," you say. Not a question.

      {npc_name} has the grace to look slightly caught.
      Then: "...Yeah."

      "It's fine," you say. And somehow that makes it fine.
      The conversation continues differently from there.
    stat_changes:
      confidence: 7
      arousal: 6
      slut_rep: 2
    next: __return__
```

### E4. Gate: slut_rep_req: 50 — offer to look properly

```yaml
  - text: "You can look properly if you want."
    slut_rep_req: 50
    result_text: |
      {npc_name} stares.

      You hold the position for three seconds, then straighten.

      "That's as far as this goes," you add,
      which is honest and leaves everything appropriately charged.
    stat_changes:
      arousal: 12
      slut_rep: 3
      confidence: 6
    next: __return__
```

---

## F. PERSONALITY REACTIONS — CHOICE RESULTS
*Short result_text blocks for shy / neutral / outgoing MC when clothing is noticed.*

### F1. Shy — someone noticed my chest

```
Your face warms immediately.
*The thin top, no bra — he can see exactly what's happening
and I have nowhere to hide.*
You pull the hem down on instinct. It doesn't help much.
```

### F2. Neutral — someone noticed, you acknowledge it

```
You register the look without reacting to it.
*It's what happens when you dress like this.
You knew that when you left the flat.*
```

### F3. Outgoing / Enjoy — someone noticed, good

```
There it is — that particular attention
you get when you're dressed the way you're dressed.
You don't break the eye contact.
*Good.*
```

---

## G. SEASONAL CLOTHING MODS
*Text variants that combine lewdness + season*

### G1. Summer braless — heat excuse

```yaml
  - requires_flag: flag_is_braless
    requires_flag: flag_season_summer
    text: |
      The heat makes the braless thing easier to justify —
      even if the logic only works when you don't think too hard about it.
      The thin fabric breathes. Everything moves naturally.
      You're not the only one dressed lightly today.
```

### G2. Winter braless — the cold is doing things

```yaml
  - requires_flag: flag_nipping
    requires_flag: flag_season_winter
    text: |
      The cold air is not subtle about what it's doing.

      You knew it would do this.
      You're choosing to think of it as a calculated risk.
```

---

## IMPLEMENTATION GUIDE

**To add a variant to an existing scene:**
```yaml
text_variants:
  - requires_flag: flag_nipping     # or flag_is_braless, flag_high_lewdness, etc.
    text: |
      [variant text here]
```

**To add a gated choice:**
```yaml
choices:
  # ... existing choices ...
  - text: [choice text]
    slut_rep_req: 25
    result_text: |
      [result text]
    stat_changes:
      arousal: 6
      slut_rep: 1
    next: __return__
```

**Priority scenes for adding variants:**
1. city_wander_park, city_wander_ice_cream, city_wander_busker (A1/E1/E2)
2. morning_routine (B1/B4/B5/B6 for braless variants)
3. bar_with_npc (E3/E4 as additional gated choices)
4. bookshop_petra_chat, tattoo_kai_consultation, velvet_cafe_tommy_banter (D1/D2/F variants)
5. explore_district scenes — Narrows, Caldwell, Millgate (C1/C3)
6. home_shower (B1 braless awareness on waking up)
7. All landlord scenes — Mitch/Sleazy variant uses D2 extensively
