#!/bin/bash
java -cp "out:lib/snakeyaml-2.2.jar" game.Main
