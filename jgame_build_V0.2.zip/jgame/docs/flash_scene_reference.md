# Flash Scene Reference Table
## Exhibitionism / Public Exposure — Design System

---

## TIER TABLE

| Tier | Path Trait | Base Req | Base Max Rep | Action Type | Max Gain/Scene |
|---|---|---|---|---|---|
| Low risk | `Path_Trait_Low_Risk_Exhibitionist` | 2–5 | 12 | `low_risk_flash` | +2/scene |
| High risk | `Path_Trait_High_Risk_Exhibitionist` | 5–10 | 16 | `high_risk_flash` | +2/scene |
| Watched | `Path_Trait_Watched_Exhibitionist` | 10–15 | 20 | `watched_flash` | +2/scene |

Max gain per choice: always +1 raw. Scene cap: +2 total. Daily cap: +5.

---

## TRAIT MODIFIERS

### slut_rep_req multipliers (lower = easier to unlock)

| Trait | Low Risk | High Risk | Watched |
|---|---|---|---|
| `Loves_Being_Watched` | — | ×0.67 | ×0.5 |
| `Risky_Exhibitionist` | ×0.67 | ×0.67 | ×0.8 |
| `Secret_Exhibitionist` | ×0.5 | ×0.8 | — |
| `Likes_Being_Watched` | — | — | ×0.67 |
| `Shy` | ×1.25 | ×1.5 | ×2.0 |
| `Uncomfortable_Being_Watched` | — | ×1.5 | ×2.0 |
| `Hates_Being_Watched` | ×1.5 | ×2.0 | ×3.0 |

### slut_rep_gain_max_rep bonuses

| Trait | Bonus |
|---|---|
| `Loves_Being_Watched` | +4 |
| `Risky_Exhibitionist` | +3 (watched), +2 (other) |
| `Secret_Exhibitionist` | +3 (low risk only), +1 (high risk) |
| `Likes_Being_Watched` | +2 |
| `Hates_Being_Watched` | −4 |
| `Uncomfortable_Being_Watched` | −3 (watched), −1 (other) |
| `Shy` | −2 |

---

## TONE SELECTION

### Witness scenes — uses `gameStageVariant()`
MC's general rep tier. She's just watching.

### Action scenes — uses `repProximityTier(minReq)`
- Within 8 of gate → **shy** (shaky, disbelieving)
- 8–15 above gate → **flustered** (does it fast, processes after)
- 16+ above gate → **enjoy** (deliberate, adrenaline welcome)

Rep-30 MC doing a rep-25 action: margin=5 → shy tone.
Rep-50 MC doing same action: margin=25 → enjoy tone.

Drunk modifier adds a layer on top — does not replace proximity tier.

---

## SCENE SEVERITY GRADING

| Situation | Tier | Path Trait |
|---|---|---|
| Empty changing room | Low | `Low_Risk_Exhibitionist` |
| Quiet corner, few people at distance | Low | `Low_Risk_Exhibitionist` |
| Mall corridor, crowd | High | `High_Risk_Exhibitionist` |
| Dance floor, partner present | High | `High_Risk_Exhibitionist` |
| Flashing directly to one person | Watched | `Watched_Exhibitionist` |
| Public dare / street | Watched | `Watched_Exhibitionist` |

---

## YAML TEMPLATE

```yaml
- text: "(do it)"
  slut_rep_req: 10
  path_traits:
    - Path_Trait_High_Risk_Exhibitionist
  slut_rep_gain: 1
  slut_rep_gain_max_rep: 16
  slut_rep_action_type: high_risk_flash
```

---

## DIMINISHING RETURNS (lifetime earned per action type)

| Action type | Cap | Full gain until | Zero at |
|---|---|---|---|
| `low_risk_flash` | 12 | earned < 3 | earned ≥ 9 |
| `high_risk_flash` | 16 | earned < 4 | earned ≥ 12 |
| `watched_flash` | 20 | earned < 5 | earned ≥ 15 |

Both `slut_rep_gain_max_rep` (current rep check) AND lifetime cap must pass.

---

## FULL FLASH TIER TABLE (all types)

| Tier | Path Trait | Base Req | Max Rep Ceiling | Action Type | Lifetime Cap |
|---|---|---|---|---|---|
| Low risk breast | `Path_Trait_Low_Risk_Exhibitionist` | 2–5 | 12 | `low_risk_flash` | 12 |
| High risk breast | `Path_Trait_High_Risk_Exhibitionist` | 5–10 | 16 | `high_risk_flash` | 16 |
| Watched breast | `Path_Trait_Watched_Exhibitionist` | 10–15 | 20 | `watched_flash` | 20 |
| Low risk lower body | `Path_Trait_Low_Risk_Exhibitionist` | 15–22 | 28 | `low_risk_flash_lower` | 28 |
| High risk lower body | `Path_Trait_High_Risk_Exhibitionist` | 25–32 | 38 | `high_risk_flash_lower` | 38 |
| Watched lower body | `Path_Trait_Watched_Exhibitionist` | 32–40 | 48 | `watched_flash_lower` | 48 |

---

## ACCIDENTAL PROXIMITY BONUS

Accidental gains scale based on how far below the `accidental_threshold` MC is.
Set `accidental_threshold` to the "natural comfort level" for the exposure type.

| MC rep vs threshold | Surprise raw multiplier | Effective gain (base raw=2) |
|---|---|---|
| rep < threshold/3 | ×2 | floor(4×0.5) = **+2** |
| threshold/3 ≤ rep < threshold | ×1 | floor(2×0.5) = **+1** |
| rep ≥ threshold | ×0.5 | floor(1×0.5) = **0** (old hat) |

Example: commando skirt flip, `accidental_threshold: 18`, MC rep=5:
- 5 < 18/3=6 → ×2 multiplier → raw=4 → effective=**+2**

Example: same scene, MC rep=20 (above threshold):
- 20 ≥ 18 → ×0.5 → raw=1 → floor(0.5)=**0**

---

## OUTFIT PASSIVE SCENES

These fire when MC goes outside with certain clothing states.
All use `accidental: true` and small threshold-relative gains.

| Scene | Gate | Accidental Threshold | Max Rep | Notes |
|---|---|---|---|---|
| `outfit_braless` | rep≥2 | 2 | 15 | Baseline braless public |
| `outfit_braless_bouncing` | rep≥5 | 5 | 20 | Braless + bounce-prone |
| `outfit_nipping` | rep≥10 | 10 | 22 | Visible through fabric |
| `outfit_commando` | rep≥10 | 10 | 24 | Commando, any bottom |
| `outfit_commando_skirt` | rep≥18 | 18 | 30 | Commando + skirt, wind risk |

All scene prose: `// #PLACEHOLDER` — see `buildRefusingInternalThought()` pattern.

---

## REFUSING INTERNAL THOUGHT

Token: `{mc_refusing_thought}`
Builder: `buildRefusingInternalThought()` in BarSystem — currently a stub.

12 variants needed: 3 rep tiers (shy/flustered/enjoy) × 4 drunk tiers (sober/tipsy/drunk/blackout).

- **Shy**: relief, some regret, mostly grateful for stopping
- **Flustered**: mixed — half relieved, half wishing she hadn't
- **Enjoy**: genuine frustration, or strategic decision to save it for later
- **Drunk overlay**: shorter sentences, more impulsive language, less articulate

