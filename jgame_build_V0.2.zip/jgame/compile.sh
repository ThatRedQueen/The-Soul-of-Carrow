#!/bin/bash
echo "Cleaning old classes..."
rm -rf out
mkdir -p out
echo "Compiling..."
find src -name "*.java" > sources.txt
javac -cp "lib/snakeyaml-2.2.jar" -d out @sources.txt
if [ $? -eq 0 ]; then
    echo "Done. Run ./run.sh to launch."
    rm sources.txt
else
    echo "Compile failed."
    rm sources.txt
fi
