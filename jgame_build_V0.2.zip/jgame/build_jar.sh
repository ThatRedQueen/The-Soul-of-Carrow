#!/bin/bash
echo "Building JAR..."
mkdir -p out

# Extract SnakeYAML into out/ so it's bundled
cd out && jar xf ../lib/snakeyaml-2.2.jar && cd ..

# Create manifest
echo "Main-Class: game.Main" > manifest.txt

# Build fat JAR
jar cfm MyGame.jar manifest.txt -C out .

rm manifest.txt
echo ""
echo "Built: MyGame.jar"
echo "Distribute: MyGame.jar + scenes/ + npcs/ + clothes/ + gamedata/ folders"
echo "Players run it with: java -jar MyGame.jar"
echo "Or wrap with Launch4j to make a .exe launcher."
