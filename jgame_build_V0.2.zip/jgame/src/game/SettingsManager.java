package game;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Loads and saves GameSettings to settings.dat.
 * Format: flat key=value, human-readable.
 * Unknown keys are silently ignored — safe across versions.
 */
public class SettingsManager {

    private static final String SEP  = "=";
    private final String settingsPath;
    private final GameSettings settings;

    public SettingsManager(String gameDir, GameSettings settings) {
        this.settingsPath = gameDir + File.separator + "settings.dat";
        this.settings     = settings;
    }

    public GameSettings getSettings() { return settings; }

    // ── Load ──────────────────────────────────────────────────────────────────

    public void load() {
        File file = new File(settingsPath);
        if (!file.exists()) return;
        try {
            Map<String,String> data = new LinkedHashMap<>();
            for (String line : Files.readAllLines(Paths.get(settingsPath))) {
                if (line.startsWith("#") || line.isBlank()) continue;
                int eq = line.indexOf(SEP);
                if (eq < 0) continue;
                data.put(line.substring(0, eq).trim(), line.substring(eq+1).trim());
            }
            applyData(data);
        } catch (Exception e) {
            System.err.println("[SettingsManager] Load failed: " + e.getMessage());
        }
    }

    private void applyData(Map<String,String> d) {
        // Visibility
        String vis = d.getOrDefault("visibility", "NORMAL").toUpperCase();
        try { settings.visibility = GameSettings.Visibility.valueOf(vis); }
        catch (Exception ignored) { settings.visibility = GameSettings.Visibility.NORMAL; }

        // Text sizes
        settings.textSize    = clamp(intVal(d, "text_size",   16), 12, 26);
        settings.choiceSize  = clamp(intVal(d, "choice_size", 14), 11, 22);
        settings.fontFamily  = d.getOrDefault("font_family", "SansSerif");
        settings.choiceFont  = d.getOrDefault("choice_font",  "SansSerif");

        // Difficulty
        settings.slutRepMultiplier  = clampF(floatVal(d, "slut_rep_mult",    1.0f), 1.0f, 8.0f);
        settings.willpowerDrainMult = clampF(floatVal(d, "wp_drain_mult",    1.0f), 0.25f, 2.0f);
        settings.stressMult         = clampF(floatVal(d, "stress_mult",      1.0f), 0.25f, 2.0f);

        // Key bindings
        settings.keyEscape   = intVal(d, "key_escape",   java.awt.event.KeyEvent.VK_ESCAPE);
        settings.keyOutfit   = intVal(d, "key_outfit",   java.awt.event.KeyEvent.VK_O);
        settings.keySave     = intVal(d, "key_save",     java.awt.event.KeyEvent.VK_S);
        settings.keySettings = intVal(d, "key_settings", java.awt.event.KeyEvent.VK_COMMA);

        // Accessibility
        settings.highContrast     = boolVal(d, "high_contrast",      false);
        settings.reduceAnimations = boolVal(d, "reduce_animations",  false);

        // Display
        settings.showCycleInHeader = boolVal(d, "show_cycle_header", true);
        settings.showMoneyInHeader = boolVal(d, "show_money_header", true);
    }

    // ── Save ──────────────────────────────────────────────────────────────────

    public void save() {
        try {
            List<String> lines = new ArrayList<>();
            lines.add("# The Soul of Carrow — settings");
            lines.add("# Edit this file or use the in-game Settings page.");
            lines.add("");
            lines.add("# NORMAL, PLAYER, DEV");
            lines.add("visibility" + SEP + settings.visibility.name());
            lines.add("");
            lines.add("text_size" + SEP + settings.textSize);
            lines.add("choice_size" + SEP + settings.choiceSize);
            lines.add("font_family" + SEP + settings.fontFamily);
            lines.add("choice_font" + SEP + settings.choiceFont);
            lines.add("");
            lines.add("# 1.0=normal  2.0=easy  4.0=ultra");
            lines.add("slut_rep_mult" + SEP + settings.slutRepMultiplier);
            lines.add("# 1.0=normal  0.5=half drain");
            lines.add("wp_drain_mult" + SEP + settings.willpowerDrainMult);
            lines.add("auto_rebuy_clothing" + SEP + settings.autoRebuyClothing);
            lines.add("stress_mult" + SEP + settings.stressMult);
            lines.add("");
            lines.add("# Key codes (Java KeyEvent VK_* values)");
            lines.add("key_escape" + SEP + settings.keyEscape);
            lines.add("key_outfit" + SEP + settings.keyOutfit);
            lines.add("key_save" + SEP + settings.keySave);
            lines.add("key_settings" + SEP + settings.keySettings);
            lines.add("");
            lines.add("high_contrast" + SEP + settings.highContrast);
            lines.add("reduce_animations" + SEP + settings.reduceAnimations);
            lines.add("show_cycle_header" + SEP + settings.showCycleInHeader);
            lines.add("show_money_header" + SEP + settings.showMoneyInHeader);
            Files.write(Paths.get(settingsPath), lines);
        } catch (Exception e) {
            System.err.println("[SettingsManager] Save failed: " + e.getMessage());
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private int   intVal(Map<String,String> m, String k, int def)     { try { return Integer.parseInt(m.getOrDefault(k,""+def)); } catch(Exception e){return def;} }
    private float floatVal(Map<String,String> m, String k, float def) { try { return Float.parseFloat(m.getOrDefault(k,""+def)); } catch(Exception e){return def;} }
    private boolean boolVal(Map<String,String> m, String k, boolean def) { String s=m.get(k); return s==null?def:Boolean.parseBoolean(s); }
    private int   clamp(int v, int lo, int hi)    { return Math.max(lo, Math.min(hi, v)); }
    private float clampF(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
}
