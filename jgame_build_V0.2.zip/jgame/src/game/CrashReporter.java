package game;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Central crash/error reporting system.
 *
 * Install once at startup via CrashReporter.install(). After that it:
 *  - Catches ALL uncaught exceptions on every thread
 *  - Writes a detailed crash report to crashes/crash_YYYYMMDD_HHmmss.txt
 *  - Shows the player a friendly error dialog with report location
 *  - Prevents duplicate reports for the same crash
 *  - Never blocks or hangs (report writing is time-boxed)
 */
public class CrashReporter {

    private static final int MAX_REPORT_WRITE_MS = 2_000;
    private static final AtomicBoolean REPORTED   = new AtomicBoolean(false);
    private static String  gameDir  = ".";
    private static GameState stateRef = null;

    // ── Installation ───────────────────────────────────────────────────────────

    public static void install(String baseDir, GameState state) {
        gameDir  = baseDir;
        stateRef = state;

        Thread.setDefaultUncaughtExceptionHandler((thread, ex) -> {
            handleCrash(ex, "Uncaught exception on thread: " + thread.getName(), state);
        });

        // Also catch EDT errors
        System.setProperty("sun.awt.exception.handler", EDTExceptionHandler.class.getName());
    }

    /** Update the GameState reference (call if state is re-created). */
    public static void setGameState(GameState state) { stateRef = state; }

    // ── Public crash/error report API ─────────────────────────────────────────

    /**
     * Report a non-fatal error (scene not found, token resolution failed, etc.)
     * Writes a report but does NOT close the game.
     */
    public static void reportError(String context, Throwable t) {
        String report = buildReport(context, t, stateRef);
        writeReport(report, "error");
        System.err.println("[CrashReporter] Error logged: " + context);
        if (t != null) t.printStackTrace();
    }

    /**
     * Report a fatal crash — writes report, shows dialog, optionally exits.
     */
    public static void handleCrash(Throwable t, String context, GameState state) {
        // Only report once — prevent cascading crash loops
        if (!REPORTED.compareAndSet(false, true)) return;

        String report = buildReport(context, t, state);
        String path   = writeReport(report, "crash");

        // Show dialog on EDT
        final String displayPath = path;
        if (SwingUtilities.isEventDispatchThread()) {
            showCrashDialog(t, displayPath);
        } else {
            try {
                SwingUtilities.invokeAndWait(() -> showCrashDialog(t, displayPath));
            } catch (Exception ignored) {}
        }
    }

    // ── Report building ────────────────────────────────────────────────────────

    private static String buildReport(String context, Throwable t, GameState state) {
        StringBuilder sb = new StringBuilder();
        String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

        sb.append("=== The Soul of Carrow — Error Report ===\n");
        sb.append("Time:    ").append(ts).append("\n");
        sb.append("Java:    ").append(System.getProperty("java.version")).append("\n");
        sb.append("OS:      ").append(System.getProperty("os.name")).append(" ")
          .append(System.getProperty("os.version")).append("\n");
        sb.append("Context: ").append(context).append("\n\n");

        // Exception details
        if (t != null) {
            sb.append("--- Exception ---\n");
            sb.append("Type:    ").append(t.getClass().getName()).append("\n");
            sb.append("Message: ").append(t.getMessage()).append("\n\n");
            sb.append("Stack trace:\n");
            StringWriter sw = new StringWriter();
            t.printStackTrace(new PrintWriter(sw));
            sb.append(sw).append("\n");

            // Cause chain
            Throwable cause = t.getCause();
            int depth = 0;
            while (cause != null && depth++ < 5) {
                sb.append("Caused by: ").append(cause.getClass().getName())
                  .append(": ").append(cause.getMessage()).append("\n");
                cause = cause.getCause();
            }
        }

        // Game state snapshot
        sb.append("\n--- Game State Snapshot ---\n");
        if (state != null) {
            try {
                sb.append("Day:         ").append(state.dayCount).append(" (").append(state.getDayName()).append(")\n");
                sb.append("Scene:       ").append(state.currentScene).append("\n");
                sb.append("Money:       $").append(state.money).append("\n");
                sb.append("Rent:        $").append(state.rent).append("/mo\n");
                sb.append("Job:         ").append(state.currentJobId != null ? state.currentJobId : "unemployed").append("\n");
                sb.append("Landlord:    ").append(state.currentLandlordNpc != null ? state.currentLandlordNpc : "none").append("\n");
                sb.append("Housing:     WP cap ").append(state.housingWillpowerCap)
                  .append(" / recovery +").append(state.housingWillpowerRecovery).append("\n");
                sb.append("Stats:       ")
                  .append("happiness=").append(state.happiness)
                  .append(" confidence=").append(state.confidence)
                  .append(" willpower=").append(state.willpower)
                  .append(" stress=").append(state.stress)
                  .append(" arousal=").append(state.arousal)
                  .append(" slut_rep=").append(state.slut_rep).append("\n");
                sb.append("Cycle day:   ").append(state.cycleDay).append(" / ").append(state.cycleLength)
                  .append(state.isOnPeriod() ? " (period)" : "").append("\n");
                sb.append("NPC:         ").append(state.currentApproachingNpc).append("\n");
                sb.append("Drunk:       ").append(state.drunk).append("\n");
                sb.append("Starting only: ").append(state.startingOutfitsOnly).append("\n");
                sb.append("Traits (").append(state.traits.size()).append("):\n");
                List<String> sortedTraits = new ArrayList<>(state.traits);
                Collections.sort(sortedTraits);
                for (int i = 0; i < sortedTraits.size(); i++) {
                    if (i % 6 == 0) sb.append("  ");
                    sb.append(sortedTraits.get(i));
                    if (i % 6 == 5 || i == sortedTraits.size()-1) sb.append("\n");
                    else sb.append(", ");
                }
                sb.append("Pending scenes: ").append(state.pendingTraitAcquisitions).append("\n");
                sb.append("Outfit:  bra=").append(state.outfitBra)
                  .append(" upper=").append(state.outfitUpper)
                  .append(" lower=").append(state.outfitLower)
                  .append(" underwear=").append(state.outfitUnderwear).append("\n");
            } catch (Exception snap) {
                sb.append("(State snapshot failed: ").append(snap.getMessage()).append(")\n");
            }
        } else {
            sb.append("(No game state available)\n");
        }

        // Thread dump — useful for deadlock diagnosis
        sb.append("\n--- Thread Dump ---\n");
        try {
            Map<Thread, StackTraceElement[]> traces = Thread.getAllStackTraces();
            for (Map.Entry<Thread, StackTraceElement[]> e : traces.entrySet()) {
                Thread thread = e.getKey();
                sb.append("Thread: ").append(thread.getName())
                  .append(" [").append(thread.getState()).append("]\n");
                for (StackTraceElement el : e.getValue()) {
                    sb.append("  at ").append(el).append("\n");
                }
                sb.append("\n");
            }
        } catch (Exception ignored) {}

        sb.append("=== End of Report ===\n");
        return sb.toString();
    }

    // ── File writing ───────────────────────────────────────────────────────────

    private static String writeReport(String content, String prefix) {
        String ts   = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String name = prefix + "_" + ts + ".txt";
        Path   dir  = Paths.get(gameDir, "crashes");
        Path   file = dir.resolve(name);

        Thread writer = new Thread(() -> {
            try {
                Files.createDirectories(dir);
                Files.write(file, content.getBytes());
                System.err.println("[CrashReporter] Report written: " + file.toAbsolutePath());
            } catch (Exception e) {
                // Last resort — print to stderr so it at least shows in console
                System.err.println("[CrashReporter] Failed to write report to " + file + ": " + e.getMessage());
                System.err.println(content);
            }
        }, "crash-reporter");
        writer.setDaemon(true);
        writer.start();

        // Wait up to MAX_REPORT_WRITE_MS for the write to complete
        try { writer.join(MAX_REPORT_WRITE_MS); } catch (InterruptedException ignored) {}

        return file.toAbsolutePath().toString();
    }

    // ── UI dialog ─────────────────────────────────────────────────────────────

    private static void showCrashDialog(Throwable t, String reportPath) {
        String msg = t != null ? t.getClass().getSimpleName() + ": " + t.getMessage()
                               : "Unknown error";
        String[] lines = {
            "Something went wrong and the game can't continue safely.",
            "",
            "Error: " + (msg.length() > 120 ? msg.substring(0, 120) + "…" : msg),
            "",
            "A crash report has been saved to:",
            reportPath,
            "",
            "Please include this file if reporting the issue."
        };
        String text = String.join("\n", lines);
        JOptionPane.showMessageDialog(
            null, text,
            "The Soul of Carrow — Error",
            JOptionPane.ERROR_MESSAGE
        );
    }

    // ── EDT exception handler (Java 8 property-based) ────────────────────────

    public static class EDTExceptionHandler implements Thread.UncaughtExceptionHandler {
        @Override
        public void uncaughtException(Thread t, Throwable e) {
            handleCrash(e, "EDT exception", stateRef);
        }
    }
}
