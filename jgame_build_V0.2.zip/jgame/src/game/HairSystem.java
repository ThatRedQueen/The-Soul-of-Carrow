package game;

import java.util.Random;

/**
 * HairSystem — builds hair movement descriptors for use anywhere in the game.
 *
 * Tokens:
 *   {hair_breeze_text}      → MC's own hair reacting to air movement
 *   {npc_hair_breeze_text}  → Another character's hair (e.g. flashing girl running off)
 *
 * Hair type is read from GameState traits:
 *   hair_wavy, hair_straight_long, hair_bob, hair_pixie, hair_afro, hair_ponytail
 *
 * Hair color is read from GameState traits:
 *   hair_blonde, hair_brown, hair_auburn, hair_black, hair_red, hair_pink,
 *   hair_white, hair_silver, hair_dark (default fallback)
 *
 * Rep tier (shy / flustered / enjoy) maps to gameStageVariant().
 * Internal thoughts use italics via leading asterisk — caller wraps in italic if needed.
 */
public class HairSystem {

    private final GameState state;
    private final Random    rng = new Random();

    public HairSystem(GameState state) {
        this.state = state;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private boolean hasTrait(String t) { return state.hasTrait(t); }

    /** Rep-tier gate: shy / flustered / enjoy. */
    private String tier() {
        int rep = state.slut_rep;
        if (rep >= 15) return "enjoy";
        if (rep >= 8)  return "flustered";
        return "shy";
    }

    /** MC hair color string from traits. */
    public String hairColor() {
        if (hasTrait("hair_blonde"))  return "blonde";
        if (hasTrait("hair_auburn"))  return "auburn";
        if (hasTrait("hair_red"))     return "red";
        if (hasTrait("hair_brown"))   return "brown";
        if (hasTrait("hair_black"))   return "black";
        if (hasTrait("hair_pink"))    return "pink";
        if (hasTrait("hair_white"))   return "white";
        if (hasTrait("hair_silver"))  return "silver";
        return "dark";  // neutral fallback — works for any unset color
    }

    /** MC hair type string for generic fallback ("hair", "wavy hair", etc). */
    private String hairTypeDesc() {
        if (hasTrait("hair_wavy"))         return "long wavy " + hairColor() + " hair";
        if (hasTrait("hair_straight_long"))return "long straight " + hairColor() + " hair";
        if (hasTrait("hair_bob"))          return "shoulder-length " + hairColor() + " bob";
        if (hasTrait("hair_pixie"))        return "short " + hairColor() + " pixie cut";
        if (hasTrait("hair_afro"))         return hairColor() + " afro";
        if (hasTrait("hair_ponytail"))     return hairColor() + " ponytail";
        return hairColor() + " hair";  // generic fallback
    }

    // ── MC hair movement ──────────────────────────────────────────────────────

    /**
     * Returns a single hair-movement descriptor for the MC.
     * Typically inserted after a high-emotion moment (flash, startle, thrill).
     * Token: {hair_breeze_text}
     */
    public String buildHairBreezeText() {
        String tier  = tier();
        String color = hairColor();
        String desc  = hairTypeDesc();

        if (hasTrait("hair_wavy"))          return wavyMC(tier, color);
        if (hasTrait("hair_straight_long")) return straightLongMC(tier, color);
        if (hasTrait("hair_bob"))           return bobMC(tier, color);
        if (hasTrait("hair_pixie"))         return pixieMC(tier, color);
        if (hasTrait("hair_afro"))          return afroMC(tier, color);
        if (hasTrait("hair_ponytail"))      return ponytailMC(tier, color);

        // Generic fallback — works for any unset hair type
        return switch (tier) {
            case "enjoy" ->
                "The AC breeze plays with your " + desc + " for a moment.\n\n"
              + "*Even your hair is in on the energy right now.*";
            case "flustered" ->
                "A puff of mall air catches your " + desc + " as you process it all.\n\n"
              + "*Small detail. Still there.*";
            default ->
                "Cool air from the vents shifts your " + desc + " slightly.\n\n"
              + "*The whole world keeps moving while you're standing still.*";
        };
    }

    // ── NPC / other character hair movement ───────────────────────────────────

    /**
     * Returns a hair-movement descriptor for another character (e.g. flashing girl).
     * Caller passes the NPC's hair color and type as strings — we don't track NPC hair traits.
     * Token: {npc_hair_breeze_text}  (resolved from scene context, not auto-detected)
     *
     * For direct calls from builders, use buildNpcHairBreezeText(color, type).
     */
    public String buildNpcHairBreezeText(String npcHairColor, String npcHairType) {
        String tier = tier();
        boolean wavy = npcHairType.contains("wavy");

        String baseLine = wavy
            ? "As she turns and runs, the mall's AC sends her long wavy " + npcHairColor
              + " hair cascading and rippling behind her like a slow-motion wave."
            : "As she laughs and turns to go, a light breeze from the mall's AC vents catches "
              + "her " + npcHairColor + " hair, making it sway gently.";

        String reaction = switch (tier) {
            case "enjoy" ->
                "*Damn — even her " + npcHairColor + " hair looked good flying around after that.\n"
              + "She owned the moment completely.*";
            case "flustered" ->
                "*Her " + npcHairColor + " hair moved with the air right as she pulled her top up…\n"
              + "The whole thing happened so fast.*";
            default ->
                "*Even her " + npcHairColor + " hair moved so freely when she turned…\n"
              + "Everything about that moment felt too exposed.*";
        };

        return baseLine + "\n\n" + reaction;
    }

    // ── Per-type MC builders ──────────────────────────────────────────────────

    private String wavyMC(String tier, String color) {
        return switch (tier) {
            case "enjoy" ->
                "You shake your head with a laugh, letting the mall breeze lift and ripple "
              + "your long wavy " + color + " hair behind you.\n\n"
              + "*It billowed out — matching how thrilling that whole moment was.*";
            case "flustered" ->
                "The cool air current catches your long wavy " + color + " hair, "
              + "sending it flowing and bouncing lightly as you take it all in.\n\n"
              + "*My long wavy hair rippled nicely in the breeze. Small detail in a big moment.*";
            default ->
                "You flinch and turn sharply, causing your long wavy " + color + " hair "
              + "to whip and ripple dramatically from the sudden movement.\n\n"
              + "*My long wavy " + color + " hair is flowing everywhere now… "
              + "all because I reacted so hard. I must look completely flustered.*";
        };
    }

    private String straightLongMC(String tier, String color) {
        return switch (tier) {
            case "enjoy" ->
                "You turn with a laugh, letting the breeze send your long straight " + color
              + " hair swinging smoothly behind you.\n\n"
              + "*The clean swing of it felt freeing — syncing with the whole rush.*";
            case "flustered" ->
                "A light breeze sends your long straight " + color + " hair gliding as you blink.\n\n"
              + "*My hair swung cleanly with the air. A small grounding detail.*";
            default ->
                "You jerk your head away, sending your long straight " + color + " hair "
              + "swinging heavily across your face from the motion and breeze.\n\n"
              + "*My long straight " + color + " hair is swinging everywhere… "
              + "I can't believe I reacted so obviously.*";
        };
    }

    private String bobMC(String tier, String color) {
        return switch (tier) {
            case "enjoy" ->
                "You shake your head laughing, making the breeze flip and bounce your "
              + "shoulder-length " + color + " bob energetically.\n\n"
              + "*The energetic flip felt playful and alive. Good hair day for a wild moment.*";
            case "flustered" ->
                "The breeze playfully flips the ends of your " + color + " bob as you process it.\n\n"
              + "*My bob moved a little. Noted.*";
            default ->
                "You duck your head, causing the ends of your shoulder-length " + color
              + " bob to flip up and brush your cheeks from the sudden air and movement.\n\n"
              + "*My bob is flipping all over… highlighting exactly how flustered I am.*";
        };
    }

    private String pixieMC(String tier, String color) {
        return switch (tier) {
            case "enjoy" ->
                "You grin and run a hand through your short " + color
              + " pixie as the breeze playfully ruffles the layers.\n\n"
              + "*Light and alive. Even short hair catches the energy.*";
            case "flustered" ->
                "The cool air lightly ruffles your short " + color + " pixie cut.\n\n"
              + "*A small ruffle. Quick, like the moment itself.*";
            default ->
                "You shrink back, the breeze ruffling your short " + color
              + " pixie and making the short strands stand up slightly.\n\n"
              + "*My pixie is all ruffled now… I look even more startled than I feel.*";
        };
    }

    private String afroMC(String tier, String color) {
        return switch (tier) {
            case "enjoy" ->
                "You laugh, shaking your head so the breeze makes your " + color
              + " afro curls bounce energetically.\n\n"
              + "*The lively bounce felt vibrant — matching the thrill completely.*";
            case "flustered" ->
                "The air current makes the curls of your " + color + " afro bounce lightly.\n\n"
              + "*My curls moved with the air. Beautiful texture for an unexpected moment.*";
            default ->
                "You turn away quickly, causing the curls of your " + color
              + " afro to bounce and shift noticeably from the movement and air.\n\n"
              + "*My " + color + " afro is bouncing all over… afro curls don't hide strong reactions.*";
        };
    }

    private String ponytailMC(String tier, String color) {
        return switch (tier) {
            case "enjoy" ->
                "You turn laughing, letting the breeze make your straight " + color
              + " ponytail swing and whip energetically.\n\n"
              + "*It swung with the whole rush. Ponytails were made for moments like this.*";
            case "flustered" ->
                "A puff of air sends your straight " + color + " ponytail swinging smoothly.\n\n"
              + "*Clean swing. Matches how quickly everything happened.*";
            default ->
                "You whip around in embarrassment, sending your straight " + color
              + " ponytail swinging wildly from the motion and breeze.\n\n"
              + "*My ponytail is swinging everywhere… it makes the whole reaction look even more obvious.*";
        };
    }
}
