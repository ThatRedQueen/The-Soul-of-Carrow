package game;

import game.data.NpcData;
import org.yaml.snakeyaml.Yaml;
import java.io.*;
import java.util.*;

public class NpcLoader {

    private final Map<String, NpcData> npcs   = new LinkedHashMap<>();
    private final Map<String, String>  modSrc = new HashMap<>();

    @SuppressWarnings("unchecked")
    public void loadAll(String dir) {
        File folder = new File(dir);
        if (!folder.exists()) return;
        Yaml yaml = new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions()));
        File[] files = folder.listFiles();
        if (files == null) return;
        Arrays.sort(files, Comparator.comparing(File::getName));
        for (File f : files) {
            if (!f.getName().endsWith(".yml")
                || f.getName().startsWith("NPC_")
                || f.getName().startsWith("npc_template")) continue;
            try (InputStream is = new FileInputStream(f)) {
                Map<String,Object> raw = yaml.load(is);
                if (raw == null) continue;
                NpcData n = parseNpc(raw);
                if (n != null && !n.id.isEmpty()) npcs.put(n.id, n);
            } catch (Exception e) {
                System.err.println("Error loading NPC " + f.getName() + ": " + e.getMessage());
            }
        }
    }

    public NpcData get(String id)           { return npcs.get(id); }
    public java.util.Collection<NpcData> getAll() { return npcs.values(); }

    public boolean hasTrait(String npcId, String trait) {
        NpcData n = get(npcId);
        return n != null && n.traits.stream().anyMatch(t -> t.equalsIgnoreCase(trait));
    }

    // ── Mod support ───────────────────────────────────────────────────────────

    /** True if NPC was injected by the given mod. */
    public boolean isFromMod(String npcId, String modId) {
        return modId.equals(modSrc.get(npcId));
    }

    /** Inject an NPC from a mod. Returns true on success. */
    @SuppressWarnings("unchecked")
    public boolean injectModNpc(java.util.Map<String, Object> raw, String modId) {
        try {
            NpcData n = parseNpc(raw);
            if (n == null || n.id == null || n.id.isEmpty()) return false;
            npcs.put(n.id, n);
            modSrc.put(n.id, modId);
            return true;
        } catch (Exception e) {
            System.err.println("[NpcLoader] injectModNpc failed: " + e.getMessage());
            return false;
        }
    }

    // ── Parsing ───────────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    NpcData parseNpc(java.util.Map<String, Object> raw) {
        if (raw == null) return null;
        NpcData n     = new NpcData();
        n.id          = str(raw, "id");
        n.name        = str(raw, "name");
        n.type        = str(raw, "type");
        n.age         = str(raw, "age");
        n.race        = str(raw, "race");
        n.personality = str(raw, "personality");
        n.career      = str(raw, "career");
        n.hair_style  = str(raw, "hair_style");
        n.hair_color  = str(raw, "hair_color");
        n.eye_color   = str(raw, "eye_color");
        n.figure      = str(raw, "figure");
        n.intro       = str(raw, "intro");
        n.work_only   = Boolean.TRUE.equals(raw.get("work_only"));
        n.bar_desc    = str(raw, "bar_desc");
        n.max_liking  = intVal(raw, "max_liking", 100);
        n.max_love    = intVal(raw, "max_love",   100);
        Object tList  = raw.get("traits");
        if (tList instanceof List)
            for (Object t : (List<?>) tList) if (t != null) n.traits.add(t.toString());
        return n;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private String str(Map<String,Object> m, String k) {
        Object v = m.get(k); return v == null ? "" : v.toString().trim();
    }
    private int intVal(Map<String,Object> m, String k, int def) {
        Object v = m.get(k); if (v == null) return def;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return def; }
    }
}
