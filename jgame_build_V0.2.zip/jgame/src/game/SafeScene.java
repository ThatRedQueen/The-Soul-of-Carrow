package game;

import game.data.SceneData;
import java.util.*;

/**
 * Factory for synthetic error/fallback scenes.
 * These appear when a real scene can't be found or loaded.
 * Always has at least one safe exit choice.
 */
public class SafeScene {

    /**
     * Returns a fallback scene shown when a scene ID cannot be resolved.
     * Includes diagnostic context so a screenshot is useful for debugging.
     */
    public static SceneData notFound(String sceneId, String context) {
        SceneData s  = new SceneData();
        s.id         = "__error_scene_not_found__";
        s.text       = buildNotFoundText(sceneId, context);

        SceneData.ChoiceData cont = new SceneData.ChoiceData();
        cont.text        = "Continue";
        cont.next        = "__return__";
        cont.slut_rep_req = 0;
        s.choices.add(cont);

        // Also log the error
        CrashReporter.reportError("Scene not found: '" + sceneId + "'" +
            (context != null ? " [context: " + context + "]" : ""), null);

        return s;
    }

    /**
     * Returns a fallback scene for token resolution failures.
     */
    public static SceneData tokenError(String token, String sceneId, Throwable cause) {
        SceneData s  = new SceneData();
        s.id         = "__error_token__";
        s.text       = "[ A display error occurred while building this scene. ]\n\n" +
                       "Token: " + token + "\n" +
                       "Scene: " + sceneId + "\n\n" +
                       (cause != null ? "Reason: " + cause.getMessage() : "");

        SceneData.ChoiceData cont = new SceneData.ChoiceData();
        cont.text        = "Continue anyway";
        cont.next        = "__return__";
        cont.slut_rep_req = 0;
        s.choices.add(cont);

        CrashReporter.reportError("Token error in scene '" + sceneId + "': " + token, cause);
        return s;
    }

    /**
     * Returns a safe empty scene that silently exits — used when an injected
     * scene ID (e.g. from pendingTraitAcquisitions) can't be found.
     */
    public static SceneData silentReturn(String missingId) {
        SceneData s  = new SceneData();
        s.id         = "__silent_return__";
        s.text       = ""; // no text — auto-continue

        SceneData.ChoiceData cont = new SceneData.ChoiceData();
        cont.text        = "Continue";
        cont.next        = "__return__";
        cont.slut_rep_req = 0;
        s.choices.add(cont);

        System.err.println("[SafeScene] Silent return for missing injected scene: " + missingId);
        return s;
    }

    private static String buildNotFoundText(String sceneId, String context) {
        StringBuilder sb = new StringBuilder();
        sb.append("[ Scene '").append(sceneId).append("' could not be found. ]\n\n");
        sb.append("This is a development issue — the game tried to navigate to a scene\n");
        sb.append("that doesn't exist or hasn't been created yet.\n");
        if (context != null && !context.isEmpty()) {
            sb.append("\nContext: ").append(context);
        }
        sb.append("\n\nA report has been logged to the crashes/ folder.\n");
        sb.append("You can continue playing — this scene has been skipped.");
        return sb.toString();
    }
}
