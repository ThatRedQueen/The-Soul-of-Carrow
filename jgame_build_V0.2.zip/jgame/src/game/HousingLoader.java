package game;

import game.data.HousingData;
import org.yaml.snakeyaml.Yaml;
import java.io.*;
import java.util.*;

/**
 * Loads housing property definitions from the housing/ folder.
 * Each .yml file is one rentable property.
 * Add a new property by dropping a .yml — no Java changes needed.
 */
public class HousingLoader {
    private final Map<String, HousingData> properties = new LinkedHashMap<>();

    @SuppressWarnings("unchecked")
    public void loadAll(String dir) {
        File folder = new File(dir);
        if (!folder.exists()) return;
        Yaml yaml = new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(
                             new org.yaml.snakeyaml.LoaderOptions()));
        File[] files = folder.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (!f.getName().endsWith(".yml") || f.getName().startsWith("_")) continue;
            try (InputStream is = new FileInputStream(f)) {
                Map<String,Object> raw = yaml.load(is);
                if (raw == null) continue;
                HousingData h = parse(raw);
                if (h != null && !h.id.isEmpty()) properties.put(h.id, h);
            } catch (Exception e) {
                System.err.println("[HousingLoader] Error loading " + f.getName() + ": " + e.getMessage());
            }
        }
        System.out.println("[HousingLoader] Loaded " + properties.size() + " properties.");
    }

    public HousingData get(String id)                  { return properties.get(id); }
    public Collection<HousingData> getAll()            { return properties.values(); }

    /** All properties for a given neighbourhood trait (e.g. "neighbourhood_rough") */
    public List<HousingData> byNeighbourhood(String trait) {
        List<HousingData> out = new ArrayList<>();
        for (HousingData h : properties.values())
            if (trait.equals(h.neighbourhood_trait)) out.add(h);
        out.sort(Comparator.comparingInt(h -> h.rent));
        return out;
    }

    /** All properties in a rent range (inclusive) */
    public List<HousingData> byRentRange(int min, int max) {
        List<HousingData> out = new ArrayList<>();
        for (HousingData h : properties.values())
            if (h.rent >= min && h.rent <= max) out.add(h);
        out.sort(Comparator.comparingInt(h -> h.rent));
        return out;
    }

    /** Find property currently occupied by player (matching landlord + rent) */
    public HousingData findCurrent(String landlordNpc, int rent) {
        for (HousingData h : properties.values())
            if (h.landlord_npc.equals(landlordNpc) && h.rent == rent) return h;
        return null;
    }

    @SuppressWarnings("unchecked")
    private HousingData parse(Map<String,Object> raw) {
        HousingData h = new HousingData();
        h.id                  = str(raw, "id");
        h.label               = str(raw, "label");
        h.landlord_npc        = str(raw, "landlord_npc");
        h.rent                = intVal(raw, "rent", 0);
        h.unit_type           = str(raw, "unit_type");
        h.neighbourhood       = str(raw, "neighbourhood");
        h.neighbourhood_trait = str(raw, "neighbourhood_trait");
        h.unit_trait          = str(raw, "unit_trait");
        h.willpower_cap       = intVal(raw, "willpower_cap", 85);
        h.willpower_recovery  = intVal(raw, "willpower_recovery", 25);
        h.stress_min          = intVal(raw, "stress_min", 2);
        h.stress_reduction    = intVal(raw, "stress_reduction", 6);
        h.move_in_scene       = str(raw, "move_in_scene");
        Object sc = raw.get("stat_changes");
        if (sc instanceof Map) for (Map.Entry<?,?> e : ((Map<?,?>)sc).entrySet()) {
            try { h.stat_changes.put(e.getKey().toString(),
                                     Integer.parseInt(e.getValue().toString())); }
            catch (Exception ignored) {}
        }
        return h;
    }

    private String str(Map<String,Object> m, String k) {
        Object v = m.get(k); return v == null ? "" : v.toString();
    }
    private int intVal(Map<String,Object> m, String k, int def) {
        Object v = m.get(k); if (v == null) return def;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return def; }
    }
}
