package game;

import game.data.ClothingData;
import game.data.TriggerData;
import java.util.*;

public class BounceSystem {

    private static final Set<String> MOVEMENT_ACTIVITIES = new HashSet<>(Arrays.asList(
        "explore", "exercise", "go_out", "go_to_bar", "find_work",
        "velvet_cafe", "skyline_office", "neon_fitness",
        "retail", "cafe", "office_admin", "bar_staff"
    ));

    private static final Set<String> BOUNCE_SCENES = new HashSet<>(Arrays.asList(
        "bounce_stare", "bounce_double_take", "bounce_catcall"
    ));

    private final GameState      state;
    private final ClothingLoader clothes;

    public BounceSystem(GameState state, ClothingLoader clothes) {
        this.state   = state;
        this.clothes = clothes;
    }

    /** Bounce level 0-7 based on cup size. 0 = no bounce. */
    public int bounceLevel() {
        ClothingData upper = state.outfitOvercoat != null
            ? clothes.get(state.outfitOvercoat)
            : clothes.get(state.outfitUpper);
        if (upper != null && upper.braless) return 0;

        boolean noBra = state.outfitBra == null;
        if (!noBra) {
            ClothingData bra = clothes.get(state.outfitBra);
            noBra = bra != null && bra.isNipRisk();
        }
        if (!noBra) return 0;

        if (state.hasTrait("Breasts_F"))  return 7;
        if (state.hasTrait("Breasts_E"))  return 6;
        if (state.hasTrait("Breasts_DD")) return 5;
        if (state.hasTrait("Breasts_D"))  return 4;
        if (state.hasTrait("Breasts_C"))  return 3;
        if (state.hasTrait("Breasts_B"))  return 2;
        return 0;
    }

    public boolean isBounceActive() { return bounceLevel() >= 2; }

    /** True if the given scene ID is a bounce encounter. */
    public boolean isBounceScene(String sceneId) { return BOUNCE_SCENES.contains(sceneId); }

    /**
     * Build TriggerData entries to merge into the activity's trigger pool.
     * Empty if no bounce or this activity doesn't involve movement.
     * Stat effects are NOT applied here — call applyBounceStats() only when a bounce scene fires.
     */
    public List<TriggerData> buildTriggers(String activityId) {
        int level = bounceLevel();
        if (level < 2 || !MOVEMENT_ACTIVITIES.contains(activityId)) return Collections.emptyList();

        int nothingMult = nothingMultiplier(level);
        List<TriggerData> triggers = new ArrayList<>();

        triggers.add(trigger("bounce_stare",       stareWeight(level),      nothingMult));
        triggers.add(trigger("bounce_double_take",  doubleTakeWeight(level), nothingMult));
        if (level >= 3)
            triggers.add(trigger("bounce_catcall", catcallWeight(level),    nothingMult));

        return triggers;
    }

    /** Apply stat effects when a bounce scene is confirmed to fire. */
    public void applyBounceStats() {
        state.changeStat("thrills",    thrillsGain());
        state.changeStat("confidence", 2);
        state.changeStat("arousal",    arousalGain());
    }

    private int nothingMultiplier(int level) {
        int mult;
        if      (level >= 5) mult = 3;
        else if (level == 4) mult = 4;
        else                 mult = 5;

        if      (state.hasTrait("Loves_Being_Watched"))           mult -= 2;
        else if (state.hasTrait("Likes_Being_Watched"))           mult -= 1;
        else if (state.hasTrait("Secret_Exhibitionist") ||
                 state.hasTrait("Risky_Exhibitionist"))           mult -= 1;

        if      (state.hasTrait("Hates_Being_Watched"))           mult += 3;
        else if (state.hasTrait("Uncomfortable_Being_Watched"))   mult += 1;

        return Math.max(1, mult);
    }

    private int stareWeight(int level)      { return Math.max(1, 6 - level); }
    private int doubleTakeWeight(int level) { return 3; }
    private int catcallWeight(int level)    { return Math.max(1, level - 2); }

    private int thrillsGain() {
        if (state.hasTrait("Loves_Being_Watched"))         return 15;
        if (state.hasTrait("Likes_Being_Watched"))         return 10;
        if (state.hasTrait("Secret_Exhibitionist"))        return 12;
        if (state.hasTrait("Risky_Exhibitionist"))         return 8;
        if (state.hasTrait("Neutral_On_Exhibitionism"))    return 5;
        if (state.hasTrait("Uncomfortable_Being_Watched")) return 2;
        if (state.hasTrait("Hates_Being_Watched"))         return -5;
        return 5;
    }

    private int arousalGain() {
        if (state.hasTrait("Loves_Being_Watched"))  return 15;
        if (state.hasTrait("Likes_Being_Watched"))  return 10;
        if (state.hasTrait("Secret_Exhibitionist")) return 12;
        if (state.hasTrait("Risky_Exhibitionist"))  return 7;
        return 3;
    }

    private TriggerData trigger(String sceneId, int weight, int nothingMult) {
        TriggerData t        = new TriggerData();
        t.scene_id           = sceneId;
        t.weight             = weight;
        t.nothing_multiplier = nothingMult;
        return t;
    }
}
