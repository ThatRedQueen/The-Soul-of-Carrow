package game;

import game.data.NpcData;
import java.util.*;

/**
 * Generates NPC job conversation text when MC asks "what do you do?"
 * Keyed to job traits in the NPC's trait list.
 * Personality modifier applied on top: WARM opens up, SELFISH keeps it terse/braggy,
 * NEUTRAL stays factual.
 */
public class JobConversationSystem {

    private final NpcLoader npcs;
    private final GameState state;

    public JobConversationSystem(NpcLoader npcs, GameState state) {
        this.npcs  = npcs;
        this.state = state;
    }

    /** Returns job conversation text for the current approaching NPC. */
    public String buildJobText() {
        if (state.currentApproachingNpc == null || state.currentApproachingNpc.isEmpty())
            return "\"I'd rather not get into it.\"";

        NpcData npc = npcs.get(state.currentApproachingNpc);
        if (npc == null) return "\"It's complicated.\"";

        String job = detectJob(npc.traits);
        if (job == null) return buildNoJobText(npc);

        return buildJobResponse(job, npc);
    }

    // ── Job detection — first matching trait wins ──────────────────────────────

    private static final List<String> JOB_TRAITS = Arrays.asList(
        "Nurse","Paramedic","GP_Doctor","Retired_Surgeon","Physiotherapist","Social_Worker",
        "Therapist","Journalist","Sports_Reporter","Photographer","Filmmaker","Aspiring_Writer",
        "Poet","Musician","Dancer","Burlesque_Performer","Tattoo_Artist","Graphic_Designer",
        "Architect","Software_Engineer","IT_Worker","Finance","Barrister","Lawyer","Translator",
        "Teacher","Retired_Teacher","Professor","Librarian","Bookshop_Owner","Restaurant_Owner",
        "Chef","Barista","Personal_Trainer","Gym_Rat","DJ","Model","Fashion_Industry",
        "Aspiring_Actress","Aspiring_Influencer","Real_Estate_Agent","Security_Guard",
        "Building_Super","Trades_Background","Night_Shift","Student","Workaholic",
        "Skateboarder","Outdoorsy","Volunteer","Retired_Teacher","Executive","Athlete"
    );

    private String detectJob(List<String> traits) {
        for (String t : JOB_TRAITS) {
            if (traits.contains(t)) return t;
        }
        return null;
    }

    // ── Response builders ──────────────────────────────────────────────────────

    private String buildJobResponse(String job, NpcData npc) {
        boolean warm    = "WARM".equals(npc.personality) || "CARING".equals(npc.personality);
        boolean selfish = "SELFISH".equals(npc.personality);
        boolean outgoing= "OUTGOING".equals(npc.personality);

        switch (job) {
            case "Nurse":
                if (warm)    return "\"Paediatric ward. Nights mostly. It's a lot, but the kids — you can't help it. You show up every time.\"";
                if (selfish) return "\"Nursing. The hours are insane and the pay doesn't match what they tell you the job means.\"";
                             return "\"Hospital. Twelve-hour shifts. You get used to it. Or you learn to pretend to.\"";
            case "Paramedic":
                if (warm)    return "\"Paramedic. You end up in people's worst moments. Most days I think it matters.\"";
                             return "\"Ambulance service. I've seen enough that most things don't surprise me anymore.\"";
            case "GP_Doctor":
                if (warm)    return "\"GP. Family practice. I've had some patients for fifteen years now — that part doesn't get old.\"";
                             return "\"General practice medicine. Mostly it's fifteen-minute appointments and trying to actually hear what's wrong.\"";
            case "Retired_Surgeon":
                             return "\"I was a surgeon. Retired now. I read more and sleep better, which turns out to be the trade.\"";
            case "Physiotherapist":
                if (selfish) return "\"Physio. Bodies, injuries, getting people moving again. I'm very good at it.\"";
                             return "\"Physiotherapy. I like the puzzle of it — working out what's actually wrong and building back from there.\"";
            case "Social_Worker":
                if (warm)    return "\"Social work. Families, mostly. It's heavy sometimes, but you do what you can with what you have.\"";
                             return "\"Social work. You hear things in that job. You learn not to take it home. Mostly.\"";
            case "Therapist":
                if (warm)    return "\"I'm a therapist. Private practice. I try not to switch it off completely outside of sessions — it doesn't work, but I try.\"";
                             return "\"Therapist. I listen for a living, which people find either reassuring or unsettling.\"";
            case "Journalist":
                if (selfish) return "\"Investigative journalism. I've broken three stories that went national. The fourth is in progress.\"";
                if (outgoing)return "\"I write. Sports for now — I'd like it to be more than that eventually.\"";
                             return "\"Journalist. It used to mean something different. Still does in places, I think.\"";
            case "Sports_Reporter":
                if (outgoing)return "\"Sports reporter. I know everything about the game and some things I shouldn't about the people playing it.\"";
                             return "\"Sports journalism. It's more politics than people expect.\"";
            case "Photographer":
                if (warm)    return "\"Photography. I shoot people mostly — portraits, events. I like how a photo freezes something that was already gone.\"";
                             return "\"Photographer. I see light differently than most people. I say that without meaning to sound pretentious.\"";
            case "Filmmaker":
                             return "\"I'm making a documentary. I'd rather not explain what it's about yet — it changes when I explain it too early.\"";
            case "Aspiring_Writer":
                if (warm)    return "\"I'm writing a novel. Or I keep saying I'm writing a novel. I'm mostly writing notes about the novel.\"";
                if (outgoing)return "\"Working on a book. Between shifts. It's going. Slowly, but it's going.\"";
                             return "\"I write. Eventually something will come of it.\"";
            case "Poet":
                             return "\"I write poetry and teach it two evenings a week. Most people at this point say 'that's brave,' which I don't quite know how to take.\"";
            case "Musician":
                if (outgoing)return "\"I play bass. We're almost there. We've been almost there for a while, but still.\"";
                if (warm)    return "\"I teach music mostly. Play in the evenings when I can find the time.\"";
                             return "\"Music. Playing, teaching. Both, depending on the day.\"";
            case "Dancer":
                if (outgoing)return "\"I dance. Contemporary, mostly. When people ask what that means I do a small demonstration and that usually answers it.\"";
                             return "\"Dancer. It's a shorter career than most people realise and a longer training than anyone expects.\"";
            case "Burlesque_Performer":
                if (outgoing)return "\"Burlesque. Yes, really. No, it's not what people's first thought is. It's performance — specific, deliberate, very intentional.\"";
                             return "\"I perform. Burlesque, mainly. I'm very comfortable talking about what it is and very boring about the other questions.\"";
            case "Tattoo_Artist":
                if (warm)    return "\"I tattoo people. It's collaborative in a way I didn't expect — the image is mine and theirs at once.\"";
                             return "\"Tattoo artist. People show up with an idea and I make it permanent. It's a specific kind of trust.\"";
            case "Graphic_Designer":
                if (outgoing)return "\"Graphic design. People underestimate how much of what they react to visually is designed. I find that either satisfying or exhausting depending on the day.\"";
                             return "\"Design. Mostly screens. I have opinions about fonts that are stronger than is probably healthy.\"";
            case "Architect":
                if (selfish) return "\"Architecture. I look at buildings and see what they could have been. It's a gift and a curse.\"";
                             return "\"I'm an architect. I look at spaces and see what they're doing to the people inside them. Most buildings aren't thinking about that.\"";
            case "Software_Engineer":
                if (warm)    return "\"Software engineering. I solve puzzles for a living, mostly. The people part is harder than the code part.\"";
                             return "\"Software engineer. I fix things that shouldn't need fixing. It's a living.\"";
            case "IT_Worker":
                             return "\"IT support. Everyone needs it, nobody wants to talk to me about it at parties. I've made my peace with that.\"";
            case "Finance":
                if (selfish) return "\"Investment banking. The hours are brutal and I'm very good at it, which somewhat justifies the first part.\"";
                             return "\"Finance. I move numbers around and sometimes that adds up to something real.\"";
            case "Barrister":
                if (selfish) return "\"I'm a barrister. I cross-examine things for a living. Everything, eventually.\"";
                             return "\"Barrister. I argue cases in court, which sounds dramatic and is mostly very detailed paperwork.\"";
            case "Lawyer":
                             return "\"Lawyer. Corporate, unfortunately. It pays for the things I actually care about.\"";
            case "Translator":
                             return "\"I translate legal documents. Five languages, all of them precise for different reasons. It's quieter work than people imagine.\"";
            case "Teacher":
                if (warm)    return "\"I teach. Music, currently — secondary school. It has its days.\"";
                             return "\"Secondary school teacher. The subject's good. The paperwork is not.\"";
            case "Retired_Teacher":
                if (warm)    return "\"I taught English for thirty years. I still correct menus. Old habit.\"";
                             return "\"Retired teacher. I have more time to read now, which was always the point.\"";
            case "Professor":
                if (warm)    return "\"History, at the university. I'm retired now but I can't stop reading, which amounts to the same thing.\"";
                             return "\"I was a professor. Academic. Still am, in all the ways that matter.\"";
            case "Librarian":
                if (warm)    return "\"I work at the library. I know where everything is, which sounds minor until someone needs it.\"";
                             return "\"Librarian. People always say it the way you'd say a thing that surprises them. I'm used to it.\"";
            case "Bookshop_Owner":
                             return "\"I have a small bookshop. Second-hand, mostly. I know every book in the place. Come in sometime and I'll find you something.\"";
            case "Restaurant_Owner":
                if (warm)    return "\"I own a restaurant. Small place — we're full most nights. Food is the point. Everything else follows from that.\"";
                if (outgoing)return "\"My restaurant. It just got a second good review. I pretend not to care and obviously do.\"";
                             return "\"Restaurant. I built it from nothing and it works, which still surprises me sometimes.\"";
            case "Chef":
                if (outgoing)return "\"Head chef. I'm very good at it and have strong opinions about most ingredients. People either find that charming or not.\"";
                if (warm)    return "\"I cook professionally. It's physical, it's chaotic, and I wouldn't trade it.\"";
                             return "\"Chef. The hours are long and the margins are thin and I can't imagine doing anything else.\"";
            case "Barista":
                if (warm)    return "\"I make coffee. Good coffee. It's more skill than people credit, and the regulars make it worth it.\"";
                if (outgoing)return "\"Barista, for now. Writing on the side. The job's good — you see everyone come through.\"";
                             return "\"Coffee. It pays, the hours work, and I'm genuinely good at it.\"";
            case "Personal_Trainer":
                if (warm)    return "\"Personal training. I help people figure out what their body can do. The getting-there part is the work and also the point.\"";
                if (selfish) return "\"Personal training. I'm very good at reading what someone needs and making them do it.\"";
                             return "\"I train people. Fitness, rehabilitation — whatever the goal is, we work backward from there.\"";
            case "Gym_Rat":
                if (outgoing)return "\"I'm in fitness — personal training. And I go to the gym a lot outside of that, which my friends find very predictable.\"";
                             return "\"Fitness industry. I spend a lot of time in gyms, which people either respect or find suspicious.\"";
            case "DJ":
                if (outgoing)return "\"I DJ. Clubs, mostly. I'm better at it than my life currently suggests, which I keep meaning to fix.\"";
                             return "\"Music — DJ work. I like the hour between setup and doors-open better than most of the rest.\"";
            case "Model":
                if (selfish) return "\"I model. Used to do it more. Still do when the job's right.\"";
                if (outgoing)return "\"Modelling. I used to do it full time — now more selectively. The walk doesn't go away.\"";
                             return "\"I've done modelling. Less now. It teaches you a lot about how other people see you.\"";
            case "Fashion_Industry":
                if (outgoing)return "\"Fashion. I know everyone in the room before I walk into it and dress accordingly. I say that affectionately.\"";
                             return "\"I work in fashion. The industry is smaller than it looks and larger than it should be.\"";
            case "Aspiring_Actress":
                if (outgoing)return "\"Actress. Or I will be. Drama school, then whatever comes after that. I'm not worried.\"";
                             return "\"Acting. I'm training at the moment. It's more technical than people think and more emotional than I expected.\"";
            case "Aspiring_Influencer":
                if (outgoing)return "\"I'm building a platform. Content creation — lifestyle, events. I know how that sounds. It's working though.\"";
                             return "\"Social media, I suppose. Content. It's more work than it looks like.\"";
            case "Real_Estate_Agent":
                if (selfish) return "\"Property. I'm very good at making people want things they were already going to want. The commission is excellent.\"";
                             return "\"Real estate. I show people spaces and let them project into them. It's more interesting than it sounds.\"";
            case "Security_Guard":
                if (warm)    return "\"Building security. Nights. You see more than people realise, which mostly you keep to yourself.\"";
                             return "\"Security. Night shifts, mostly. Quiet job. I don't mind quiet.\"";
            case "Building_Super":
                             return "\"Building super. Pipes, circuits, the boiler that makes that sound. I know everything in this building and it's not as boring as it sounds.\"";
            case "Trades_Background":
                if (warm)    return "\"Plumbing. Twenty years of it. I fix things and people are genuinely glad to see me, which is underrated.\"";
                             return "\"Trades. I work with my hands. There's something satisfying about a problem you can actually fix.\"";
            case "Executive":
                if (selfish) return "\"I run a division. The revenue makes sense of most of the rest of it.\"";
                             return "\"Corporate — senior level. It's as interesting as it is and no more.\"";
            case "Athlete":
                if (outgoing)return "\"I play semi-professionally. Football. It's going well enough that I'm making it work.\"";
                             return "\"Sport, professionally. Or semi-professionally. The line is more complicated than it should be.\"";
            default:
                return buildNoJobText(null);
        }
    }

    private String buildNoJobText(NpcData npc) {
        if (npc == null) return "\"Between things at the moment.\"";
        String p = npc.personality;
        if ("SELFISH".equals(p))  return "\"Something that pays well. Why?\"";
        if ("WARM".equals(p))     return "\"A few things, honestly. Nothing worth talking about here. What about you?\"";
        if ("OUTGOING".equals(p)) return "\"Something different every week. What do you do?\"";
        return "\"Working it out. Ask me again in six months.\"";
    }
}
