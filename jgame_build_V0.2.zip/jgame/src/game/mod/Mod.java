package game.mod;

import java.util.*;
import java.io.File;

/**
 * Represents a single mod — its metadata and validation state.
 * Populated by ModLoader, validated by ModValidator.
 */
public class Mod {

    // ── Identity ──────────────────────────────────────────────────────────────
    public String  id          = "";   // folder name, used as namespace
    public String  name        = "";   // display name from mod.yml
    public String  author      = "";
    public String  version     = "";
    public String  description = "";
    public File    folder;             // the mod's root directory

    // ── State ────────────────────────────────────────────────────────────────
    public enum Status { PENDING, OK, PARTIAL, FAILED }
    public Status status = Status.PENDING;

    // ── Content counts ───────────────────────────────────────────────────────
    public int scenesLoaded  = 0;
    public int npcsLoaded    = 0;
    public int clothesLoaded = 0;
    public int jobsLoaded    = 0;

    // ── Errors ───────────────────────────────────────────────────────────────
    /** Every problem found — file name + human-readable description. */
    public final List<ModError> errors = new ArrayList<>();

    public void addError(String file, String message) {
        errors.add(new ModError(file, message, ModError.Level.ERROR));
    }
    public void addWarning(String file, String message) {
        errors.add(new ModError(file, message, ModError.Level.WARNING));
    }

    public boolean hasErrors()   { return errors.stream().anyMatch(e -> e.level == ModError.Level.ERROR); }
    public boolean hasWarnings() { return errors.stream().anyMatch(e -> e.level == ModError.Level.WARNING); }

    /** Recompute status from errors list after loading. */
    public void finaliseStatus() {
        if (scenesLoaded + npcsLoaded + clothesLoaded + jobsLoaded == 0 && hasErrors()) {
            status = Status.FAILED;
        } else if (hasErrors()) {
            status = Status.PARTIAL;
        } else {
            status = Status.OK;
        }
    }

    @Override public String toString() { return name.isEmpty() ? id : name; }

    // ── ModError inner class ──────────────────────────────────────────────────
    public static class ModError {
        public enum Level { WARNING, ERROR }
        public final String file;
        public final String message;
        public final Level  level;
        public final long   timestamp = System.currentTimeMillis();

        public ModError(String file, String message, Level level) {
            this.file    = file;
            this.message = message;
            this.level   = level;
        }

        @Override public String toString() {
            return "[" + level + "] " + file + ": " + message;
        }
    }
}
