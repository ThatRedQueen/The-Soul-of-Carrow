package game.mod;

import game.CrashReporter;
import game.SceneLoader;
import game.NpcLoader;
import game.ClothingLoader;
import game.JobLoader;
import game.data.*;
import org.yaml.snakeyaml.Yaml;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Discovers mods in the mods/ directory and injects their content
 * into the game's loaders. Reports detailed errors per mod.
 *
 * Load order: mods are loaded alphabetically. Later mods override
 * earlier ones on ID collision (last-write-wins), with a warning.
 *
 * Thread safety: call from main thread before game starts.
 */
public class ModLoader {

    /**
     * Returns true if the given file is safely inside the expected root directory.
     * Prevents symlink attacks and path traversal (../../etc/passwd style).
     */
    private static boolean isSafeModPath(File root, File file) {
        try {
            String rootCanon = root.getCanonicalPath();
            String fileCanon = file.getCanonicalPath();
            return fileCanon.startsWith(rootCanon + File.separator) || fileCanon.equals(rootCanon);
        } catch (java.io.IOException e) {
            return false; // if we can't resolve it, don't trust it
        }
    }

    private final File              modsDir;
    private final SceneLoader       scenes;
    private final NpcLoader         npcs;
    private final ClothingLoader    clothes;
    private final JobLoader         jobs;
    private final List<Mod>         loaded  = new ArrayList<>();
    private final Set<String>       allSceneIds;  // existing scene IDs before mod load

    public ModLoader(String gameDir, SceneLoader scenes, NpcLoader npcs,
                     ClothingLoader clothes, JobLoader jobs) {
        this.modsDir  = new File(gameDir, "mods");
        this.scenes   = scenes;
        this.npcs     = npcs;
        this.clothes  = clothes;
        this.jobs     = jobs;
        this.allSceneIds = new HashSet<>(scenes.allIds());
    }

    /** Discover and load all mods. Returns list of loaded mods (with status). */
    public List<Mod> loadAll() {
        if (!modsDir.exists() || !modsDir.isDirectory()) {
            System.out.println("[ModLoader] No mods/ directory found — skipping.");
            return loaded;
        }

        File[] modFolders = modsDir.listFiles(File::isDirectory);
        if (modFolders == null || modFolders.length == 0) {
            System.out.println("[ModLoader] No mods found.");
            return loaded;
        }

        Arrays.sort(modFolders, Comparator.comparing(File::getName));

        for (File folder : modFolders) {
            try {
                Mod mod = loadMod(folder);
                loaded.add(mod);
                System.out.printf("[ModLoader] %s — scenes:%d npcs:%d clothes:%d jobs:%d errors:%d%n",
                    mod, mod.scenesLoaded, mod.npcsLoaded,
                    mod.clothesLoaded, mod.jobsLoaded, mod.errors.size());
            } catch (Exception e) {
                Mod failed = new Mod();
                failed.id     = folder.getName();
                failed.name   = folder.getName();
                failed.folder = folder;
                failed.addError("(loader)", "Unexpected error: " + e.getMessage());
                failed.status = Mod.Status.FAILED;
                loaded.add(failed);
                CrashReporter.reportError("ModLoader failed on: " + folder.getName(), e);
            }
        }

        writeErrorLogs();
        return loaded;
    }

    public List<Mod> getMods() { return Collections.unmodifiableList(loaded); }

    // ── Per-mod loading ───────────────────────────────────────────────────────

    private Mod loadMod(File folder) {
        Mod mod  = new Mod();
        mod.id   = folder.getName();
        mod.name = folder.getName();
        mod.folder = folder;

        // 1. Read mod.yml metadata (optional but recommended)
        File metaFile = new File(folder, "mod.yml");
        if (metaFile.exists()) {
            readMeta(mod, metaFile);
        } else {
            mod.addWarning("mod.yml", "No mod.yml found. Add one for name, author, version info.");
        }

        // 2. Load scenes
        File scenesDir = new File(folder, "scenes");
        if (scenesDir.exists()) loadScenes(mod, scenesDir);

        // 3. Load NPCs
        File npcsDir = new File(folder, "npcs");
        if (npcsDir.exists()) loadNpcs(mod, npcsDir);

        // 4. Load clothing
        File clothesDir = new File(folder, "clothes");
        if (clothesDir.exists()) loadClothes(mod, clothesDir);

        // 5. Load jobs
        File jobsDir = new File(folder, "jobs");
        if (jobsDir.exists()) loadJobs(mod, jobsDir);

        // 6. Post-load validation
        ModValidator.validate(mod, scenes, npcs);

        mod.finaliseStatus();
        return mod;
    }

    @SuppressWarnings("unchecked")
    private void readMeta(Mod mod, File file) {
        try (InputStream is = new FileInputStream(file)) {
            Map<String, Object> raw = (Map<String, Object>) new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions())).load(is);
            if (raw == null) { mod.addWarning("mod.yml", "Empty mod.yml"); return; }
            mod.name        = str(raw, "name",        mod.id);
            mod.author      = str(raw, "author",      "");
            mod.version     = str(raw, "version",     "");
            mod.description = str(raw, "description", "");
        } catch (Exception e) {
            mod.addError("mod.yml", "Parse error: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void loadScenes(Mod mod, File dir) {
        for (File f : allYaml(dir)) {
            String relPath = "scenes/" + f.getName();
            if (!isSafeModPath(folder, f)) {
                    System.err.println("[ModLoader] Skipping unsafe path: " + f.getPath());
                    continue;
                }
                try (InputStream is = new FileInputStream(f)) {
                Yaml yaml = new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions()));
                for (Object doc : yaml.loadAll(is)) {
                    if (!(doc instanceof Map)) continue;
                    Map<String, Object> raw = (Map<String, Object>) doc;
                    String id        = str(raw, "id", "");
                    String patchTarget = str(raw, "patch_scene", "");

                    if (!patchTarget.isEmpty()) {
                        // ── Patch mode: extend an existing scene ──────────
                        boolean ok = scenes.applyModPatch(raw, mod.id);
                        if (ok) mod.scenesLoaded++;
                        else    mod.addWarning(relPath,
                            "Patch targets unknown scene '" + patchTarget + "' — skipped.");
                        continue;
                    }

                    if (id.isEmpty()) {
                        mod.addWarning(relPath, "Scene missing 'id' or 'patch_scene' field — skipped.");
                        continue;
                    }
                    if (allSceneIds.contains(id)) {
                        mod.addWarning(relPath, "Scene '" + id + "' overrides a base game scene.");
                    }
                    // Inject into SceneLoader
                    boolean ok = scenes.injectModScene(raw, mod.id);
                    if (ok) { mod.scenesLoaded++; allSceneIds.add(id); }
                    else    mod.addError(relPath, "Failed to inject scene '" + id + "'");
                }
            } catch (Exception e) {
                mod.addError(relPath, "YAML parse error: " + e.getMessage());
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void loadNpcs(Mod mod, File dir) {
        for (File f : allYaml(dir)) {
            String relPath = "npcs/" + f.getName();
            if (!isSafeModPath(folder, f)) {
                    System.err.println("[ModLoader] Skipping unsafe path: " + f.getPath());
                    continue;
                }
                try (InputStream is = new FileInputStream(f)) {
                Map<String, Object> raw = (Map<String, Object>) new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions())).load(is);
                if (raw == null) { mod.addWarning(relPath, "Empty NPC file."); continue; }

                String id = str(raw, "id", "");
                if (id.isEmpty()) {
                    mod.addError(relPath, "NPC missing required 'id' field.");
                    continue;
                }
                String type = str(raw, "type", "");
                if (type.isEmpty()) {
                    mod.addError(relPath, "NPC '" + id + "' missing 'type' (MALE/FEMALE).");
                    continue;
                }
                if (!type.equalsIgnoreCase("MALE") && !type.equalsIgnoreCase("FEMALE")) {
                    mod.addError(relPath, "NPC '" + id + "' has invalid type '" + type + "' — must be MALE or FEMALE.");
                    continue;
                }
                if (str(raw, "intro", "").isEmpty()) {
                    mod.addWarning(relPath, "NPC '" + id + "' has no intro text — bar description will be generic.");
                }

                boolean ok = npcs.injectModNpc(raw, mod.id);
                if (ok) mod.npcsLoaded++;
                else    mod.addError(relPath, "Failed to inject NPC '" + id + "'");

            } catch (Exception e) {
                mod.addError(relPath, "YAML parse error: " + e.getMessage());
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void loadClothes(Mod mod, File dir) {
        for (File f : allYaml(dir)) {
            String relPath = "clothes/" + f.getName();
            if (!isSafeModPath(folder, f)) {
                    System.err.println("[ModLoader] Skipping unsafe path: " + f.getPath());
                    continue;
                }
                try (InputStream is = new FileInputStream(f)) {
                Map<String, Object> raw = (Map<String, Object>) new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions())).load(is);
                if (raw == null) { mod.addWarning(relPath, "Empty clothing file."); continue; }

                String id   = str(raw, "id", "");
                String slot = str(raw, "slot", "");
                if (id.isEmpty())   { mod.addError(relPath, "Clothing missing 'id' field."); continue; }
                if (slot.isEmpty()) { mod.addError(relPath, "Clothing '" + id + "' missing 'slot' (upper/lower/shoes/bra/underwear)."); continue; }
                List<String> validSlots = Arrays.asList("upper","lower","shoes","bra","underwear");
                if (!validSlots.contains(slot.toLowerCase())) {
                    mod.addWarning(relPath, "Clothing '" + id + "' slot '" + slot + "' is non-standard.");
                }

                boolean ok = clothes.injectModClothing(raw, mod.id);
                if (ok) mod.clothesLoaded++;
                else    mod.addError(relPath, "Failed to inject clothing '" + id + "'");

            } catch (Exception e) {
                mod.addError(relPath, "YAML parse error: " + e.getMessage());
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void loadJobs(Mod mod, File dir) {
        for (File f : allYaml(dir)) {
            String relPath = "jobs/" + f.getName();
            if (!isSafeModPath(folder, f)) {
                    System.err.println("[ModLoader] Skipping unsafe path: " + f.getPath());
                    continue;
                }
                try (InputStream is = new FileInputStream(f)) {
                Map<String, Object> raw = (Map<String, Object>) new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions())).load(is);
                if (raw == null) { mod.addWarning(relPath, "Empty job file."); continue; }

                String id = str(raw, "id", "");
                if (id.isEmpty()) { mod.addError(relPath, "Job missing 'id' field."); continue; }
                if (!raw.containsKey("pay_per_day")) {
                    mod.addWarning(relPath, "Job '" + id + "' has no pay_per_day — will default to 0.");
                }

                boolean ok = jobs.injectModJob(raw, mod.id);
                if (ok) mod.jobsLoaded++;
                else    mod.addError(relPath, "Failed to inject job '" + id + "'");

            } catch (Exception e) {
                mod.addError(relPath, "YAML parse error: " + e.getMessage());
            }
        }
    }

    // ── Error log writing ─────────────────────────────────────────────────────

    private void writeErrorLogs() {
        for (Mod mod : loaded) {
            if (mod.errors.isEmpty()) continue;
            File logFile = new File(mod.folder, "mod_errors.log");
            try (PrintWriter pw = new PrintWriter(logFile)) {
                pw.println("=== Mod Error Log: " + mod.name + " ===");
                pw.println("Generated: " + new java.util.Date());
                pw.println("Status: " + mod.status);
                pw.println();
                for (Mod.ModError e : mod.errors) {
                    pw.println("[" + e.level + "] " + e.file);
                    pw.println("  → " + e.message);
                    pw.println();
                }
            } catch (Exception e) {
                System.err.println("[ModLoader] Could not write error log for " + mod.id + ": " + e.getMessage());
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private List<File> allYaml(File dir) {
        List<File> result = new ArrayList<>();
        collectYaml(dir, result);
        result.sort(Comparator.comparing(File::getName));
        return result;
    }

    private void collectYaml(File dir, List<File> result) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory())               collectYaml(f, result);
            else if (f.getName().endsWith(".yml")) result.add(f);
        }
    }

    private String str(Map<String, Object> m, String key, String def) {
        Object v = m.get(key);
        return (v == null) ? def : v.toString().trim();
    }
}
