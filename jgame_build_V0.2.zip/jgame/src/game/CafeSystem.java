package game;

import game.data.NpcData;
import java.util.*;

/**
 * CafeSystem — token builder for Velvet Cafe scenes.
 * Handles dice mechanics, clothing-aware prose, and
 * session state for the top_shelf scene and future cafe scenes.
 *
 * Tokens resolved by Engine:
 *   {cafe_jump_text}          → buildJumpText()
 *   {cafe_stretch_text}       → buildStretchText()
 *   {cafe_stretch_delib_text} → buildStretchDeliberateText()
 *   {cafe_hesitate_text}      → buildHesitateText()
 *   {cafe_callout_text}       → buildCalloutText()
 *   {cafe_sleazy_first_text}  → buildSleazyFirstText()
 *   {cafe_sleazy_repeat_text} → buildSleazyRepeatText()
 *   {cafe_stool_text}         → buildStoolText()
 *   {cafe_customer_text}      → buildCustomerText()
 */
public class CafeSystem {

    /** Registers café text tokens. Called once by Engine at construction. */
    public void registerTokens(java.util.Map<String,java.util.function.Supplier<String>> m) {
        m.put("{cafe_top_shelf_opener}", this::buildSceneOpenerText);
        m.put("{cafe_jump_text}", this::buildJumpText);
        m.put("{cafe_stretch_text}", this::buildStretchText);
        m.put("{cafe_hesitate_text}", this::buildHesitateText);
        m.put("{cafe_callout_text}", this::buildCalloutText);
        m.put("{cafe_sleazy_first_text}", this::buildSleazyFirstText);
        m.put("{cafe_sleazy_repeat_text}", this::buildSleazyRepeatText);
        m.put("{cafe_stool_text}", this::buildStoolText);
        m.put("{cafe_customer_text}", this::buildCustomerText);
        m.put("{cafe_closing_text}", this::buildClosingText);
    }

    private final GameState state;
    private final Random    rng = new Random();

    // Rolled once per scene load — determines customer attention intensity
    // 1-4 = Low, 5-7 = Medium, 8-10 = High
    private int customerAttentionRoll = 0;

    public CafeSystem(GameState state) {
        this.state = state;
    }

    /** Call on scene entry to roll customer attention for this shift. */
    public void rollCustomerAttention() {
        customerAttentionRoll = rng.nextInt(10) + 1;
    }

    public String attentionTier() {
        if (customerAttentionRoll >= 8) return "high";
        if (customerAttentionRoll >= 5) return "medium";
        return "low";
    }

    // ── Clothing helpers ──────────────────────────────────────────────────────

    private boolean hasTrait(String t)     { return state.hasTrait(t); }
    private boolean isBraless()            { return hasTrait("exposed_breasts") || hasTrait("no_bra"); }
    private boolean isCroptop()            { return hasTrait("croptop"); }
    private boolean isCommando()           { return hasTrait("commando"); }
    private boolean isShortSkirt()         { return hasTrait("short_skirt"); }
    private boolean isPierced()            { return hasTrait("nipping_pierced") || hasTrait("pierced_nipping"); }
    private boolean isDiaphanous()         { return hasTrait("diaphanous"); }
    private boolean hasButtons()           { return hasTrait("has_buttons"); }
    private boolean isTightShirt()         { return hasTrait("tight_shirt"); }
    private boolean isShy()               { return hasTrait("Shy"); }
    private boolean isWellRead()           { return hasTrait("Well-Read"); }
    private boolean isHighSensitivity()    { return hasTrait("High_Breast_Sensitivity"); }

    /**
     * "Loves being watched" reaction gate for the cafe context.
     * Source doc used Loves_Being_Watched trait — in jgame this maps
     * to slut_rep >= 15 (established exhibitionist comfort with public attention).
     * Nightlife_Lover remains an NPC trait only; not checked here.
     */
    private boolean lovesBeingWatched()    { return state.slut_rep >= 15; }

    /**
     * Whether she'd get a visible thrill reaction vs shame.
     * slut_rep 10+ = thrill. Below = shame/embarrassment.
     */
    private boolean thrillsFromWatching()  { return state.slut_rep >= 10; }

    /** Jiggle description by breast size trait. Returns empty string if no jiggle. */
    private String jiggleDesc() {
        if (hasTrait("breast_f")) return "heavy, unmistakable jiggling with each movement";
        if (hasTrait("breast_e")) return "a heavy, very noticeable bounce";
        if (hasTrait("breast_d")) return "a noticeable, weighty sway";
        if (hasTrait("breast_c")) return "a light, visible bounce";
        if (hasTrait("breast_b")) return "a faint, barely-there tremor";
        return ""; // A cup — no jiggle
    }

    /** Nipping / pierced / diaphanous physical note. */
    private String nippingNote(String context) {
        if (isDiaphanous() && isPierced())
            return "The sheer fabric turns almost transparent under the lights; the metal "
                 + "bars catch and glint with every small movement.";
        if (isDiaphanous())
            return "Through the sheer fabric, the outline and color of your chest is visible "
                 + "to anyone who looks directly.";
        if (isPierced())
            return "The piercings press clearly through the fabric, catching the light "
                 + "with each shift.";
        if (isBraless())
            return "Without a bra, the AC makes itself very obvious. You're aware "
                 + "of exactly how visible that is.";
        return "";
    }

    /** Whether button pop dice fires (D-F cup + tight + has_buttons + high roll). */
    private boolean buttonPopFires(int roll) {
        return hasButtons() && isTightShirt()
            && (hasTrait("breast_d") || hasTrait("breast_e") || hasTrait("breast_f"))
            && roll >= 8;
    }


    // ── Scene opener ──────────────────────────────────────────────────────────

    /**
     * Scene opener — sensory ground-setting before any branch choice.
     * Three personality tiers. Token: {cafe_top_shelf_opener}
     */
    public String buildSceneOpenerText() {
        String tier = thrillsFromWatching() ? (lovesBeingWatched() ? "enjoy" : "flustered") : "shy";

        return switch (tier) {
            case "enjoy" ->
                "The rich aroma of fresh espresso and warm pastries fills the cozy cafe, "
              + "mixing with the faint metallic hum of the AC blowing cool air across your skin. "
              + "You stretch up confidently on your toes toward the top shelf, fingers brushing "
              + "teasingly short of the syrup bottle as the thin fabric of your top pulls tight "
              + "across your chest and rides up at the waist. "
              + "The cool air kisses the strip of bare skin it reveals, while a light nervous sweat "
              + "beads warmly along your spine and under your arms. "
              + "You bite back a small smile, secretly enjoying the stretch and the way it makes "
              + "your body feel on display.";
            case "flustered" ->
                "The rich aroma of fresh espresso and warm pastries fills the cozy cafe, "
              + "mixing with the faint metallic hum of the AC blowing cool air across your skin. "
              + "You rise onto your toes, reaching for the syrup bottle on the top shelf, "
              + "fingers grazing just out of reach. "
              + "The fabric of your top stretches taut across your body and rides up slightly, "
              + "letting a cool draft kiss the newly exposed skin at your waist. "
              + "A light nervous sweat prickles along your spine as you focus on trying one "
              + "more time without drawing too much attention.";
            default -> // shy
                "The rich aroma of fresh espresso and warm pastries fills the cozy cafe, "
              + "mixing with the faint metallic hum of the AC blowing cool air across your skin. "
              + "You stretch up on your toes toward the top shelf, heart already fluttering as "
              + "your fingers brush just short of the syrup bottle. "
              + "The thin fabric of your top pulls tight across your chest and rides up at the "
              + "waist, exposing a sliver of bare skin that makes you acutely aware of how "
              + "exposed you feel. "
              + "A light nervous sweat beads along your spine and under your arms, your cheeks "
              + "warming as you hope no one notices you struggling.";
        };
    }

    // ── Branch 2: Jump ────────────────────────────────────────────────────────

    /**
     * Dice-driven jump outcome.
     * 1-6: soft landing / minor exposure
     * 7-10: awkward + flash (if croptop + braless)
     * Wardrobe malfunction from jump = surprise = slut_rep gained 0 (handled in YAML).
     */
    public String buildJumpText() {
        int roll = rng.nextInt(10) + 1;
        int skirtRoll = rng.nextInt(10) + 1;
        boolean popFires = buttonPopFires(roll);
        String jiggle = jiggleDesc();
        String nipping = nippingNote("jump");
        boolean bottomFlash = isShortSkirt() && isCommando() && skirtRoll >= 5;
        boolean topFlash = isCroptop() && isBraless() && roll >= 7;
        boolean anyFlash = topFlash || bottomFlash || popFires;

        // Set flag so reaction choices can gate surprise slut_rep correctly
        if (anyFlash) state.changeStat("flag_cafe_jump_flashed", 1);

        StringBuilder sb = new StringBuilder();
        sb.append("You bend your knees and give a quick hop, reaching high.\n\n");

        if (topFlash) {
            // Hard landing with top flash — Grok hard landing prose
            String reaction = thrillsFromWatching()
                ? (lovesBeingWatched()
                    ? "A surprised laugh escapes before you can stop it. You quickly pull the crop "
                      + "top back down, but not before giving the room a playful, embarrassed grin.\n\n"
                      + "\"Whoops…\"\n\n"
                      + "*Fuck — my tits just popped out completely in the cafe. The crop top betrayed "
                      + "me hard, but the rush of adrenaline and the looks I'm getting right now feel "
                      + "weirdly exciting. Still scrambling to cover though.*"
                    : "You suck in a sharp breath as the crop top flips up. Immediately you twist "
                      + "away slightly and tug the hem back down, cheeks burning.\n\n"
                      + "\"Shit…\" you mutter under your breath.\n\n"
                      + "*The top rode all the way up on that landing. My breasts were completely "
                      + "exposed for a second — nipples and all. I'm mortified but trying to play it "
                      + "cool while covering up as fast as possible.*")
                : "Shock freezes you for half a heartbeat. Then you scramble frantically, yanking "
                  + "the crop top down with both hands while heat floods your face. Your voice comes "
                  + "out as a mortified whisper.\n\n"
                  + "\"Oh my god…\"\n\n"
                  + "*No no no — my tits just bounced out right here in the middle of the cafe. "
                  + "Everyone saw. The fabric barely covers anything now and my nipples are still hard "
                  + "from the AC. I want to disappear.*";
            sb.append(reaction);
        } else {
            // Soft landing — no flash, minor physical effects by breast size
            String jiggleProse;
            String thought;
            if (hasTrait("breast_f") || hasTrait("breast_e")) {
                jiggleProse = "Your landing sends a powerful, eye-catching bounce through your chest. "
                    + "They sway and jiggle heavily inside the crop top for several long seconds, "
                    + "the fabric straining and lifting to reveal a significant strip of underboob "
                    + "before slowly settling back.";
                thought = "*Oh no… that bounce was so obvious and lasted forever. "
                    + "The fabric strained and the AC chill kissed so much skin. "
                    + "I feel completely on display even though nothing actually came out.*";
            } else if (hasTrait("breast_d")) {
                jiggleProse = "The landing makes your breasts bounce heavily — a pronounced jiggle "
                    + "that lasts several seconds. The crop top strains noticeably across your chest, "
                    + "the hem lifting just enough to flash a sliver of underboob before dropping back.";
                thought = "*God, they really bounced… the weight made them move so much. "
                    + "The fabric pulled tight and the cool air hit for a second. "
                    + "I feel so self-conscious right now.*";
            } else if (hasTrait("breast_c")) {
                jiggleProse = "The impact sends a noticeable bounce through your chest. "
                    + "Your breasts jiggle briefly inside the crop top, "
                    + "the fabric stretching then snapping back. "
                    + "A light sheen of nervous sweat forms along your skin.";
                thought = "*They bounced pretty hard… I felt the weight shift and the top pull tight. "
                    + "The AC made my nipples stiffen a bit. "
                    + "This is embarrassing even without flashing anyone.*";
            } else if (hasTrait("breast_b")) {
                jiggleProse = "A modest, natural bounce on impact — your breasts press briefly "
                    + "against the thin fabric before settling. "
                    + "The crop top tightens slightly across your chest for a moment.";
                thought = "*They bounced a little… nothing crazy, but I felt the fabric pull. "
                    + "Hope no one noticed.*";
            } else {
                jiggleProse = "The landing causes only a light, subtle movement — "
                    + "barely noticeable, settling almost immediately.";
                thought = "*Barely anything happened. The top stayed down. "
                    + "Still, the AC chill made my nipples tingle for a second.*";
            }
            if (!nipping.isEmpty()) jiggleProse += " " + nipping;
            sb.append(jiggleProse).append("\n\n").append(thought);
        }

        return sb.toString();
    }

    // ── Branch 3: Stretch ─────────────────────────────────────────────────────

    /**
     * Stretch outcome — deliberate, she knows she's showing.
     */
    public String buildStretchText() {
        String jiggle  = jiggleDesc();
        String nipping = nippingNote("stretch");
        boolean braless = isBraless();

        String baseStretch = "You push up onto your tiptoes and arch your back deeply, "
            + "chest thrust forward as you reach as high as you can.\n\n"
            + "The fabric of your top stretches drum-tight across your breasts";
        if (braless)
            baseStretch += " with nothing underneath";
        baseStretch += ". The cafe's AC blows steadily across your chest, "
            + "making your nipples harden and press prominently against the taut material";
        if (isPierced())
            baseStretch += " — the metal catching the overhead light with every small shift";
        baseStretch += ".\n\n";

        String reaction = lovesBeingWatched()
            ? "*God, this stretch makes my tits look incredible — the top is stretched so tight "
              + "and my nipples are poking right through from the AC. I know people can see, and "
              + "part of me loves how bold and on-display it feels right now.*"
            : thrillsFromWatching()
            ? "You focus on the shelf, trying to ignore how exposed the pose feels.\n\n"
              + "*This stretch is really pushing my chest out… the crop top is pulled so tight and "
              + "the AC is making my nipples visible. It's a little embarrassing how obvious it is, "
              + "but I just need that syrup.*"
            : "Your face burns as you hold the stretched position, feeling obscenely on display.\n\n"
              + "*Oh god… I'm basically presenting my chest like this. The top is so tight my nipples "
              + "are showing through — the AC is making them so hard and obvious. I hope no one is "
              + "staring… but I can't reach the bottle without holding it.*";

        String extra = "";
        if (!jiggle.isEmpty()) extra += "With each tiny adjustment: " + jiggle + ".\n\n";
        if (!nipping.isEmpty()) extra += nipping + "\n\n";

        return baseStretch + extra + reaction;
    }

    // ── Branch 4: Hesitate ────────────────────────────────────────────────────

    /**
     * Shy hesitation — physical body awareness before and during the reach.
     */
    public String buildHesitateText() {
        String nipping = nippingNote("hesitate");
        boolean braless  = isBraless();
        boolean pierced  = isPierced();

        String pause = "You freeze mid-stretch, arms still raised, "
            + "chest pushed forward in that dramatic, sustained pose.\n\n";

        String body;
        if (braless && pierced)
            body = "No bra, and the metal of your piercings presses clearly through the taut fabric. "
                 + "The AC has turned your nipples into stiff, prominent peaks that tent the material "
                 + "shamelessly — the rings catching the light with every shallow breath.\n\n"
                 + "*Oh god… no bra was such a stupid choice today. My nipples are poking out so "
                 + "obviously — the cold air is making them ache and everyone who glances over will "
                 + "notice the metal glinting. I feel completely on display.*";
        else if (braless)
            body = "No bra means the crop top clings to your bare breasts with nothing underneath. "
                 + "The AC makes your nipples harden into stiff, obvious peaks that tent the fabric "
                 + "shamelessly.\n\n"
                 + "*Oh god… no bra was such a stupid choice today. My nipples are poking out so "
                 + "obviously — the cold air is making them ache and everyone who glances over will "
                 + "notice. I feel completely on display, like my chest is the main attraction.*";
        else if (pierced)
            body = "The piercings press clearly through the taut fabric, catching the overhead light "
                 + "with each tiny shift. Your nipples are already stiff and sensitive from the AC "
                 + "— every breath makes them drag against the material.\n\n"
                 + "*They're so hard… the AC is making my nipples poke through like this. I can feel "
                 + "them rubbing against the material with every tiny breath. What if the barista is "
                 + "watching? I must look so exposed right now, stretched like this.*";
        else
            body = "The fabric pulls drum-tight across your chest. The AC chill bites at your skin, "
                 + "making your nipples stiffen into clear, prominent points beneath the stretched material.\n\n"
                 + "*Everyone can see how tight this top is… my nipples are probably showing. I look so "
                 + "ridiculous stretched out like this in the middle of the cafe. I should just give up "
                 + "and ask for help… but it's right there.*";

        String pushThrough = "\n\nSelf-consciousness makes your thighs press together instinctively, "
            + "nervous sweat sliding down your back. But you push through the hesitation anyway — "
            + "extending your reach with quiet, shaky determination.";

        if (!nipping.isEmpty()) body += "\n\n" + nipping;
        return pause + body + pushThrough;
    }

    // ── Branch 5 / 7: Callout / Sleazy ───────────────────────────────────────

    /**
     * Callout text — shows AFTER she calls out to the line.
     * First visit: branch 5 opener. Repeat: branch 7 opener.
     * Dedicated scenes (cafe_top_shelf_sleazy_first / repeat) handle the outcomes.
     * Token resolves in scene text, not result_text (fix applied).
     */
    public String buildCalloutText() {
        boolean isRepeat = state.getBodyFlag("flag_cafe_sleazy_visited");
        return isRepeat ? buildSleazyRepeatText() : buildSleazyFirstText();
    }

    /**
     * Branch 5 — Sleazy guy, first visit.
     * Groping = surprise. Slut_rep gained from groping = 0.
     * Well-Read reaction always fires if trait present.
     */
    public String buildSleazyFirstText() {
        int gropeDice = rng.nextInt(10) + 1;
        String gropeTier = gropeDice <= 4 ? "mild" : gropeDice <= 7 ? "medium" : "bold";
        boolean wellRead = isWellRead();

        StringBuilder sb = new StringBuilder();

        // Well-Read instinctive reaction — always fires first if trait present
        if (wellRead) {
            sb.append("Something about him is immediately off-putting — the calculated grin, "
                    + "the cheap cologne, the performative charm. Your well-read mind picks up on "
                    + "the tells: eyes that linger too long, confidence that feels rehearsed. "
                    + "Intellectual distaste settles in your stomach before he's said a word.\n\n");
        }

        // His approach
        sb.append("A tall, sleazy-looking guy in his mid-30s steps forward with a greasy grin. "
                + "The overpowering scent of his musky cologne washes over you before he even reaches you.\n\n"
                + "\"Hey there, sweetheart,\" he drawls. \"Looks like you could use a hand.\"\n\n"
                + "His hands settle on your waist from behind — warm, slightly sweaty palms "
                + "pressing through the thin fabric. He steps in close, body heat radiating against your back.\n\n");

        // Shy base reaction
        if (isShy()) {
            sb.append("You stiffen instantly. The cologne makes your nose wrinkle. Heart hammers.\n\n"
                    + "*Oh no… he smells so strong. His hands are already on me and I barely asked. "
                    + "This feels wrong — too close, too familiar for a first meeting. "
                    + "But I'm still stuck reaching… I can't pull away now without looking rude.*\n\n");
        }

        // Grope dice outcome
        switch (gropeTier) {
            case "mild" ->
                sb.append("His hands stay mostly respectful at first, thumbs brushing lightly along your sides. "
                        + "But one thumb \"accidentally\" drifts upward, grazing the underside of your breast "
                        + "through the crop top for a quick, testing touch.\n\n"
                        + "You flinch. Breath catches.\n\n"
                        + "*His thumb just brushed my breast… it wasn't an accident. The cologne is so thick "
                        + "I can taste it, and his body is pressed too close. I feel trapped and exposed.*");
            case "medium" ->
                sb.append("His grip on your waist tightens as he leans in closer, the heavy cologne enveloping you. "
                        + "One hand slides upward slowly while he grabs the bottle — "
                        + "openly cupping the side of your breast and giving a firm, lingering squeeze through "
                        + "the thin fabric before pretending to adjust his hold.\n\n"
                        + "Your body tenses hard. Cheeks flaming.\n\n"
                        + "*He just squeezed my breast… right here in the cafe. His hand felt so bold and his "
                        + "cologne is making me dizzy. This is too much — I'm so uncomfortable, but I asked for "
                        + "help and now his fingers are still lingering. I want to shrink away.*");
            default -> // bold
                sb.append("The moment his hands are on your waist, he gets greedy. While reaching for the bottle "
                        + "with one arm, his other hand boldly slides up and fully gropes your breast — fingers "
                        + "sinking into the soft flesh through the crop top, thumb deliberately brushing across "
                        + "your hardened nipple. A slow, possessive squeeze. His body presses flush against your back.\n\n"
                        + "You freeze in panic. A tiny whimper escapes.\n\n"
                        + "*Oh god — he's groping my tit outright. His hand is so rough and he just rubbed my nipple "
                        + "like he owns it. The cologne is suffocating and his body is pressed all the way against me. "
                        + "I'm mortified… this is my first time in this cafe and a sleazy stranger is feeling me up "
                        + "while \"helping.\" I want to disappear but I can't move.*");
        }

        // Set flag for repeat visit routing
        state.changeStat("flag_cafe_sleazy_visited", 1);
        return sb.toString();
    }

    /**
     * Branch 7 — Sleazy guy, repeat visit.
     * She KNOWS what happens. Slut_rep check already gated on choice.
     */
    public String buildSleazyRepeatText() {
        int gropeDice = Math.min(rng.nextInt(10) + 2, 10); // +1 baseline shift on repeat
        String gropeTier = gropeDice <= 4 ? "mild" : gropeDice <= 7 ? "medium" : "bold";
        boolean wellRead = isWellRead();

        StringBuilder sb = new StringBuilder();

        // Well-Read returning reaction — always fires
        if (wellRead) {
            sb.append("The off-putting feeling returns even stronger. His familiarity feels scripted, "
                    + "his entitlement lifted straight from a lazy sequel. Intellectual distaste "
                    + "hits hard before he's even said a word.\n\n");
        }

        // His approach — bolder, expectant
        sb.append("You smell his cologne before you've even turned around.\n\n"
                + "\"Well, well… look who's back, sweetheart,\" he drawls. "
                + "\"Missed me? Let me give you a proper hand this time.\"\n\n"
                + "His hands settle on your waist without waiting to be asked — "
                + "warmer, more confident than last week. He presses closer as you step onto the stool.\n\n");

        // Shy recognition
        if (isShy()) {
            sb.append("Your stomach drops the moment you recognize him. "
                    + "Memories of last week flood back before you can stop them.\n\n"
                    + "*It's him again… he remembers me. I can't believe I'm in this position a second time. "
                    + "His hands are already on my waist and he's bolder now. "
                    + "I should say no, but the words won't come out. Why did I come back?*\n\n");
        }

        // Grope tier — escalated from first visit
        switch (gropeTier) {
            case "mild" ->
                sb.append("He guides you onto the stool and lets the crop top ride up a little longer "
                        + "than necessary before stepping in to cover you. This time his palms press "
                        + "more firmly — thumbs brushing your nipples deliberately while he \"shields\" you.\n\n"
                        + "*He's doing it again… but his hands feel greedier. Rubbing my nipples on purpose "
                        + "while pretending to help. The cologne is just as suffocating and his body is "
                        + "pressed tighter. I'm so embarrassed I can barely breathe.*");
            case "medium" ->
                sb.append("The fabric rides up slowly, flashing your breasts. "
                        + "He covers you quickly, but this time gives a slow, possessive squeeze to each breast — "
                        + "fingers sinking into soft flesh, thumbs circling your hardened nipples. "
                        + "His breath hits your ear, hot and close.\n\n"
                        + "*He's squeezing my breasts outright now… playing with my nipples like he owns them. "
                        + "Last week was bad enough, but he's so much bolder this time. "
                        + "I feel trapped and violated, yet I'm frozen while everyone might be watching.*");
            default -> // bold
                sb.append("He doesn't wait for a full flash this time. "
                        + "One hand slides straight under the rising fabric, groping your bare breast "
                        + "before it's even fully exposed. When the top clears completely, both hands "
                        + "maul openly — squeezing, lifting, pinching your nipples while keeping you "
                        + "\"hidden\" from view.\n\n"
                        + "*Oh god — he went straight under my top this time. Groping and pinching like "
                        + "he has every right. The cologne, his heavy breathing, his body pressed against mine — "
                        + "it's worse than last week. I'm mortified and my heart is racing, but I can't push "
                        + "him away without making a huge scene.*");
        }

        // Parting lines vary by grope intensity
        String[] partingLines = {
            "\n\n\"There you go, sweetheart. Same time next week? I'll be waiting to help my favorite customer.\"",
            "\n\n\"Careful with that top next time… or don't.\" He winks. \"I don't mind fixing it for you.\"",
            "\n\n\"You feel even better than last week. Don't be a stranger, pretty thing.\""
        };
        sb.append(partingLines[gropeDice % 3]);

        return sb.toString();
    }

    // ── Branch 5.3 / 7.3: Step Stool ─────────────────────────────────────────

    /**
     * Step stool flash + sleazy cover.
     * She had partial awareness of risk (req 2 on entry).
     * Slut_rep from flash: 50% of standard (partial awareness).
     * Cover = surprise = 0 slut_rep.
     */
    public String buildStoolText() {
        int flashDice  = rng.nextInt(10) + 1;
        boolean isRepeat = visits >= 1;

        String flashDesc;
        String mcThought;

        if (flashDice <= 3) {
            // Brief — 2 seconds
            flashDesc = "The crop top rides up just enough for a quick flash — "
                + "both breasts bounce free for a brief moment before he steps in.";
            mcThought = "*Just a second… but he saw everything. Now his bare hands are on my breasts, "
                + "warm and heavy, pretending to 'help' so others don't see. "
                + "The cologne is suffocating and I can feel his thumbs resting right against my nipples. "
                + "I want to die.*";
        } else if (flashDice <= 7) {
            // Noticeable — 4-5 seconds
            flashDesc = "The fabric continues its slow, agonizing ride upward. "
                + "Your breasts spill out completely and jiggle softly in the open air for several "
                + "long seconds while you're balanced on the stool. "
                + "He lets it happen just long enough to get a good look, then presses forward, "
                + "covering your bare chest with both hands — fingers spreading wide over your soft flesh.";
            mcThought = "*It won't stop riding up… my tits are completely out and bouncing in front of him. "
                + "He's staring. Now his hands are covering me, but he's squeezing a little, "
                + "thumbs brushing my nipples like it's part of 'helping.' "
                + "I'm so embarrassed I can't breathe, but I can't shove him away without everyone noticing.*";
        } else {
            // Prolonged — 6+ seconds
            flashDesc = "The crop top keeps sliding higher in slow motion, fully exposing your breasts "
                + "and holding them bare for an extended, humiliating stretch of time. "
                + "They bounce gently with your shaky breathing while the sleazy guy watches openly. "
                + "Only then does he move in close, pressing his body against yours and covering "
                + "your breasts with both hands — palms kneading slightly under the guise of shielding you.";
            mcThought = "*It's been too long… my breasts are just hanging out on the stool in the middle "
                + "of the cafe and he's taking his time looking. Now his hands are on me — bare skin to bare skin — "
                + "covering me so no one else sees, but his fingers are groping. "
                + "The cologne, the heat of his body, the way he's holding my tits… "
                + "I feel completely violated and trapped. Please let this end.*";
        }

        String coverLine = isRepeat
            ? "\"Whoa, easy there — I got you covered again. Wouldn't want the whole cafe seeing everything, "
              + "right? Just relax while I steady you… there we go, nice and safe now. "
              + "See? I'm always here when you need me.\""
            : "\"Whoa, easy there, sweetheart! I got you covered. "
              + "Wouldn't want the whole cafe seeing everything, right? "
              + "Just relax while I steady you… there we go, nice and safe now.\"";

        String parting = "\n\nAs his hands finally withdraw, one thumb drags slowly across your "
            + "now-covered nipple — a deliberate parting contact that sends a sharp, unwanted jolt "
            + "down your spine.\n\n"
            + "\"See? Just helping. " + (isRepeat ? "Again. You really do need me around, don't you? " : "")
            + "Anytime you need a hand… or two.\"";

        // Set flash flag
        state.changeStat("flag_cafe_jump_flashed", 1);

        return flashDesc + "\n\n" + coverLine + "\n\n" + mcThought + parting;
    }

    // ── Customer reactions ────────────────────────────────────────────────────

    /**
     * Customer reaction text scaled by attention roll.
     * Reactions auto-appended with trait notes (pierced, diaphanous, etc.)
     */
    public String buildCustomerText() {
        if (customerAttentionRoll == 0) rollCustomerAttention();
        String tier = attentionTier();

        // High attention: combine two distinct reactions
        if (tier.equals("high")) {
            int r1 = rng.nextInt(18) + 1;
            int r2;
            do { r2 = rng.nextInt(18) + 1; } while (r2 == r1);
            return singlePatronReaction(r1) + "\n\n" + singlePatronReaction(r2);
        }

        return singlePatronReaction(rng.nextInt(18) + 1);
    }

    private String singlePatronReaction(int pick) {
        return switch (pick) {
            // ── Set 1: flash / covering reactions ────────────────────────────
            case 1 ->
                "An older woman at the nearest table gasps softly, hand flying to her mouth. "
              + "She quickly looks away, cheeks pink, and mutters under her breath, "
              + "\"Good heavens… in broad daylight.\"";
            case 2 ->
                "The college-aged guy sitting by the window nearly spills his latte. "
              + "His eyes widen for a split second before he jerks his gaze away, "
              + "ears burning red. He fumbles with his phone, pretending to scroll.";
            case 3 ->
                "A woman in her late twenties with a laptop smirks behind her iced coffee, "
              + "raising one eyebrow as she watches. "
              + "She doesn't look away immediately, clearly entertained.";
            case 4 ->
                "An older man at the counter clears his throat loudly and shakes his head, "
              + "frowning deeply. He mutters just loud enough to be heard, "
              + "\"Some people have no shame these days…\"";
            case 5 ->
                "A middle-aged customer nearby keeps sipping her drink but steals quick glances, "
              + "then looks pointedly at her book. "
              + "Her expression stays carefully neutral, though her cheeks are slightly flushed.";
            case 6 ->
                "A group of two friends at a nearby table whispers and giggles quietly, "
              + "one of them leaning over to get a better look before the other elbows her. "
              + "They both grin, clearly enjoying the spectacle.";
            // ── Set 2: bold groping, repeat visit ────────────────────────────
            case 7 -> {
                boolean isRepeat = visits >= 1;
                yield isRepeat
                    ? "A sharply dressed woman in her forties narrows her eyes and shakes her head. "
                      + "She leans toward her companion and says, just loud enough to carry, "
                      + "\"Some girls these days have no self-respect… letting a man paw at them right in public.\""
                    : "A woman nearby glances over with a slight frown. "
                      + "She turns back to her drink without comment, but the look stays.";
            }
            case 8 ->
                "A guy in his early twenties at a high-top table leans forward, "
              + "not bothering to hide his grin. "
              + "He mutters something to himself — you can't hear it over the machines, "
              + "but the expression is easy to read.";
            case 9 ->
                "A young couple at the next table exchange an awkward glance. "
              + "The woman looks down at her phone immediately. "
              + "Her partner shifts in his seat, jaw set, "
              + "clearly deciding whether to say something.";
            case 10 ->
                "A girl around your age yanks one earbud out and stares. "
              + "She whispers something sharp to her friend — "
              + "you catch the word \"gross\" and the direction of her gaze.";
            case 11 ->
                "One of the other baristas catches the whole thing from across the counter. "
              + "They raise an eyebrow and mouth something at you — "
              + "probably \"you good?\" — while very obviously not laughing.";
            case 12 ->
                "A confident woman in business casual sips her coffee and watches "
              + "with the expression of someone who has already decided what she thinks. "
              + "She doesn't look away. She doesn't look disapproving either.";
            // ── Set 3: escalation / managerial awareness ─────────────────────
            case 13 ->
                "A woman in yoga pants with a stroller makes a point of covering her toddler's eyes. "
              + "\"This is a family place,\" she says, loud and deliberate. "
              + "Nobody in the line disagrees out loud.";
            case 14 ->
                "A man in the corner hasn't moved. "
              + "He's not pretending to look at anything else. "
              + "His expression is the uncomfortable kind of attentive.";
            case 15 ->
                "A woman nearby meets your eyes for just a moment. "
              + "Her expression is concerned — the quiet kind that asks without speaking. "
              + "She looks away before you can respond.";
            case 16 ->
                "Three women at a corner table have stopped pretending to talk to each other. "
              + "One of them leans in. You catch the phrase \"is she into that?\" "
              + "before the espresso machine drowns the rest.";
            case 17 ->
                "A bearded guy with an oat milk latte chuckles quietly to himself "
              + "and says, to no one in particular, "
              + "\"Ten out of ten for commitment to the bit.\"";
            default -> { // 18 — shift manager
                yield state.hasTrait("cafe_worker")
                    ? "Your shift manager is watching from behind the counter. "
                      + "Arms crossed. Expression flat. "
                      + "The look says *we will be talking about this later* without using any words."
                    : "The barista behind the counter glances over once, then goes back to steaming milk. "
                      + "The deliberate non-reaction is somehow worse than staring.";
            }
        };
    }

    // ── Closing beat ──────────────────────────────────────────────────────────

    /**
     * Closing text — pours syrup, straightens up, returns to shift.
     * Grope tier inferred from session state.
     * Token: {cafe_closing_text}
     */
    public String buildClosingText() {
        boolean bold   = state.getBodyFlag("flag_cafe_sleazy_visited") && visits >= 2;
        boolean medium = state.getBodyFlag("flag_cafe_sleazy_visited") && !bold;

        String grind;
        String thought;
        if (bold) {
            grind  = "Straightening your crop top becomes almost frantic — you tug it down hard "
                   + "and smooth it over your chest again and again, desperate to erase any evidence "
                   + "of what just happened. ";
            thought = "*His hands were all over my bare tits… I can still smell his cologne. "
                    + "I feel so dirty and exposed. How am I supposed to finish my shift? "
                    + "I just want to go home and hide.*\n\n";
        } else if (medium) {
            grind  = "You straighten the crop top hurriedly, pulling it down and adjusting it "
                   + "multiple times to make sure nothing is still showing. ";
            thought = "*He squeezed me so openly… I can still feel his fingers. "
                    + "My face is probably bright red and I have to go back to work like nothing happened. "
                    + "This shift is going to feel endless.*\n\n";
        } else {
            grind  = "You straighten the crop top with a quick, firm tug and smooth the fabric "
                   + "down over your chest. ";
            thought = "*I can still feel where his hands were… my skin is tingling. "
                    + "I just want to disappear, but I have to finish my shift. "
                    + "No one can know how embarrassed I am right now.*\n\n";
        }

        return "You finally pour the syrup into your drink, hands still slightly unsteady. "
             + grind + "\n\n" + thought
             + "The rich espresso aroma fills your nose again — steadier now, familiar. "
             + "You take a breath, straighten your posture, and step back to the counter — "
             + "forcing a small, professional smile as you resume serving customers.\n\n"
             + "The espresso machines keep hissing. The AC keeps blowing. "
             + "The cafe keeps going like nothing happened.";
    }
}
