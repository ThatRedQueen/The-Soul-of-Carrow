package game;

import java.util.*;

/**
 * A single "moment" that can occur during a slow dance.
 * The pool is filtered by current state flags, then weighted-random selected.
 * Each moment fires once per session (tracked by id in usedMoments set).
 */
public class DanceMoment {
    /** Unique id used to track whether this moment has already fired. */
    public final String  id;
    /** Scene text — supports {breast_desc} token, will be processed by applyTextVars. */
    public final String  text;
    /** Arousal change on this moment firing. */
    public final int     arousalDelta;
    /** NPC arousal change. */
    public final int     npcArousalDelta;
    /** NPC frustration change (negative = relieves frustration). */
    public final int     npcFrustrationDelta;
    /** NPC liking change. */
    public final int     npcLikingDelta;
    /** Flags set true when this moment fires. */
    public final Set<String> setsFlags;
    /** All of these flags must be true for moment to appear. Empty = no requirement. */
    public final Set<String> requiresFlags;
    /** All of these flags must be false for moment to appear. Empty = no requirement. */
    public final Set<String> blocksIfFlags;
    /** Relative weight (higher = more likely). Default 10. */
    public final int     weight;
    /** If true, can fire multiple times in same session. Default false. */
    public final boolean repeatable;
    /** If set, moment only appears when MC has this trait (e.g. clothing traits). */
    public final String  requiredMcTrait;
    /** Minimum gameStageVariant to appear: "shy", "flustered", "enjoy". Empty = any. */
    public final String  minStage;

    public final int     minMcArousal;
    /** If > 0, only appears when state.currentNpcArousal >= this value. */
    public final int     minNpcArousal;
    /** If > 0, only appears when state.currentNpcArousal < this value. */
    public final int     maxNpcArousal;
    /** If > 0, only appears when state.drunk >= this value. */
    public final int     minDrunk;

    /** If true, moment only fires for MALE-type NPCs (cock/erection/pants-cum content). */
    public final boolean maleOnly;

    private DanceMoment(Builder b) {
        this.id                  = b.id;
        this.text                = b.text;
        this.arousalDelta        = b.arousalDelta;
        this.npcArousalDelta     = b.npcArousalDelta;
        this.npcFrustrationDelta = b.npcFrustrationDelta;
        this.npcLikingDelta      = b.npcLikingDelta;
        this.requiredMcTrait      = b.requiredMcTrait;
        this.minMcArousal        = b.minMcArousal;
        this.minNpcArousal       = b.minNpcArousal;
        this.maxNpcArousal       = b.maxNpcArousal;
        this.minDrunk            = b.minDrunk;
        this.setsFlags           = Collections.unmodifiableSet(b.setsFlags);
        this.requiresFlags       = Collections.unmodifiableSet(b.requiresFlags);
        this.blocksIfFlags       = Collections.unmodifiableSet(b.blocksIfFlags);
        this.weight              = b.weight;
        this.repeatable          = b.repeatable;
        this.minStage            = b.minStage;
        this.maleOnly            = b.maleOnly;
    }

    public static Builder id(String id) { return new Builder(id); }

    public static class Builder {
        String id, text = "", minStage = "";
        int arousalDelta = 3, npcArousalDelta = 3, npcFrustrationDelta = -3, npcLikingDelta = 3;
        int weight = 10;
        boolean repeatable = false;
        boolean maleOnly   = false;
        int minDrunk = 0;
        int minNpcArousal = 0;
        int maxNpcArousal = Integer.MAX_VALUE;
        int minMcArousal  = 0;
        String requiredMcTrait = "";
        Set<String> setsFlags = new LinkedHashSet<>(), requiresFlags = new LinkedHashSet<>(), blocksIfFlags = new LinkedHashSet<>();

        Builder(String id) { this.id = id; }
        public Builder text(String t)           { this.text = t; return this; }
        public Builder arousal(int v)           { this.arousalDelta = v; return this; }
        public Builder npcArousal(int v)        { this.npcArousalDelta = v; return this; }
        public Builder npcFrustration(int v)    { this.npcFrustrationDelta = v; return this; }
        public Builder npcLiking(int v)         { this.npcLikingDelta = v; return this; }
        public Builder weight(int v)            { this.weight = v; return this; }
        public Builder repeatable()             { this.repeatable = true; return this; }
        public Builder maleOnly()               { this.maleOnly   = true; return this; }
        public Builder minStage(String s)       { this.minStage = s; return this; }
        public Builder minDrunk(int v)          { this.minDrunk = v; return this; }
        public Builder minNpcArousal(int v)     { this.minNpcArousal = v; return this; }
        public Builder maxNpcArousal(int v)     { this.maxNpcArousal = v; return this; }
        public Builder minMcArousal(int v)      { this.minMcArousal = v; return this; }
        public Builder mcTrait(String t)        { this.requiredMcTrait = t; return this; }
        public Builder sets(String... flags)    { setsFlags.addAll(Arrays.asList(flags)); return this; }
        public Builder requires(String... flags){ requiresFlags.addAll(Arrays.asList(flags)); return this; }
        public Builder blocks(String... flags)  { blocksIfFlags.addAll(Arrays.asList(flags)); return this; }
        public DanceMoment build()              { return new DanceMoment(this); }
    }
}
