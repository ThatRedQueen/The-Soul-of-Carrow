package game;

import game.data.ActivityData;
import org.yaml.snakeyaml.Yaml;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class ActivityLoader {
    private final Map<String, ActivityData> activities = new LinkedHashMap<>();

    @SuppressWarnings("unchecked")
    public void loadAll(String dir) {
        File folder = new File(dir);
        if (!folder.exists()) return;
        Yaml yaml = new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions()));
        File[] _files = folder.listFiles(); if (_files == null) return; for (File f : _files) {
            if (!f.getName().endsWith(".yml")) continue;
            try (InputStream is = new FileInputStream(f)) {
                Map<String,Object> raw = yaml.load(is);
                if (raw == null) continue;
                ActivityData a = new ActivityData();
                a.id             = str(raw, "id");
                a.label          = str(raw, "label");
                a.description    = str(raw, "description");
                a.category       = str(raw, "category");
                if (a.category.isEmpty()) a.category = "General";
                a.slots          = intVal(raw, "slots",     1);
                a.min_slot       = intVal(raw, "min_slot",  1);
                a.max_slot       = intVal(raw, "max_slot",  8);
                a.money_change   = intVal(raw, "money_change", 0);
                a.triggers_scene = str(raw, "triggers_scene");
                // possible_triggers list
                Object pt = raw.get("possible_triggers");
                if (pt instanceof List) {
                    for (Object entry : (List<?>) pt) {
                        if (!(entry instanceof Map)) continue;
                        @SuppressWarnings("unchecked")
                        Map<String,Object> m = (Map<String,Object>) entry;
                        game.data.TriggerData td = new game.data.TriggerData();
                        td.scene_id           = str(m, "scene_id");
                        td.weight             = intVal(m, "weight",             5);
                        td.nothing_multiplier = intVal(m, "nothing_multiplier", 3);
                        td.requires_dynamic_trait = str(m, "requires_dynamic_trait");
                        if (!td.scene_id.isEmpty()) a.possible_triggers.add(td);
                    }
                }
                a.requires_traits  = strList(raw, "requires_traits");
                a.blocks_if_traits = strList(raw, "blocks_if_traits");
                a.stat_changes     = intMap(raw, "stat_changes");
                if (!a.id.isEmpty()) activities.put(a.id, a);
            } catch (Exception e) { System.err.println("Error loading activity " + f.getName() + ": " + e.getMessage()); }
        }
    }

    public ActivityData get(String id) {
        if (id == null) return fallback("stay_home");
        return activities.getOrDefault(id, fallback(id));
    }

    public List<ActivityData> availableAt(int slotNumber, GameState state) {
        int slotsRemaining = 9 - slotNumber;  // how many slots exist from this point onward
        return activities.values().stream()
            .filter(a -> slotNumber >= a.min_slot && slotNumber <= a.max_slot)
            .filter(a -> a.slots <= slotsRemaining)   // must fit in remaining day
            .filter(a -> {
                for (String t : a.requires_traits)  if (!state.hasTrait(t)) return false;
                for (String t : a.blocks_if_traits) if  (state.hasTrait(t)) return false;
                return true;
            }).collect(Collectors.toList());
    }

    private ActivityData fallback(String id) {
        ActivityData a = new ActivityData(); a.id = id;
        a.label = id.replace("_", " "); a.slots = 1; a.category = "General"; return a;
    }

    private String str(Map<String,Object> m, String k) { Object v = m.get(k); return v == null ? "" : v.toString(); }
    @SuppressWarnings("unchecked")
    private List<String> strList(Map<String,Object> m, String k) {
        Object v = m.get(k); List<String> out = new ArrayList<>();
        if (v instanceof List) for (Object o : (List<?>)v) if (o != null) out.add(o.toString());
        return out;
    }
    @SuppressWarnings("unchecked")
    private Map<String,Integer> intMap(Map<String,Object> m, String k) {
        Object v = m.get(k); Map<String,Integer> out = new LinkedHashMap<>();
        if (v instanceof Map) for (Map.Entry<?,?> e : ((Map<?,?>)v).entrySet()) {
            try { out.put(e.getKey().toString(), Integer.parseInt(e.getValue().toString())); } catch (Exception ignored) {}
        }
        return out;
    }
    private int intVal(Map<String,Object> m, String k, int def) {
        Object v = m.get(k); if (v == null) return def;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return def; }
    }
}
