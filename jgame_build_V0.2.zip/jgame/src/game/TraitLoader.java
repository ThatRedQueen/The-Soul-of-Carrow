package game;

import game.data.*;
import org.yaml.snakeyaml.Yaml;
import java.io.*;
import java.util.*;

public class TraitLoader {

    public static List<TraitCategoryData> load(String path) {
        Yaml yaml = new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions()));
        File f = new File(path);
        if (!f.exists()) { System.err.println("traits.yml not found: " + path); return new ArrayList<>(); }
        try (InputStream is = new FileInputStream(f)) {
            List<Map<String,Object>> raw = yaml.load(is);
            List<TraitCategoryData> result = new ArrayList<>();
            for (Map<String,Object> m : raw) {
                TraitCategoryData cat = new TraitCategoryData();
                cat.id             = str(m, "id");
                cat.label          = str(m, "label");
                cat.pickOne        = bool(m, "pickOne",        true);
                cat.showInCreation = bool(m, "showInCreation", true);
                List<Map<String,Object>> tList = (List<Map<String,Object>>) m.getOrDefault("traits", new ArrayList<>());
                for (Map<String,Object> t : tList) {
                    TraitData td = new TraitData();
                    td.id          = str(t, "id");
                    td.label       = str(t, "label");
                    td.description = str(t, "description");
                    td.maleNpcOnly = bool(t, "male_npc_only", false);
                    td.shy_locked  = bool(t, "shy_locked",    false);
                    if (td.description.isEmpty()) td.description = "No description.";
                    cat.traits.add(td);
                }
                result.add(cat);
            }
            return result;
        } catch (Exception e) { System.err.println("Error loading traits: " + e.getMessage()); return new ArrayList<>(); }
    }

    private static String str(Map<String,Object> m, String key) {
        Object v = m.get(key); return v == null ? "" : v.toString();
    }
    private static boolean bool(Map<String,Object> m, String key, boolean def) {
        Object v = m.get(key); return v == null ? def : Boolean.parseBoolean(v.toString());
    }
}
