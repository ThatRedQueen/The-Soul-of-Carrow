package game.data;

import java.util.*;

/** One rentable housing property, loaded from housing/*.yml */
public class HousingData {
    public String id                  = "";
    public String label               = "";
    public String landlord_npc        = "";
    public int    rent                = 0;
    public String unit_type           = "";   // basement/shared/studio/1bed/house
    public String neighbourhood       = "";
    public String neighbourhood_trait = "";   // neighbourhood_respectable etc
    public String unit_trait          = "";   // lives_studio etc
    public Map<String,Integer> stat_changes = new LinkedHashMap<>();

    // Sleep / recovery modifiers
    public int willpower_cap      = 85;
    public int willpower_recovery = 25;
    public int stress_min         = 2;
    public int stress_reduction   = 6;

    public String move_in_scene   = "";
}
