package game.data;

public class TraitData {
    public String  id          = "";
    public String  label       = "";
    public String  description = "No description.";
    public boolean maleNpcOnly = false;  // only valid on male NPCs
    public boolean shy_locked  = false;  // greyed out in creation if Shy is selected
}
