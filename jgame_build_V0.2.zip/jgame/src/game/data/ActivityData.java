package game.data;

import java.util.*;

public class ActivityData {
    public String             id             = "";
    public String             label          = "";
    public String             description    = "";
    public String             category       = "General";
    public int                slots          = 1;
    public int                min_slot       = 1;
    public int                max_slot       = 8;
    public Map<String,Integer> stat_changes  = new LinkedHashMap<>();
    public int                money_change   = 0;
    public String             triggers_scene = "";   // legacy single trigger — kept for compat
    public List<TriggerData>  possible_triggers = new ArrayList<>();
    public List<String>       requires_traits   = new ArrayList<>();
    public List<String>       blocks_if_traits  = new ArrayList<>();
}
