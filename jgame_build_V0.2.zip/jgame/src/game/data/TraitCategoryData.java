package game.data;

import java.util.ArrayList;
import java.util.List;

public class TraitCategoryData {
    public String          id             = "";
    public String          label          = "";
    public boolean         pickOne        = true;
    public boolean         showInCreation = true;
    public List<TraitData> traits         = new ArrayList<>();
}
