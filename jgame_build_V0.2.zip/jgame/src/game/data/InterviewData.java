package game.data;

import java.util.*;

public class InterviewData {
    public String            job_id     = "";
    public List<SmallTalk>   small_talk = new ArrayList<>();
    public List<Question>    questions  = new ArrayList<>();

    public static class SmallTalk {
        public String       boss_line = "";
        public List<Answer> answers   = new ArrayList<>();
    }

    public static class Answer {
        public String  text     = "";
        public boolean positive = true;
        public String  response = "";
    }

    public static class Question {
        public String       question       = "";
        public List<String> choices        = new ArrayList<>();
        public int          correct_index  = 0;           // single correct answer (legacy)
        public List<Integer> correct_indices = new ArrayList<>(); // multiple correct answers
        public String       hint_trait     = "";          // trait that gives a facial hint
        public String       hint_text      = "";          // the hint shown if trait matches

        /** Returns true if this answer index is correct */
        public boolean isCorrect(int idx) {
            if (!correct_indices.isEmpty()) {
                return correct_indices.contains(idx);
            }
            return idx == correct_index;
        }

        /** Returns true if multiple answers are accepted */
        public boolean isMultiCorrect() {
            return correct_indices.size() > 1;
        }
    }
}
