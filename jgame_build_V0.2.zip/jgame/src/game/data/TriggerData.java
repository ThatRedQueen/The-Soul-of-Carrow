package game.data;

/**
 * A possible scene trigger attached to an activity or scene.
 *
 * weight (1–10): relative probability this scene fires when selected from the pool.
 * nothing_multiplier (default 3): how much more likely "nothing" is vs something firing.
 *   Roll = random(1, total_pool_weight × nothing_multiplier)
 *   If roll ≤ total_pool_weight → pick a scene weighted by individual weights.
 *   Lower nothing_multiplier = more likely something fires (2 = more urgent than default 3).
 *
 * requires_dynamic_trait: if set, this trigger is only included in the pool when
 *   the player's current dynamic traits include this flag (e.g. "wearing_skirt",
 *   "wearing_high_heels", "button_pop_risk"). Checked before rolling.
 */
public class TriggerData {
    public String scene_id             = "";
    public int    weight               = 5;   // 1–10
    public int    nothing_multiplier   = 3;
    public String requires_dynamic_trait = "";
    public String requires_flag          = ""; // body flag that must be true  // "" = no clothing gate
}
