package game.data;

import java.util.ArrayList;
import java.util.List;

public class NpcData {
    public String       id          = "";
    public String       name        = "";
    public String       type        = "FEMALE";
    public String       age         = "YOUNG_ADULT";
    public String       race        = "";
    public String       personality = "NEUTRAL";
    public String       career      = "UNEMPLOYED";
    public String       hair_style  = "";
    public String       hair_color  = "";
    public String       eye_color   = "";
    public String       figure      = "";
    public List<String> traits      = new ArrayList<>();
    public int          max_liking  = 100;
    public int          max_love    = 100;
    public String       intro       = "";
    /** If true, this NPC only appears in work contexts — never in social/bar scenes. */
    public boolean      work_only   = false;
    /**
     * Short description used when the player spots this NPC across the bar.
     * If blank, one is generated from appearance fields.
     */
    public String       bar_desc    = "";
}
