package game;

import game.data.InterviewData;
import org.yaml.snakeyaml.Yaml;
import java.io.*;
import java.util.*;

public class InterviewLoader {
    private final Map<String, InterviewData> interviews = new LinkedHashMap<>();

    public void loadAll(String dir) {
        File folder = new File(dir);
        if (!folder.exists()) return;
        Yaml yaml = new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions()));
        File[] _files = folder.listFiles(); if (_files == null) return; for (File f : _files) {
            if (!f.getName().endsWith(".yml")) continue;
            try (InputStream is = new FileInputStream(f)) {
                Map<String,Object> raw = yaml.load(is);
                if (raw == null) continue;
                InterviewData iv = parse(raw);
                if (iv != null && !iv.job_id.isEmpty()) interviews.put(iv.job_id, iv);
            } catch (Exception e) { System.err.println("Error loading interview " + f.getName() + ": " + e.getMessage()); }
        }
    }

    public InterviewData get(String jobId) { return interviews.get(jobId); }

    @SuppressWarnings("unchecked")
    private InterviewData parse(Map<String,Object> raw) {
        InterviewData iv = new InterviewData();
        iv.job_id = str(raw, "job_id");

        // Small talk
        List<Map<String,Object>> stList = (List<Map<String,Object>>) raw.getOrDefault("small_talk", new ArrayList<>());
        for (Map<String,Object> st : stList) {
            InterviewData.SmallTalk talk = new InterviewData.SmallTalk();
            talk.boss_line = str(st, "boss_line");
            List<Map<String,Object>> answers = (List<Map<String,Object>>) st.getOrDefault("answers", new ArrayList<>());
            for (Map<String,Object> a : answers) {
                InterviewData.Answer ans = new InterviewData.Answer();
                ans.text     = str(a, "text");
                ans.positive = Boolean.parseBoolean(a.getOrDefault("positive", "true").toString());
                ans.response = str(a, "response");
                talk.answers.add(ans);
            }
            iv.small_talk.add(talk);
        }

        // Questions
        List<Map<String,Object>> qList = (List<Map<String,Object>>) raw.getOrDefault("questions", new ArrayList<>());
        for (Map<String,Object> q : qList) {
            InterviewData.Question question = new InterviewData.Question();
            question.question   = str(q, "question");
            question.choices    = (List<String>) q.getOrDefault("choices", new ArrayList<>());
            question.hint_trait = str(q, "hint_trait");
            question.hint_text  = str(q, "hint_text");

            // Support both single correct_index and list correct_indices
            Object ci = q.get("correct_indices");
            if (ci instanceof List) {
                for (Object idx : (List<?>) ci)
                    question.correct_indices.add(Integer.parseInt(idx.toString()));
            }
            Object single = q.get("correct_index");
            if (single != null) question.correct_index = Integer.parseInt(single.toString());
            if (question.correct_indices.isEmpty())
                question.correct_indices.add(question.correct_index);

            iv.questions.add(question);
        }

        return iv;
    }

    private String str(Map<String,Object> m, String key) {
        Object v = m.get(key); return v == null ? "" : v.toString();
    }
}
