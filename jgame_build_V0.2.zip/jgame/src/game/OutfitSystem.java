package game;

import game.data.ClothingData;
import game.data.TriggerData;
import java.util.*;

/**
 * Generates passive world scene triggers based on MC's current outfit.
 * Analogous to BounceSystem — call buildTriggers(activityId) and merge
 * into the activity's trigger pool in DayPlannerPanel.
 *
 * Scenes fired: outfit_braless, outfit_braless_bouncing, outfit_nipping,
 *               outfit_commando, outfit_commando_skirt
 *
 * slut_rep gates are enforced here before adding to the pool so low-rep
 * MCs don't get bombarded with scenes they'd find overwhelming.
 */
public class OutfitSystem {

    private static final Set<String> OUTSIDE_ACTIVITIES = new HashSet<>(Arrays.asList(
        "explore", "go_out", "shopping", "go_to_bar", "find_work",
        "velvet_cafe", "neon_fitness", "retail", "bar_staff",
        "skyline_office", "office_admin", "cafe"
    ));

    private final GameState      state;
    private final ClothingLoader clothes;

    public OutfitSystem(GameState state, ClothingLoader clothes) {
        this.state   = state;
        this.clothes = clothes;
    }

    // ── Clothing state helpers ────────────────────────────────────────────────

    public boolean isBraless() {
        if (state.outfitBra == null) return true;
        ClothingData bra = clothes.get(state.outfitBra);
        return bra != null && bra.isNipRisk(); // sheer/bandeau counts as braless for this
    }

    public boolean isBounceProne() {
        if (!isBraless()) return false;
        return state.hasTrait("bounce_prone_3") || state.hasTrait("bounce_prone_4")
            || state.hasTrait("bounce_prone_5") || state.hasTrait("bounce_prone_6")
            || state.hasTrait("bounce_prone_7");
    }

    public boolean isNipping() {
        return state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");
    }

    public boolean isCommando() {
        return state.outfitUnderwear == null;
    }

    public boolean isCommandoInSkirt() {
        if (!isCommando()) return false;
        ClothingData lower = clothes.get(state.outfitLower);
        if (lower == null) return false;
        String slot = lower.id != null ? lower.id.toLowerCase() : "";
        String type = lower.item_type != null ? lower.item_type.toLowerCase() : "";
        return slot.contains("skirt") || type.contains("skirt") || type.contains("dress");
    }

    // ── Trigger pool builder ──────────────────────────────────────────────────

    /**
     * Returns TriggerData entries to merge into the day's activity trigger pool.
     * Only adds entries if: activity involves going outside AND slut_rep meets
     * the gate AND outfit state matches.
     */
    public List<TriggerData> buildTriggers(String activityId) {
        if (!OUTSIDE_ACTIVITIES.contains(activityId)) return Collections.emptyList();

        List<TriggerData> out = new ArrayList<>();
        int rep = state.slut_rep;

        // Braless (gate: rep >= 2)
        if (isBraless() && rep >= 2) {
            if (isBounceProne() && rep >= 5) {
                // Bouncing braless is more specific — skip base braless scene
                out.add(trigger("outfit_braless_bouncing", 3, nothingMult(rep, 5)));
            } else {
                out.add(trigger("outfit_braless", 2, nothingMult(rep, 2)));
            }
        }

        // Nipping (gate: rep >= 10)
        if (isNipping() && rep >= 10) {
            out.add(trigger("outfit_nipping", 2, nothingMult(rep, 10)));
        }

        // Commando in skirt (gate: rep >= 18) — takes priority over basic commando
        if (isCommandoInSkirt() && rep >= 18) {
            out.add(trigger("outfit_commando_skirt", 3, nothingMult(rep, 18)));
        } else if (isCommando() && rep >= 10) {
            out.add(trigger("outfit_commando", 2, nothingMult(rep, 10)));
        }

        return out;
    }

    /**
     * Nothing multiplier: lower when rep is well above the gate (MC is comfortable),
     * higher when rep is barely above (it still registers as a moment).
     */
    private int nothingMult(int rep, int gate) {
        int margin = rep - gate;
        if (margin < 5)  return 3;   // barely unlocked — fires often
        if (margin < 15) return 5;   // comfortable — moderate frequency
        return 8;                     // old hat — rare
    }

    private TriggerData trigger(String sceneId, int weight, int nothingMult) {
        TriggerData t        = new TriggerData();
        t.scene_id           = sceneId;
        t.weight             = weight;
        t.nothing_multiplier = nothingMult;
        return t;
    }
}
