package game;

import game.data.NpcData;
import java.util.*;

/**
 * Moment pools for each NPC personality type.
 *
 * Extracted from BarSystem to keep that class manageable.
 * Each method returns a List<DanceMoment> appropriate for the given NPC.
 *
 * To add a new personality pool: add a method here and a hasTrait branch
 * in BarSystem.getMomentPool().
 */
class NpcMomentPools {

    private final BarSystem bar;

    NpcMomentPools(BarSystem bar) {
        this.bar = bar;
    }

    List<DanceMoment> sleazyMoments(NpcData n) {
        String tier = bar.gameStageVariant();
        List<DanceMoment> p = new ArrayList<>();
        String they = "MALE".equalsIgnoreCase(n.type) ? "{npc_He}" : "{npc_He}";

        p.add(DanceMoment.id("sleazy_pull_flush").text(
            n.name + " yanks you flush against her without warning. You feel every inch of contact.")
            .arousal(4).npcArousal(5).npcFrustration(-4).npcLiking(4).weight(12).build());

        p.add(DanceMoment.id("sleazy_grope_ass").text(
            they + " slides a hand straight down and gropes your ass hard, fingers spreading.\n\n"
            + (tier.equals("shy") ? "*Oh god — {npc_his} hand is on my ass.*" : tier.equals("enjoy") ? "You press back into it." : "You breathe differently."))
            .arousal(5).npcArousal(6).npcFrustration(-5).npcLiking(3).sets("ass_groped").weight(14).build());

        p.add(DanceMoment.id("sleazy_ass_cont").text(
            "{npc_His} hand is still locked on your ass, fingers digging deeper. \"Been groping this ass the whole time and it still feels so fucking good.\"")
            .requires("ass_groped").arousal(4).npcArousal(5).npcFrustration(-3).npcLiking(2)
            .weight(12).repeatable().build());

        p.add(DanceMoment.id("sleazy_breast_over").text(
            they + " slides a hand up under your shirt and cups your breast over your bra, thumb circling.\n\n"
            + (tier.equals("shy") ? "*{npc_He}'s touching my breast right here…*" : tier.equals("enjoy") ? "You arch into it." : "You tense but don't pull back yet."))
            .arousal(6).npcArousal(7).npcFrustration(-5).npcLiking(4)
            .blocks("kissed").sets("breast_groped").weight(11).build());

        p.add(DanceMoment.id("sleazy_breast_direct").text(
            they + " slides under your shirt, and with nothing in the way, {npc_his} palm cups your bare breast directly.\n\n"
            + (tier.equals("shy") ? "*Bare skin — {npc_his} hands on my bare chest.*" : tier.equals("enjoy") ? "You moan softly." : "You go very still."))
            .requires("breast_groped").arousal(7).npcArousal(8).npcFrustration(-5).npcLiking(4).weight(10).build());

        p.add(DanceMoment.id("sleazy_neck_kiss").text(
            they + " moves {npc_his} mouth to your neck and starts sucking — slow, deliberate, marking you.")
            .arousal(6).npcArousal(7).npcFrustration(-5).sets("neck_kissed").weight(10).build());

        p.add(DanceMoment.id("sleazy_mouth_kiss").text(
            they + " captures your mouth in a sloppy, hungry kiss before you've decided about it.")
            .arousal(6).npcArousal(7).npcFrustration(-6).sets("kissed").weight(9).build());

        p.add(DanceMoment.id("sleazy_grind_hard").text(
            they + " grinds {npc_his} obvious hard-on against you deliberately. No pretense about it.")
            .arousal(5).npcArousal(7).npcFrustration(-4).npcLiking(3).weight(11).repeatable().maleOnly().build());

        p.add(DanceMoment.id("sleazy_body_roam").text(
            "{npc_His} hands roam — ass to hip to waist and back. {npc_He}'s mapping her body.\n\n\"Been all over you and I'm still not bored.\"")
            .requires("ass_groped").arousal(5).npcArousal(6).npcFrustration(-4).weight(10).repeatable().build());

        p.add(DanceMoment.id("sleazy_whisper_crude").text(
            they + " presses {npc_his} lips to your ear. Hot breath. A crude whisper about what {npc_he}'d do if you went home with her.")
            .arousal(6).npcArousal(7).npcFrustration(-3).weight(9)
            .minStage("flustered").build());

        p.add(DanceMoment.id("sleazy_hickey_try").text(
            they + " sucks harder on your neck — clearly trying to leave a mark.")
            .requires("neck_kissed").arousal(5).npcArousal(6).npcFrustration(-4).sets("neck_kissed").weight(8).build());

        p.add(DanceMoment.id("sleazy_clothing_comment").text(
            breastCommentFromClothing(n))
            .arousal(4).npcArousal(5).npcFrustration(-2).weight(9).repeatable().build());

        p.add(DanceMoment.id("sleazy_pull_back").text(
            they + " eases back slightly — just enough to look at you. \"You're staying though.\"\n\nIt's not really a question.")
            .arousal(2).npcArousal(2).npcFrustration(3).weight(6).repeatable().build());

        // ── Deepening kiss (requires kissed) ─────────────────────
        p.add(DanceMoment.id("sleazy_deep_kiss").text(
            "{npc_He} pushes the kiss deeper — tongue, hands still moving, grinding not stopping. Sloppy and hungry.\n\n"
            + (tier.equals("shy") ? "*Everything at once — I can't track it all.*" 
             : tier.equals("enjoy") ? "You lean into it. All of it."
             : "You let it happen and don't fully know why."))
            .requires("kissed").arousal(7).npcArousal(8).npcFrustration(-6)
            .sets("deep_kissed").weight(10).build());

        // ── Continuing breast grope (requires breast_groped) ──────
        p.add(DanceMoment.id("sleazy_breast_cont").text(
            "{npc_His} hands stay under your shirt, still kneading. Not slowing down. \"These feel too good to stop.\"\n\n"
            + (tier.equals("shy") ? "*{npc_He} won't stop — hands still on my bare skin.*" 
             : tier.equals("enjoy") ? "You press into it. \"Don't.\""
             : "You breathe through it and don't pull away yet."))
            .requires("breast_groped").arousal(6).npcArousal(7).npcFrustration(-5)
            .weight(11).repeatable().build());

        p.add(DanceMoment.id("sleazy_breast_nipple").text(
            "{npc_His} thumbs roll slowly over your nipples through the fabric — or directly, if there's nothing in the way. Deliberate. Watching your face.")
            .requires("breast_groped").arousal(7).npcArousal(8).npcFrustration(-5)
            .weight(9).build());

        // ── Post-kiss warm check-in ───────────────────────────────
        p.add(DanceMoment.id("sleazy_post_kiss_check").text(
            "\"You tasted sweet as hell.\" She stays close, watching your face. \"That flustered you, didn't it?\"")
            .requires("kissed").arousal(5).npcArousal(5).npcFrustration(-3).weight(9).build());

        // ── Under-skirt over clothes (drunk-specific) ──────────────
        p.add(DanceMoment.id("sleazy_under_skirt").text(
            "She backs you further into the corner — body shielding you from the crowd — and slides a hand under the hem of your skirt. {npc_His} palm cups and rubs firmly between your legs over your panties.\n\n"
            + (state.hasTrait("commando") ? "No fabric in the way. Direct contact." : "")
            + "\n\n" + (tier.equals("shy")
                ? "*{npc_He}'s touching me down there, under my skirt, in the corner — everyone might see {npc_his} arm moving.*"
                : tier.equals("enjoy") ? "You roll your hips forward into {npc_his} palm."
                : "You let it continue for several seconds before your hand drifts toward {npc_his} wrist."))
            .sets("pussy_groped", "cornered").arousal(8).npcArousal(9).npcFrustration(-7)
            .minDrunk(11).weight(10).build());

        // ── Silent escalation (post-kiss, no words) ────────────────
        p.add(DanceMoment.id("sleazy_silent_escalation").text(
            "The kiss breaks. {npc_He} doesn't speak — just breathes heavily, eyes locked on yours. Hands resume without announcement: one on your breast, one sliding under your skirt. Everything in deliberate silence.\n\n"
            + (tier.equals("shy") ? "*{npc_He}'s not saying anything — just watching me while {npc_he} touches everything.*"
             : tier.equals("enjoy") ? "You meet {npc_his} gaze and don't pull back."
             : "You stay frozen in the stillness of it."))
            .requires("kissed").requires("breast_groped").sets("pussy_groped", "cornered")
            .arousal(9).npcArousal(10).npcFrustration(-8).minDrunk(11).weight(9).build());

        // ── Playful energy shift ───────────────────────────────────
        p.add(DanceMoment.id("sleazy_playful_shift").text(
            "{npc_He} grins suddenly and spins you — arms coming back around tight, hands \"accidentally\" grazing your chest during the pull-back. \"Whoops.\" {npc_His} smirk says it wasn't an accident.")
            .arousal(5).npcArousal(6).npcFrustration(-4).weight(8).repeatable().build());

        p.add(DanceMoment.id("sleazy_slow_hand").text(
            "{npc_His} hand on your ass begins sliding upward without a word — hip, waist, ribs — until {npc_his} palm cups your bare breast directly under your shirt. Greedy. Pressing firmly the whole way.\n\n"
            + (tier.equals("shy") ? "*{npc_His} hand just kept moving higher without saying anything… now it's on my bare chest.* [whimper, drunk push at arm]"
             : tier.equals("enjoy") ? "You arch into the arrival. \"Took you long enough.\""
             : "You felt every inch of the journey. You breathe through the arrival and don't stop {npc_him}."))
            .requires("ass_groped").sets("breast_groped").arousal(7).npcArousal(8).npcFrustration(-6)
            .minDrunk(11).weight(10).build());

        p.add(DanceMoment.id("sleazy_post_deep_kiss").text(
            "The kiss breaks. {npc_He} stares at your swollen lips and flushed cheeks with obvious hunger, low groan rumbling in {npc_his} chest. Already thinking about more.")
            .requires("deep_kissed").arousal(6).npcArousal(7).npcFrustration(-4).weight(9).build());

        p.add(DanceMoment.id("sleazy_crude_multi").text(
            "{npc_He} pulls you tighter and crashes {npc_his} mouth onto yours while one hand kneads your bare breast and the other rubs firmly between your legs under your skirt. Low between kisses: \"Tongue in your mouth, tits in my hand, rubbing your pussy. You taste sweet as hell, baby.\"\n\n"
            + (tier.equals("shy") ? "*{npc_He}'s doing everything at once and saying such dirty things…* [whimper, drunk push]"
             : tier.equals("enjoy") ? "You moan louder and grind down onto {npc_his} hand."
             : "The overload hits all at once. You moan into {npc_his} mouth."))
            .requires("kissed").requires("breast_groped").sets("pussy_groped")
            .arousal(10).npcArousal(10).npcFrustration(-8).minDrunk(11).weight(9).build());

        // ── Dirty whisper ────────────────────────────────────────────────────
        p.add(DanceMoment.id("sleazy_dirty_whisper").text(
            buildDirtyWhisperText())
            .requires("kissed").requires("neck_kissed")
            .arousal(7).npcArousal(8).npcFrustration(-5).weight(9).build());

        // ── Natural stopping scenes (NPC backs off on own) ───────────────────
        p.add(DanceMoment.id("sleazy_stops_breast").text(
            "{npc_His} hands slowly slide out from under your shirt and settle on your waist. \"Been playing with these long enough for now.\"\n\n"
            + (gameStageVariant("breast_public").equals("enjoy")
                ? "*Finally.* Some distant part of you is disappointed anyway."
              : "*{npc_He} stopped. The relief and the shame arrive at the same time.*"))
            .requires("breast_groped").arousal(3).npcArousal(3).npcFrustration(2).weight(6).build());

        p.add(DanceMoment.id("sleazy_stops_roaming").text(
            "{npc_His} hands settle — ass, waist — instead of roaming. \"I'll give you a break before you completely fall apart.\"\n\n"
            + (bar.gameStageVariant().equals("enjoy") ? "You catch your breath. Lean into her." : "*Every place {npc_he} touched still tingles.*"))
            .requires("breast_groped").requires("ass_groped").arousal(2).npcArousal(3).npcFrustration(3).weight(5).repeatable().build());

        // ── NPC orgasm (rare, embarrassing — requires very high NPC arousal) ──
        p.add(DanceMoment.id("sleazy_npc_cums").text(
            "She goes rigid mid-grind. Grip on your ass tightens hard for one full second — then releases.\n\n"
            + "A long, very quiet pause.\n\n"
            + "\"...Fuck.\"\n\n"
            + "The warmth spreads against your hip through the fabric. No question what it is.\n\n"
            + "{npc_He} exhales — slow, controlled — then tips {npc_his} chin down at you with a grin that is frankly impressive given the circumstances.\n\n"
            + (bar.gameStageVariant().equals("enjoy")
                ? "\"Look what you did to me,\" {npc_he} murmurs. Not embarrassed. If anything, proud of you.\n\nYou feel the warmth at your hip and press your lips together. *{npc_He} is unbelievable.*"
              : bar.gameStageVariant().equals("flustered")
                ? "\"...That\'s on you,\" {npc_he} says quietly. Half amused. Half not.\n\n*You feel it. {npc_He} knows you feel it. The dance has definitely changed.*"
              : "*Oh god. Did {npc_he} just — yes. {npc_He} did. On the dance floor. Against you.*\n\nYour face is a controlled emergency."))
            .requires("ass_groped").minNpcArousal(88)
            .arousal(5).npcArousal(-40)
            // Frustration spikes to 100 → triggers bar_npc_leaves on next hub tick
            // flag_npc_came set for walk home / morning after references
            .npcFrustration(100).npcLiking(2)
            .sets("npc_came").weight(3).maleOnly().build());

        // ── MC orgasm from fingering (slut_rep 35+, drunk 11+, high MC arousal) ──
        p.add(DanceMoment.id("sleazy_mc_orgasm").text(
            "{npc_His} fingers have been working steadily, and the combination of pressure, rhythm, and the sheer public exposure of it hits a threshold.\n\n"
            + "Your hips stutter. You grab {npc_his} arm — not to stop {npc_him} — just to hold on.\n\n"
            + "It lasts about eight seconds. Long enough that you're fairly sure two people at the bar noticed.\n\n"
            + (gameStageVariant("finger_public").equals("enjoy")
                ? "You exhale against {npc_his} neck. *Well. That happened.* You feel {npc_his} smirk against your ear."
              : "*Oh no. Oh no. Not here. Not like this.*\n\nYou go very still after. {npc_He} says nothing. {npc_His} hand stays where it is."))
            .requires("pussy_groped").minDrunk(11).minMcArousal(78)
            .arousal(-20).npcArousal(10).npcFrustration(-15).npcLiking(8)
            .weight(4).build());

        
        
                p.add(DanceMoment.id("sleazy_conv_1").text(
            "\"You feel good against me when we're not rushing. I could get used to this.\"\n\n"
            + (tier.equals("enjoy") ? "Then don't rush, you say, easy."
             : tier.equals("flustered") ? "That's one way to put it, you murmur."
             : "You stay quiet, a little tense. *Don't read into it.*"))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("sleazy_conv_2").text(
            "\"Most girls try too hard on the dance floor. You're just here. I like that.\"\n\n"
            + (tier.equals("enjoy") ? "Just here, you agree. And I'll stay that way."
             : tier.equals("flustered") ? "Thanks. I think, you say."
             : "*Here.* You're not sure that's a compliment."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("sleazy_conv_3").text(
            "\"Slow like this makes me notice little things. Like how warm you are.\"\n\n"
            + (tier.equals("enjoy") ? "Notice away, you say."
             : tier.equals("flustered") ? "Is that so, you say carefully."
             : "*{npc_He} noticed.* You're hyper-aware of every point of contact."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("sleazy_conv_4").text(
            "\"I'm not even thinking about the next song. That's rare for me.\"\n\n"
            + (tier.equals("enjoy") ? "Neither am I, you admit."
             : tier.equals("flustered") ? "Good, you say softly."
             : "You say nothing. *Okay.* That might be true."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("sleazy_conv_5").text(
            "\"You're making slow dancing feel less boring than usual.\"\n\n"
            + (tier.equals("enjoy") ? "Keep going then, you say."
             : tier.equals("flustered") ? "High bar, you say drily."
             : "*Less boring.* You keep your face neutral."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());

        // Pool complete — Sleazy at 33+
        // ── NPC cums in pants during grinding ────────────────────────────────
        p.add(DanceMoment.id("sleazy_npc_pants_cum").text(
            "She goes very still. Not the controlled kind.\n\n"
            + "{npc_His} hips stutter twice against you — once, twice — then {npc_he} exhales hard\n"
            + "through {npc_his} nose and grips your waist like {npc_he} needs something to hold onto.\n\n"
            + "You feel the warmth spread through the fabric between you. No ambiguity.\n\n"
            + (bar.gameStageVariant().equals("enjoy")
                ? "{npc_He} recovers faster than {npc_he} deserves to. \"...Look what you did,\" {npc_he} says, low and amused. "
                  + "*{npc_He} is genuinely unashamed. I made {npc_him} cum in {npc_his} pants on the dance floor "
                  + "and {npc_he}'s treating it like a compliment.*"
              : bar.gameStageVariant().equals("flustered")
                ? "\"That's,\" she starts. Stops. Starts again: \"That's on you.\"\n\n"
                  + "*It is, technically, on {npc_him}. You keep this observation to yourself.*"
              : "*Oh. Oh that's — {npc_he} just. In {npc_his}. Oh.*\n\n"
                + "You stand very still for a moment, processing. {npc_His} jaw is tight. {npc_He} will not look at you."))
            .minNpcArousal(80).minDrunk(4)
            .arousal(4).npcArousal(-45).npcFrustration(60).npcLiking(4)
            .sets("npc_came").weight(3).maleOnly().build());

        p.add(DanceMoment.id("sleazy_hickey_realize_shy").text(
            "{npc_His} mouth is still latched onto your neck, suction steady and deliberate. It clicks — {npc_he}'s leaving a mark.\n\n"
            + "*{npc_He}'s giving me a hickey — everyone will see it tomorrow.*\n\n"
            + "Panic. You squirm and tilt your shoulder hard, hand pushing weakly at {npc_his} chest. *I can already feel it darkening. Why didn't I stop {npc_him} sooner?*")
            .requires("neck_kissed").blocks("pussy_groped")
            .minStage("shy").arousal(4).npcArousal(6).npcFrustration(-3).weight(8).build());

        p.add(DanceMoment.id("sleazy_hickey_realize_enjoy").text(
            "{npc_His} mouth is latched onto your neck, steady suction darkening the spot. The realization lands warm.\n\n"
            + "*{npc_He}'s marking me. I'll have this for days.*\n\n"
            + "You tilt your head further and let out a soft sound. Hand slides to the back of {npc_his} head instead of pushing away.")
            .requires("neck_kissed").minStage("enjoy")
            .arousal(7).npcArousal(8).npcFrustration(-6).sets("neck_kissed").weight(9).build());

        p.add(DanceMoment.id("sleazy_wrist_pin").text(
            "{npc_He} catches her wrists — one grip, then two — and pins them against the wall as she leans in and claims the kiss harder: deeper tongue, more pressure, zero hesitation.\n\n"
            + (tier.equals("enjoy")
                ? "{npc_He} melts into it. Doesn't fight the grip."
              : "The restraint is firm but not painful. {npc_He} could break it. {npc_He} hasn't tried yet."))
            .requires("kissed").arousal(8).npcArousal(9).npcFrustration(-7)
            .minDrunk(11).minStage("flustered").weight(9).build());

        p.add(DanceMoment.id("sleazy_first_breast_kiss").text(
            "{npc_He} keeps the kiss going while {npc_his} free hand glides up to her breast for the first time — direct, no bra in the way, palm closing warm around the soft bare skin.\n\n"
            + "\"Mmm, first time feeling these… so fucking soft,\" {npc_he} groans against her lips without fully breaking the kiss.\n\n"
            + (tier.equals("shy")
                ? "*Oh god — {npc_his} hand is on my breast! I've never let anyone do this while kissing me.* Eyes fly wide. Small muffled whimper. Squirming weakly."
              : tier.equals("enjoy")
                ? "She presses into {npc_his} hand. *First time and it already feels this good.*"
              : "*{npc_His} hand just moved to my breast mid-kiss — I didn't expect it to be so direct.* Tries to pull back slightly. Can't quite."))
            .requires("kissed").blocks("breast_groped")
            .sets("breast_groped").arousal(8).npcArousal(9).npcFrustration(-7)
            .weight(9).build());

        p.add(DanceMoment.id("sleazy_light_escalation_check").text(
            "{npc_His} hand slides up her side toward her breast — slow, testing.\n\n"
            + (tier.equals("shy")
                ? "She tenses and guides {npc_his} hand back down quietly. {npc_He} groans but lets it go. \"Fine, fine.\""
              : tier.equals("enjoy")
                ? "{npc_He} doesn't stop it."
              : "{npc_He} shifts it back to her waist. {npc_He} complies with a muttered complaint."))
            .arousal(3).npcArousal(4).npcFrustration(-2).weight(8).build());

        // ── Dominant kiss — mouth occupied, physical push-away available ────
        // The "Push away" choice in bar_slow_dance is the stop option.
        // Her mouth is occupied during the kiss; she uses physical action, not words.
        p.add(DanceMoment.id("sleazy_dominant_kiss_v2").text(
            "{npc_He} catches her wrists and pins them to her sides — firm, not painful — then claims her mouth in a harder, deeper kiss. Tongue. Pressure. No asking.\n\n"
            + (tier.equals("enjoy")
                ? "{npc_He} kisses back just as hard, testing {npc_his} grip. {npc_He} holds."
              : "Her mouth is occupied. The only way to stop this is to physically push her back. {npc_He} can feel the choice.")
            + "\n\n*[Push away to stop it. Keep dancing to continue.]*")
            .requires("kissed").arousal(8).npcArousal(9).npcFrustration(-7)
            .minDrunk(11).minStage("flustered").weight(9).build());

        // ── Four decisive escalation steps ─────────────────────────────────
        p.add(DanceMoment.id("sleazy_decisive_under_shirt").text(
            "Hand moves from her waist, slips under her shirt, and cups {npc_him} bare breast directly. One clean motion. No preamble.\n\n"
            + (tier.equals("shy") ? "*{npc_He} just went straight under my shirt.* Body jolts. Small panicked whimper. Arms feel heavy."
             : tier.equals("enjoy") ? "{npc_He} arches into the touch, pressing herself into {npc_his} palm."
             : "Warm direct contact. Tense slightly. Quiet breath."))
            .blocks("breast_groped").sets("breast_groped")
            .arousal(7).npcArousal(8).npcFrustration(-6).weight(8).build());

        p.add(DanceMoment.id("sleazy_decisive_hip_pull").text(
            "Both hands grip her hips and yank {npc_him} flush against her. One firm deliberate grind forward — pressure, no pretense.\n\n"
            + (tier.equals("shy") ? "*{npc_He} just yanked me against her — I can feel {npc_him}.* Eyes wide. Hot embarrassed flush."
             : tier.equals("enjoy") ? "{npc_He} rolls her hips back hard, matching the pressure."
             : "Heavy warmth through {npc_him} core. Breathing faster."))
            .arousal(7).npcArousal(8).npcFrustration(-6).weight(9).repeatable().build());

        p.add(DanceMoment.id("sleazy_decisive_neck_latch").text(
            "Without warning {npc_he} dips and latches {npc_his} mouth onto the side of her neck. Lips sealed. Slow deliberate suction. Clearly aiming to mark {npc_him}.\n\n"
            + (tier.equals("shy") ? "*{npc_His} mouth is on my neck — {npc_he}'s sucking hard.* Panic. Squirms, tilts shoulder weakly."
             : tier.equals("enjoy") ? "{npc_He} tilts {npc_him} head, giving {npc_him} better access."
             : "Jolt. Tense. Wet pull on her skin. Pulse quickens under {npc_his} mouth."))
            .sets("neck_kissed").arousal(6).npcArousal(8).npcFrustration(-6).weight(8).build());

        // ── Dare-back genuine pause ─────────────────────────────────────────
        p.add(DanceMoment.id("sleazy_dare_back_pause").text(
            "{npc_He} does something unexpected — initiates, dares {npc_him}, says something forward. {npc_He} actually stops moving for a second. A genuine, non-cocky grin appears.\n\n\"Shit… didn't think you had it in you.\" She leans in slower than usual. The pause made {npc_him} more careful.")
            .requires("kissed").arousal(5).npcArousal(7).npcFrustration(-5).npcLiking(7).weight(7).build());

        return p;
    }

    // ── ENGAGING ──────────────────────────────────────────────────────────────
    // Current: 8 moments. Need: 12+ more. Ask Grok for: warm conversation beats,
    // respectful escalation, soft kiss variety, compliments that feel genuine.
    List<DanceMoment> engagingMoments(NpcData n) {
        List<DanceMoment> p = new ArrayList<>();
        String d    = drunkTier();
        String they = "MALE".equalsIgnoreCase(n.type) ? "{npc_He}" : "{npc_He}";
        String tier = bar.gameStageVariant();

        p.add(DanceMoment.id("eng_pull_close").text(
            n.name + " pulls you a little closer, hand warm and steady. No pressure — just closer.")
            .arousal(3).npcArousal(3).npcFrustration(-3).npcLiking(5).weight(12).build());

        p.add(DanceMoment.id("eng_compliment").text(
            "\"You know,\" " + n.name + " says softly, \"you're really easy to be around.\"\n\nIt lands somewhere warm.")
            .arousal(2).npcArousal(2).npcFrustration(-3).npcLiking(8).weight(11).build());

        p.add(DanceMoment.id("eng_hand_migrates").text(
            they + " hand migrates slowly — lower back to the top of your ass. {npc_He} pauses there, waiting.\n\n"
            + (tier.equals("shy") ? "You go still." : tier.equals("enjoy") ? "You tilt your hips slightly." : "You don't stop it."))
            .arousal(4).npcArousal(5).npcFrustration(-4).sets("ass_groped").weight(9)
            .minStage("flustered").build());

        p.add(DanceMoment.id("eng_neck_soft").text(
            they + " lips brush your neck — barely there. Almost asks permission.")
            .arousal(5).npcArousal(5).npcFrustration(-5).sets("neck_kissed").weight(8)
            .minStage("flustered").build());

        p.add(DanceMoment.id("eng_first_kiss").text(
            n.name + " tilts {npc_his} head and kisses you — soft, unhurried. Lets you decide what to do with it.")
            .arousal(6).npcArousal(6).npcFrustration(-6).sets("kissed").weight(7)
            .minStage("flustered").build());

        p.add(DanceMoment.id("eng_sway_quiet").text(
            "You sway together without speaking. {npc_His} hand stays steady. The silence is comfortable.")
            .arousal(2).npcArousal(2).npcFrustration(-2).npcLiking(6).weight(10).repeatable().build());

        p.add(DanceMoment.id("eng_asks_okay").text(
            "\"Is this okay?\" {npc_he} asks — hand already a little lower, but the asking is genuine.")
            .arousal(3).npcArousal(4).npcFrustration(-3).npcLiking(7).weight(9).build());

        p.add(DanceMoment.id("eng_forehead").text(
            n.name + " rests {npc_his} forehead against yours. Close. Warm. No rush.")
            .arousal(4).npcArousal(4).npcFrustration(-4).npcLiking(8).weight(8)
            .minStage("flustered").build());

        p.add(DanceMoment.id("eng_deep_kiss").text(
            "The kiss deepens slowly — {npc_he}'s not rushing it. Checks in with a pause. \"Still okay?\"\n\n"
            + (tier.equals("shy") ? "You nod. Your face is warm." 
             : tier.equals("enjoy") ? "You pull her back in for an answer."
             : "\"Yeah,\" you say quietly. {npc_He} continues."))
            .requires("kissed").arousal(6).npcArousal(6).npcFrustration(-6)
            .sets("deep_kissed").weight(9).minStage("flustered").build());

        p.add(DanceMoment.id("eng_breast_cont").text(
            "{npc_His} hand stays where it drifted — not groping, just resting. Warm. Checking if you'll move it.\n\n"
            + (tier.equals("shy") ? "You don't move it. Your heart is loud."
             : tier.equals("enjoy") ? "You press in slightly."
             : "You let it sit there and neither of you says anything."))
            .requires("breast_groped").arousal(4).npcArousal(5).npcFrustration(-4)
            .npcLiking(5).weight(8).build());

        p.add(DanceMoment.id("eng_post_kiss").text(
            "The kiss breaks. She stays close, forehead near yours. \"Hey… you okay? I don't want to push you if it's too much.\"\n\n"
            + (tier.equals("shy") ? "\"It was a lot,\" you whisper. \"Maybe just dance for now.\" {npc_He} nods and holds you a little looser."
             : tier.equals("enjoy") ? "\"I really liked it,\" you say. {npc_He} lights up and kisses your forehead softly."
             : "\"It was good,\" you say quietly. \"Just maybe not too fast.\""))
            .requires("kissed").arousal(3).npcArousal(4).npcFrustration(-4).npcLiking(8).weight(10).build());

        p.add(DanceMoment.id("eng_playful_spin").text(
            "{npc_He} grins and spins you out, pulling you back in with a warm laugh. Energy shifts lighter — bouncy, fun. {npc_His} hands stay respectful on your waist.")
            .arousal(2).npcArousal(3).npcFrustration(-3).npcLiking(6).weight(9).repeatable().build());

        p.add(DanceMoment.id("eng_dip").text(
            "{npc_He} dips you smoothly and holds you there for a second, eyes warm. Then pulls you back up.\n\n\"Told you I could keep up.\"")
            .arousal(4).npcArousal(4).npcFrustration(-4).npcLiking(7).weight(8).build());

        p.add(DanceMoment.id("eng_slow_hand").text(
            "{npc_His} hand rests on your lower back, then begins sliding upward with gentle pressure — over your side, your ribs — pausing there. Tilting {npc_his} head slightly, checking. Then continuing until {npc_he} cups your breast softly.\n\n"
            + (tier.equals("shy") ? "You go still. \"Is this okay?\" {npc_he} asks quietly, already paused."
             : tier.equals("enjoy") ? "You press in slightly. {npc_He} continues."
             : "You don't move it. Your heart is loud."))
            .requires("ass_groped").sets("breast_groped").arousal(5).npcArousal(6).npcFrustration(-5)
            .npcLiking(5).weight(9).build());

        p.add(DanceMoment.id("eng_post_deep_kiss").text(
            "The deep kiss breaks. She looks at you with soft warm eyes, thumb lightly brushing your cheek as {npc_he} studies your flushed face. No rush. Clearly checking if you're okay.")
            .requires("deep_kissed").arousal(4).npcArousal(5).npcFrustration(-4).npcLiking(7).weight(10).build());

        p.add(DanceMoment.id("eng_reads_wrong").text(
            "She moves in for a kiss — then catches your expression and pulls back immediately. \"Sorry. I misread that.\"\n\nHe doesn't make it weird. Just keeps dancing.")
            .arousal(2).npcArousal(3).npcFrustration(-1).npcLiking(8).weight(8).build());

        p.add(DanceMoment.id("eng_hand_checks_in").text(
            "{npc_His} hand drifts toward your hip, then stops just short. {npc_He} meets your eyes. \"How are you doing?\" Genuine question.")
            .arousal(2).npcArousal(2).npcFrustration(-3).npcLiking(9).weight(9).build());

        p.add(DanceMoment.id("eng_dominant_kiss").text(
            "{npc_He} deepens the kiss and gently catches her wrists, drawing them to her sides. Holds them there — firm but careful. Checks her eyes mid-kiss before going deeper.")
            .requires("kissed").arousal(6).npcArousal(7).npcFrustration(-6)
            .minStage("flustered").weight(8).build());

        p.add(DanceMoment.id("eng_first_breast_kiss").text(
            "Mid-kiss, {npc_his} hand drifts upward and rests carefully on her breast for the first time — gentle, staying still. {npc_He} pulls back from the kiss just enough to check her face. \"Still okay?\"\n\n"
            + (tier.equals("shy")
                ? "*Oh — {npc_his} hand is there for the first time.* {npc_He} nods, barely, heart loud."
              : tier.equals("enjoy")
                ? "{npc_He} answers by pressing in slightly."
              : "{npc_He} takes a breath. \"Yeah,\" {npc_he} manages. {npc_He} continues carefully."))
            .requires("kissed").blocks("breast_groped")
            .sets("breast_groped").arousal(6).npcArousal(7).npcFrustration(-6)
            .npcLiking(5).weight(9).build());

        p.add(DanceMoment.id("eng_respects_push_back").text(
            "She starts to pull her hips closer — {npc_he} shifts slightly away. {npc_He} reads it immediately and loosens {npc_his} hold. \"Got it. Just the dancing then.\"\n\nContinues like nothing happened. No awkwardness.")
            .arousal(2).npcArousal(2).npcFrustration(-1).npcLiking(8).weight(8).build());

        // GAP: need 0 more Engaging moments (at target)
        // more conversation beats, soft escalation after forehead touch,
        // warm compliments that vary, slow build to first kiss variety,
        // aftermath/aftermath of kiss, reading her reaction correctly


        
                p.add(DanceMoment.id("eng_conv_1").text(
            "\"You look really peaceful when you dance like this. It's nice.\"\n\n"
            + (tier.equals("enjoy") ? "Me neither. This is perfect, you smile."
             : tier.equals("flustered") ? "Yeah... it's calm, you say softly."
             : "*I... I like it too,* you whisper, cheeks warm.")
            + (!d.equals("sober") ? "\n\nHe says it a little softer. The drink is making everything warmer." : ""))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("eng_conv_2").text(
            "\"I like how we don't have to fill every silence. This feels comfortable.\"\n\n"
            + (tier.equals("enjoy") ? "Same. No performance required, you murmur."
             : tier.equals("flustered") ? "Yeah. It does, you agree."
             : "You nod once, quietly grateful {npc_he} said it first."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("eng_conv_3").text(
            "\"Been a while since I just slowed down with someone. Thanks for that.\"\n\n"
            + (tier.equals("enjoy") ? "Don't thank me. I'm getting something out of it too, you smile."
             : tier.equals("flustered") ? "I'm glad, you say simply."
             : "You look up briefly, not sure what to say. So you don't."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("eng_conv_4").text(
            "\"You have a really gentle way of moving. Makes me want to stay right here.\"\n\n"
            + (tier.equals("enjoy") ? "Then stay, you say quietly, meaning it."
             : tier.equals("flustered") ? "That's a nice thing to say, you murmur."
             : "Your cheeks go warm. *{npc_He} noticed.*"))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("eng_conv_5").text(
            "\"Sometimes I forget how good it feels to just dance without trying to impress anyone.\"\n\n"
            + (tier.equals("enjoy") ? "Not even a little? you tease gently."
             : tier.equals("flustered") ? "Yeah. No audition, you agree."
             : "Is that what this is? you say softly."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("eng_conv_6").text(
            "\"If the song never ended, I wouldn't complain.\"\n\n"
            + (tier.equals("enjoy") ? "Good. Neither would I, you say. You both keep swaying."
             : tier.equals("flustered") ? "Neither would I, you admit quietly."
             : "You don't say anything. But you slow down slightly."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());

                p.add(DanceMoment.id("gen_genuine_curiosity").text(
            "\"What made you want to dance with me tonight?\"\n\n"
            + (tier.equals("enjoy") ? "Because I wanted to be close to you, you say with a small smile."
             : tier.equals("flustered") ? "You seemed nice. And the song was good, you answer honestly."
             : "I don't know. It just felt right, you whisper shyly."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("gen_soft_vulnerability").text(
            "\"I don't usually slow dance. Feels too exposed. But this doesn't.\"\n\n"
            + (tier.equals("enjoy") ? "Then I'm glad it's me, you say warmly."
             : tier.equals("flustered") ? "It's different when it feels easy, you murmur."
             : "Me neither… it's kind of scary, you admit quietly."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("gen_reflective").text(
            "\"Nights like this make me realize I don't slow down enough.\"\n\n"
            + (tier.equals("enjoy") ? "I'm enjoying slowing down with you, you reply warmly."
             : tier.equals("flustered") ? "Then maybe we should do it more often, you suggest quietly."
             : "I don't either, you say softly, swaying with her."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());

        // Engaging pool at 29+
        return p;
    }

    // ── MAGNETIC ──────────────────────────────────────────────────────────────
    // Current: 7 moments. Need: 13+ more.
    List<DanceMoment> magneticMoments(NpcData n) {
        List<DanceMoment> p = new ArrayList<>();
        String tier = bar.gameStageVariant();

        p.add(DanceMoment.id("mag_pulls_flush").text(
            n.name + " pulls you flush without a word. Hand splayed possessively on your lower back.\n\nSilence feels electric.")
            .arousal(5).npcArousal(5).npcFrustration(-5).npcLiking(5).weight(13).build());

        p.add(DanceMoment.id("mag_eye_contact").text(
            "{npc_He} holds eye contact for an uncomfortably long moment. Doesn't look away.\n\n"
            + (tier.equals("shy") ? "You break first." : "You hold it."))
            .arousal(4).npcArousal(5).npcFrustration(-3).npcLiking(6).weight(11).repeatable().build());

        p.add(DanceMoment.id("mag_hand_slides").text(
            "{npc_His} hand slides deliberately to your ass — one smooth motion, like it was always going to end up there.")
            .arousal(5).npcArousal(6).npcFrustration(-5).sets("ass_groped").weight(10).build());

        p.add(DanceMoment.id("mag_close_whisper").text(
            "She leans close — lips at your ear. Doesn't say anything for a second. Just breathes.\n\nThen: \"You feel it too.\"")
            .arousal(7).npcArousal(7).npcFrustration(-6).npcLiking(7).weight(9)
            .minStage("flustered").build());

        p.add(DanceMoment.id("mag_kiss").text(
            "{npc_He} kisses you. Not asking. Not rushing. Just sure.")
            .arousal(7).npcArousal(7).npcFrustration(-7).sets("kissed").weight(8)
            .minStage("flustered").build());

        p.add(DanceMoment.id("mag_neck").text(
            "{npc_His} mouth moves to your neck. Slow. Deliberate. Leaves the rest to your imagination.")
            .arousal(6).npcArousal(7).npcFrustration(-5).sets("neck_kissed").weight(8).build());

        p.add(DanceMoment.id("mag_just_holds").text(
            "{npc_He} just holds you. Not escalating. Not speaking. The restraint feels intentional.")
            .arousal(3).npcArousal(4).npcFrustration(-2).npcLiking(7).weight(9).repeatable().build());

        p.add(DanceMoment.id("mag_deep_kiss").text(
            "{npc_He} doesn't pull back from the kiss. Just goes deeper. Unhurried. Like {npc_he} has all night.\n\n"
            + (tier.equals("shy") ? "Your thoughts go quiet. Something else takes over."
             : tier.equals("enjoy") ? "You meet every bit of it."
             : "You follow where {npc_he} leads."))
            .requires("kissed").arousal(8).npcArousal(8).npcFrustration(-7)
            .sets("deep_kissed").weight(10).minStage("flustered").build());

        p.add(DanceMoment.id("mag_breast_cont").text(
            "{npc_His} hand stays on your chest. Not moving much — just present. The stillness is somehow more intense than the motion.")
            .requires("breast_groped").arousal(6).npcArousal(6).npcFrustration(-5)
            .weight(8).build());

        p.add(DanceMoment.id("mag_post_kiss_silence").text(
            "The kiss breaks. {npc_He} doesn't speak. Just breathes against your neck, eyes dark, holding perfectly still. Waiting to see what you do.")
            .requires("kissed").arousal(7).npcArousal(7).npcFrustration(-5).npcLiking(7).weight(10).build());

        p.add(DanceMoment.id("mag_whisper_lands").text(
            "She leans close to your ear. Waits a full second.\n\n\"I've been thinking about you since you walked in.\"\n\nSays nothing else.")
            .arousal(6).npcArousal(6).npcFrustration(-5).npcLiking(9).weight(9).build());

        p.add(DanceMoment.id("mag_under_skirt").text(
            "One hand stays splayed on your bare chest. The other slides under your skirt — slow and certain — and cups you firmly over the fabric. No announcement. Just steady pressure while {npc_his} eyes stay on yours.")
            .requires("breast_groped").sets("pussy_groped", "cornered")
            .arousal(9).npcArousal(9).npcFrustration(-7).minDrunk(11).weight(8).build());

        p.add(DanceMoment.id("mag_slow_hand").text(
            "{npc_His} hand starts on your ass and begins a deliberate, wordless migration upward. Eyes on your face the entire slide. Hand on ribs — full pause — then continuing to cup your breast. Controlled. Certain.")
            .requires("ass_groped").sets("breast_groped").arousal(7).npcArousal(8).npcFrustration(-6)
            .weight(10).minDrunk(11).build());

        p.add(DanceMoment.id("mag_post_deep_kiss").text(
            "The kiss breaks. {npc_He} doesn't move. Dark eyes locked on your flushed face, breathing steady, hand still on your neck. Not blinking. Making the silence heavier by staying in it.")
            .requires("deep_kissed").arousal(8).npcArousal(8).npcFrustration(-5).npcLiking(8).weight(10).build());

        p.add(DanceMoment.id("mag_crude_multi").text(
            "No announcement. Kiss claims your mouth again while {npc_his} hands settle — breast, then under your skirt. Low against your ear between kisses: \"Mouth, tits, cunt. All mine right now.\"\n\n"
            + (tier.equals("shy") ? "Everything goes still inside you."
             : tier.equals("enjoy") ? "You press into every point of contact."
             : "You breathe through it and don't pull anything back."))
            .requires("kissed").requires("breast_groped").sets("pussy_groped")
            .arousal(10).npcArousal(10).npcFrustration(-8).minDrunk(11).weight(8).build());

        p.add(DanceMoment.id("mag_dominant_kiss").text(
            "{npc_He} catches both her wrists in one motion and pins them — firm, unhurried — while the kiss goes deeper and harder. No words. Just the pressure of {npc_his} hands and {npc_his} mouth.")
            .requires("kissed").arousal(9).npcArousal(9).npcFrustration(-8)
            .minDrunk(11).minStage("flustered").weight(9).build());

        p.add(DanceMoment.id("mag_first_breast_kiss").text(
            "The kiss holds while {npc_his} hand slides up and cups her breast for the first time. Still. Deliberate. Eyes on her face even while doing it.\n\n"
            + (tier.equals("shy")
                ? "*First time anyone's touched me there during a kiss.* She goes very still."
              : tier.equals("enjoy")
                ? "The eye contact makes it more intense. {npc_He} holds it."
              : "{npc_He} exhales slowly through {npc_him} nose. Doesn't pull back."))
            .requires("kissed").blocks("breast_groped")
            .sets("breast_groped").arousal(8).npcArousal(9).npcFrustration(-7)
            .weight(9).build());

        p.add(DanceMoment.id("mag_reads_hesitation").text(
            "She starts to pull her closer. She tenses almost imperceptibly. She stills completely. Waits. \"Too much?\"\n\nHe already knows the answer before {npc_he} gives it.")
            .arousal(3).npcArousal(4).npcFrustration(-2).npcLiking(7).weight(8).build());

        p.add(DanceMoment.id("mag_watching_you").text(
            "{npc_He} lowers {npc_his} head until {npc_his} breath ghosts warm and steady against her neck — no kiss, no touch. Just breathing. Several slow heartbeats. Then, very low: \"I've been watching you all night…\"\n\n"
            + (tier.equals("shy") ? "*Has {npc_he} been looking at me the whole time? {npc_His} breath is so warm…* She goes completely still."
             : tier.equals("enjoy") ? "{npc_He} tilts {npc_him} head slightly, exposing her neck. \"Yeah…?\" Barely audible."
             : "{npc_He} lets out a slow quiet breath. Pulse quickens."))
            .arousal(6).npcArousal(7).npcFrustration(-5).npcLiking(8).weight(10).build());

        p.add(DanceMoment.id("mag_forehead_kiss").text(
            "{npc_He} rests {npc_his} forehead against hers slowly. Both breathe together in the dim light. {npc_He} holds it — charged, still — then draws back just enough to look at {npc_him}. {npc_His} gaze moves from her eyes to her lips. Then she leans in again, unhurried, for a soft second kiss.")
            .requires("kissed").arousal(7).npcArousal(7).npcFrustration(-6).npcLiking(8).weight(9).build());

        p.add(DanceMoment.id("mag_dominant_kiss_v2").text(
            "{npc_He} catches her wrists — both — and holds them at her sides as the kiss goes deeper and harder. Not a question. Eyes open. Watching her face the whole time.\n\n"
            + (tier.equals("enjoy") ? "She presses into it. {npc_He} holds steady."
             : "Her mouth is occupied. The push-away is the only language left."))
            .requires("kissed").arousal(9).npcArousal(9).npcFrustration(-8)
            .minDrunk(11).minStage("flustered").weight(8).build());

        p.add(DanceMoment.id("mag_decisive_hip_pull").text(
            "{npc_He} pulls her flush against her with quiet force. One deliberate grind — slow, controlled, unmistakable. Eye contact doesn't break.")
            .arousal(7).npcArousal(8).npcFrustration(-6).weight(8).repeatable().build());

        p.add(DanceMoment.id("mag_dare_back_pause").text(
            "{npc_He} does something {npc_he} didn't expect. She goes completely still — genuine surprise, the control dropping for a real second. After a slow exhale: \"You caught me off guard. That doesn't happen often.\" She stays close. Waits.")
            .requires("kissed").arousal(5).npcArousal(7).npcFrustration(-5).npcLiking(9).weight(8).build());

        p.add(DanceMoment.id("mag_dirty_whisper").text(
            buildDirtyWhisperText())
            .requires("kissed").requires("neck_kissed")
            .arousal(7).npcArousal(8).npcFrustration(-5).weight(9).build());

        
        
                p.add(DanceMoment.id("mag_conv_1").text(
            "\"You're easier to be around than most people I meet in places like this.\"\n\n"
            + (tier.equals("enjoy") ? "Good. I'm trying, you say with a half-smile."
             : tier.equals("flustered") ? "That's nice to hear, you murmur."
             : "You stay quiet. It lands somewhere anyway."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("mag_conv_2").text(
            "\"I don't usually stay in one spot this long when I dance. You're changing that.\"\n\n"
            + (tier.equals("enjoy") ? "Good. Stay then, you say simply."
             : tier.equals("flustered") ? "I'll take that as a compliment, you say."
             : "You sway a little closer without quite meaning to."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("mag_conv_3").text(
            "\"There's something steady about you. I notice it when we move together.\"\n\n"
            + (tier.equals("enjoy") ? "You're not so bad yourself, you reply, meaning something more."
             : tier.equals("flustered") ? "I'm not always steady, you say honestly."
             : "*Steady.* You've never thought of yourself that way."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("mag_conv_4").text(
            "\"Most nights blur together. This one isn't blurring.\"\n\n"
            + (tier.equals("enjoy") ? "Good. Pay attention to it, you say softly."
             : tier.equals("flustered") ? "Yeah, you say. Just that."
             : "You don't answer. But you feel it too."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("mag_conv_5").text(
            "\"You make the noise in the room feel farther away.\"\n\n"
            + (tier.equals("enjoy") ? "That's the nicest thing anyone's said to me in a bar, you tell {npc_him}."
             : tier.equals("flustered") ? "Is that good? you ask quietly."
             : "*It does feel farther away.* You say nothing."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("mag_conv_6").text(
            "\"I keep catching myself wanting the song to slow down even more.\"\n\n"
            + (tier.equals("enjoy") ? "Tell the DJ, you murmur into {npc_his} shoulder."
             : tier.equals("flustered") ? "Me too, you admit."
             : "You shift slightly closer. You don't explain why."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());

                p.add(DanceMoment.id("gen_genuine_curiosity").text(
            "\"What made you want to dance with me tonight?\"\n\n"
            + (tier.equals("enjoy") ? "Because I wanted to be close to you, you say with a small smile."
             : tier.equals("flustered") ? "You seemed nice. And the song was good, you answer honestly."
             : "I don't know. It just felt right, you whisper shyly."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("gen_quiet_appreciation").text(
            "\"You smell really nice. It's distracting in a good way.\"\n\n"
            + (tier.equals("enjoy") ? "Then keep getting distracted, you murmur with a small grin."
             : tier.equals("flustered") ? "So do you, you say simply."
             : "You blush hard and stay silent for a moment. Thank you, you whisper."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());

        // Magnetic pool at 30+
        return p;
    }

    // ── OUTGOING ──────────────────────────────────────────────────────────────
    // Current: 6 moments. Need: 14+ more.
    List<DanceMoment> outgoingMoments(NpcData n) {
        List<DanceMoment> p = new ArrayList<>();
        String tier = bar.gameStageVariant();

        p.add(DanceMoment.id("out_spins_{npc_him}").text(
            n.name + " spins you out and pulls you back in, laughing. \"See? Natural.\"")
            .arousal(3).npcArousal(3).npcFrustration(-4).npcLiking(7).weight(12).build());

        p.add(DanceMoment.id("out_shout_compliment").text(
            "\"You're a really good dancer!\" " + n.name + " shouts over the music. Means it.")
            .arousal(2).npcArousal(2).npcFrustration(-3).npcLiking(8).weight(11).build());

        p.add(DanceMoment.id("out_pulls_close").text(
            n.name + " pulls you close with both hands on your hips. \"Closer! Can't hear you!\" The excuse is paper-thin.")
            .arousal(4).npcArousal(4).npcFrustration(-4).npcLiking(5).weight(10).build());

        p.add(DanceMoment.id("out_announces_kiss").text(
            "\"Okay, I'm gonna kiss you,\" " + n.name + " announces — and does.")
            .arousal(6).npcArousal(6).npcFrustration(-6).sets("kissed").weight(8)
            .minStage("flustered").build());

        p.add(DanceMoment.id("out_goes_handsy").text(
            "\"Going for it,\" " + n.name + " says cheerfully, hand already sliding to your ass.\n\n"
            + (tier.equals("shy") ? "Caught off guard." : "You laugh despite yourself."))
            .arousal(5).npcArousal(5).npcFrustration(-5).sets("ass_groped").weight(9)
            .minStage("flustered").build());

        p.add(DanceMoment.id("out_hypes").text(
            n.name + " hypes you up mid-dance. \"YES! That move! More of that!\"")
            .arousal(2).npcArousal(3).npcFrustration(-2).npcLiking(7).weight(10).repeatable().build());

        p.add(DanceMoment.id("out_deep_kiss").text(
            "\"Okay I'm going for the deeper kiss now,\" " + n.name + " announces — and does. Laughing a little against your mouth.")
            .requires("kissed").arousal(6).npcArousal(7).npcFrustration(-6)
            .sets("deep_kissed").weight(9).minStage("flustered").build());

        p.add(DanceMoment.id("out_breast_cont").text(
            "{npc_His} hands stay enthusiastically on your chest, still moving. \"These are fantastic, just so you know.\"")
            .requires("breast_groped").arousal(5).npcArousal(6).npcFrustration(-5)
            .weight(8).build());

        p.add(DanceMoment.id("out_post_kiss").text(
            "{npc_He} grins against your cheek after the kiss. \"Whoa — you went all red! Was that too much or just right? Be honest.\"\n\n"
            + (tier.equals("shy") ? "{npc_He} laughs kindly and dials back: \"Okay, okay — we'll keep it chill.\""
             : tier.equals("enjoy") ? "\"Just right,\" you say. {npc_He} cheers softly."
             : "\"Somewhere in between,\" you say. {npc_He} nods and keeps dancing."))
            .requires("kissed").arousal(4).npcArousal(5).npcFrustration(-4).npcLiking(7).weight(10).build());

        p.add(DanceMoment.id("out_dip_graze").text(
            "{npc_He} dips you dramatically and holds you low — hand grazing up your side as {npc_he} pulls you back. \"Staying with me?\" {npc_he} grins.")
            .arousal(5).npcArousal(5).npcFrustration(-4).npcLiking(6).weight(9).build());

        p.add(DanceMoment.id("out_challenge").text(
            "\"Okay, I'm challenging you — keep up.\" {npc_He} shifts into an energetic rhythm, hands guiding your hips playfully. \"Show me what you've got.\"")
            .arousal(3).npcArousal(4).npcFrustration(-3).npcLiking(7).weight(10).repeatable().build());

        p.add(DanceMoment.id("out_slow_hand").text(
            "During a spin {npc_he} keeps one hand on your ass, then slides it upward as you turn — hip, waist, breast on the pull-back. \"Whoops.\" {npc_He} grins. It was not a whoops.")
            .requires("ass_groped").sets("breast_groped").arousal(6).npcArousal(7).npcFrustration(-5).weight(9).build());

        p.add(DanceMoment.id("out_post_deep_kiss").text(
            "Kiss ends. {npc_He} pulls back with bright dazed eyes and a soft laugh. \"Okay. Okay wow. You're really good at that.\"")
            .requires("deep_kissed").arousal(5).npcArousal(6).npcFrustration(-5).npcLiking(8).weight(10).build());

        p.add(DanceMoment.id("out_crude_multi").text(
            "\"Hell yeah — kissing you, groping these tits, and rubbing you under the skirt!\" {npc_he} breathes between kisses, hands doing exactly what {npc_he} said. \"You're soaking already, aren't you?\"\n\n"
            + (tier.equals("enjoy") ? "You moan into {npc_his} mouth and grind down." : "You laugh despite everything."))
            .requires("kissed").requires("breast_groped").sets("pussy_groped")
            .arousal(9).npcArousal(9).npcFrustration(-7).minDrunk(11).weight(8).build());

        p.add(DanceMoment.id("out_dominant_kiss").text(
            "\"Okay, holding your hands now,\" {npc_he} announces — and does, catching her wrists playfully and kissing {npc_him} deeper. \"Is that okay or did I just make it weird?\"\n\n"
            + (tier.equals("enjoy") ? "\"It's not weird,\" {npc_he} laughs into the kiss." : "\"Little weird,\" {npc_he} says. {npc_He} lets go immediately. \"Fair.\""))
            .requires("kissed").arousal(7).npcArousal(7).npcFrustration(-6)
            .minStage("flustered").weight(8).build());

        p.add(DanceMoment.id("out_first_breast_kiss").text(
            "Mid-kiss she moves {npc_his} hand to her breast for the first time, grinning into it. \"Finally getting to feel you here…\"\n\n"
            + (tier.equals("shy") ? "*Oh god — first time and {npc_he}'s so cheerful about it.* [embarrassed whimper mid-kiss]"
             : tier.equals("enjoy") ? "{npc_He} laughs a little into the kiss. \"You've been waiting for that, huh?\""
             : "Surprise hits. Then warmth. {npc_He} lets it settle for a moment."))
            .requires("kissed").blocks("breast_groped")
            .sets("breast_groped").arousal(7).npcArousal(8).npcFrustration(-6).weight(9).build());

        p.add(DanceMoment.id("out_respects_no").text(
            "{npc_He} pulls her hips in and {npc_he} pushes back with a small laugh, hand on {npc_his} chest. *Too much.* {npc_He} reads it immediately, grins, and steps back half a beat. \"Right, right!\" Spins her once to reset the energy.")
            .arousal(2).npcArousal(2).npcFrustration(-1).npcLiking(7).weight(7).build());

        p.add(DanceMoment.id("out_post_dip_personal").text(
            "{npc_He} dips her smoothly and brings her up close. Still a little breathless, {npc_he} says with a warm laugh: \"I spend most nights just messing around… but right now, slow dancing with you? It actually feels real. I like that.\"\n\n"
            + (tier.equals("shy") ? "You blush hard and look down. \"That's… really sweet.\""
             : tier.equals("enjoy") ? "\"That means a lot,\" you say, leaning your forehead to {npc_his}. \"I like when you say things like that.\""
             : "\"I wasn't expecting that,\" you say quietly. \"It's nice to hear something real.\""))
            .arousal(3).npcArousal(4).npcFrustration(-4).npcLiking(10).weight(9).build());

        p.add(DanceMoment.id("out_forehead_kiss").text(
            "{npc_He} touches {npc_his} forehead to hers with a soft smile {npc_he} can feel. A tiny warm laugh escapes before {npc_he} pulls back. {npc_He} waits for her eyes to meet {npc_his}, then leans in for a second kiss — letting {npc_him} meet {npc_him} halfway.")
            .requires("kissed").arousal(5).npcArousal(6).npcFrustration(-5).npcLiking(7).weight(9).build());

        p.add(DanceMoment.id("out_surprise_{npc_he}_matches").text(
            "{npc_He}'s doing {npc_his} usual playful thing — hands on hips, easy rhythm — when {npc_he} matches {npc_him} note for note, move for move. She stops. Actually blinks. \"Wait — you're actually good at this.\"\n\nHe grins differently now. Less performance, more real.")
            .arousal(3).npcArousal(5).npcFrustration(-4).npcLiking(9).weight(8).build());

        p.add(DanceMoment.id("out_decisive_hip_pull").text(
            "{npc_He} grabs her hips and pulls her flush in one enthusiastic motion, laughing as {npc_he} does it. \"Okay yeah, we're doing this.\" The grind that follows is unmistakable even if the delivery was cheerful.")
            .arousal(6).npcArousal(7).npcFrustration(-5).weight(8).build());

        p.add(DanceMoment.id("out_dare_back_pause").text(
            "{npc_He} does something unexpected. She freezes mid-sway — mouth open, genuine shock — then bursts into a bright surprised laugh. \"Whoa — okay, you got me! I did not see that coming from you.\" The laugh is real. {npc_He} pulls her closer with new energy.")
            .requires("kissed").arousal(4).npcArousal(6).npcFrustration(-4).npcLiking(9).weight(8).build());

        
        
                p.add(DanceMoment.id("out_conv_1").text(
            "\"Okay, I'll admit it — slow dancing with you is way better than I expected.\"\n\n"
            + (tier.equals("enjoy") ? "High praise. Tell your friends, you grin."
             : tier.equals("flustered") ? "Was the bar that low? you reply."
             : "You give a tiny, embarrassed laugh."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("out_conv_2").text(
            "\"You've got this cute little sway thing going on. It's contagious.\"\n\n"
            + (tier.equals("enjoy") ? "You're welcome, you say, and do it more deliberately."
             : tier.equals("flustered") ? "Now I'm self-conscious, you say."
             : "You immediately try to change your sway and overcorrect."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("out_conv_3").text(
            "\"I usually bounce around the whole floor… but I'm not in a rush tonight.\"\n\n"
            + (tier.equals("enjoy") ? "Good. You're stuck with me then, you say cheerfully."
             : tier.equals("flustered") ? "I wasn't planning on going anywhere either, you admit."
             : "Don't let me hold you back, you say, a little stiff."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("out_conv_4").text(
            "\"You make even the slow songs feel like they have energy.\"\n\n"
            + (tier.equals("enjoy") ? "Wait until you see me in fast songs, you reply."
             : tier.equals("flustered") ? "That might be the nicest thing anyone's said about my dancing, you say."
             : "You're not sure what that means but it doesn't feel bad."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("out_conv_5").text(
            "\"If I step on your toes, just blame the music, not me.\"\n\n"
            + (tier.equals("enjoy") ? "I step on people on purpose. Just so you know, you deadpan."
             : tier.equals("flustered") ? "I'll blame both, you say pleasantly."
             : "Noted, you say. You keep your toes tucked back."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("out_conv_6").text(
            "\"This is the first time I've smiled this much while barely moving.\"\n\n"
            + (tier.equals("enjoy") ? "Then keep smiling. I like it, you grin back."
             : tier.equals("flustered") ? "Then keep going, you say."
             : "You glance up. {npc_He} really is smiling. You look away before you match it."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());

                p.add(DanceMoment.id("gen_light_playful").text(
            "\"You know, you're surprisingly good at making slow dancing not feel boring.\"\n\n"
            + (tier.equals("enjoy") ? "Good. Then keep dancing with me, you smile softly."
             : tier.equals("flustered") ? "Thanks. You're not bad yourself, you say quietly."
             : "I-I'm not that good, you mumble, looking down."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("gen_playful_teasing").text(
            "\"If I step on your toes, you have permission to kick me.\"\n\n"
            + (tier.equals("enjoy") ? "Only if you deserve it, you tease back softly."
             : tier.equals("flustered") ? "Noted. I'll be gentle, you reply with a small smile."
             : "I-I wouldn't kick you, you say with a tiny nervous laugh."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());

        // Outgoing pool at 28+
        return p;
    }

    // ── SHY NPC ───────────────────────────────────────────────────────────────
    // Current: 5 moments. Need: 15+ more.
    List<DanceMoment> shyMoments(NpcData n) {
        List<DanceMoment> p = new ArrayList<>();
        String d    = drunkTier();

        p.add(DanceMoment.id("shy_nervous_hold").text(
            n.name + " keeps a careful distance, hand barely on your waist. You can feel the nerves coming off {npc_him}.")
            .arousal(1).npcArousal(2).npcFrustration(-1).npcLiking(5).weight(12).build());

        p.add(DanceMoment.id("shy_blushes").text(
            n.name + " catches himself looking at you and goes red. Looks away fast. Looks back.")
            .arousal(2).npcArousal(3).npcFrustration(-2).npcLiking(8).weight(11).build());

        p.add(DanceMoment.id("shy_closes_gap").text(
            "Very slowly — over the course of a full verse — " + n.name + " closes the gap between you. Almost doesn't notice {npc_he}'s done it.")
            .arousal(3).npcArousal(4).npcFrustration(-3).npcLiking(7).weight(9).build());

        p.add(DanceMoment.id("shy_accidental_hand").text(
            n.name + "'s hand drifts lower by accident. She freezes, face flaming. Doesn't move it back right away.")
            .arousal(4).npcArousal(5).npcFrustration(-4).npcLiking(6).weight(8)
            .minStage("flustered").build());

        p.add(DanceMoment.id("shy_tries_kiss").text(
            n.name + " leans in — pulls back — leans in again. Finally makes contact. Brief. Mortified immediately after.")
            .arousal(5).npcArousal(6).npcFrustration(-5).sets("kissed").weight(6)
            .minStage("enjoy").build());

        p.add(DanceMoment.id("shy_deep_kiss").text(
            n.name + " doesn't pull back from the kiss — keeps going, trembling slightly. Clearly surprised {npc_he} got this far.")
            .requires("kissed").arousal(6).npcArousal(7).npcFrustration(-6)
            .sets("deep_kissed").weight(6).minStage("enjoy").build());

        p.add(DanceMoment.id("shy_post_kiss_panic").text(
            n.name + " blushes nearly as hard as you. \"U-um… sorry if that was too much. You just looked really pretty and I got carried away. Are you mad?\"")
            .requires("kissed").arousal(3).npcArousal(4).npcFrustration(-4).npcLiking(9).weight(10).build());

        p.add(DanceMoment.id("shy_playful_attempt").text(
            n.name + " tries to spin you — it's a bit clumsy. Both of you almost lose balance. {npc_He} laughs nervously. \"Sorry, that was — I've been practicing that, actually.\"")
            .arousal(2).npcArousal(3).npcFrustration(-2).npcLiking(8).weight(9).repeatable().build());

        p.add(DanceMoment.id("shy_asks_directly").text(
            "After a long quiet moment: \"Do you… like me? Like, is this okay? I can't always tell and I don't want to be weird.\"")
            .arousal(2).npcArousal(3).npcFrustration(-3).npcLiking(10).weight(7).build());

        p.add(DanceMoment.id("shy_slow_hand").text(
            n.name + "'s hand on your waist begins drifting upward — slowly, hesitantly, almost stopping twice. It arrives at your breast like it surprised {npc_him} too. She freezes.\n\n\"I-I didn't plan that,\" {npc_he} says immediately.")
            .requires("ass_groped").sets("breast_groped").arousal(5).npcArousal(6).npcFrustration(-4)
            .npcLiking(6).weight(8).build());

        p.add(DanceMoment.id("shy_post_deep_kiss").text(
            n.name + " pulls back, eyes wide and nervous, blushing hard. {npc_His} mouth opens and closes. {npc_He} clearly wants to say something and can't.\n\nThe moment hangs in sweet awful silence.")
            .requires("deep_kissed").arousal(4).npcArousal(5).npcFrustration(-4).npcLiking(9).weight(10).build());

        p.add(DanceMoment.id("shy_gets_brave").text(
            "Something shifts. " + n.name + " pulls you closer more deliberately than {npc_he} has all night. Still nervous — hands slightly trembling — but clearly deciding to try something.")
            .arousal(4).npcArousal(5).npcFrustration(-4).npcLiking(7).weight(8).build());

        p.add(DanceMoment.id("shy_dominant_kiss_attempt").text(
            n.name + " catches her wrists — then immediately second-guesses himself, grip going soft. {npc_He} keeps the deeper kiss going anyway, trembling slightly, like {npc_he}'s surprised {npc_he} got this far.")
            .requires("kissed").arousal(6).npcArousal(7).npcFrustration(-5)
            .minStage("enjoy").weight(7).build());

        p.add(DanceMoment.id("shy_first_breast_kiss").text(
            "{npc_His} hand drifts upward mid-kiss — slowly, hesitantly — and ends up on her breast. She freezes. The kiss keeps going only because neither of them stops it.\n\n"
            + (tier.equals("shy") ? "*Oh — first time and we're both terrified.* [mutual freeze, muffled sound]"
             : tier.equals("enjoy") ? "{npc_He} exhales into the kiss. {npc_He} takes that as permission and keeps going."
             : "She stills. She stills. The moment holds itself."))
            .requires("kissed").blocks("breast_groped")
            .sets("breast_groped").arousal(5).npcArousal(6).npcFrustration(-5).npcLiking(7).weight(7)
            .minStage("flustered").build());

        p.add(DanceMoment.id("shy_overcorrects").text(
            "She tries to pull her slightly closer and she tenses. {npc_He} yanks back immediately. \"S-sorry! Too much — I'll stay over here.\"\n\nHe holds himself very still at maximum polite distance for the next several seconds.")
            .arousal(1).npcArousal(2).npcFrustration(-1).npcLiking(8).weight(8).build());

        p.add(DanceMoment.id("shy_forehead_hold").text(
            "Very slowly, " + n.name + " rests {npc_his} forehead against hers. {npc_His} breath is shaky. {npc_He} holds the touch for a long time, clearly nervous. Then {npc_he} pulls back and looks at {npc_him} with wide eyes — and after a very long pause, leans in for a second kiss. Extra soft. Extra careful.")
            .requires("kissed").arousal(5).npcArousal(6).npcFrustration(-5).npcLiking(9).weight(9).build());

        p.add(DanceMoment.id("shy_watching_confession").text(
            "She leans slightly close, breath nervous and warm near her neck, and murmurs quietly: \"I've… been watching you all night.\"\n\nImmediate silence. {npc_He}'s mortified {npc_he} said it.\n\n"
            + (tier.equals("shy") ? "Both of them freeze. Equally mortified."
             : tier.equals("enjoy") ? "{npc_He} tilts {npc_him} head. \"I know.\" {npc_His} face goes red."
             : "{npc_He} takes a slow breath. \"That's nice of you to say,\" {npc_he} manages."))
            .arousal(4).npcArousal(5).npcFrustration(-4).npcLiking(9).weight(8).build());

        p.add(DanceMoment.id("shy_post_dip_personal").text(
            n.name + " dips her — barely, nervous about it — and brings her up. Blushes. \"I… usually overthink everything when I dance with someone. But with you I keep forgetting to be nervous. That's new for me.\"\n\n"
            + (tier.equals("shy") ? "*{npc_He} said something real. So did I, kind of. By not saying anything.*"
             : tier.equals("enjoy") ? "\"Me too,\" {npc_he} says, and means it differently than {npc_he} expected."
             : "{npc_He} smiles softly. \"I like that.\""))
            .arousal(2).npcArousal(3).npcFrustration(-3).npcLiking(10).weight(9).build());

        p.add(DanceMoment.id("shy_succeeds_small_thing").text(
            "{npc_He} tried to pull her slightly closer — actually succeeded this time. Both of them seem surprised by this. {npc_He}'s visibly thrilled, which makes it worse and better at the same time.")
            .arousal(3).npcArousal(5).npcFrustration(-4).npcLiking(8).weight(8).build());

        p.add(DanceMoment.id("shy_asks_before_touching").text(
            "\"Can I… is it okay if I put my hand…\" {npc_He} gestures vaguely at her waist. {npc_He}'s asking before doing anything. Extremely awkward. Extremely sincere.")
            .arousal(2).npcArousal(3).npcFrustration(-2).npcLiking(9).weight(8).build());

        // ── Shy NPC orgasm — peak comedy ─────────────────────────────────────
        p.add(DanceMoment.id("shy_npc_cums").text(
            n.name + " stops moving.\n\n"
            + "Just... stops. Arms still around you. Breathing very carefully.\n\n"
            + "\"...I need to,\" she starts. Then: \"I have to go to the bathroom.\"\n\n"
            + "She steps back. {npc_His} face is the colour of a traffic light.\n\n"
            + "{npc_He} cannot make eye contact.\n\n"
            + (bar.gameStageVariant().equals("enjoy")
                ? "You watch {npc_him} go. You press your lips together very hard.\n\n*Oh. Poor thing. That was — yeah.*\n\nHe returns eight minutes later looking like {npc_he} has lost a fight with a paper towel dispenser. {npc_He} does not mention it. You do not mention it. You resume dancing with an entirely new understanding of each other."
              : bar.gameStageVariant().equals("flustered")
                ? "*Oh. Oh no. You feel genuinely bad about how funny this is.*\n\nHe comes back. Avoids your eyes completely. Offers {npc_his} hand for the next song with the formal gravity of a man signing a peace treaty.\n\nYou accept it."
              : "*That was... what just happened? Oh. Oh.*\n\nYou stand on the dance floor alone for thirty seconds, processing. {npc_He} reappears from the bathroom looking red-eared and younger than before.\n\n\"Sorry,\" {npc_he} says to the middle distance. You have never liked someone more."))
            .requires("ass_groped").minNpcArousal(88)
            .arousal(3).npcArousal(-50)
            .npcFrustration(100).npcLiking(5)
            .sets("npc_came").weight(4).maleOnly().build());

        
        
                p.add(DanceMoment.id("shy_conv_1").text(
            "\"I usually mess up the timing when I slow dance. But this feels okay.\"\n\n"
            + (tier.equals("enjoy") ? "You're doing fine, you say. And mean it."
             : tier.equals("flustered") ? "You're doing fine, you say gently."
             : "It's okay... I'm nervous too, you whisper."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("shy_conv_2").text(
            "\"Sorry if I'm holding you too loosely. Or too tightly. I can never tell.\"\n\n"
            + (tier.equals("enjoy") ? "You're fine, you say. I'd tell you if you weren't."
             : tier.equals("flustered") ? "You're fine, you say. Right where you are."
             : "You shift slightly. *You can't tell either.*"))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("shy_conv_3").text(
            "\"You're not bored, right? I know I'm not the most exciting dancer.\"\n\n"
            + (tier.equals("enjoy") ? "Would I be here if I was? you point out softly."
             : tier.equals("flustered") ? "Not bored, you confirm."
             : "I'm not bored, you say quietly, surprising yourself."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("shy_conv_4").text(
            "\"This is nicer than I thought it would be. I keep worrying I'll say something dumb.\"\n\n"
            + (tier.equals("enjoy") ? "You're doing great, you say. Relax a little."
             : tier.equals("flustered") ? "You haven't yet, you say with a small smile."
             : "You haven't, you say. It comes out gentler than you meant."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("shy_conv_5").text(
            "\"I like that we're not talking too much. My brain usually runs too fast.\"\n\n"
            + (tier.equals("enjoy") ? "Then let's keep not talking too much, you agree softly."
             : tier.equals("flustered") ? "Same, honestly, you say."
             : "You nod. *Mine does too.*"))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("shy_conv_6").text(
            "\"You smell nice. Wait — that was weird to say out loud, wasn't it?\"\n\n"
            + (tier.equals("enjoy") ? "A little, you say. But I'll allow it."
             : tier.equals("flustered") ? "No, it wasn't, you say, a little pink."
             : "You go very still. *Does {npc_he} mean it?* Your face is hot.")
            + (!d.equals("sober") ? "\n\nHe winces right after. Endearing." : ""))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());

                p.add(DanceMoment.id("gen_soft_vulnerability").text(
            "\"I don't usually slow dance. Feels too exposed. But this doesn't.\"\n\n"
            + (tier.equals("enjoy") ? "Then I'm glad it's me, you say warmly."
             : tier.equals("flustered") ? "It's different when it feels easy, you murmur."
             : "Me neither… it's kind of scary, you admit quietly."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("gen_reflective").text(
            "\"Nights like this make me realize I don't slow down enough.\"\n\n"
            + (tier.equals("enjoy") ? "I'm enjoying slowing down with you, you reply warmly."
             : tier.equals("flustered") ? "Then maybe we should do it more often, you suggest quietly."
             : "I don't either, you say softly, swaying with her."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("gen_self_deprecation").text(
            "\"I'm probably terrible at this. You're carrying the whole dance.\"\n\n"
            + (tier.equals("enjoy") ? "Then let me carry you a little longer, you tease gently."
             : tier.equals("flustered") ? "We're both doing okay, you say with a small smile."
             : "No, you're doing fine, you reassure {npc_him} shyly."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());

        // Shy NPC pool at 30+
        return p;
    }

    // ── SELF_ASSURED ──────────────────────────────────────────────────────────
    List<DanceMoment> selfAssuredMoments(NpcData n) {
        List<DanceMoment> p = new ArrayList<>();
        String tier = bar.gameStageVariant();

        p.add(DanceMoment.id("sa_claims_back").text(
            "{npc_His} hand claims your lower back — firm, no ceremony. Pulls you in.")
            .arousal(4).npcArousal(4).npcFrustration(-4).npcLiking(4).weight(12).build());

        p.add(DanceMoment.id("sa_ass").text(
            "{npc_His} hand slides to your ass. Stays there. Calm. Like it was obvious.")
            .arousal(5).npcArousal(5).npcFrustration(-5).sets("ass_groped").weight(10)
            .minStage("flustered").build());

        p.add(DanceMoment.id("sa_direct_kiss").text(
            "{npc_He} kisses you. Clean. No preamble. Waits to see what you do.")
            .arousal(6).npcArousal(6).npcFrustration(-6).sets("kissed").weight(9)
            .minStage("flustered").build());

        p.add(DanceMoment.id("sa_states_intent").text(
            "\"I like you,\" {npc_he} says. Matter of fact. Doesn't look away.")
            .arousal(3).npcArousal(4).npcFrustration(-3).npcLiking(9).weight(10).build());

        p.add(DanceMoment.id("sa_deep_kiss").text(
            "{npc_He} deepens the kiss without ceremony. Certain. Like {npc_he} knew it was going here from the start.")
            .requires("kissed").arousal(7).npcArousal(7).npcFrustration(-7)
            .sets("deep_kissed").weight(9).minStage("flustered").build());

        p.add(DanceMoment.id("sa_breast_cont").text(
            "\"You feel very good,\" {npc_he} says, hand still on your chest. Statement of fact. No apology for it.")
            .requires("breast_groped").arousal(5).npcArousal(6).npcFrustration(-5)
            .weight(8).build());

        p.add(DanceMoment.id("sa_post_kiss_read").text(
            "She looks at you steadily after the kiss. \"Be straight with me — too much, or do you want me to kiss you like that again?\"\n\n"
            + (tier.equals("shy") ? "\"We can slow down,\" {npc_he} says before you answer. \"Your pace.\""
             : tier.equals("enjoy") ? "\"Good. Because I enjoyed that too,\" {npc_he} says with a confident smile."
             : "You give a small nod. {npc_He} does the same."))
            .requires("kissed").arousal(4).npcArousal(5).npcFrustration(-4).npcLiking(7).weight(10).build());

        p.add(DanceMoment.id("sa_deliberate_dip").text(
            "{npc_He} dips you smoothly — holds you low, one eyebrow raised slightly — waiting for your reaction before pulling you back up. No rush.")
            .arousal(5).npcArousal(5).npcFrustration(-4).npcLiking(6).weight(9).build());

        p.add(DanceMoment.id("sa_states_next").text(
            "\"I'm going to put my hand on your ass now,\" {npc_he} says simply. Does it. Watches your face.")
            .arousal(6).npcArousal(6).npcFrustration(-5).sets("ass_groped").weight(8).minStage("flustered").build());

        p.add(DanceMoment.id("sa_slow_hand").text(
            "{npc_His} hand begins sliding upward from your ass — smooth, purposeful, no pauses. Arrives at your breast and settles there. Like it was always the destination.")
            .requires("ass_groped").sets("breast_groped").arousal(6).npcArousal(7).npcFrustration(-6).weight(10).build());

        p.add(DanceMoment.id("sa_post_deep_kiss").text(
            "She looks at you after the kiss — steady, satisfied. Eyes move from your lips to your eyes and back. \"I thought so,\" {npc_he} says quietly.")
            .requires("deep_kissed").arousal(5).npcArousal(6).npcFrustration(-5).npcLiking(7).weight(10).build());

        p.add(DanceMoment.id("sa_crude_multi").text(
            "Both hands placed with deliberate purpose — breast and under your skirt — while maintaining a deep kiss. Against your ear: \"I'm kissing you, playing with your tits, and rubbing your pussy all at once. Tell me you like it.\"\n\n"
            + (tier.equals("enjoy") ? "\"Yes,\" you say without hesitation." : "The directness hits harder than the touch."))
            .requires("kissed").requires("breast_groped").sets("pussy_groped")
            .arousal(10).npcArousal(10).npcFrustration(-8).minDrunk(11).weight(8).build());

        p.add(DanceMoment.id("sa_observation").text(
            "{npc_He} watches you dance for a long moment without escalating anything. Reading. Then: \"You're more comfortable now than when we started.\"\n\nStatement of fact. {npc_He} seems pleased by it.")
            .arousal(2).npcArousal(3).npcFrustration(-2).npcLiking(8).weight(9).build());

        p.add(DanceMoment.id("sa_dominant_kiss").text(
            "{npc_He} catches her wrists and pins them behind {npc_him} back — clean and deliberate — while the kiss deepens. Watching her face the whole time. When {npc_he} breaks it: \"Good.\"\n\n"
            + (tier.equals("enjoy") ? "One word. {npc_He} agrees." : "{npc_He} tests the grip. It holds. {npc_He} breathes through it."))
            .requires("kissed").arousal(8).npcArousal(8).npcFrustration(-7)
            .minDrunk(11).minStage("flustered").weight(8).build());

        p.add(DanceMoment.id("sa_first_breast_kiss").text(
            "Mid-kiss, hand moves to her breast. First time. Confident. Thumb brushing over the fabric — or directly, if there's nothing in the way. \"Tell me if you want me to stop.\"\n\n"
            + (tier.equals("shy") ? "*First time anyone's touched me there while kissing me.* {npc_He} whimpers softly."
             : tier.equals("enjoy") ? "{npc_He} doesn't say stop." : "{npc_He} considers. Doesn't say stop yet."))
            .requires("kissed").blocks("breast_groped")
            .sets("breast_groped").arousal(7).npcArousal(8).npcFrustration(-6).weight(9).build());

        p.add(DanceMoment.id("sa_respects_signal").text(
            "{npc_He} gives a small signal — a shift, a look — and she stops the escalation immediately. \"Your pace,\" {npc_he} says simply. Keeps dancing.")
            .arousal(2).npcArousal(2).npcFrustration(-2).npcLiking(7).weight(7).build());

        p.add(DanceMoment.id("sa_watching_you").text(
            "{npc_He} lowers {npc_his} head until warm breath grazes her neck. Steady. Unhurried. Then: \"I've been watching you all night.\" Said with quiet certainty. {npc_He} continues breathing there, not moving to touch more.")
            .arousal(6).npcArousal(6).npcFrustration(-5).npcLiking(7).weight(9).build());

        p.add(DanceMoment.id("sa_forehead_kiss").text(
            "{npc_He} rests {npc_his} forehead against hers — confident, slow. Holds the contact steadily. Then draws back with calm eyes and leans in for a second kiss. No hesitation. No rush.")
            .requires("kissed").arousal(6).npcArousal(7).npcFrustration(-6).weight(9).build());

        p.add(DanceMoment.id("sa_post_dip_personal").text(
            "Post-dip, holding her close, {npc_he} says quietly: \"I don't chase moments like this often. Most nights I keep things surface-level. Something about you makes me want to stay in it longer.\"")
            .arousal(3).npcArousal(4).npcFrustration(-4).npcLiking(9).weight(8).build());

        p.add(DanceMoment.id("sa_deliberate_step").text(
            "She moves one hand from her waist to {npc_him} lower back. Then, a moment later, further still — slow and deliberate. Each move a decision. No comment made about any of them.")
            .arousal(5).npcArousal(6).npcFrustration(-5).sets("ass_groped").weight(9)
            .minStage("flustered").build());

        p.add(DanceMoment.id("sa_dominant_kiss_v2").text(
            "{npc_He} catches her wrists — one motion — pins them behind {npc_him} back and deepens the kiss into something much harder. Confident. No commentary. {npc_He} watches her face the whole time.\n\n"
            + (tier.equals("enjoy") ? "She presses into the restraint. The message is clear."
             : "Her mouth is occupied. Pushing away is the only option left."))
            .requires("kissed").arousal(8).npcArousal(9).npcFrustration(-7)
            .minDrunk(11).minStage("flustered").weight(8).build());

        p.add(DanceMoment.id("sa_decisive_neck_latch").text(
            "{npc_He} dips {npc_his} head and latches onto her neck — purposeful, clean. Slow suction. {npc_He} holds her lower back steady while {npc_his} mouth works.")
            .arousal(6).npcArousal(8).npcFrustration(-6).sets("neck_kissed").weight(8).build());

        p.add(DanceMoment.id("sa_dare_back_pause").text(
            "{npc_He} does something {npc_he} didn't expect. {npc_He} pauses — one eyebrow up, genuine surprise — then a small, impressed smile. \"Well… damn. You flipped that on me. Respect.\" {npc_He} nods for {npc_him} to continue. Waiting.")
            .requires("kissed").arousal(4).npcArousal(6).npcFrustration(-4).npcLiking(8).weight(7).build());

        p.add(DanceMoment.id("sa_dirty_whisper").text(
            buildDirtyWhisperText())
            .requires("kissed").requires("neck_kissed")
            .arousal(7).npcArousal(8).npcFrustration(-5).weight(9).build());

        
        
                p.add(DanceMoment.id("sa_conv_1").text(
            "\"I don't do slow dances often. You're making me reconsider that.\"\n\n"
            + (tier.equals("enjoy") ? "Then we should do this more often, you reply simply."
             : tier.equals("flustered") ? "I'm glad, you say with a small smile."
             : "You nod quietly, blushing."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("sa_conv_2").text(
            "\"You move well with me. Most people don't match my pace this easily.\"\n\n"
            + (tier.equals("enjoy") ? "You're not hard to match, you say."
             : tier.equals("flustered") ? "Thanks. You're not hard to follow, you say."
             : "*You almost say you've been trying.* You don't."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("sa_conv_3").text(
            "\"This is the most relaxed I've felt all night. That's because of you.\"\n\n"
            + (tier.equals("enjoy") ? "Good. That was my plan, you say lightly."
             : tier.equals("flustered") ? "I'm glad, you murmur."
             : "You look up. {npc_He} says it without making it a big thing."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("sa_conv_4").text(
            "\"I like that you're not trying to lead or follow too hard. It just works.\"\n\n"
            + (tier.equals("enjoy") ? "I noticed, you say."
             : tier.equals("flustered") ? "I was just trying not to step on you, you admit."
             : "You hadn't noticed, but now that {npc_he} says it — yeah, it does."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("sa_conv_5").text(
            "\"If the night keeps going like this, I might not want it to end.\"\n\n"
            + (tier.equals("enjoy") ? "Good. I don't want it to end either, you reply warmly."
             : tier.equals("flustered") ? "That's a good problem to have, you say."
             : "*Neither might I.* You sway without answering."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("sa_conv_6").text(
            "\"You're good company. Simple as that.\"\n\n"
            + (tier.equals("enjoy") ? "I know, you say, and smile."
             : tier.equals("flustered") ? "So are you, you say."
             : "It's a short thing to say. It hits harder than you expected."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());

                p.add(DanceMoment.id("gen_light_playful").text(
            "\"You know, you're surprisingly good at making slow dancing not feel boring.\"\n\n"
            + (tier.equals("enjoy") ? "Good. Then keep dancing with me, you smile softly."
             : tier.equals("flustered") ? "Thanks. You're not bad yourself, you say quietly."
             : "I-I'm not that good, you mumble, looking down."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("gen_quiet_appreciation").text(
            "\"You smell really nice. It's distracting in a good way.\"\n\n"
            + (tier.equals("enjoy") ? "Then keep getting distracted, you murmur with a small grin."
             : tier.equals("flustered") ? "So do you, you say simply."
             : "You blush hard and stay silent for a moment. Thank you, you whisper."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());

        // Self_Assured pool at 30+
        return p;
    }

    // ── CONFRONTATIONAL ───────────────────────────────────────────────────────
    List<DanceMoment> confrontationalMoments(NpcData n) {
        List<DanceMoment> p = new ArrayList<>();
        String tier = bar.gameStageVariant();
        String d    = drunkTier();

        p.add(DanceMoment.id("con_tests_boundary").text(
            "{npc_His} hand slides just above your ass — daring you to say something. Watching your face.")
            .arousal(4).npcArousal(5).npcFrustration(-4).weight(12).build());

        p.add(DanceMoment.id("con_grabs_ass").text(
            "{npc_He} grabs your ass — not subtle, not asking. Testing what you do.\n\n"
            + (tier.equals("shy") ? "You tense." : tier.equals("enjoy") ? "You push back." : "You meet {npc_his} gaze."))
            .arousal(5).npcArousal(6).npcFrustration(-5).sets("ass_groped").weight(10)
            .minStage("flustered").build());

        p.add(DanceMoment.id("con_challenging_look").text(
            "{npc_He} holds eye contact. Doesn't speak. The challenge is clear.")
            .arousal(3).npcArousal(4).npcFrustration(-2).npcLiking(4).weight(11).repeatable().build());

        p.add(DanceMoment.id("con_kiss_dare").text(
            "She leans close — not kissing, not quite. Seeing if {npc_he}'ll close the gap.")
            .arousal(5).npcArousal(6).npcFrustration(-4).weight(8)
            .minStage("flustered").build());

        p.add(DanceMoment.id("con_deep_kiss").text(
            "{npc_He} kisses you deeper — daring you to pull back. Watching for what you do.")
            .requires("kissed").arousal(7).npcArousal(7).npcFrustration(-6)
            .sets("deep_kissed").weight(8).minStage("flustered").build());

        p.add(DanceMoment.id("con_post_kiss_stare").text(
            "{npc_He} pulls back from the kiss and just looks at {npc_him}. Not blinking. Watching what {npc_he} does next.")
            .requires("kissed").arousal(6).npcArousal(6).npcFrustration(-4).weight(10).build());

        p.add(DanceMoment.id("con_dip_hold").text(
            "{npc_He} dips her low and holds — body over hers. \"You going to push me away or are we doing this?\"")
            .arousal(6).npcArousal(7).npcFrustration(-5).weight(9).minStage("flustered").build());

        p.add(DanceMoment.id("con_under_skirt").text(
            "{npc_His} hand slides under her skirt while keeping eye contact. Daring {npc_him} to say something first.")
            .sets("pussy_groped", "cornered").arousal(8).npcArousal(8).npcFrustration(-6)
            .minDrunk(11).weight(8).minStage("flustered").build());

        p.add(DanceMoment.id("con_respects_boundary").text(
            "{npc_He} pushes back at something and she stops — fully, cleanly. Looks at {npc_him} differently. \"Good.\" One word. Like {npc_he} was testing exactly that.")
            .arousal(3).npcArousal(4).npcFrustration(2).npcLiking(8).weight(7).build());

        p.add(DanceMoment.id("con_slow_hand").text(
            "Hand on her ass. Then — slowly, watching her face — begins moving upward. Daring {npc_him} to say something before it arrives.")
            .requires("ass_groped").sets("breast_groped").arousal(7).npcArousal(7).npcFrustration(-5)
            .weight(9).minStage("flustered").build());

        p.add(DanceMoment.id("con_post_deep_kiss").text(
            "Kiss breaks. {npc_He} doesn't move back far. Still in {npc_him} space, watching. The challenge is still there — just different now.")
            .requires("deep_kissed").arousal(7).npcArousal(7).npcFrustration(-5).weight(10).build());

        p.add(DanceMoment.id("con_escalates_after_standoff").text(
            "{npc_He} held the eye contact. {npc_He} held it back. After a full beat she moves — kissing {npc_him}, hand to her ass — not asking, responding.")
            .arousal(7).npcArousal(8).npcFrustration(-7).sets("ass_groped", "kissed").weight(9)
            .minStage("flustered").build());

        p.add(DanceMoment.id("con_dominant_kiss").text(
            "{npc_He} catches her wrists mid-dance — one hand, then the other — and holds them while the kiss goes harder. Daring {npc_him} to break free. Watching to see if {npc_he} does.")
            .requires("kissed").arousal(8).npcArousal(8).npcFrustration(-6)
            .minDrunk(11).minStage("flustered").weight(9).build());

        p.add(DanceMoment.id("con_first_breast_kiss").text(
            "Hand moves to her breast mid-kiss — testing, watching her face. First time. No announcement. Pure dare.\n\n"
            + (tier.equals("shy") ? "*{npc_He}'s touching my breast during the kiss, first time — I don't know how to react.*"
             : tier.equals("enjoy") ? "{npc_He} holds the eye contact. So does {npc_he}."
             : "{npc_He} hesitates. {npc_He} waits."))
            .requires("kissed").blocks("breast_groped")
            .sets("breast_groped").arousal(7).npcArousal(8).npcFrustration(-6)
            .minStage("flustered").weight(8).build());

        p.add(DanceMoment.id("con_{npc_he}_pushes_back").text(
            "{npc_He} pushes back at something — hand on {npc_his} chest, small step away. She goes completely still.\n\nThen: \"Fair.\" {npc_He} adjusts. And somehow that makes {npc_him} more interested in {npc_him}, not less.")
            .arousal(3).npcArousal(5).npcFrustration(-2).npcLiking(9).weight(8).build());

        p.add(DanceMoment.id("con_watching_you").text(
            "She leans in close — not touching, just near — breath warm against her neck. Watching her face from an inch away. Then, low: \"I've been watching you all night.\"\n\nSaid like a fact. Like a dare.")
            .arousal(6).npcArousal(7).npcFrustration(-5).weight(9).build());

        p.add(DanceMoment.id("con_{npc_he}_dares_back").text(
            "{npc_He} does something {npc_he} didn't expect — fires back, holds the eye contact, or doesn't flinch when {npc_he} should. {npc_He} actually pauses.\n\nA beat. Then the corner of {npc_his} mouth moves. \"Okay.\" Different energy now. Genuinely interested.")
            .arousal(4).npcArousal(6).npcFrustration(-4).npcLiking(9).weight(8).build());

        p.add(DanceMoment.id("con_raises_stakes").text(
            "{npc_He} didn't back down from the last thing. So she tries something more — hand lower, body closer, eye contact that doesn't break. Escalating because {npc_he} didn't stop {npc_him}, not despite it.")
            .arousal(7).npcArousal(8).npcFrustration(-6).sets("ass_groped").weight(9)
            .minStage("flustered").build());

        p.add(DanceMoment.id("con_forehead_challenge").text(
            "{npc_He} rests {npc_his} forehead against hers — not warmly, as a challenge. Daring {npc_him} to pull back. {npc_He} can feel her breathing against her face. {npc_He} doesn't move. Waiting.")
            .arousal(5).npcArousal(6).npcFrustration(-4).weight(8).build());

        p.add(DanceMoment.id("con_genuine_pause").text(
            "{npc_He} does something that actually surprises {npc_him} — unexpected enough that {npc_his} expression shifts. The challenge drops for a half second. Something genuine underneath.\n\nHe blinks it away. But {npc_he} saw it.")
            .arousal(3).npcArousal(5).npcFrustration(-3).npcLiking(8).weight(7).build());

        p.add(DanceMoment.id("con_dominant_kiss_v2").text(
            "{npc_He} catches her wrists and pins them — eyes on her face — while the kiss goes from testing into claiming. {npc_He}'s not asking anymore. Watching to see what {npc_he} does with her hands gone.")
            .requires("kissed").arousal(9).npcArousal(9).npcFrustration(-7)
            .minDrunk(11).minStage("flustered").weight(9).build());

        p.add(DanceMoment.id("con_decisive_neck_latch").text(
            "{npc_He} latches onto her neck — hard and deliberate. Sucking. A dare to see if {npc_he}'ll stop {npc_him}.")
            .arousal(7).npcArousal(8).npcFrustration(-6).sets("neck_kissed").weight(8)
            .minStage("flustered").build());

        p.add(DanceMoment.id("con_dare_back_reaction").text(
            "{npc_He} dares {npc_him} back. {npc_He} pauses — real surprise, the smirk going wrong for a second — then a short huff of genuine laughter. \"Huh. Didn't expect that.\" {npc_He}'s looking at {npc_him} differently. The dare landed.")
            .requires("kissed").arousal(5).npcArousal(7).npcFrustration(-5).npcLiking(10).weight(8).build());

        // ── Slow dance conversation beats ─────────────────────────────────────
        p.add(DanceMoment.id("con_conv_1").text(
            "\"Most people can't handle a slow song without filling the silence. You're doing okay.\"\n\n"
            + (tier.equals("enjoy") ? "Okay? You raise an eyebrow. {npc_He} grins — first genuine one all night."
             : tier.equals("flustered") ? "You're not sure if that's a compliment. You decide to take it anyway."
             : "*Most people.* You file it away and say nothing."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());

        p.add(DanceMoment.id("con_conv_2").text(
            "\"Tell me one thing about yourself that would actually surprise me.\"\n\n"
            + (tier.equals("enjoy") ? "You think about it. Then you tell {npc_him} something true. {npc_He} doesn't look away."
             : tier.equals("flustered") ? "You laugh once. It's either a challenge or a terrible opener. You genuinely can't tell."
             : "You look up at {npc_him}. *That's the question {npc_he} opens with.* You're not sure you have an answer."))
            .arousal(1).npcLiking(6).npcFrustration(-2).weight(7).repeatable().build());

        p.add(DanceMoment.id("con_conv_3").text(
            "\"You've got this look like you're deciding something. What is it?\"\n\n"
            + (tier.equals("enjoy") ? "Whether to make this interesting, you say. {npc_He} raises an eyebrow. Good, {npc_he} says."
             : tier.equals("flustered") ? "You blink. Nothing, you say. {npc_He} clearly doesn't believe you."
             : "Your face goes carefully neutral. {npc_He} clocks it and smirks."))
            .arousal(2).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());

        p.add(DanceMoment.id("con_conv_4").text(
            "\"I'm going to be honest with you — I don't usually do the slow dance thing. But here I am.\"\n\n"
            + (tier.equals("enjoy") ? "Here you are, you say. {npc_He} huffs a quiet laugh."
             : tier.equals("flustered") ? "What changed your mind? you ask. {npc_He} just shrugs. Hard to say."
             : "You nod once. You don't point out you're still here too."))
            .arousal(1).npcLiking(6).npcFrustration(-3).weight(8).repeatable().build());

        p.add(DanceMoment.id("con_conv_5").text(
            "\"You keep looking like you want to say something and then deciding not to.\"\n\n"
            + (tier.equals("enjoy") ? "You look at {npc_him} directly. Maybe I'm deciding if you can handle it, you say. {npc_His} expression shifts."
             : tier.equals("flustered") ? "You're not wrong, you admit. {npc_He} waits. You don't fill the silence either."
             : "*{npc_He} noticed.* You hold {npc_his} gaze without responding."))
            .arousal(2).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());

        p.add(DanceMoment.id("con_conv_6").text(
            "\"I like that you don't just agree with everything I say. It's refreshing.\"\n\n"
            + (tier.equals("enjoy") ? "Then I'm about to be very refreshing, you say. {npc_He} grins."
             : tier.equals("flustered") ? "You file that away. Hard to know what to do with it."
             : "You say nothing. Which is somehow the correct response."))
            .arousal(1).npcLiking(7).npcFrustration(-3).weight(8).repeatable().build());

        // Confrontational pool at 26+
        return p;
    }

    // ── JERK ──────────────────────────────────────────────────────────────────
    // Current: 6 moments. Need: 14+ more.
    List<DanceMoment> jerkMoments(NpcData n) {
        List<DanceMoment> p = new ArrayList<>();
        String tier = bar.gameStageVariant();

        p.add(DanceMoment.id("jerk_backhanded").text(
            "\"You're not as bad a dancer as I expected,\" " + n.name + " says. As compliments go, it's barely one.")
            .arousal(1).npcArousal(1).npcFrustration(-1).npcLiking(2).weight(11).build());

        p.add(DanceMoment.id("jerk_grabs_ass").text(
            "{npc_He} grabs your ass with arrogant confidence, like it was {npc_his} to take.")
            .arousal(4).npcArousal(5).npcFrustration(-4).sets("ass_groped").weight(10).build());

        p.add(DanceMoment.id("jerk_smug_comment").text(
            "\"Lucky you ended up dancing with me,\" {npc_he} says. Smug. Expecting agreement.")
            .arousal(1).npcArousal(2).npcFrustration(-1).npcLiking(1).weight(10).repeatable().build());

        p.add(DanceMoment.id("jerk_breast_grope").text(
            "{npc_His} hand slides up under your shirt and squeezes your breast. No preamble. \"Not bad,\" {npc_he} says.")
            .arousal(5).npcArousal(6).npcFrustration(-5).sets("breast_groped").weight(9).build());

        p.add(DanceMoment.id("jerk_kiss_possession").text(
            "{npc_He} kisses you like {npc_he}'s proving a point.")
            .arousal(5).npcArousal(6).npcFrustration(-6).sets("kissed").weight(8)
            .minStage("flustered").build());

        p.add(DanceMoment.id("jerk_neg_then_grab").text(
            "\"You should smile more.\" Before you can respond, {npc_his} hand is on your ass.")
            .arousal(4).npcArousal(5).npcFrustration(-4).sets("ass_groped").weight(8).build());

        p.add(DanceMoment.id("jerk_deep_kiss").text(
            "{npc_He} kisses you harder — taking more, not asking. \"You were into it,\" {npc_he} says when {npc_he} finally pulls back slightly.")
            .requires("kissed").arousal(6).npcArousal(7).npcFrustration(-6)
            .sets("deep_kissed").weight(9).minStage("flustered").build());

        p.add(DanceMoment.id("jerk_breast_cont").text(
            "{npc_His} hands stay on your chest. \"I wasn't done,\" {npc_he} says flatly. Keeps kneading.")
            .requires("breast_groped").arousal(5).npcArousal(6).npcFrustration(-4)
            .weight(8).build());

        p.add(DanceMoment.id("jerk_post_kiss").text(
            "\"You looked pretty into that,\" {npc_he} smirks. \"Or was I imagining things? Don't go shy on me now.\"")
            .requires("kissed").arousal(4).npcArousal(5).npcFrustration(-3).weight(10).build());

        p.add(DanceMoment.id("jerk_under_skirt").text(
            "Hand under her skirt over her panties, arrogant about it. \"Cornered and letting me do this. Not so difficult after all.\"")
            .sets("pussy_groped", "cornered").arousal(7).npcArousal(8).npcFrustration(-6)
            .minDrunk(11).weight(8).build());

        p.add(DanceMoment.id("jerk_grudging_admit").text(
            "{npc_He} fires back at something and {npc_he} actually pauses. The smirk doesn't disappear — but it changes quality. \"Not bad.\" Barely counts as a compliment. Means it anyway.")
            .arousal(2).npcArousal(3).npcFrustration(-2).npcLiking(6).weight(8).build());

        p.add(DanceMoment.id("jerk_neg_dancing").text(
            "\"Your dancing is alright — for someone who's had that many drinks.\" {npc_He} keeps moving with her anyway.")
            .arousal(1).npcArousal(1).npcFrustration(-1).weight(9).repeatable().build());

        // GAP: need 8+ more Jerk moments

        p.add(DanceMoment.id("jerk_slow_hand").text(
            "Hand on her ass. Begins sliding upward — deliberately slow, smirk visible even in the dim light. Like {npc_he} knows exactly how bold this is and doesn't care.\n\n"
            + (tier.equals("shy") ? "You watch {npc_his} face as it travels. Can't do anything about it."
             : tier.equals("enjoy") ? "\"Finally,\" you murmur when it arrives."
             : "\"Sure of yourself,\" you say. \"Obviously,\" {npc_he} says."))
            .requires("ass_groped").sets("breast_groped").arousal(6).npcArousal(7).npcFrustration(-5)
            .weight(9).build());

        p.add(DanceMoment.id("jerk_post_deep_kiss_react").text(
            "Kiss breaks. She looks at {npc_him} with that one eyebrow up. \"Not bad,\" the expression says — but {npc_his} breathing is heavier than {npc_he}'d like to admit.")
            .requires("deep_kissed").arousal(4).npcArousal(5).npcFrustration(-3).weight(9).build());

        p.add(DanceMoment.id("jerk_crude_multi").text(
            "Mouth on hers. One hand on {npc_him} bare breast, the other under her skirt, rubbing slow circles over her panties. Against {npc_him} ear, low and crude: \"Not bad — kissing me while I feel up your tits and pussy. Didn't think you'd let me do all this at once.\"\n\n"
            + (tier.equals("shy") ? "[whimper, drunk squirm, face burning]"
             : tier.equals("enjoy") ? "\"Shut up and keep going,\" you mutter into {npc_his} mouth."
             : "The words land somewhere between irritating and effective."))
            .requires("kissed").requires("breast_groped").sets("pussy_groped")
            .arousal(9).npcArousal(9).npcFrustration(-7).minDrunk(11).weight(8).build());

        p.add(DanceMoment.id("jerk_neg_outfit").text(
            "\"That shirt's a little obvious, you know.\" {npc_His} eyes make the point for {npc_him}. {npc_He} doesn't look away.")
            .arousal(2).npcArousal(3).npcFrustration(-2).weight(8).repeatable().build());

        p.add(DanceMoment.id("jerk_neg_choices").text(
            "\"Most people would have gone home by now.\" Beat. \"Not complaining.\" {npc_He} keeps dancing.")
            .arousal(1).npcArousal(2).npcFrustration(-1).npcLiking(2).weight(8).repeatable().build());

        p.add(DanceMoment.id("jerk_{npc_he}_fires_back").text(
            "{npc_He} says something back. {npc_He} actually pauses — blinks once. The smirk changes quality.\n\n\"…alright. Point.\" {npc_He} keeps moving with her, something slightly different in {npc_his} eyes now.")
            .arousal(3).npcArousal(4).npcFrustration(-3).npcLiking(7).weight(7).build());

        p.add(DanceMoment.id("jerk_grudging_physical").text(
            "{npc_He} doesn't say anything this time. Just moves {npc_his} hand to the small of {npc_him} back and pulls her closer. No comment. No smirk. Just that.")
            .arousal(5).npcArousal(5).npcFrustration(-5).npcLiking(5).weight(8).build());

        p.add(DanceMoment.id("jerk_awkward_q").text(
            "\"Do you even like me, or…?\" {npc_He} says it with fake casualness that fails completely. Looking slightly away after. Immediately regretting it.\n\n"
            + (tier.equals("shy") ? "\"I… maybe?\" you whisper. {npc_He}: \"Yeah, figured.\" [relieved underneath the smirk]"
             : tier.equals("enjoy") ? "\"Yeah.\" {npc_He} smirks but the relief shows. \"Obviously.\""
             : "\"Somewhere in between.\" {npc_He} nods like this is acceptable information."))
            .arousal(2).npcArousal(3).npcFrustration(-2).npcLiking(6).weight(6).build());

        // Jerk pool at 14+ moments

        p.add(DanceMoment.id("jerk_dominant_kiss").text(
            "{npc_He} catches both her wrists and pins them to her sides, smirking into the kiss as {npc_he} deepens it. \"Look at you — can't even push me away now.\"")
            .requires("kissed").arousal(7).npcArousal(8).npcFrustration(-6)
            .minDrunk(11).minStage("flustered").weight(8).build());

        p.add(DanceMoment.id("jerk_first_breast_kiss").text(
            "Hand slides to her breast during the kiss — first time. {npc_He} raises an eyebrow. \"Not bad. Stopping me, or…?\"\n\n"
            + (tier.equals("shy") ? "*First time anyone's grabbed me there.* [stunned, whimpers mid-kiss]"
             : tier.equals("enjoy") ? "\"Or,\" {npc_he} says. {npc_He} keeps going."
             : "{npc_He} doesn't answer immediately. {npc_He} takes that as a yes."))
            .requires("kissed").blocks("breast_groped")
            .sets("breast_groped").arousal(7).npcArousal(8).npcFrustration(-5)
            .minStage("flustered").weight(8).build());

        p.add(DanceMoment.id("jerk_slow_dance_check").text(
            "She starts sliding {npc_his} hand higher during the slow dance. {npc_He} guides it back to her waist.\n\n\"Really? We're slow dancing and you're already stopping me?\" {npc_He} pauses with a smirk — then actually complies. The dance continues, mood slightly cooler.")
            .arousal(2).npcArousal(2).npcFrustration(2).weight(7).build());

        p.add(DanceMoment.id("jerk_situation_neg").text(
            "\"Of course it's packed in here tonight.\" {npc_He} says it to the air, not {npc_him} — then pulls her slightly closer anyway. The complaint wasn't really about the crowd.")
            .arousal(2).npcArousal(2).npcFrustration(-1).weight(8).repeatable().build());

        p.add(DanceMoment.id("jerk_closer_no_comment").text(
            "{npc_He} ends up closer than {npc_he} meant to be — their faces near, arms tighter. {npc_He} doesn't comment on it. Doesn't step back either. Just keeps dancing like it's unremarkable.")
            .arousal(4).npcArousal(5).npcFrustration(-3).npcLiking(5).weight(8).build());

        p.add(DanceMoment.id("jerk_gets_under_skin").text(
            "{npc_He} says something — or doesn't say something — and it gets under {npc_his} skin in a way {npc_he} can't immediately smirk away. She goes quiet for a second. Actually quiet. Not performing.\n\nHe recovers, but the beat was real.")
            .arousal(3).npcArousal(5).npcFrustration(-4).npcLiking(8).weight(7).build());

        p.add(DanceMoment.id("jerk_dare_back").text(
            "{npc_He} dares {npc_him} back. {npc_He} hufts a surprised laugh — actual, not performed. \"Huh. Didn't expect you to actually say that.\" The tone drops its usual edge for one real second. \"Alright. Your move.\"")
            .requires("kissed").arousal(4).npcArousal(6).npcFrustration(-4).npcLiking(7).weight(7).build());

        p.add(DanceMoment.id("jerk_hickey_realize").text(
            "{npc_His} mouth is on your neck, sucking steadily. The realization arrives.\n\n"
            + "*{npc_He}'s leaving a mark. On purpose.*\n\n"
            + (tier.equals("enjoy")
                ? "Something warm runs through you. You tilt your chin up. Let {npc_him}."
              : "*I can already feel it. {npc_He}'s going to leave something visible.*\n\nYour hand moves toward {npc_his} shoulder. Slow. The push-away choice is there."))
            .requires("neck_kissed").arousal(5).npcArousal(7).npcFrustration(-5).weight(8).build());

        p.add(DanceMoment.id("jerk_dirty_whisper").text(
            buildDirtyWhisperText())
            .requires("kissed").requires("neck_kissed")
            .arousal(6).npcArousal(7).npcFrustration(-4).weight(9).build());

        p.add(DanceMoment.id("jerk_stops_breast").text(
            "{npc_His} hands slowly slide out from under your shirt. \"Decent enough. I'll give them a rest.\"\n\n"
            + (gameStageVariant("breast_public").equals("enjoy")
                ? "Somewhere between irritated and warm. You breathe out."
              : "*{npc_His} hands are off. The shame and the relief arrive in the same moment.*"))
            .requires("breast_groped").arousal(2).npcArousal(2).npcFrustration(3).weight(5).build());

        p.add(DanceMoment.id("jerk_stops_roaming").text(
            "{npc_He} pulls {npc_his} hands back to safer territory. \"I'll stop before you make it weird.\"\n\n"
            + (bar.gameStageVariant().equals("enjoy")
                ? "\"You were the one making it weird,\" you say. {npc_He} smirks."
              : "*Everything finally stopped. The places {npc_he} touched still burn.*"))
            .requires("ass_groped").arousal(1).npcArousal(2).npcFrustration(4).weight(5).build());

        // ── Jerk + braless shirt pull ─────────────────────────────────────────
            if (state.hasTrait("exposed_breasts")) {
            String tier = gameStageVariant("breast_public");
            p.add(DanceMoment.id("jerk_shirt_pull").text(
                "Without asking, {npc_he} grabs the hem of your shirt and pulls it up — quick, "
                + "casual, like {npc_he}'s entitled to.\n\n"
                + "Your bare breasts are exposed for a moment before {npc_he} covers them again "
                + "with {npc_his} hands directly.\n\n"
                + (tier.equals("shy")
                    ? "The shock freezes you completely. The sound of the room disappears.\n\n"
                      + "*Everyone — {npc_he} just — oh god — everyone could see—*\n\n"
                      + "Your hands come up too late. {npc_His} are already there."
                  : tier.equals("flustered")
                    ? "The jolt hits before you can think.\n\n"
                      + "*He just — in the middle of—* You don't push back. You're not sure why not.\n\n"
                      + "{npc_His} hands stay. You let them."
                  : "You catch your breath. {npc_His} hands are already there.\n\n"
                      + "\"Figured,\" {npc_he} says. Like this was always where this was going.\n\n"
                      + "It was. You knew that."))
                .requires("breast_groped")
                .minDrunk(6)
                .minNpcArousal(50)
                .arousal(6).npcArousal(8).npcFrustration(-8).sets("breast_groped")
                .weight(7).maleOnly().build());
        }

        
        
                p.add(DanceMoment.id("jerk_conv_1").text(
            "\"Not bad. You're actually decent at slow dancing.\"\n\n"
            + (tier.equals("enjoy") ? "High praise. I'll take it, you laugh softly."
             : tier.equals("flustered") ? "Thanks... I think, you reply drily."
             : "You look down, unsure how to take it."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("jerk_conv_2").text(
            "\"Didn't think you'd be the type to just sway like this. It's tolerable.\"\n\n"
            + (tier.equals("enjoy") ? "I'll put it on my résumé, you say."
             : tier.equals("flustered") ? "Tolerable. Wow, you say flatly."
             : "*Tolerable.* You keep moving and say nothing."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("jerk_conv_3").text(
            "\"You're quieter than I expected. Turns out that's not annoying.\"\n\n"
            + (tier.equals("enjoy") ? "You're welcome, you reply pleasantly."
             : tier.equals("flustered") ? "Shocking, you say."
             : "You don't say anything, which proves {npc_his} point somehow."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("jerk_conv_4").text(
            "\"Most people talk too much when the music slows down. You don't.\"\n\n"
            + (tier.equals("enjoy") ? "I'm full of surprises, you say."
             : tier.equals("flustered") ? "You're talking right now, you point out."
             : "You press your lips together. *Obviously.*"))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("jerk_conv_5").text(
            "\"I'll give you this — you make the song feel longer in a good way.\"\n\n"
            + (tier.equals("enjoy") ? "Then I'll keep doing what I'm doing, you reply."
             : tier.equals("flustered") ? "Appreciated, you say simply."
             : "You glance up. *In a good way.* Coming from {npc_him} that's something."))
            .arousal(1).npcLiking(4).npcFrustration(-2).weight(7).repeatable().build());

                p.add(DanceMoment.id("gen_playful_teasing").text(
            "\"If I step on your toes, you have permission to kick me.\"\n\n"
            + (tier.equals("enjoy") ? "Only if you deserve it, you tease back softly."
             : tier.equals("flustered") ? "Noted. I'll be gentle, you reply with a small smile."
             : "I-I wouldn't kick you, you say with a tiny nervous laugh."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());
        p.add(DanceMoment.id("gen_self_deprecation").text(
            "\"I'm probably terrible at this. You're carrying the whole dance.\"\n\n"
            + (tier.equals("enjoy") ? "Then let me carry you a little longer, you tease gently."
             : tier.equals("flustered") ? "We're both doing okay, you say with a small smile."
             : "No, you're doing fine, you reassure {npc_him} shyly."))
            .arousal(1).npcLiking(5).npcFrustration(-2).weight(7).repeatable().build());

        // Jerk pool at 34+
        return p;
    }

    // ── DEFAULT ───────────────────────────────────────────────────────────────
    List<DanceMoment> defaultMoments(NpcData n) {
        List<DanceMoment> p = new ArrayList<>();
        p.add(DanceMoment.id("def_closer").text("The dance gets a little closer. Neither of you mentions it.")
            .arousal(3).npcArousal(3).npcFrustration(-3).npcLiking(4).weight(10).build());
        p.add(DanceMoment.id("def_hand_lower").text("{npc_His} hand drifts lower on your back. Stays.")
            .arousal(4).npcArousal(4).npcFrustration(-4).weight(9).build());
        p.add(DanceMoment.id("def_quiet_moment").text("You sway together. Nothing said. Comfortable.")
            .arousal(2).npcArousal(2).npcFrustration(-2).npcLiking(5).weight(10).repeatable().build());

        // ── Clothing panic beats (MC internal — fire based on MC clothing traits) ──
        // All NPC pools include these via defaultMoments merger OR they're added here
        // and getMomentPool returns defaults for unmatched NPCs only.
        // For all pools: these are added via clothingPanicMoments() called separately.

        return p;
    }

    /**
     * Clothing-aware panic beats — added to every pool in buildFilteredPool.
     * Only fire when MC has the relevant clothing trait.
     * Tier-gated: shy tier = panic, flustered = discomfort, enjoy = fine with it.
     */
}
