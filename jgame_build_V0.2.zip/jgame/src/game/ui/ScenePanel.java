package game.ui;

import game.*;
import game.data.SceneData;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

public class ScenePanel extends JPanel {

    private final Engine         engine;
    private final GameState      state;
    private final ClothingLoader clothes;
    private final Consumer<Void> onChange;
    private Runnable             onSceneComplete;
    private game.GameSettings    settings; // optional — null = normal mode

    private final JTextArea textArea;
    private final JPanel    choicesPanel;

    // Track dynamic traits snapshot — detect mid-scene changes
    private java.util.Set<String> lastDynamicTraits = new java.util.HashSet<>();

    public ScenePanel(Engine engine, GameState state, ClothingLoader clothes, Consumer<Void> onChange) {
        this.engine   = engine;
        this.state    = state;
        this.clothes  = clothes;
        this.onChange = onChange;
        setBackground(Colors.BG);
        setLayout(new BorderLayout());

        textArea = new JTextArea();
        textArea.setEditable(false); textArea.setOpaque(false);
        textArea.setForeground(Colors.TEXT);
        textArea.setFont(settings != null
            ? new Font(settings.fontFamily, Font.PLAIN, settings.textSize)
            : new Font("Georgia", Font.PLAIN, 18)); // fallback if settings not yet injected
        textArea.setLineWrap(true); textArea.setWrapStyleWord(true);
        textArea.setBorder(BorderFactory.createEmptyBorder(30, 44, 20, 44));

        JScrollPane scroll = new JScrollPane(textArea);
        scroll.setOpaque(false); scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        choicesPanel = new JPanel();
        choicesPanel.setOpaque(false);
        choicesPanel.setLayout(new BoxLayout(choicesPanel, BoxLayout.Y_AXIS));
        choicesPanel.setBorder(BorderFactory.createEmptyBorder(8, 44, 28, 44));

        add(scroll,       BorderLayout.CENTER);
        add(choicesPanel, BorderLayout.SOUTH);
    }

    public void setOnSceneComplete(Runnable r) { this.onSceneComplete = r; }
    public void setSettings(game.GameSettings s) {
        this.settings = s;
        if (s != null && textArea != null)
            textArea.setFont(new Font(s.fontFamily, Font.PLAIN, s.textSize));
    }



    public void showCurrentScene() {
        // Null guard — if no current scene, complete immediately
        if (state.currentScene == null || state.currentScene.isEmpty()
                || state.currentScene.startsWith("__")) {
            if (onSceneComplete != null) onSceneComplete.run();
            return;
        }
        SceneData scene;
        try {
            scene = engine.loadCurrent();
        } catch (Exception e) {
            game.CrashReporter.reportError("Failed to load scene: " + state.currentScene, e);
            if (onSceneComplete != null) onSceneComplete.run();
            return;
        }
        if (scene == null) {
            if (onSceneComplete != null) onSceneComplete.run();
            return;
        }
        engine.onSceneEnter(state.currentScene);
        // Snapshot current dynamic traits for mid-scene comparison
        lastDynamicTraits = new java.util.HashSet<>(state.computeDynamicTraits(clothes));
        textArea.setForeground(Colors.TEXT);
        textArea.setText(engine.resolveText(scene));
        textArea.setCaretPosition(0);
        buildChoices(engine.availableChoices(scene));
    }

    private void buildChoices(List<SceneData.ChoiceData> choices) {
        choicesPanel.removeAll();
        if (choices.isEmpty() && onSceneComplete != null) {
            // No choices — add a "Continue" button that returns to day planner
            JButton cont = makeBtn("Continue →");
            cont.addActionListener(e -> onSceneComplete.run());
            choicesPanel.add(Box.createVerticalStrut(7));
            choicesPanel.add(cont);
        } else {
            for (SceneData.ChoiceData choice : choices) {
                boolean isWip    = choice.wip;
                boolean isLocked = !isWip && (choice.show_when_locked && !engine.isChoiceVisible(choice));
                JButton btn = isWip || isLocked
                            ? makeGreyBtn(isWip ? "[WIP]  " + choice.text : "🔒  " + choice.text)
                            : makeBtn(choice.text);
                if (!isWip && !isLocked) {
                    btn.addActionListener(e -> handleChoice(choice));
                }
                // DEV mode: tooltip showing gates, stats, path types
                if (settings != null && settings.isDev()) {
                    btn.setToolTipText(buildDevTooltip(choice));
                }
                choicesPanel.add(Box.createVerticalStrut(7));
                choicesPanel.add(btn);
            }
        }
        choicesPanel.revalidate(); choicesPanel.repaint();
    }

    private void handleChoice(SceneData.ChoiceData choice) {
        String sceneBefore = state.currentScene;
        // Snapshot stats before applying choice for PLAYER/DEV diff
        int _snapHap=state.happiness, _snapConf=state.confidence, _snapWP=state.willpower;
        int _snapStr=state.stress, _snapAro=state.arousal, _snapFit=state.fitness;
        int _snapRep=state.reputation, _snapSlut=state.slut_rep, _snapMoney=state.money;

        String result = engine.applyChoice(choice);
        onChange.accept(null);

        // Check if arousal-based nipping crossed a threshold mid-scene
        String nippingNote = checkArousedNippingChange();

        String fullResult = result != null ? result.trim() : "";
        if (!nippingNote.isEmpty()) {
            fullResult = fullResult.isEmpty() ? nippingNote : fullResult + "\n\n" + nippingNote;
        }
        // PLAYER / DEV mode: append stat summary line
        if (settings != null && settings.isPlayer()) {
            String statLine = buildStatSummary(choice, _snapHap, _snapConf, _snapWP,
                _snapStr, _snapAro, _snapFit, _snapRep, _snapSlut, _snapMoney);
            if (!statLine.isEmpty())
                fullResult = (fullResult.isEmpty() ? "" : fullResult + "\n\n") + statLine;
        }

        // Did the choice route us to a genuinely different scene?
        boolean routedElsewhere = !state.currentScene.equals(sceneBefore);

        if (!fullResult.isEmpty()) {
            textArea.setForeground(Colors.RESULT);
            textArea.setText(fullResult);
            choicesPanel.removeAll();
            JButton cont = makeBtn("Continue →");
            cont.addActionListener(e -> {
                textArea.setForeground(Colors.TEXT);
                if (routedElsewhere) {
                    // next pointed to a different scene — load it
                    showCurrentScene();
                } else {
                    // Same scene or no next — this beat is done, advance
                    if (onSceneComplete != null) onSceneComplete.run();
                    else showCurrentScene();
                }
            });
            choicesPanel.add(Box.createVerticalStrut(7));
            choicesPanel.add(cont);
            choicesPanel.revalidate();
        } else {
            // No result text — advance immediately if scene didn't change
            if (routedElsewhere) {
                showCurrentScene();
            } else {
                if (onSceneComplete != null) onSceneComplete.run();
                else showCurrentScene();
            }
        }
    }

    /** Returns a note if arousal crossed the nipping threshold since last check. */
    private String checkArousedNippingChange() {
        java.util.Set<String> nowTraits = state.computeDynamicTraits(clothes);
        boolean wasNipping  = lastDynamicTraits.contains("arousal_nipping");
        boolean nowNipping  = nowTraits.contains("arousal_nipping");
        boolean wasPierced  = lastDynamicTraits.contains("pierced_nipping") ||
                              lastDynamicTraits.contains("pierced_nipping_prominent");
        boolean nowPierced  = nowTraits.contains("pierced_nipping") ||
                              nowTraits.contains("pierced_nipping_prominent");
        boolean nowProminent = nowTraits.contains("pierced_nipping_prominent");

        // Update snapshot
        lastDynamicTraits = new java.util.HashSet<>(nowTraits);

        if (!wasNipping && nowNipping) {
            // Arousal crossed threshold — subtle physical note
            if (state.arousal >= 75) {
                return "You're aware of the warmth in your skin. The fabric of your top feels a little thinner than it did.";
            } else {
                return "There's a faint awareness — the fabric pressing where it shouldn't quite be noticed.";
            }
        }
        if (!wasPierced && nowPierced) {
            return nowProminent
                ? "The jewelry catches against the fabric. Anyone looking would notice it."
                : "The jewelry catches slightly against the fabric. Noticeable if you know what to look for.";
        }
        return "";
    }

    private JButton makeBtn(String text) {
        // Special button variants
        boolean isContinue  = text.startsWith("Continue") || text.equals("Continue →");
        boolean isPushAway  = text.startsWith("Push away") || text.startsWith("End the dance")
                           || text.startsWith("End the night") || text.startsWith("Say goodnight");
        boolean isGoHome    = text.contains("head out") || text.contains("Go home")
                           || text.startsWith("🏠");

        // Emoji prefix for contextual buttons
        String display = text;
        if (isContinue && !text.contains("→"))   display = "Continue  →";
        if (isGoHome && !text.contains("🏠"))     display = "🏠  " + text;

        final boolean fin = isContinue;
        final boolean push = isPushAway;
        final String finalText = display;

        JButton btn = new JButton(finalText) {
            boolean hov = false;
            { addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent e) { hov = true;  repaint(); }
                public void mouseExited (java.awt.event.MouseEvent e) { hov = false; repaint(); }
            }); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg, border;
                if (fin) {
                    bg     = hov ? new Color(90, 70, 170) : new Color(70, 55, 140);
                    border = hov ? new Color(140, 120, 230) : new Color(100, 80, 180);
                } else if (push) {
                    bg     = hov ? new Color(62, 32, 38) : new Color(48, 24, 30);
                    border = hov ? new Color(180, 70, 90) : new Color(110, 50, 60);
                } else {
                    bg     = hov ? Colors.BG_BTN_HOV : Colors.BG_BTN;
                    border = hov ? Colors.ACCENT_LIT  : Colors.BORDER;
                }
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(border);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 8, 8);
                super.paintComponent(g);
            }
        };
        btn.setForeground(isPushAway ? new Color(220, 150, 160) : new Color(210, 200, 255));
        btn.setFont(settings != null
            ? new Font(settings.choiceFont, Font.PLAIN, settings.choiceSize)
            : Colors.SANS_PLAIN);
        btn.setContentAreaFilled(false); btn.setBorderPainted(false); btn.setFocusPainted(false);
        btn.setHorizontalAlignment(isContinue ? SwingConstants.CENTER : SwingConstants.LEFT);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        btn.setAlignmentX(LEFT_ALIGNMENT);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    /** Grey, non-clickable button for WIP or locked-but-visible choices. */
    private JButton makeGreyBtn(String text) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(38, 36, 44));          // very dark, near-invisible bg
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(new Color(70, 68, 78));          // dim border
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 8, 8);
                super.paintComponent(g);
            }
        };
        btn.setForeground(new Color(90, 85, 105));           // muted grey-purple text
        btn.setFont(settings != null
            ? new Font(settings.choiceFont, Font.PLAIN, settings.choiceSize)
            : Colors.SANS_PLAIN);
        btn.setContentAreaFilled(false); btn.setBorderPainted(false); btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        btn.setAlignmentX(LEFT_ALIGNMENT);
        btn.setEnabled(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
        return btn;
    }
    private String buildStatSummary(game.data.SceneData.ChoiceData c,
            int h0, int conf0, int wp0, int str0, int aro0, int fit0,
            int rep0, int slut0, int money0) {
        java.util.List<String> parts = new java.util.ArrayList<>();
        appendDiff(parts, "happiness",  h0,     state.happiness);
        appendDiff(parts, "confidence", conf0,   state.confidence);
        appendDiff(parts, "willpower",  wp0,     state.willpower);
        appendDiff(parts, "stress",     str0,    state.stress);
        appendDiff(parts, "arousal",    aro0,    state.arousal);
        appendDiff(parts, "fitness",    fit0,    state.fitness);
        appendDiff(parts, "reputation", rep0,    state.reputation);
        appendDiff(parts, "slut rep",   slut0,   state.slut_rep);
        if (state.money != money0) {
            int d = state.money - money0;
            parts.add((d > 0 ? "+" : "") + "$" + d);
        }
        if (parts.isEmpty()) return "";
        return "[ " + String.join("  ", parts) + " ]";
    }

    private void appendDiff(java.util.List<String> parts, String name, int before, int after) {
        int d = after - before;
        if (d == 0) return;
        String sign = d > 0 ? "+" : "";
        parts.add(sign + d + " " + name);
    }


    private String buildDevTooltip(game.data.SceneData.ChoiceData c) {
        StringBuilder sb = new StringBuilder("<html><b>DEV INFO</b><br>");
        if (c.slut_rep_req > 0)           sb.append("slut_rep ≥ ").append(c.slut_rep_req).append("<br>");
        if (c.min_npc_rep > 0)            sb.append("npc_rep ≥ ").append(c.min_npc_rep).append("<br>");
        if (c.min_arousal > 0)            sb.append("arousal ≥ ").append(c.min_arousal).append("<br>");
        if (c.min_willpower > 0)          sb.append("willpower ≥ ").append(c.min_willpower).append("<br>");
        if (c.min_money > 0)              sb.append("money ≥ ").append(c.min_money).append("<br>");
        if (!c.requires_traits.isEmpty()) sb.append("requires: <i>").append(c.requires_traits).append("</i><br>");
        if (!c.requires_flag.isEmpty())   sb.append("flag: <i>").append(c.requires_flag).append("</i><br>");
        if (!c.blocks_if_flag.isEmpty())  sb.append("blocks if: <i>").append(c.blocks_if_flag).append("</i><br>");
        if (!c.path_traits.isEmpty())     sb.append("path: <i>").append(c.path_traits).append("</i><br>");
        if (!c.add_traits.isEmpty())      sb.append("adds: ").append(c.add_traits).append("<br>");
        if (!c.timed_traits.isEmpty())    sb.append("timed: ").append(c.timed_traits).append("<br>");
        if (!c.remove_traits.isEmpty())   sb.append("removes: ").append(c.remove_traits).append("<br>");
        if (!c.stat_changes.isEmpty()) {
            sb.append("stats: ");
            c.stat_changes.forEach((k,v) -> sb.append(k).append(v>0?"+":"").append(v).append(" "));
            sb.append("<br>");
        }
        if (c.money_change != 0) sb.append("money: ").append(c.money_change > 0 ? "+" : "").append(c.money_change).append("<br>");
        if (!c.path_types.isEmpty())     sb.append("path: ").append(c.path_types).append("<br>");
        // Settings multipliers active
        if (settings.slutRepMultiplier != 1.0f && c.stat_changes.containsKey("slut_rep")) {
            sb.append("<i>slut_rep ×").append(settings.slutRepMultiplier).append(" active</i><br>");
        }
        sb.append("</html>");
        return sb.toString();
    }


}
