package game.ui;

import game.mod.Mod;
import game.mod.ModLoader;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.List;
import java.util.function.Supplier;

/**
 * Main menu — shown on launch, before the day planner.
 * Shows game title, Play/Continue, Mod Manager, and Quit.
 */
public class MainMenuPanel extends JPanel {

    private final Runnable          onPlay;
    private final ModLoader         modLoader;
    private final Runnable          onShowModManager;
    private final Runnable          onShowLoad;
    private final game.SaveManager  saveManager;

    private final Runnable onShowSettings;

    public MainMenuPanel(Runnable onPlay, ModLoader modLoader, Runnable onShowModManager,
                         Runnable onShowLoad, game.SaveManager saveManager,
                         Runnable onShowSettings) {
        this.onPlay           = onPlay;
        this.modLoader        = modLoader;
        this.onShowModManager = onShowModManager;
        this.onShowLoad       = onShowLoad;
        this.saveManager      = saveManager;
        this.onShowSettings   = onShowSettings;

        setBackground(Colors.BG);
        setLayout(new GridBagLayout());
        build();
    }

    private void build() {
        JPanel center = new JPanel();
        center.setOpaque(false);
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setBorder(BorderFactory.createEmptyBorder(0, 60, 0, 60));

        // ── Title ─────────────────────────────────────────────────────────────
        JLabel title = new JLabel("The Soul of Carrow");
        title.setFont(new Font("SansSerif", Font.BOLD, 72));
        title.setForeground(Colors.TEXT_HEAD);
        title.setAlignmentX(CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("a life simulator");
        subtitle.setFont(Colors.LABEL);
        subtitle.setForeground(Colors.TEXT_DIM);
        subtitle.setAlignmentX(CENTER_ALIGNMENT);

        center.add(title);
        center.add(Box.createVerticalStrut(6));
        center.add(subtitle);
        center.add(Box.createVerticalStrut(48));

        // ── Buttons ───────────────────────────────────────────────────────────
        boolean hasSave = saveManager != null &&
            (saveManager.autosaveExists() || saveManager.slotExists(1)
             || saveManager.slotExists(2) || saveManager.slotExists(3));

        JButton playBtn = menuButton("▶  New Game", hasSave ? Colors.TEXT_DIM : Colors.TEXT_HEAD);
        playBtn.addActionListener(e -> {
            if (hasSave) {
                int c = javax.swing.JOptionPane.showConfirmDialog(this,
                    "Starting a new game will not delete your saves.\nContinue to new game?",
                    "New Game", javax.swing.JOptionPane.YES_NO_OPTION);
                if (c != javax.swing.JOptionPane.YES_OPTION) return;
            }
            onPlay.run();
        });

        JButton contBtn = menuButton("▶  Continue", Colors.TEXT_HEAD);
        contBtn.setEnabled(hasSave);
        contBtn.addActionListener(e -> { if (onShowLoad != null) onShowLoad.run(); });

        JButton loadBtn = menuButton("↺  Load Game", Colors.TEXT_DIM);
        loadBtn.setEnabled(saveManager != null &&
            (saveManager.autosaveExists() || saveManager.slotExists(1) ||
             saveManager.slotExists(2)    || saveManager.slotExists(3)));
        loadBtn.addActionListener(e -> { if (onShowLoad != null) onShowLoad.run(); });

        JButton modsBtn = menuButton("⚙  Mod Manager", Colors.TEXT_DIM);
        modsBtn.addActionListener(e -> onShowModManager.run());

        JButton quitBtn = menuButton("✕  Quit", new Color(180, 80, 80));
        quitBtn.addActionListener(e -> System.exit(0));

        JButton settBtn = menuButton("⚙  Settings", Colors.TEXT_DIM);
        settBtn.addActionListener(e -> { if (onShowSettings != null) onShowSettings.run(); });

        if (hasSave) {
            center.add(contBtn);
            center.add(Box.createVerticalStrut(12));
        }
        center.add(playBtn);
        center.add(Box.createVerticalStrut(12));
        center.add(modsBtn);
        center.add(Box.createVerticalStrut(12));
        center.add(settBtn);
        center.add(Box.createVerticalStrut(12));
        center.add(quitBtn);
        center.add(Box.createVerticalStrut(36));

        // ── Mod status summary ────────────────────────────────────────────────
        List<Mod> mods = modLoader.getMods();
        if (!mods.isEmpty()) {
            long ok      = mods.stream().filter(m -> m.status == Mod.Status.OK).count();
            long partial = mods.stream().filter(m -> m.status == Mod.Status.PARTIAL).count();
            long failed  = mods.stream().filter(m -> m.status == Mod.Status.FAILED).count();

            String summary = mods.size() + " mod" + (mods.size() == 1 ? "" : "s") + " loaded";
            if (partial > 0 || failed > 0)
                summary += "  ·  ⚠ " + (partial + failed) + " with errors";
            else
                summary += "  ·  ✓ all clean";

            JLabel modStatus = new JLabel(summary);
            modStatus.setFont(Colors.SANS_SMALL);
            modStatus.setForeground(failed > 0 || partial > 0
                ? new Color(220, 160, 60) : new Color(80, 180, 100));
            modStatus.setAlignmentX(CENTER_ALIGNMENT);
            center.add(modStatus);
        } else {
            JLabel noMods = new JLabel("No mods loaded");
            noMods.setFont(Colors.SANS_SMALL);
            noMods.setForeground(Colors.TEXT_DIM);
            noMods.setAlignmentX(CENTER_ALIGNMENT);
            center.add(noMods);
        }

        // ── Version ───────────────────────────────────────────────────────────
        center.add(Box.createVerticalStrut(48));
        JLabel version = new JLabel("v0.1.0");
        version.setFont(Colors.SANS_SMALL);
        version.setForeground(new Color(60, 60, 70));
        version.setAlignmentX(CENTER_ALIGNMENT);
        center.add(version);

        add(center);
    }

    private JButton menuButton(String text, Color fg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 18));
        btn.setForeground(fg);
        btn.setBackground(new Color(28, 28, 36));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(55, 55, 70), 1),
            BorderFactory.createEmptyBorder(12, 40, 12, 40)));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setAlignmentX(CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(280, 52));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            final Color base = btn.getBackground();
            @Override public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(40, 40, 54));
            }
            @Override public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(base);
            }
        });

        return btn;
    }
}
