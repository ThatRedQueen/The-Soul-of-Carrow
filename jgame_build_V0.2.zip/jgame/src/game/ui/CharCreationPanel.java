package game.ui;

import game.GameState;
import game.data.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

public class CharCreationPanel extends JPanel {

    private final GameState               state;
    private final List<TraitCategoryData> categories;
    private final Runnable                onComplete;

    private JTextField nameField;

    // groupId → selected trait id (pickOne groups)
    private final Map<String, String>       radioSelected = new LinkedHashMap<>();
    // traitId → JToggleButton (multi-select groups)
    private final Map<String, JToggleButton> checkSelected = new LinkedHashMap<>();
    private final java.util.List<JToggleButton> shyLockedButtons = new java.util.ArrayList<>();

    // Tooltip window
    private final JWindow tooltipWindow;
    private final JLabel  tooltipLabel;

    public CharCreationPanel(GameState state, List<TraitCategoryData> categories, Runnable onComplete) {
        this.state      = state;
        this.categories = categories;
        this.onComplete = onComplete;

        // Build tooltip window
        tooltipWindow = new JWindow();
        tooltipLabel  = new JLabel();
        tooltipLabel.setForeground(Colors.TEXT);
        tooltipLabel.setFont(Colors.SANS_SMALL);
        tooltipLabel.setBackground(new Color(28, 28, 50));
        tooltipLabel.setOpaque(true);
        tooltipLabel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Colors.ACCENT, 1),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        tooltipWindow.add(tooltipLabel);
        tooltipWindow.setBackground(new Color(0,0,0,0));

        setBackground(Colors.BG);
        setLayout(new BorderLayout());
        build();
    }

    private void build() {
        JLabel title = new JLabel("CHARACTER CREATION", SwingConstants.CENTER);
        title.setForeground(Colors.TEXT_HEAD);
        title.setFont(new Font("SansSerif", Font.BOLD, 60));
        title.setBorder(BorderFactory.createEmptyBorder(28, 0, 16, 0));
        add(title, BorderLayout.NORTH);

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(0, 60, 20, 60));

        // Name
        content.add(sectionLabel("YOUR NAME"));
        nameField = new JTextField("Player");
        styleField(nameField);
        content.add(nameField);
        content.add(Box.createVerticalStrut(18));

        // Trait categories
        for (TraitCategoryData cat : categories) {
            if (!cat.showInCreation) continue;
            String suffix = cat.pickOne ? "  (pick one)" : "  (pick any)";
            content.add(sectionLabel(cat.label + suffix));
            content.add(buildRow(cat));
            content.add(Box.createVerticalStrut(8));
        }

        // Done button
        content.add(Box.createVerticalStrut(12));
        JButton done = makeDoneBtn();
        done.setAlignmentX(CENTER_ALIGNMENT);
        content.add(done);
        content.add(Box.createVerticalStrut(40));

        JScrollPane scroll = new JScrollPane(content);
        scroll.setOpaque(false); scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        add(scroll, BorderLayout.CENTER);
    }

    /** Sensible defaults for each pickOne category — overrides first-in-list behaviour. */
    private static final java.util.Map<String,String> DEFAULTS = new java.util.HashMap<>();
    static {
        // Personality stays as-is (Antisocial first — user should actively choose)
        DEFAULTS.put("Social_Energy",      "Engaging");          // not Boring
        DEFAULTS.put("Willpower",          "Average_Will");      // not Iron_Will
        DEFAULTS.put("Role",               "Switch");            // not Dom
        DEFAULTS.put("Body_Type",          "Body_Average");      // not Body_Petite
        DEFAULTS.put("Height",             "Average_Height");    // not Short
        DEFAULTS.put("Breast_Size",        "Breasts_C");         // not Breasts_A
        DEFAULTS.put("Breast_Sensitivity", "Medium_Breast_Sensitivity"); // not Low
        DEFAULTS.put("Virginity_Status",   "Non_Virgin");        // not Virgin
        DEFAULTS.put("Pussy_Traits",       "Tight");             // not Extremely_Tight
        DEFAULTS.put("Size_Preference",    "Size_Doesnt_Matter");// not Prefers_Smaller
        DEFAULTS.put("Fertility",          "Fertile");           // not Infertile
        DEFAULTS.put("Cum_Preference",     "Neutral_On_Cum");    // not Likes_Cum
        DEFAULTS.put("Kids_Preference",    "Doesnt_Want_Kids");  // not Wants_Kids
        DEFAULTS.put("Exhibitionism",      "Neutral_On_Exhibitionism"); // not Hates_Being_Watched
        DEFAULTS.put("PDA_Preference",     "Neutral_On_PDA");   // not Hates_PDA
        DEFAULTS.put("Sexual_Disposition", "Sexually_Neutral");  // not Prude
        DEFAULTS.put("Hair_Length",        "Hair_Medium");       // not Hair_Short
    }

    private JPanel buildRow(TraitCategoryData cat) {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        row.setOpaque(false); row.setAlignmentX(LEFT_ALIGNMENT);

        if (cat.pickOne && !cat.traits.isEmpty()) {
            // Use explicit sensible default if defined, otherwise first trait
            String def = DEFAULTS.getOrDefault(cat.id, cat.traits.get(0).id);
            radioSelected.putIfAbsent(cat.id, def);
        }

        // Track shy button for cross-category locking
        boolean isPersonality = cat.id.equals("Personality");
        boolean isExhibitionism = cat.id.equals("Exhibitionism");

        for (TraitData trait : cat.traits) {
            JToggleButton btn = makeToggle(trait.label);
            final boolean shyLocked = trait.shy_locked;

            if (cat.pickOne) {
                btn.setSelected(trait.id.equals(radioSelected.get(cat.id)));
                final String traitId = trait.id;
                btn.addActionListener(e -> {
                    if (!btn.isEnabled()) return;
                    radioSelected.put(cat.id, traitId);
                    for (Component c : row.getComponents()) {
                        if (c instanceof JToggleButton && c != btn)
                            ((JToggleButton)c).setSelected(false);
                    }
                    btn.setSelected(true);

                    // If this is Personality, update exhibitionism locks
                    if (isPersonality) {
                        updateShyLocks(traitId.equals("Shy"));
                    }
                });
            } else {
                final String traitId = trait.id;
                checkSelected.put(traitId, btn);
            }

            // Store shy-lockable buttons for later toggling
            if (shyLocked) shyLockedButtons.add(btn);

            final String desc = trait.description + (shyLocked ? "\n\n[Unavailable when Shy]" : "");
            btn.addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { showTip(desc, e.getLocationOnScreen()); }
                public void mouseExited (MouseEvent e) { tooltipWindow.setVisible(false); }
            });

            row.add(btn);
        }
        return row;
    }

    private void updateShyLocks(boolean isShy) {
        for (JToggleButton btn : shyLockedButtons) {
            btn.setEnabled(!isShy);
            if (isShy && btn.isSelected()) {
                // Deselect locked trait, select first in its group
                btn.setSelected(false);
                // Find and select Neutral_On_Exhibitionism as fallback
                radioSelected.put("Exhibitionism", "Neutral_On_Exhibitionism");
                // Visually update the row
                Container parent = btn.getParent();
                if (parent != null) {
                    for (Component c : parent.getComponents()) {
                        if (c instanceof JToggleButton) {
                            JToggleButton tb = (JToggleButton) c;
                            // Select Neutral option (3rd button, index 2)
                            tb.setSelected(false);
                        }
                    }
                    // Re-select Neutral
                    for (Component c : parent.getComponents()) {
                        if (c instanceof JToggleButton) {
                            JToggleButton tb = (JToggleButton) c;
                            if (tb.getText().equals("Neutral")) { tb.setSelected(true); break; }
                        }
                    }
                }
            }
        }
    }

    private void showTip(String text, Point p) {
        tooltipLabel.setText("<html><body style='width:200px'>" + text + "</body></html>");
        tooltipWindow.pack();
        int x = Math.min(p.x + 14, Toolkit.getDefaultToolkit().getScreenSize().width  - tooltipWindow.getWidth()  - 10);
        int y = Math.max(p.y - tooltipWindow.getHeight() - 6, 10);
        tooltipWindow.setLocation(x, y);
        tooltipWindow.setVisible(true);
    }

    private void applyAndFinish() {
        tooltipWindow.setVisible(false);
        state.playerName = nameField.getText().trim().isEmpty() ? "Player" : nameField.getText().trim();

        // Apply pickOne selections
        for (TraitCategoryData cat : categories) {
            if (cat.pickOne) {
                String sel = radioSelected.get(cat.id);
                if (sel != null) state.addTrait(sel);
            }
        }
        // Apply multi-select
        for (Map.Entry<String, JToggleButton> e : checkSelected.entrySet()) {
            if (e.getValue().isSelected()) state.addTrait(e.getKey());
        }

        // Stat adjustments
        if (state.hasTrait("Wealthy_Background")) { state.money = 3000; state.confidence = 65; }
        if (state.hasTrait("Broke_Background"))   { state.money = 600;  state.confidence = 40; }
        if (state.hasTrait("Outgoing"))  state.changeStat("confidence", 10);
        if (state.hasTrait("Shy"))       state.changeStat("confidence", -10);
        if (state.hasTrait("Athletic"))  state.changeStat("fitness", 15);

        // Willpower tier → starting willpower stat
        if      (state.hasTrait("Iron_Will"))   state.willpower = 90;
        else if (state.hasTrait("Strong_Will")) state.willpower = 70;
        else if (state.hasTrait("Average_Will")) state.willpower = 50;
        else if (state.hasTrait("Weak_Will"))   state.willpower = 30;
        else if (state.hasTrait("Pushover"))    state.willpower = 10;

        state.currentScene = "housing";

        // ── Set defaults for fields not touched by char creation ──────────
        // Happiness baseline — shy starts lower, outgoing starts higher
        if (state.hasTrait("Outgoing"))       state.happiness  = 60;
        else if (state.hasTrait("Shy"))       state.happiness  = 40;
        else                                  state.happiness  = 50;

        // Stress baseline — strong will = calmer start
        if (state.hasTrait("Iron_Will") || state.hasTrait("Strong_Will"))
                                              state.stress     = 15;
        else if (state.hasTrait("Pushover"))  state.stress     = 35;
        else                                  state.stress     = 20;

        // Fitness from Athletic trait already applied via changeStat above
        // Reputation and slut_rep start at 0 (GameState defaults)

        // Work mode defaults
        state.workMode          = "normal";
        state.officeRep         = 60;
        state.promotionProgress = 0;

        // Housing starts at floor-sleeping until first choice
        if (!state.hasTrait("Wealthy_Background")) {
            state.addTrait("sleeping_on_floor");
            state.rent = 0;   // no rent until housing chosen
            state.housingWillpowerCap      = 60;
            state.housingWillpowerRecovery = 4;
            state.housingStressReduction   = 2;
            state.housingStressMin         = 50;
        } else {
            // Wealthy start — skip floor, go straight to housing choice
            state.rent = 0;
        }

        // Cycle — start at neutral mid-cycle (not on period)
        state.cycleDay    = 14;
        state.cycleLength = 28;

        // Monthly rep tracking reset
        state.repMonthStart = 1;

        onComplete.run();
    }

    // ── UI helpers ────────────────────────────────────────────────
    private JLabel sectionLabel(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(Colors.TEXT_HEAD);
        l.setFont(new Font("SansSerif", Font.BOLD, 33));
        l.setBorder(BorderFactory.createEmptyBorder(4, 0, 4, 0));
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JToggleButton makeToggle(String label) {
        JToggleButton btn = new JToggleButton(label) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(isSelected() ? Colors.ACCENT : new Color(32, 32, 52));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(isSelected() ? Colors.ACCENT_LIT : Colors.BORDER);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 8, 8);
                super.paintComponent(g);
            }
        };
        btn.setForeground(Colors.TEXT);
        btn.setFont(Colors.SANS_PLAIN);
        btn.setContentAreaFilled(false); btn.setBorderPainted(false); btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(6, 14, 6, 14));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void styleField(JTextField f) {
        f.setBackground(new Color(32, 32, 52));
        f.setForeground(Colors.TEXT); f.setCaretColor(Colors.TEXT);
        f.setFont(Colors.SANS_PLAIN);
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Colors.ACCENT, 1),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)));
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        f.setAlignmentX(LEFT_ALIGNMENT);
    }

    private JButton makeDoneBtn() {
        JButton btn = new JButton("BEGIN YOUR STORY →") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(85, 65, 165));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                super.paintComponent(g);
            }
        };
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 42));
        btn.setContentAreaFilled(false); btn.setBorderPainted(false); btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(12, 44, 12, 44));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> applyAndFinish());
        return btn;
    }
}
