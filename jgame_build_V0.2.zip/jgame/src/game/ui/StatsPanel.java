package game.ui;

import game.GameState;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.geom.*;

/**
 * Redesigned stats sidebar — compact stat cards with emoji icons,
 * clean card groupings, and professional dark-panel aesthetic.
 */
public class StatsPanel extends JPanel {

    private final GameState state;
    private Runnable onOutfitClick;

    // Header
    private JLabel nameLabel, dayLabel, moneyLabel, promotionLabel, neighbourhoodLabel;

    // Primary stat cards
    private StatCard fitnessCard, workRepCard, happinessCard,
                     confidenceCard, willpowerCard, stressCard;

    // Secondary stat cards (shown when nonzero)
    private StatCard slutRepCard, thrillsCard, arousalCard, drunkCard;

    // Cycle
    private JLabel cycleLabel;

    // Situational NPC bar (only during bar scenes)
    private NpcBar npcFrustBar, npcArousalBar;
    private JPanel npcSection;

    // Dance lock indicator (shown when flagDanceLocked)
    private JLabel danceLockLabel;
    private JPanel danceLockSection;

    // Daily slut rep cap indicator (shown when slutRepGainedToday > 0)
    private JLabel dayRepLabel;
    private JPanel dayRepSection;

    public StatsPanel(GameState state, Runnable onOutfitClick) {
        this.onOutfitClick = onOutfitClick;
        this.state = state;
        setPreferredSize(new Dimension(220, 0));
        setBackground(C.PANEL);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, C.DIVIDER));
        build();
    }

    // ── color + font constants scoped to sidebar ──────────────────────────────
    private static final class C {
        static final Color PANEL      = new Color(20, 20, 34);
        static final Color CARD       = new Color(28, 28, 46);
        static final Color CARD_HOV   = new Color(36, 34, 58);
        static final Color DIVIDER    = new Color(42, 42, 66);
        static final Color TEXT       = new Color(218, 218, 232);
        static final Color TEXT_DIM   = new Color(110, 110, 140);
        static final Color TEXT_HEAD  = new Color(175, 155, 255);
        static final Color ACCENT     = new Color(130, 110, 210);
        static final Color TRACK      = new Color(38, 38, 58);

        // Stat bar colors
        static final Color FIT  = new Color(72,  188, 100);
        static final Color REP  = new Color(72,  148, 218);
        static final Color HAP  = new Color(218, 178, 52);
        static final Color CON  = new Color(178, 72,  200);
        static final Color WP   = new Color(200, 72,  72);
        static final Color STR  = new Color(200, 120, 50);  // amber — stress
        static final Color SLUT = new Color(200, 60,  160);
        static final Color THR  = new Color(220, 120, 200);
        static final Color ARO  = new Color(230, 80,  130);
        static final Color DRK  = new Color(170, 130, 52);
        static final Color NPC  = new Color(90,  170, 250);

        static final Font HEAD   = new Font("SansSerif", Font.BOLD, 13);
        static final Font LABEL  = new Font("SansSerif", Font.PLAIN, 11);
        static final Font SMALL  = new Font("SansSerif", Font.PLAIN, 10);
        static final Font EMOJI  = new Font("SansSerif", Font.PLAIN, 13);
        static final Font NUM    = new Font("SansSerif", Font.BOLD,  11);
    }

    private void build() {
        // ── Player header card ────────────────────────────────────────────────
        JPanel header = card(12);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        nameLabel = new JLabel("Player");
        nameLabel.setFont(C.HEAD);
        nameLabel.setForeground(C.TEXT_HEAD);
        nameLabel.setAlignmentX(LEFT_ALIGNMENT);

        dayLabel = new JLabel("Day 1  ·  Mon");
        dayLabel.setFont(C.SMALL);
        dayLabel.setForeground(C.TEXT_DIM);
        dayLabel.setAlignmentX(LEFT_ALIGNMENT);

        moneyLabel = new JLabel("💰 $1,000");
        moneyLabel.setFont(C.LABEL);
        moneyLabel.setForeground(new Color(210, 185, 80));
        moneyLabel.setAlignmentX(LEFT_ALIGNMENT);
        moneyLabel.setBorder(BorderFactory.createEmptyBorder(4, 0, 0, 0));

        header.add(nameLabel);
        header.add(Box.createVerticalStrut(2));
        header.add(dayLabel);
        neighbourhoodLabel = new JLabel("");
        neighbourhoodLabel.setFont(Colors.SANS_SMALL);
        neighbourhoodLabel.setForeground(new Color(100, 160, 120));
        neighbourhoodLabel.setAlignmentX(LEFT_ALIGNMENT);
        neighbourhoodLabel.setVisible(false);
        header.add(neighbourhoodLabel);

        header.add(moneyLabel);
        addCard(header);

        // ── Primary stats ─────────────────────────────────────────────────────
        JLabel statsHead = sectionHead("CHARACTER");
        add(statsHead);

        fitnessCard    = new StatCard("💪", "Fitness",    100, C.FIT);
        workRepCard    = new StatCard("🏢", "Office Rep", 100, C.REP);
        happinessCard  = new StatCard("😊", "Happiness",  100, C.HAP);
        confidenceCard = new StatCard("💎", "Confidence", 100, C.CON);
        willpowerCard  = new StatCard("🧠", "Willpower",  100, C.WP);
        stressCard     = new StatCard("😰", "Stress",      100, C.STR);
        addCard(fitnessCard);
        addCard(workRepCard);

        // Promotion progress — only shown when employed and progress > 0
        promotionLabel = new JLabel("▲ Promotion: 0%");
        promotionLabel.setFont(Colors.SANS_SMALL);
        promotionLabel.setForeground(new Color(120, 180, 120));
        promotionLabel.setAlignmentX(LEFT_ALIGNMENT);
        promotionLabel.setBorder(BorderFactory.createEmptyBorder(0, 4, 6, 0));
        promotionLabel.setVisible(false);
        add(promotionLabel);

        addCard(happinessCard);
        addCard(confidenceCard);
        addCard(willpowerCard);
        addCard(stressCard);

        // ── Cycle / body ──────────────────────────────────────────────────────
        JLabel cycleHead = sectionHead("CYCLE");
        add(cycleHead);
        JPanel cycleCard = card(10);
        cycleCard.setLayout(new BoxLayout(cycleCard, BoxLayout.X_AXIS));
        JLabel cycleIcon = new JLabel("🌙");
        cycleIcon.setFont(C.EMOJI);
        cycleLabel = new JLabel("Day 1 of 28");
        cycleLabel.setFont(C.LABEL);
        cycleLabel.setForeground(C.TEXT_DIM);
        cycleCard.add(cycleIcon);
        cycleCard.add(Box.createHorizontalStrut(6));
        cycleCard.add(cycleLabel);
        cycleCard.add(Box.createHorizontalGlue());
        addCard(cycleCard);

        // ── Situational stats (hidden until nonzero) ──────────────────────────
        JLabel situHead = sectionHead("SITUATIONAL");
        add(situHead);

        slutRepCard  = new StatCard("💜", "Rep",     100, C.SLUT);
        thrillsCard  = new StatCard("⚡", "Thrills", 100, C.THR);
        arousalCard  = new StatCard("🔥", "Arousal", 80,  C.ARO);
        drunkCard    = new StatCard("🍺", "Drunk",   20,  C.DRK);
        addCard(slutRepCard);
        addCard(thrillsCard);
        addCard(arousalCard);
        addCard(drunkCard);

        // ── NPC section (bar scenes) ──────────────────────────────────────────
        npcSection = new JPanel();
        npcSection.setOpaque(false);
        npcSection.setLayout(new BoxLayout(npcSection, BoxLayout.Y_AXIS));
        npcSection.setAlignmentX(LEFT_ALIGNMENT);
        npcFrustBar   = new NpcBar("😤 Frustration", C.WP);
        npcArousalBar = new NpcBar("💓 NPC Arousal",  C.NPC);
        JLabel npcHead = sectionHead("NPC");
        npcSection.add(npcHead);
        JPanel nf = card(8); nf.setLayout(new BoxLayout(nf, BoxLayout.Y_AXIS));
        nf.add(npcFrustBar); nf.add(Box.createVerticalStrut(6)); nf.add(npcArousalBar);
        JPanel nfWrap = wrap(nf);
        npcSection.add(nfWrap);
        add(npcSection);

        // ── Dance lock indicator ───────────────────────────────────────────────
        danceLockSection = new JPanel();
        danceLockSection.setOpaque(false);
        danceLockSection.setLayout(new BoxLayout(danceLockSection, BoxLayout.Y_AXIS));
        danceLockSection.setAlignmentX(LEFT_ALIGNMENT);
        danceLockLabel = new JLabel("🔒 Dancing — can't stop");
        danceLockLabel.setFont(danceLockLabel.getFont().deriveFont(java.awt.Font.BOLD, 11f));
        danceLockLabel.setForeground(new Color(220, 80, 80));
        danceLockLabel.setAlignmentX(LEFT_ALIGNMENT);
        JPanel dlCard = card(8);
        dlCard.add(danceLockLabel);
        danceLockSection.add(wrap(dlCard));
        add(danceLockSection);

        // ── Daily rep cap indicator ────────────────────────────────────────────
        dayRepSection = new JPanel();
        dayRepSection.setOpaque(false);
        dayRepSection.setLayout(new BoxLayout(dayRepSection, BoxLayout.Y_AXIS));
        dayRepSection.setAlignmentX(LEFT_ALIGNMENT);
        dayRepLabel = new JLabel("💜 Rep today: 0/5");
        dayRepLabel.setFont(dayRepLabel.getFont().deriveFont(11f));
        dayRepLabel.setForeground(C.TEXT_DIM);
        dayRepLabel.setAlignmentX(LEFT_ALIGNMENT);
        JPanel drCard = card(8);
        drCard.add(dayRepLabel);
        dayRepSection.add(wrap(drCard));
        add(dayRepSection);

        // ── Action buttons ────────────────────────────────────────────────────
        add(Box.createVerticalGlue());
        add(vstrut(8));
        add(btnRow("👗 Outfit", "🏷️ Traits"));
        add(vstrut(10));
    }

    // ── Refresh ───────────────────────────────────────────────────────────────

    public void refresh() {
        nameLabel.setText(state.playerName);
        moneyLabel.setText("💰  $" + String.format("%,d", state.money));

        int day = state.dayCount;
        String[] days = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
        dayLabel.setText("Day " + day + "  ·  " + days[state.dayOfWeek % 7] + "  " + state.getSeasonEmoji() + " " + state.getSeasonName());
        if (neighbourhoodLabel != null) {
            boolean hasNeighbourhood = state.currentNeighbourhood != null && !state.currentNeighbourhood.isEmpty();
            neighbourhoodLabel.setVisible(hasNeighbourhood);
            if (hasNeighbourhood) neighbourhoodLabel.setText("📍 " + state.currentNeighbourhood);
        }

        fitnessCard.setValue(state.fitness);
        // Work mode stats — only show when employed
        if (state.currentJobId != null) {
            workRepCard.setVisible(true);
            workRepCard.setValue(state.officeRep);
        } else {
            workRepCard.setVisible(false);
        }
        happinessCard.setValue(state.happiness);
        confidenceCard.setValue(state.confidence);
        willpowerCard.setValue(state.willpower);
        stressCard.setValue(state.stress);

        // Effective willpower — use arousal-drain version when in bar scene
        boolean barActive = state.currentApproachingNpc != null;
        int effWp = barActive
                  ? state.effectiveWillpowerForCheck(40)
                  : state.effectiveWillpower();
        willpowerCard.setEffective(effWp);

        // Situational
        slutRepCard.setVisible(state.slut_rep   > 0); slutRepCard.setValue(state.slut_rep);
        thrillsCard.setVisible(state.thrills     > 0); thrillsCard.setValue(state.thrills);
        arousalCard.setVisible(state.arousal     > 0); arousalCard.setValue(state.arousal);
        drunkCard  .setVisible(state.drunk       > 0); drunkCard.setValue(state.drunk);

        // NPC bars — only during bar sessions
        npcSection.setVisible(barActive);
        if (barActive) {
            npcFrustBar.setValue(state.currentNpcFrustration, 100);
            npcArousalBar.setValue(state.currentNpcArousal, 100);
        }

        // Dance lock — show turns remaining when locked
        danceLockSection.setVisible(state.flagDanceLocked);
        if (state.flagDanceLocked) {
            String turns = state.danceLockTurns == 1 ? "1 turn left"
                         : state.danceLockTurns + " turns left";
            danceLockLabel.setText("🔒 Dancing — can't stop  (" + turns + ")");
        }

        // Promotion progress
        if (promotionLabel != null) {
            boolean showPromo = state.currentJobId != null && state.promotionProgress > 0;
            promotionLabel.setVisible(showPromo);
            if (showPromo) {
                int p = state.promotionProgress;
                promotionLabel.setText("▲ Promotion: " + p + "%");
                promotionLabel.setForeground(p >= 80 ? new Color(200, 220, 80)
                                           : p >= 50 ? new Color(120, 200, 120)
                                           : new Color(100, 150, 100));
            }
        }

        // Daily rep cap — show when any gained today
        boolean repActive = state.slutRepGainedToday > 0;
        dayRepSection.setVisible(repActive);
        if (repActive) {
            int gained = state.slutRepGainedToday;
            int cap    = GameState.SLUT_REP_DAILY_CAP;
            dayRepLabel.setText("💜 Rep today: " + gained + "/" + cap);
            dayRepLabel.setForeground(gained >= cap
                    ? new Color(200, 80, 80)   // at cap — red
                    : new Color(160, 120, 200)); // still room — purple
        }

        // Cycle label + color
        String status = state.cycleStatus();
        cycleLabel.setText(status);
        if      (state.isOnPeriod())       cycleLabel.setForeground(new Color(200, 80, 80));
        else if (state.isOvulating())      cycleLabel.setForeground(new Color(220, 160, 60));
        else if (state.isFertileWindow())  cycleLabel.setForeground(new Color(80, 200, 120));
        else                               cycleLabel.setForeground(C.TEXT_DIM);

        // Drunk color
        drunkCard.setColor(state.drunk >= 15 ? new Color(200, 60, 60)
                         : state.drunk >= 11 ? new Color(200, 140, 40)
                         : C.DRK);

        revalidate(); repaint();
    }

    // ── Stat card component ───────────────────────────────────────────────────

    private class StatCard extends JPanel {
        private final String emoji;
        private final String label;
        private final int    max;
        private       Color  barColor;
        private int value = 0, effective = -1;

        StatCard(String emoji, String label, int max, Color color) {
            this.emoji = emoji; this.label = label; this.max = max; this.barColor = color;
            setOpaque(false);
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
            setAlignmentX(LEFT_ALIGNMENT);
        }
        void setValue(int v)        { value = Math.max(0, Math.min(max, v)); effective = -1; repaint(); }
        void setEffective(int e)    { effective = e; repaint(); }
        void setColor(Color c)      { barColor = c; repaint(); }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            int W = getWidth(), H = getHeight();
            int trackH = 3, trackY = H - 7, px = 2;
            int barW = W - px * 2;

            // Emoji
            g2.setFont(C.EMOJI); g2.setColor(C.TEXT);
            g2.drawString(emoji, px, H - 10);

            // Label
            g2.setFont(C.LABEL); g2.setColor(C.TEXT_DIM);
            g2.drawString(label, px + 20, H - 10);

            // Value number (right-aligned)
            String numStr = String.valueOf(value);
            g2.setFont(C.NUM); g2.setColor(C.TEXT);
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(numStr, W - px - fm.stringWidth(numStr), H - 10);

            // Track
            g2.setColor(C.TRACK);
            g2.fillRoundRect(px, trackY, barW, trackH, 2, 2);

            // Fill
            int fillW = Math.max(2, (int)(barW * (double)value / max));
            g2.setColor(barColor);
            g2.fillRoundRect(px, trackY, fillW, trackH, 2, 2);

            // Effective willpower line (drain indicator)
            if (effective >= 0 && effective < value) {
                int effX = px + (int)(barW * (double)effective / max);
                g2.setColor(new Color(255, 80, 80, 200));
                g2.fillRect(effX, trackY - 1, 2, trackH + 2);
            }
        }
        @Override public Dimension getPreferredSize() { return new Dimension(200, 30); }
    }

    // ── NPC mini-bar ──────────────────────────────────────────────────────────

    private class NpcBar extends JPanel {
        private final String label;
        private final Color  color;
        private int value = 0, max = 100;

        NpcBar(String label, Color color) {
            this.label = label; this.color = color;
            setOpaque(false);
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 20));
            setAlignmentX(LEFT_ALIGNMENT);
        }
        void setValue(int v, int m) { value = v; max = m; repaint(); }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int W = getWidth(), H = getHeight(), px = 2;
            int barW = W - px * 2, barH = 3, barY = H - 5;
            g2.setFont(C.SMALL); g2.setColor(C.TEXT_DIM);
            g2.drawString(label, px, H - 7);
            String v = String.valueOf(value);
            FontMetrics fm = g2.getFontMetrics();
            g2.setColor(C.TEXT); g2.drawString(v, W - px - fm.stringWidth(v), H - 7);
            g2.setColor(C.TRACK); g2.fillRoundRect(px, barY, barW, barH, 2, 2);
            int fill = Math.max(2, (int)(barW * (double)Math.min(value, max) / max));
            // NPC frustration pulses red when high
            Color c = (label.contains("Frust") && value > 70)
                    ? new Color(220, 60, 60) : color;
            g2.setColor(c); g2.fillRoundRect(px, barY, fill, barH, 2, 2);
        }
        @Override public Dimension getPreferredSize() { return new Dimension(200, 20); }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private JPanel card(int vpad) {
        JPanel p = new JPanel();
        p.setBackground(C.CARD);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        p.setAlignmentX(LEFT_ALIGNMENT);
        p.setBorder(BorderFactory.createEmptyBorder(vpad, 12, vpad, 12));
        return p;
    }

    private void addCard(JPanel c) {
        JPanel wrap = wrap(c);
        add(wrap);
    }

    private JPanel wrap(JPanel inner) {
        JPanel outer = new JPanel();
        outer.setOpaque(false);
        outer.setLayout(new BoxLayout(outer, BoxLayout.Y_AXIS));
        outer.setAlignmentX(LEFT_ALIGNMENT);
        outer.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        outer.setBorder(BorderFactory.createEmptyBorder(1, 6, 1, 6));
        outer.add(inner);
        return outer;
    }

    private JLabel sectionHead(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(C.TEXT_DIM);
        l.setFont(new Font("SansSerif", Font.BOLD, 9));
        l.setBorder(BorderFactory.createEmptyBorder(8, 8, 2, 0));
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JPanel btnRow(String label1, String label2) {
        JPanel row = new JPanel(new GridLayout(1, 2, 4, 0));
        row.setOpaque(false);
        row.setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 6));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        row.setAlignmentX(LEFT_ALIGNMENT);
        row.add(sideBtn(label1, () -> { if (onOutfitClick != null) onOutfitClick.run(); }));
        row.add(sideBtn(label2, () -> showTraitsDialog()));
        return row;
    }

    private JButton sideBtn(String text, Runnable onClick) {
        JButton btn = new JButton(text) {
            boolean hov = false;
            { addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent e) { hov = true;  repaint(); }
                public void mouseExited (java.awt.event.MouseEvent e) { hov = false; repaint(); }
            }); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(hov ? new Color(48, 44, 78) : new Color(34, 32, 56));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(hov ? C.ACCENT : C.DIVIDER);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 8, 8);
                super.paintComponent(g);
            }
        };
        btn.setForeground(C.TEXT_HEAD);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 11));
        btn.setContentAreaFilled(false); btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setHorizontalAlignment(SwingConstants.CENTER);
        btn.addActionListener(e -> onClick.run());
        return btn;
    }

    private JComponent vstrut(int h) {
        JPanel s = new JPanel();
        s.setOpaque(false);
        s.setMaximumSize(new Dimension(Integer.MAX_VALUE, h));
        s.setPreferredSize(new Dimension(1, h));
        return s;
    }

    private void showTraitsDialog() {
        JDialog dialog = new JDialog(
            (Frame) SwingUtilities.getWindowAncestor(this), "🏷️  Traits", false);
        dialog.getContentPane().setBackground(C.PANEL);
        dialog.setLayout(new BorderLayout());

        JLabel title = new JLabel("  Character Traits");
        title.setForeground(C.TEXT_HEAD);
        title.setFont(C.HEAD);
        title.setBorder(BorderFactory.createEmptyBorder(14, 6, 8, 0));
        dialog.add(title, BorderLayout.NORTH);

        // Permanent + timed traits
        StringBuilder sb = new StringBuilder();
        for (String t : state.traits) {
            String fmt = t.replace("_", " ");
            fmt = Character.toUpperCase(fmt.charAt(0)) + fmt.substring(1);
            sb.append("  •  ").append(fmt).append("\n");
        }
        for (var entry : state.timedTraits.entrySet()) {
            String fmt = entry.getKey().replace("_", " ");
            fmt = Character.toUpperCase(fmt.charAt(0)) + fmt.substring(1);
            int daysLeft = entry.getValue() - state.dayCount;
            sb.append("  •  ").append(fmt)
              .append("  (").append(daysLeft).append("d)\n");
        }

        JTextArea area = new JTextArea(sb.length() > 0 ? sb.toString().trim() : "No traits yet.");
        area.setEditable(false); area.setOpaque(false);
        area.setForeground(Colors.TEXT); area.setFont(Colors.PANEL_PLAIN);
        area.setLineWrap(true); area.setWrapStyleWord(true);
        area.setBorder(BorderFactory.createEmptyBorder(4, 14, 14, 14));

        JScrollPane scroll = new JScrollPane(area);
        scroll.setOpaque(false); scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        dialog.add(scroll, BorderLayout.CENTER);

        dialog.setSize(290, 360);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }


    private final GameState state;
    private Runnable onOutfitClick;
    private JLabel nameLabel, moneyLabel, rentLabel, cycleLabel;
    private StatBar fitnessBar, workRepBar, happinessBar, confidenceBar, willpowerBar,
                    slutRepBar, thrillsBar, arousalBar, drunkBar;

    public StatsPanel(GameState state, Runnable onOutfitClick) {
        this.onOutfitClick = onOutfitClick;
        this.state = state;
        setPreferredSize(new Dimension(200, 0));
        setBackground(Colors.BG_PANEL);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Colors.BORDER));
        build();
    }

    private void build() {
        add(Box.createVerticalStrut(14));
        nameLabel = label("Player", Colors.TEXT_HEAD, Colors.PANEL_HEAD);
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 13));
        nameLabel.setAlignmentX(CENTER_ALIGNMENT);
        add(nameLabel);
        add(Box.createVerticalStrut(10));
        add(sep());

        add(sectionTitle("FINANCES"));
        moneyLabel = label("$1,000", Colors.TEXT, Colors.PANEL_PLAIN);
        rentLabel  = label("Rent: $0 / month", Colors.TEXT_DIM, Colors.PANEL_SMALL);
        add(indented(moneyLabel));
        add(indented(rentLabel));
        add(Box.createVerticalStrut(4));
        add(sep());

        add(sectionTitle("STATS"));
        fitnessBar    = new StatBar("Fitness",      Colors.BAR_FIT);
        workRepBar    = new StatBar("Work Rep",     Colors.BAR_REP);
        happinessBar  = new StatBar("Happiness",    Colors.BAR_HAP);
        confidenceBar = new StatBar("Confidence",   Colors.BAR_CON);
        willpowerBar  = new StatBar("Willpower",    new Color(200, 80, 80));
        slutRepBar    = new StatBar("Reputation",   new Color(180, 60, 160));
        thrillsBar    = new StatBar("Thrills",      new Color(220, 120, 200));
        arousalBar    = new StatBar("Arousal",      new Color(220, 80, 140));
        drunkBar      = new StatBar("Drunk",        new Color(180, 140, 60), 20); // max 20
        add(fitnessBar); add(workRepBar); add(happinessBar);
        add(confidenceBar); add(willpowerBar); add(slutRepBar);
        add(thrillsBar); add(arousalBar); add(drunkBar);
        add(Box.createVerticalStrut(4));
        add(sep());

        add(sectionTitle("CYCLE"));
        cycleLabel = label("Day 1 of 28", Colors.TEXT_DIM, Colors.PANEL_SMALL);
        add(indented(cycleLabel));
        add(Box.createVerticalStrut(4));
        add(sep());

        // Traits button
        // Traits button — colors defined once as constants
        final java.awt.Color BTN_BG  = new java.awt.Color(38, 38, 62);
        final java.awt.Color BTN_BDR = new java.awt.Color(70, 60, 110);
        JButton traitsBtn = new JButton("View Traits") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BTN_BG);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                g2.setColor(BTN_BDR);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 6, 6);
                super.paintComponent(g);
            }
        };
        traitsBtn.setForeground(Colors.TEXT_HEAD);
        traitsBtn.setFont(Colors.PANEL_PLAIN);
        traitsBtn.setContentAreaFilled(false); traitsBtn.setBorderPainted(false);
        traitsBtn.setFocusPainted(false);
        traitsBtn.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
        traitsBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        traitsBtn.setAlignmentX(CENTER_ALIGNMENT);
        traitsBtn.addActionListener(e -> showTraitsPopup(traitsBtn));

        JButton outfitBtn = makeSideBtn("Change Outfit");
        outfitBtn.addActionListener(e -> { if (onOutfitClick != null) onOutfitClick.run(); });

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 6));
        btnRow.setOpaque(false);
        btnRow.add(traitsBtn);
        btnRow.add(outfitBtn);
        add(btnRow);
        add(Box.createVerticalGlue());
    }

    private JButton makeSideBtn(String text) {
        final java.awt.Color BG  = new java.awt.Color(38, 38, 62);
        final java.awt.Color BDR = new java.awt.Color(70, 60, 110);
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(java.awt.Graphics g) {
                java.awt.Graphics2D g2 = (java.awt.Graphics2D) g;
                g2.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG); g2.fillRoundRect(0,0,getWidth(),getHeight(),6,6);
                g2.setColor(BDR); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,6,6);
                super.paintComponent(g);
            }
        };
        btn.setForeground(Colors.TEXT_HEAD);
        btn.setFont(Colors.PANEL_PLAIN);
        btn.setContentAreaFilled(false); btn.setBorderPainted(false); btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void showTraitsPopup(java.awt.Component anchor) {
        JDialog dialog = new JDialog((java.awt.Frame)
            javax.swing.SwingUtilities.getWindowAncestor(this), "Traits", false);
        dialog.getContentPane().setBackground(Colors.BG_PANEL);
        dialog.setLayout(new BorderLayout());

        JLabel title = new JLabel("  Character Traits", SwingConstants.LEFT);
        title.setForeground(Colors.TEXT_HEAD);
        title.setFont(new Font("SansSerif", Font.BOLD, 13));
        title.setBorder(BorderFactory.createEmptyBorder(12, 4, 8, 0));
        dialog.add(title, BorderLayout.NORTH);

        JTextArea area = new JTextArea();
        area.setEditable(false); area.setOpaque(false);
        area.setForeground(Colors.TEXT);
        area.setFont(Colors.PANEL_PLAIN);
        area.setLineWrap(true); area.setWrapStyleWord(true);
        area.setBorder(BorderFactory.createEmptyBorder(4, 14, 14, 14));

        if (state.traits.isEmpty()) {
            area.setText("No traits set.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (String t : state.traits) {
                String fmt = t.replace("_", " ");
                fmt = Character.toUpperCase(fmt.charAt(0)) + fmt.substring(1);
                sb.append("• ").append(fmt).append("\n");
            }
            area.setText(sb.toString().trim());
        }

        JScrollPane scroll = new JScrollPane(area);
        scroll.setOpaque(false); scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        dialog.add(scroll, BorderLayout.CENTER);

        dialog.setSize(280, 420);
        dialog.setLocationRelativeTo(anchor);
        dialog.setVisible(true);
    }

    public void refresh() {
        nameLabel.setText(state.playerName);
        moneyLabel.setText("$" + String.format("%,d", state.money));
        rentLabel.setText("Rent: $" + String.format("%,d", state.rent) + " / mo");
        fitnessBar.setValue(state.fitness);
        workRepBar.setValue(state.work_rep);
        happinessBar.setValue(state.happiness);
        confidenceBar.setValue(state.confidence);
        willpowerBar.setValue(state.willpower);

        // Situational bars — only shown when nonzero so they don't confuse new players
        slutRepBar.setVisible(state.slut_rep > 0);
        slutRepBar.setValue(state.slut_rep);
        thrillsBar.setVisible(state.thrills > 0);
        thrillsBar.setValue(state.thrills);
        arousalBar.setVisible(state.arousal > 0);
        arousalBar.setValue(state.arousal);
        drunkBar.setVisible(state.drunk > 0);
        drunkBar.setValue(state.drunk);

        String status = state.cycleStatus();
        cycleLabel.setText(status);
        if (state.isOnPeriod())           cycleLabel.setForeground(new Color(200, 80, 80));
        else if (state.isOvulating())     cycleLabel.setForeground(new Color(220, 160, 60));
        else if (state.isFertileWindow()) cycleLabel.setForeground(new Color(80, 200, 120));
        else                              cycleLabel.setForeground(Colors.TEXT_DIM);

        revalidate(); repaint();
    }


    private JLabel label(String txt, Color col, Font font) {
        JLabel l = new JLabel(txt); l.setForeground(col); l.setFont(font); return l;
    }
    private JComponent indented(JComponent c) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 1));
        p.setOpaque(false); p.add(c); return p;
    }
    private JLabel sectionTitle(String t) {
        JLabel l = new JLabel(t);
        l.setForeground(Colors.TEXT_HEAD);
        l.setFont(Colors.PANEL_HEAD);
        l.setBorder(BorderFactory.createEmptyBorder(4, 10, 1, 0));
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }
    private JSeparator sep() {
        JSeparator s = new JSeparator(); s.setForeground(Colors.BORDER);
        s.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1)); return s;
    }

    private class StatBar extends JPanel {
        private final String label; private final Color color;
        private final int max;   // scale max — 100 for most bars, 20 for drunk
        private int value = 0;
        private static final Color BAR_TRACK = new Color(40, 40, 60);
        StatBar(String label, Color color)        { this(label, color, 100); }
        StatBar(String label, Color color, int max) {
            this.label = label; this.color = color; this.max = max;
            setOpaque(false); setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
            setAlignmentX(LEFT_ALIGNMENT);
        }
        void setValue(int v) { value = Math.max(0, Math.min(max, v)); repaint(); }
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int px = 10, barW = getWidth() - px * 2, barH = 5, py = 6;
            g2.setFont(Colors.PANEL_SMALL); g2.setColor(Colors.TEXT_DIM);
            g2.drawString(label, px, py + barH + 10);
            String vs = String.valueOf(value); FontMetrics fm = g2.getFontMetrics();
            g2.setColor(Colors.TEXT); g2.drawString(vs, getWidth() - px - fm.stringWidth(vs), py + barH + 10);
            g2.setColor(BAR_TRACK); g2.fillRoundRect(px, py, barW, barH, 3, 3);
            g2.setColor(color); g2.fillRoundRect(px, py, (int)(barW * (double)value / max), barH, 3, 3);
        }
        @Override public Dimension getPreferredSize() { return new Dimension(180, 28); }
    }
}
