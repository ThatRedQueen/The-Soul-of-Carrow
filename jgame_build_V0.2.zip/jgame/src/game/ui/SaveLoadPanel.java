package game.ui;

import game.SaveManager;
import game.SaveManager.SaveMeta;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

/**
 * Save/Load panel — shown from main menu or via pause.
 * Three manual slots + autosave display.
 */
public class SaveLoadPanel extends JPanel {

    public enum Mode { SAVE, LOAD }

    private final SaveManager manager;
    private final Mode        mode;
    private final Runnable    onBack;
    private final Runnable    onLoaded; // called after successful load

    public SaveLoadPanel(SaveManager manager, Mode mode, Runnable onBack, Runnable onLoaded) {
        this.manager  = manager;
        this.mode     = mode;
        this.onBack   = onBack;
        this.onLoaded = onLoaded;
        setBackground(Colors.BG);
        setLayout(new BorderLayout());
        build();
    }

    private void build() {
        // Header
        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setOpaque(false);
        header.setBorder(BorderFactory.createEmptyBorder(24, 48, 16, 48));

        JButton back = new JButton("← Back");
        back.setForeground(Colors.TEXT_DIM);
        back.setBackground(Colors.BG);
        back.setBorderPainted(false);
        back.setFocusPainted(false);
        back.setFont(Colors.LABEL);
        back.addActionListener(e -> onBack.run());

        JLabel title = new JLabel(mode == Mode.SAVE ? "Save Game" : "Load Game");
        title.setFont(new Font("SansSerif", Font.BOLD, 36));
        title.setForeground(Colors.TEXT_HEAD);

        header.add(back, BorderLayout.WEST);
        header.add(title, BorderLayout.CENTER);

        // Slot list
        JPanel slots = new JPanel();
        slots.setOpaque(false);
        slots.setLayout(new BoxLayout(slots, BoxLayout.Y_AXIS));
        slots.setBorder(BorderFactory.createEmptyBorder(0, 48, 24, 48));

        // Autosave row (load only)
        if (mode == Mode.LOAD) {
            slots.add(buildSlotRow(-1));
            slots.add(Box.createVerticalStrut(10));
        }

        for (int i = 1; i <= 3; i++) {
            slots.add(buildSlotRow(i));
            slots.add(Box.createVerticalStrut(10));
        }

        add(header, BorderLayout.NORTH);
        add(new JScrollPane(slots) {{
            setBorder(null); setOpaque(false); getViewport().setOpaque(false);
        }}, BorderLayout.CENTER);
    }

    private JPanel buildSlotRow(int slot) {
        boolean isAuto = slot < 0;
        SaveMeta meta  = isAuto ? manager.autosaveMeta() : manager.slotMeta(slot);
        String label   = isAuto ? "Autosave" : "Slot " + slot;

        JPanel row = new JPanel(new BorderLayout(16, 0));
        row.setBackground(new Color(24, 24, 32));
        row.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(45, 45, 60), 1),
            BorderFactory.createEmptyBorder(14, 18, 14, 18)));

        // Left: label + meta info
        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));

        JLabel nameLbl = new JLabel(label);
        nameLbl.setFont(new Font("SansSerif", Font.BOLD, 15));
        nameLbl.setForeground(meta.exists ? Colors.TEXT_HEAD : Colors.TEXT_DIM);
        info.add(nameLbl);

        if (meta.exists) {
            String detail = "Day " + meta.day + "  ·  $" + meta.money +
                (meta.jobId.isEmpty() ? "  ·  Unemployed" : "  ·  " + meta.jobId.replace('_',' ')) +
                "  ·  " + meta.date;
            JLabel detailLbl = new JLabel(detail);
            detailLbl.setFont(Colors.SANS_SMALL);
            detailLbl.setForeground(Colors.TEXT_DIM);
            info.add(detailLbl);
        } else {
            JLabel empty = new JLabel("Empty slot");
            empty.setFont(Colors.SANS_SMALL);
            empty.setForeground(new Color(55, 55, 70));
            info.add(empty);
        }

        row.add(info, BorderLayout.CENTER);

        // Right: action button
        if (mode == Mode.SAVE && !isAuto) {
            JButton btn = actionBtn(meta.exists ? "Overwrite" : "Save", meta.exists);
            btn.addActionListener(e -> {
                if (meta.exists) {
                    int confirm = JOptionPane.showConfirmDialog(this,
                        "Overwrite " + label + "?", "Overwrite Save",
                        JOptionPane.YES_NO_OPTION);
                    if (confirm != JOptionPane.YES_OPTION) return;
                }
                if (manager.save(slot)) {
                    JOptionPane.showMessageDialog(this, "Saved to " + label + ".", "Saved",
                        JOptionPane.INFORMATION_MESSAGE);
                    onBack.run();
                }
            });
            row.add(btn, BorderLayout.EAST);

        } else if (mode == Mode.LOAD && meta.exists) {
            JButton btn = actionBtn("Load", false);
            final int s = slot;
            btn.addActionListener(e -> {
                int confirm = JOptionPane.showConfirmDialog(this,
                    "Load " + label + "? Unsaved progress will be lost.",
                    "Load Game", JOptionPane.YES_NO_OPTION);
                if (confirm != JOptionPane.YES_OPTION) return;
                boolean ok = isAuto ? manager.loadAutosave() : manager.load(s);
                if (ok) onLoaded.run();
                else JOptionPane.showMessageDialog(this, "Load failed.", "Error",
                    JOptionPane.ERROR_MESSAGE);
            });
            row.add(btn, BorderLayout.EAST);
        }

        return row;
    }

    private JButton actionBtn(String text, boolean danger) {
        JButton btn = new JButton(text);
        btn.setFont(Colors.PANEL_SMALL);
        btn.setForeground(danger ? new Color(220, 100, 100) : Colors.TEXT_HEAD);
        btn.setBackground(new Color(35, 35, 48));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(60, 60, 80), 1),
            BorderFactory.createEmptyBorder(6, 20, 6, 20)));
        btn.setFocusPainted(false);
        return btn;
    }
}
