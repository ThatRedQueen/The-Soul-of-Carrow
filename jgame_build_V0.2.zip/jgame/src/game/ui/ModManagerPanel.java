package game.ui;

import game.mod.Mod;
import game.mod.ModLoader;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.io.*;
import java.util.List;

/**
 * Mod Manager — lists all loaded mods with status badges,
 * error counts, and an expandable error log per mod.
 */
public class ModManagerPanel extends JPanel {

    private static final Color COL_OK      = new Color(70, 180, 100);
    private static final Color COL_PARTIAL  = new Color(220, 160, 60);
    private static final Color COL_FAILED   = new Color(200, 70, 70);
    private static final Color COL_PENDING  = new Color(100, 100, 120);
    private static final Color COL_WARNING  = new Color(220, 150, 40);
    private static final Color COL_ERROR    = new Color(210, 80, 80);

    private final ModLoader modLoader;
    private final Runnable  onBack;

    public ModManagerPanel(ModLoader modLoader, Runnable onBack) {
        this.modLoader = modLoader;
        this.onBack    = onBack;
        setBackground(Colors.BG);
        setLayout(new BorderLayout());
        build();
    }

    private void build() {
        // ── Header ────────────────────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout(16, 0));
        header.setOpaque(false);
        header.setBorder(BorderFactory.createEmptyBorder(24, 48, 16, 48));

        JButton backBtn = new JButton("← Back");
        backBtn.setForeground(Colors.TEXT_DIM);
        backBtn.setBackground(Colors.BG);
        backBtn.setBorderPainted(false);
        backBtn.setFocusPainted(false);
        backBtn.setFont(Colors.LABEL);
        backBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        backBtn.addActionListener(e -> onBack.run());

        JLabel title = new JLabel("Mod Manager");
        title.setFont(new Font("SansSerif", Font.BOLD, 36));
        title.setForeground(Colors.TEXT_HEAD);

        List<Mod> mods = modLoader.getMods();
        JLabel count = new JLabel(mods.size() + " mod" + (mods.size() == 1 ? "" : "s") + " found");
        count.setForeground(Colors.TEXT_DIM);
        count.setFont(Colors.SANS_SMALL);

        JPanel titleRow = new JPanel();
        titleRow.setOpaque(false);
        titleRow.setLayout(new BoxLayout(titleRow, BoxLayout.Y_AXIS));
        titleRow.add(title);
        titleRow.add(count);

        header.add(backBtn, BorderLayout.WEST);
        header.add(titleRow, BorderLayout.CENTER);

        // ── Mod list ──────────────────────────────────────────────────────────
        JPanel listPanel = new JPanel();
        listPanel.setOpaque(false);
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));
        listPanel.setBorder(BorderFactory.createEmptyBorder(0, 48, 24, 48));

        if (mods.isEmpty()) {
            JLabel empty = new JLabel("No mods found in the mods/ folder.");
            empty.setForeground(Colors.TEXT_DIM);
            empty.setFont(Colors.LABEL);
            empty.setBorder(BorderFactory.createEmptyBorder(24, 0, 0, 0));
            listPanel.add(empty);

            JLabel hint = new JLabel("Drop a mod folder (containing mod.yml) into mods/ and restart the game.");
            hint.setForeground(Colors.TEXT_DIM);
            hint.setFont(Colors.SANS_SMALL);
            hint.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
            listPanel.add(hint);
        } else {
            for (Mod mod : mods) {
                listPanel.add(buildModCard(mod));
                listPanel.add(Box.createVerticalStrut(12));
            }
        }

        // ── Mods folder path hint ─────────────────────────────────────────────
        listPanel.add(Box.createVerticalStrut(24));
        JLabel pathHint = new JLabel("mods/ folder: " + new File("mods").getAbsolutePath());
        pathHint.setForeground(new Color(60, 60, 75));
        pathHint.setFont(Colors.SANS_SMALL);
        listPanel.add(pathHint);

        JScrollPane scroll = new JScrollPane(listPanel);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.getVerticalScrollBar().setUnitIncrement(16);

        add(header,  BorderLayout.NORTH);
        add(scroll,  BorderLayout.CENTER);
    }

    private JPanel buildModCard(Mod mod) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(new Color(24, 24, 32));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(borderColorFor(mod), 1),
            BorderFactory.createEmptyBorder(14, 18, 14, 18)));

        // ── Top row: name + badge ─────────────────────────────────────────────
        JPanel topRow = new JPanel(new BorderLayout(12, 0));
        topRow.setOpaque(false);

        JPanel nameBlock = new JPanel();
        nameBlock.setOpaque(false);
        nameBlock.setLayout(new BoxLayout(nameBlock, BoxLayout.Y_AXIS));

        JLabel nameLbl = new JLabel(mod.name.isEmpty() ? mod.id : mod.name);
        nameLbl.setFont(new Font("SansSerif", Font.BOLD, 15));
        nameLbl.setForeground(Colors.TEXT_HEAD);

        String meta = buildMeta(mod);
        JLabel metaLbl = new JLabel(meta);
        metaLbl.setFont(Colors.SANS_SMALL);
        metaLbl.setForeground(Colors.TEXT_DIM);

        nameBlock.add(nameLbl);
        if (!meta.isEmpty()) nameBlock.add(metaLbl);

        JLabel badge = new JLabel(" " + badgeText(mod) + " ");
        badge.setFont(Colors.SANS_SMALL);
        badge.setForeground(Color.WHITE);
        badge.setBackground(badgeColor(mod));
        badge.setOpaque(true);
        badge.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 8));

        topRow.add(nameBlock, BorderLayout.WEST);
        topRow.add(badge,     BorderLayout.EAST);
        card.add(topRow);

        // ── Content summary ────────────────────────────────────────────────────
        String summary = buildContentSummary(mod);
        if (!summary.isEmpty()) {
            card.add(Box.createVerticalStrut(6));
            JLabel summaryLbl = new JLabel(summary);
            summaryLbl.setFont(Colors.SANS_SMALL);
            summaryLbl.setForeground(Colors.TEXT_DIM);
            card.add(summaryLbl);
        }

        // ── Error log ─────────────────────────────────────────────────────────
        if (!mod.errors.isEmpty()) {
            card.add(Box.createVerticalStrut(10));
            JPanel logPanel = buildErrorLog(mod);
            card.add(logPanel);
        }

        return card;
    }

    private JPanel buildErrorLog(Mod mod) {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel header = new JLabel(mod.errors.size() + " issue" +
            (mod.errors.size() == 1 ? "" : "s") + ":");
        header.setFont(Colors.SANS_SMALL);
        header.setForeground(Colors.TEXT_DIM);
        panel.add(header);
        panel.add(Box.createVerticalStrut(4));

        for (Mod.ModError err : mod.errors) {
            Color col = err.level == Mod.ModError.Level.ERROR ? COL_ERROR : COL_WARNING;

            JPanel row = new JPanel(new BorderLayout(8, 0));
            row.setOpaque(false);

            JLabel levelTag = new JLabel(err.level == Mod.ModError.Level.ERROR ? "[ERR]" : "[WARN]");
            levelTag.setFont(Colors.SANS_SMALL);
            levelTag.setForeground(col);
            levelTag.setPreferredSize(new Dimension(52, 16));

            JLabel msg = new JLabel("<html><b>" + err.file + "</b>  " + err.message + "</html>");
            msg.setFont(Colors.SANS_SMALL);
            msg.setForeground(col);

            row.add(levelTag, BorderLayout.WEST);
            row.add(msg,      BorderLayout.CENTER);
            panel.add(row);
            panel.add(Box.createVerticalStrut(3));
        }

        // Link to written log file
        File logFile = new File(mod.folder, "mod_errors.log");
        if (logFile.exists()) {
            JLabel logLink = new JLabel("Full log: " + logFile.getPath());
            logLink.setFont(Colors.SANS_SMALL);
            logLink.setForeground(new Color(80, 120, 200));
            logLink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            logLink.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                    try { Desktop.getDesktop().open(logFile); }
                    catch (Exception ex) { /* ignore */ }
                }
            });
            panel.add(Box.createVerticalStrut(4));
            panel.add(logLink);
        }

        return panel;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private String buildMeta(Mod mod) {
        StringBuilder sb = new StringBuilder();
        if (!mod.author.isEmpty())  sb.append("by ").append(mod.author);
        if (!mod.version.isEmpty()) { if (sb.length()>0) sb.append("  ·  "); sb.append("v").append(mod.version); }
        if (!mod.description.isEmpty()) { if (sb.length()>0) sb.append("  ·  "); sb.append(mod.description); }
        return sb.toString();
    }

    private String buildContentSummary(Mod mod) {
        StringBuilder sb = new StringBuilder();
        if (mod.scenesLoaded  > 0) sb.append(mod.scenesLoaded).append(" scenes  ");
        if (mod.npcsLoaded    > 0) sb.append(mod.npcsLoaded).append(" NPCs  ");
        if (mod.clothesLoaded > 0) sb.append(mod.clothesLoaded).append(" clothing items  ");
        if (mod.jobsLoaded    > 0) sb.append(mod.jobsLoaded).append(" jobs");
        return sb.toString().trim();
    }

    private String badgeText(Mod mod) {
        switch (mod.status) {
            case OK:      return "✓  Loaded";
            case PARTIAL: return "⚠  Partial";
            case FAILED:  return "✕  Failed";
            default:      return "…  Pending";
        }
    }

    private Color badgeColor(Mod mod) {
        switch (mod.status) {
            case OK:      return new Color(40, 120, 60);
            case PARTIAL: return new Color(120, 80, 20);
            case FAILED:  return new Color(120, 40, 40);
            default:      return new Color(60, 60, 80);
        }
    }

    private Color borderColorFor(Mod mod) {
        switch (mod.status) {
            case OK:      return new Color(40, 80, 50);
            case PARTIAL: return new Color(90, 70, 30);
            case FAILED:  return new Color(90, 40, 40);
            default:      return new Color(45, 45, 60);
        }
    }
}
