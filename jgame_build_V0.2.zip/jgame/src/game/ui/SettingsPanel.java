package game.ui;

import game.GameSettings;
import game.GameSettings.Visibility;
import game.SettingsManager;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.function.Consumer;

/**
 * Full settings page. Accessible from main menu and escape menu.
 * Changes apply immediately to the GameSettings object.
 * SettingsManager.save() is called on Back.
 */
public class SettingsPanel extends JPanel {

    private final GameSettings    settings;
    private final SettingsManager manager;
    private final Runnable        onBack;
    private final Runnable        onSettingsChanged; // e.g. refresh font sizes

    public SettingsPanel(GameSettings settings, SettingsManager manager,
                         Runnable onBack, Runnable onSettingsChanged) {
        this.settings          = settings;
        this.manager           = manager;
        this.onBack            = onBack;
        this.onSettingsChanged = onSettingsChanged;
        setBackground(Colors.BG);
        setLayout(new BorderLayout());
        build();
    }

    private void build() {
        // ── Header ─────────────────────────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout(12,0));
        header.setOpaque(false);
        header.setBorder(BorderFactory.createEmptyBorder(24,48,16,48));

        JButton back = new JButton("← Back");
        back.setForeground(Colors.TEXT_DIM); back.setBackground(Colors.BG);
        back.setBorderPainted(false); back.setFocusPainted(false);
        back.setFont(Colors.LABEL);
        back.addActionListener(e -> { manager.save(); if (onSettingsChanged != null) onSettingsChanged.run(); onBack.run(); });

        JLabel title = new JLabel("Settings");
        title.setFont(new Font("SansSerif", Font.BOLD, 36));
        title.setForeground(Colors.TEXT_HEAD);

        header.add(back,  BorderLayout.WEST);
        header.add(title, BorderLayout.CENTER);

        // ── Content ────────────────────────────────────────────────────────────
        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(0,48,32,48));

        content.add(sectionHeader("DISPLAY MODE"));
        content.add(buildVisibilitySection());
        content.add(Box.createVerticalStrut(24));

        content.add(sectionHeader("TEXT SIZE"));
        content.add(buildTextSizeSection());
        content.add(Box.createVerticalStrut(24));

        content.add(sectionHeader("FONT"));
        content.add(buildFontSection());
        content.add(Box.createVerticalStrut(24));

        content.add(sectionHeader("DIFFICULTY"));
        content.add(buildDifficultySection());
        content.add(Box.createVerticalStrut(24));

        content.add(sectionHeader("KEY BINDINGS"));
        content.add(buildKeyBindSection());
        content.add(Box.createVerticalStrut(24));

        content.add(sectionHeader("DISPLAY OPTIONS"));
        content.add(buildDisplaySection());
        content.add(Box.createVerticalStrut(24));

        content.add(sectionHeader("ACCESSIBILITY"));
        content.add(buildAccessibilitySection());

        JScrollPane scroll = new JScrollPane(content);
        scroll.setBorder(null); scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.getVerticalScrollBar().setUnitIncrement(16);

        add(header, BorderLayout.NORTH);
        add(scroll,  BorderLayout.CENTER);
    }

    // ── Visibility section ─────────────────────────────────────────────────────

    private JPanel buildVisibilitySection() {
        JPanel p = card();

        String[][] modes = {
            {"Normal",  "Text only. No hints, no stat readouts.",
             "Everything is shown through writing. The numbers stay invisible."},
            {"Player",  "Stat gains shown after each choice.",
             "After making a choice you see: +4 arousal  −2 willpower  +6 rep\nUseful for learning the game."},
            {"Dev",     "Full debug overlay.",
             "Hover over any choice button to see: required traits, slut_rep threshold,\npath types, stat formula, and calculated values."},
        };

        Visibility current = settings.visibility;
        ButtonGroup group = new ButtonGroup();

        for (String[] mode : modes) {
            Visibility v = Visibility.valueOf(mode[0].toUpperCase());
            JRadioButton rb = new JRadioButton(mode[1]);
            rb.setForeground(Colors.TEXT_HEAD);
            rb.setBackground(Colors.BG);
            rb.setFont(new Font("SansSerif", Font.BOLD, 14));
            rb.setFocusPainted(false);
            rb.setSelected(v == current);
            rb.addActionListener(e -> { settings.visibility = v; });
            group.add(rb);

            JLabel nameLabel = new JLabel(mode[0]);
            nameLabel.setFont(Colors.LABEL);
            nameLabel.setForeground(v == Visibility.DEV ? new Color(160,200,120)
                                  : v == Visibility.PLAYER ? new Color(100,160,220)
                                  : Colors.TEXT_DIM);

            JLabel desc = new JLabel("<html>" + mode[2].replace("\n","<br>") + "</html>");
            desc.setFont(Colors.SANS_SMALL);
            desc.setForeground(Colors.TEXT_DIM);

            JPanel row = new JPanel(); row.setOpaque(false);
            row.setLayout(new BoxLayout(row, BoxLayout.Y_AXIS));
            row.setBorder(BorderFactory.createEmptyBorder(0,0,12,0));
            row.add(nameLabel);
            row.add(rb);
            row.add(desc);
            p.add(row);
        }
        return p;
    }

    // ── Text size section ──────────────────────────────────────────────────────

    private JPanel buildTextSizeSection() {
        JPanel p = card();

        JLabel preview = new JLabel("Preview  —  The quick brown fox. Open window, evening light.");
        preview.setFont(new Font(settings.fontFamily, Font.PLAIN, settings.textSize));
        preview.setForeground(Colors.TEXT_HEAD);
        preview.setBorder(BorderFactory.createEmptyBorder(10, 0, 4, 0));

        p.add(sliderRow("Scene text size", 12, 26, settings.textSize, v -> {
            settings.textSize = v;
            preview.setFont(new Font(settings.fontFamily, Font.PLAIN, v));
        }, "pt"));
        p.add(Box.createVerticalStrut(12));
        p.add(sliderRow("Choice button size", 11, 22, settings.choiceSize,
            v -> settings.choiceSize = v, "pt"));
        preview.setForeground(Colors.TEXT_DIM);
        preview.setBackground(new Color(30,30,42));
        preview.setBorder(BorderFactory.createEmptyBorder(10,20,10,20));
        preview.setFocusPainted(false);
        p.add(Box.createVerticalStrut(8));
        p.add(preview);

        return p;
    }


    // ── Font section ──────────────────────────────────────────────────────────

    private static final String[][] FONTS = {
        {"SansSerif",    "Sans-serif  (default)",          "The quick brown fox. Clean and neutral."},
        {"Serif",        "Serif  (book-like)",              "The quick brown fox. Feels like a novel."},
        {"Monospaced",   "Monospaced  (terminal)",          "The quick brown fox. Even character spacing."},
        {"Georgia",      "Georgia  (elegant serif)",        "The quick brown fox. Warm and readable."},
        {"Palatino",     "Palatino Linotype  (classic)",    "The quick brown fox. Traditional elegance."},
        {"Garamond",     "Garamond  (literary)",            "The quick brown fox. Old-world print feel."},
        {"Verdana",      "Verdana  (screen-optimised)",     "The quick brown fox. Wide and very clear."},
        {"Tahoma",       "Tahoma  (compact)",               "The quick brown fox. Compact, professional."},
        {"Trebuchet MS", "Trebuchet MS  (humanist)",        "The quick brown fox. Friendly and legible."},
        {"Courier New",  "Courier New  (typewriter)",       "The quick brown fox. Like a typed letter."},
        {"Calibri",      "Calibri  (modern sans)",          "The quick brown fox. Clean Microsoft style."},
    };

    private JPanel buildFontSection() {
        JPanel p = card();

        p.add(hintLabel("Choose a font for scene text. If a font isn't installed on your system it falls back to Sans-serif."));
        p.add(Box.createVerticalStrut(10));

        // Scene font picker
        p.add(label("Scene Text Font", Colors.TEXT_HEAD, true));
        p.add(Box.createVerticalStrut(6));
        p.add(buildFontPicker(settings.fontFamily, font -> {
            settings.fontFamily = font;
        }));
        p.add(Box.createVerticalStrut(16));

        // Choice button font picker
        p.add(label("Choice Button Font", Colors.TEXT_HEAD, true));
        p.add(Box.createVerticalStrut(6));
        p.add(buildFontPicker(settings.choiceFont, font -> {
            settings.choiceFont = font;
        }));

        return p;
    }

    private JPanel buildFontPicker(String currentFont, java.util.function.Consumer<String> setter) {
        JPanel container = new JPanel();
        container.setOpaque(false);
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));

        // Preview label — updates when selection changes
        JLabel preview = new JLabel("The quick brown fox. Bright evening, open window.");
        preview.setFont(new java.awt.Font(currentFont, java.awt.Font.PLAIN, settings.textSize));
        preview.setForeground(Colors.TEXT_HEAD);
        preview.setBorder(BorderFactory.createEmptyBorder(8, 0, 12, 0));

        // Button group for font options
        ButtonGroup group = new ButtonGroup();
        JPanel btnPanel = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 6, 4));
        btnPanel.setOpaque(false);

        for (String[] font : FONTS) {
            String familyName = font[0];
            String displayName = font[1];
            String sampleText  = font[2];

            // Check if font is available
            boolean available = isFontAvailable(familyName);
            if (!available) continue;

            JToggleButton tb = new JToggleButton(displayName.split("  ")[0]);
            tb.setFont(new java.awt.Font(familyName, java.awt.Font.PLAIN, 12));
            tb.setForeground(currentFont.equals(familyName) ? Color.WHITE : Colors.TEXT_DIM);
            tb.setBackground(currentFont.equals(familyName) ? new Color(55,80,110) : new Color(30,30,44));
            tb.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(50,60,80), 1),
                BorderFactory.createEmptyBorder(5,12,5,12)));
            tb.setFocusPainted(false);
            tb.setSelected(currentFont.equals(familyName));
            tb.setToolTipText("<html><b>" + displayName + "</b><br><i>" + sampleText + "</i></html>");

            tb.addActionListener(e -> {
                setter.accept(familyName);
                preview.setFont(new java.awt.Font(familyName, java.awt.Font.PLAIN, settings.textSize));
                // Update button colours
                for (java.awt.Component c : btnPanel.getComponents()) {
                    if (c instanceof JToggleButton) {
                        JToggleButton b = (JToggleButton) c;
                        boolean sel = b.isSelected();
                        b.setForeground(sel ? Color.WHITE : Colors.TEXT_DIM);
                        b.setBackground(sel ? new Color(55,80,110) : new Color(30,30,44));
                    }
                }
            });

            group.add(tb);
            btnPanel.add(tb);
        }

        container.add(btnPanel);
        container.add(preview);
        return container;
    }

    /** True if a font family name is available on this system. */
    private boolean isFontAvailable(String name) {
        // Java logical fonts are always available
        if (name.equals("SansSerif") || name.equals("Serif") || name.equals("Monospaced")) return true;
        // Check against installed fonts
        String[] available = java.awt.GraphicsEnvironment
            .getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
        for (String a : available) if (a.equalsIgnoreCase(name)) return true;
        return false;
    }

    // ── Difficulty section ─────────────────────────────────────────────────────

    private JPanel buildDifficultySection() {
        JPanel p = card();

        // Slut rep multiplier — discrete steps
        p.add(label("Slut Rep Gain", Colors.TEXT_HEAD, true));
        p.add(hintLabel("How quickly your reputation grows from exhibitionist choices."));
        p.add(Box.createVerticalStrut(6));
        JPanel slutBtns = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        slutBtns.setOpaque(false);
        for (float[] opt : new float[][]{{1f},{2f},{4f}}) {
            String lbl = opt[0] == 4 ? "×4 Ultra Easy" : opt[0] == 2 ? "×2 Easy" : "×1 Normal";
            JToggleButton tb = toggleBtn(lbl, settings.slutRepMultiplier == opt[0]);
            float val = opt[0];
            tb.addActionListener(e -> settings.slutRepMultiplier = val);
            slutBtns.add(tb);
        }
        p.add(slutBtns);
        p.add(Box.createVerticalStrut(16));

        // Willpower drain
        p.add(label("Willpower Drain", Colors.TEXT_HEAD, true));
        p.add(hintLabel("Multiplier on negative willpower changes. 0.5× = half the drain."));
        p.add(Box.createVerticalStrut(6));
        JPanel wpBtns = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        wpBtns.setOpaque(false);
        for (float[] opt : new float[][]{{0.5f},{1f},{1.5f}}) {
            String lbl = opt[0] < 1 ? "×0.5 Reduced" : opt[0] > 1 ? "×1.5 Harder" : "×1 Normal";
            JToggleButton tb = toggleBtn(lbl, settings.willpowerDrainMult == opt[0]);
            float val = opt[0];
            tb.addActionListener(e -> settings.willpowerDrainMult = val);
            wpBtns.add(tb);
        }
        p.add(wpBtns);
        p.add(Box.createVerticalStrut(16));

        // Stress multiplier
        p.add(label("Stress Gain", Colors.TEXT_HEAD, true));
        p.add(hintLabel("Multiplier on positive stress changes. 0.5× = half the stress."));
        p.add(Box.createVerticalStrut(6));
        JPanel stressBtns = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        stressBtns.setOpaque(false);
        for (float[] opt : new float[][]{{0.5f},{1f},{1.5f}}) {
            String lbl = opt[0] < 1 ? "×0.5 Reduced" : opt[0] > 1 ? "×1.5 Harder" : "×1 Normal";
            JToggleButton tb = toggleBtn(lbl, settings.stressMult == opt[0]);
            float val = opt[0];
            tb.addActionListener(e -> settings.stressMult = val);
            stressBtns.add(tb);
        }
        p.add(stressBtns);
        return p;
    }

    // ── Key binding section ────────────────────────────────────────────────────

    private JPanel buildKeyBindSection() {
        JPanel p = card();
        p.add(hintLabel("Click a key field, then press the key you want to bind. Ctrl/Shift combos not supported."));
        p.add(Box.createVerticalStrut(10));

        p.add(keyBindRow("Escape / Pause menu",   settings.keyEscape,   v -> settings.keyEscape   = v));
        p.add(keyBindRow("Open outfit panel  [O]", settings.keyOutfit,  v -> settings.keyOutfit   = v));
        p.add(keyBindRow("Quick save         [Ctrl+S]", settings.keySave, v -> settings.keySave   = v));
        p.add(keyBindRow("Settings           [Ctrl+,]", settings.keySettings, v -> settings.keySettings = v));

        JButton resetBinds = new JButton("Reset to defaults");
        resetBinds.setFont(Colors.SANS_SMALL);
        resetBinds.setForeground(new Color(180,100,100));
        resetBinds.setBackground(new Color(40,25,25));
        resetBinds.setBorder(BorderFactory.createEmptyBorder(6,16,6,16));
        resetBinds.setFocusPainted(false);
        resetBinds.addActionListener(e -> {
            settings.keyEscape   = KeyEvent.VK_ESCAPE;
            settings.keyOutfit   = KeyEvent.VK_O;
            settings.keySave     = KeyEvent.VK_S;
            settings.keySettings = KeyEvent.VK_COMMA;
            rebuild();
        });
        p.add(Box.createVerticalStrut(10));
        p.add(resetBinds);
        return p;
    }

    private JPanel keyBindRow(String action, int currentKey, Consumer<Integer> setter) {
        JPanel row = new JPanel(new BorderLayout(16,0));
        row.setOpaque(false);
        row.setBorder(BorderFactory.createEmptyBorder(0,0,8,0));

        JLabel actionLbl = new JLabel(action);
        actionLbl.setFont(Colors.LABEL);
        actionLbl.setForeground(Colors.TEXT_DIM);
        actionLbl.setPreferredSize(new Dimension(220,22));

        JTextField keyField = new JTextField(KeyEvent.getKeyText(currentKey));
        keyField.setFont(new Font("SansSerif", Font.BOLD, 13));
        keyField.setForeground(Colors.TEXT_HEAD);
        keyField.setBackground(new Color(30,30,42));
        keyField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(55,55,75),1),
            BorderFactory.createEmptyBorder(4,10,4,10)));
        keyField.setEditable(false);
        keyField.setPreferredSize(new Dimension(120, 30));
        keyField.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { keyField.requestFocus(); }
        });
        keyField.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                int code = e.getKeyCode();
                if (code == KeyEvent.VK_UNDEFINED) return;
                setter.accept(code);
                keyField.setText(KeyEvent.getKeyText(code));
                keyField.transferFocus();
            }
        });

        row.add(actionLbl, BorderLayout.WEST);
        row.add(keyField,  BorderLayout.EAST);
        return row;
    }

    // ── Display options ────────────────────────────────────────────────────────

    private JPanel buildDisplaySection() {
        JPanel p = card();
        p.add(checkRow("Show cycle phase in day planner header", settings.showCycleInHeader, v -> settings.showCycleInHeader = v));
        p.add(checkRow("Show money & rent in day planner header", settings.showMoneyInHeader, v -> settings.showMoneyInHeader = v));
        return p;
    }

    // ── Accessibility section ──────────────────────────────────────────────────

    private JPanel buildAccessibilitySection() {
        JPanel p = card();
        p.add(checkRow("High contrast text", settings.highContrast, v -> settings.highContrast = v));
        p.add(checkRow("Reduce UI animations", settings.reduceAnimations, v -> settings.reduceAnimations = v));
        return p;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void rebuild() {
        removeAll(); build(); revalidate(); repaint();
    }

    private JPanel sliderRow(String name, int min, int max, int cur, Consumer<Integer> setter, String unit) {
        JPanel p = new JPanel(); p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
        JLabel nameLbl = new JLabel(name + ":  "); nameLbl.setForeground(Colors.TEXT_DIM); nameLbl.setFont(Colors.LABEL);
        JLabel valLbl = new JLabel(cur + unit + " "); valLbl.setForeground(Colors.TEXT_HEAD); valLbl.setFont(Colors.LABEL);
        valLbl.setPreferredSize(new Dimension(48,20));
        JSlider sl = new JSlider(min, max, cur);
        sl.setOpaque(false);
        sl.addChangeListener(e -> { setter.accept(sl.getValue()); valLbl.setText(sl.getValue()+unit+" "); });
        p.add(nameLbl); p.add(sl); p.add(valLbl);
        return p;
    }

    private JPanel checkRow(String text, boolean cur, Consumer<Boolean> setter) {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false); p.setBorder(BorderFactory.createEmptyBorder(0,0,8,0));
        JCheckBox cb = new JCheckBox(text, cur);
        cb.setForeground(Colors.TEXT_DIM); cb.setBackground(Colors.BG);
        cb.setFont(Colors.LABEL); cb.setFocusPainted(false);
        cb.addActionListener(e -> setter.accept(cb.isSelected()));
        p.add(cb, BorderLayout.WEST);
        return p;
    }

    private JToggleButton toggleBtn(String text, boolean selected) {
        JToggleButton tb = new JToggleButton(text, selected);
        tb.setFont(Colors.SANS_SMALL);
        tb.setForeground(selected ? Color.WHITE : Colors.TEXT_DIM);
        tb.setBackground(selected ? new Color(60,90,60) : new Color(35,35,48));
        tb.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(60,80,60),1),
            BorderFactory.createEmptyBorder(5,14,5,14)));
        tb.setFocusPainted(false);
        tb.addChangeListener(e -> {
            tb.setForeground(tb.isSelected() ? Color.WHITE : Colors.TEXT_DIM);
            tb.setBackground(tb.isSelected() ? new Color(60,90,60) : new Color(35,35,48));
        });
        return tb;
    }

    private JPanel card() {
        JPanel p = new JPanel(); p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(4,0,0,0));
        return p;
    }

    private JLabel sectionHeader(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("SansSerif", Font.BOLD, 11));
        l.setForeground(new Color(90,90,110));
        l.setBorder(BorderFactory.createEmptyBorder(0,0,8,0));
        return l;
    }

    private JLabel label(String text, Color color, boolean bold) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("SansSerif", bold ? Font.BOLD : Font.PLAIN, 14));
        l.setForeground(color);
        return l;
    }

    private JLabel hintLabel(String text) {
        JLabel l = new JLabel("<html>" + text + "</html>");
        l.setFont(Colors.SANS_SMALL); l.setForeground(Colors.TEXT_DIM);
        return l;
    }
}
