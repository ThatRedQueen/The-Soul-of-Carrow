package game.ui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

/**
 * In-game escape / pause menu.
 * Triggered by Escape key during gameplay.
 * Options: Resume, Save, Load, Settings, Main Menu, Quit.
 */
public class EscapeMenuPanel extends JPanel {

    public interface EscapeActions {
        void resume();
        void showSave();
        void showLoad();
        void showSettings();
        void showMainMenu();
        void quitGame();
    }

    private final EscapeActions actions;

    public EscapeMenuPanel(EscapeActions actions) {
        this.actions = actions;
        setBackground(new Color(10, 10, 16, 220)); // semi-transparent
        setLayout(new GridBagLayout());
        build();
    }

    private void build() {
        JPanel dialog = new JPanel();
        dialog.setBackground(new Color(20, 20, 30));
        dialog.setLayout(new BoxLayout(dialog, BoxLayout.Y_AXIS));
        dialog.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(55, 55, 75), 1),
            BorderFactory.createEmptyBorder(32, 48, 32, 48)));

        JLabel title = new JLabel("Paused");
        title.setFont(new Font("SansSerif", Font.BOLD, 28));
        title.setForeground(Colors.TEXT_HEAD);
        title.setAlignmentX(CENTER_ALIGNMENT);

        dialog.add(title);
        dialog.add(Box.createVerticalStrut(28));

        dialog.add(menuBtn("▶  Resume",          new Color(80, 200, 120), e -> actions.resume()));
        dialog.add(Box.createVerticalStrut(10));
        dialog.add(menuBtn("💾  Save Game",        Colors.TEXT_HEAD,        e -> actions.showSave()));
        dialog.add(Box.createVerticalStrut(10));
        dialog.add(menuBtn("↺  Load Game",         Colors.TEXT_DIM,         e -> actions.showLoad()));
        dialog.add(Box.createVerticalStrut(10));
        dialog.add(menuBtn("⚙  Settings",          Colors.TEXT_DIM,         e -> actions.showSettings()));
        dialog.add(Box.createVerticalStrut(20));

        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(45, 45, 60));
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        dialog.add(sep);
        dialog.add(Box.createVerticalStrut(20));

        dialog.add(menuBtn("⌂  Main Menu",         new Color(180, 140, 60),  e -> {
            int c = JOptionPane.showConfirmDialog(this,
                "Return to main menu? Unsaved progress will be lost.",
                "Main Menu", JOptionPane.YES_NO_OPTION);
            if (c == JOptionPane.YES_OPTION) actions.showMainMenu();
        }));
        dialog.add(Box.createVerticalStrut(10));
        dialog.add(menuBtn("✕  Quit to Desktop",   new Color(200, 70, 70),   e -> {
            int c = JOptionPane.showConfirmDialog(this,
                "Quit the game? Unsaved progress will be lost.",
                "Quit", JOptionPane.YES_NO_OPTION);
            if (c == JOptionPane.YES_OPTION) actions.quitGame();
        }));

        add(dialog);
    }

    private JButton menuBtn(String text, Color fg, java.awt.event.ActionListener al) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 16));
        btn.setForeground(fg);
        btn.setBackground(new Color(30, 30, 44));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(50, 50, 68), 1),
            BorderFactory.createEmptyBorder(10, 28, 10, 28)));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setAlignmentX(CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(260, 46));
        btn.addActionListener(al);
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            final Color base = btn.getBackground();
            @Override public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(new Color(44,44,60)); }
            @Override public void mouseExited (java.awt.event.MouseEvent e) { btn.setBackground(base); }
        });
        return btn;
    }
}
