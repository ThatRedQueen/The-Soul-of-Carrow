# Job Index
Every job in the game. All IDs match across `jobs/`, `interviews/`, and `scenes/work/`.
To add a new job: drop `jobs/yourjob.yml` + `interviews/yourjob.yml` + `scenes/work/yourjob/`.

## bar_staff
**Label:** Bar Staff
**Pay:** $90/day (weekly)
**Days:** THU, FRI, SAT, SUN
**Boss NPC:** none
**Interview:** interviews/bar_staff.yml
**Work scenes:** bar_staff_awkward_patron.yml, bar_staff_friday_night.yml, bar_staff_regular_patron.yml, bar_staff_slow_tuesday.yml, bar_staff_staff_meeting.yml

## bookshop
**Label:** Second Shelf Books — Assistant
**Pay:** $60/day (weekly)
**Days:** MON, WED, FRI, SAT, SUN
**Boss NPC:** eli_b
**Interview:** interviews/bookshop.yml
**Work scenes:** bookshop_difficult_customer.yml, bookshop_eli_b_recommendation.yml, bookshop_saturday_rush.yml, bookshop_slow_morning.yml, bookshop_stock_day.yml

## cafe
**Label:** Café Staff
**Pay:** $70/day (weekly)
**Days:** WED, THU, FRI, SAT, SUN
**Boss NPC:** none
**Interview:** interviews/cafe.yml
**Work scenes:** cafe_coworker_chat.yml, cafe_difficult_order.yml, cafe_equipment_problem.yml, cafe_morning_rush.yml, cafe_regular_patron.yml

## cafe_morning
**Label:** Corner Café — Morning Barista
**Pay:** $65/day (weekly)
**Days:** MON, TUE, WED, THU, FRI
**Boss NPC:** freya
**Interview:** interviews/cafe_morning.yml
**Work scenes:** cafe_morning_scenes.yml

## library
**Label:** City Library — Assistant
**Pay:** $65/day (weekly)
**Days:** MON, TUE, WED, THU, FRI
**Boss NPC:** grace
**Interview:** interviews/library.yml
**Work scenes:** library_difficult_patron.yml, library_find_rare_book.yml, library_grace_chat.yml, library_quiet_hour.yml, library_school_visit.yml

## neon_fitness
**Label:** Neon Fitness — Front Desk
**Pay:** $85/day (weekly)
**Days:** MON, WED, FRI, SAT
**Boss NPC:** jake
**Interview:** interviews/neon_fitness.yml
**Work scenes:** cam_vents.yml, cover_shift.yml, equipment_mishap.yml, jake_feedback.yml, medical_scare.yml, member_asks_number.yml, member_complaint.yml

## office_admin
**Label:** Office Administrator
**Pay:** $110/day (weekly)
**Days:** MON, TUE, WED, THU, FRI
**Boss NPC:** none
**Interview:** interviews/office_admin.yml
**Work scenes:** office_admin_helen_chat.yml, office_admin_inbox.yml, office_admin_nina_project.yml, office_admin_scenes.yml, office_admin_scheduling_crisis.yml

## restaurant_kitchen
**Label:** Kitchen Hand — Restaurant
**Pay:** $80/day (weekly)
**Days:** WED, THU, FRI, SAT, SUN
**Boss NPC:** antonio
**Interview:** interviews/restaurant_kitchen.yml
**Work scenes:** kitchen_after_service.yml, kitchen_antonio_teaches.yml, kitchen_dinner_rush.yml, kitchen_food_waste.yml, restaurant_kitchen_scenes.yml

## retail
**Label:** Retail Worker
**Pay:** $80/day (weekly)
**Days:** MON, TUE, WED, THU, FRI
**Boss NPC:** none
**Interview:** interviews/retail.yml
**Work scenes:** retail_awkward_coworker.yml, retail_difficult_return.yml, retail_end_of_day.yml, retail_inventory.yml, retail_saturday.yml

## skyline_office
**Label:** Skyline Solutions — Admin Assistant
**Pay:** $130/day (weekly)
**Days:** MON, TUE, WED, THU, FRI
**Boss NPC:** richard
**Interview:** interviews/skyline_office.yml
**Work scenes:** ancient_employee_whiteout.yml, coworker_chat.yml, dev_confession.yml, dev_confession_b.yml, office_birthday.yml, printer_incident.yml, richard_expectant.yml, richard_expectant_cold.yml, richard_visit.yml, stay_late.yml

## tattoo_studio
**Label:** Ink & Bone — Studio Receptionist
**Pay:** $70/day (weekly)
**Days:** TUE, WED, THU, FRI, SAT
**Boss NPC:** violet
**Interview:** interviews/tattoo_studio.yml
**Work scenes:** tattoo_studio_consultation.yml, tattoo_studio_end_of_day.yml, tattoo_studio_nervous_client.yml, tattoo_studio_quiet_day.yml, tattoo_studio_violet_shows_work.yml

## velvet_cafe
**Label:** Velvet Café — Barista
**Pay:** $75/day (weekly)
**Days:** TUE, WED, THU, FRI, SAT
**Boss NPC:** sofia
**Interview:** interviews/velvet_cafe.yml
**Work scenes:** closing_shift.yml, coworker_chat.yml, equipment_mishap.yml, regular_customer.yml, rush_hour.yml, slow_morning.yml, walkout.yml

