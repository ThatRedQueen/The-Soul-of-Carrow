# Housing Properties

Each file is one rentable property. All fields are data — no hardcoding needed to add a new property.

To add a new property:
1. Drop a `.yml` here following the format below
2. Add a choice to `scenes/main/housing.yml` using `add_traits: [_set_housing_{landlord_npc}_{rent}]`
3. Create a move-in scene matching `move_in_scene:` value

## Properties by Neighbourhood

### Thornwick
- **respectable_studio_1200** — Studio — $1,200/month  |  Small, well-maintained, quiet building
  - Landlord: `landlord_1bed` | WP cap: 85 | WP recovery: +25 | Stress floor: 2
- **respectable_1bed_1600** — 1-Bedroom — $1,600/month  |  Proper apartment, nice street
  - Landlord: `landlord_1bed` | WP cap: 90 | WP recovery: +35 | Stress floor: 0
- **respectable_1bed_1900** — Premium 1-Bedroom — $1,900/month  |  Top floor, best building on the street
  - Landlord: `landlord_1bed` | WP cap: 90 | WP recovery: +35 | Stress floor: 0

### Millgate
- **middle_shared_550** — Shared House — $550/month  |  Three roommates, cheaper, social
  - Landlord: `landlord_shared_house` | WP cap: 80 | WP recovery: +20 | Stress floor: 3
- **middle_studio_750** — Studio — $750/month  |  Decent block, yours alone
  - Landlord: `landlord_shared_house` | WP cap: 85 | WP recovery: +25 | Stress floor: 2
- **middle_1bed_1100** — 1-Bedroom — $1,100/month  |  Nice enough building, quiet street
  - Landlord: `landlord_shared_house` | WP cap: 90 | WP recovery: +35 | Stress floor: 0

### The Narrows
- **rough_basement_350** — Basement Suite — $350/month  |  Below street level, damp
  - Landlord: `landlord_studio` | WP cap: 75 | WP recovery: +15 | Stress floor: 5
- **rough_shared_400** — Shared House — $400/month  |  A few others, you don't know them yet
  - Landlord: `landlord_studio` | WP cap: 80 | WP recovery: +20 | Stress floor: 3
- **rough_studio_550** — Studio — $550/month  |  Small, yours alone, sketchy block
  - Landlord: `landlord_studio` | WP cap: 85 | WP recovery: +25 | Stress floor: 2
- **rough_house_700** — Beaten-Down Terrace — $700/month  |  Whole house, terrible condition
  - Landlord: `landlord_studio` | WP cap: 95 | WP recovery: +40 | Stress floor: 0
- **rough_1bed_750** — 1-Bedroom — $750/month  |  Best you'll get at this end of town
  - Landlord: `landlord_studio` | WP cap: 90 | WP recovery: +35 | Stress floor: 0

### The Lanes
- **slums_basement_175** — Basement Suite — $175/month  |  No windows. Genuinely grim.
  - Landlord: `landlord_basement` | WP cap: 75 | WP recovery: +15 | Stress floor: 5
- **slums_shared_250** — Shared House — $250/month  |  Four or more roommates, you don't know them
  - Landlord: `landlord_basement` | WP cap: 80 | WP recovery: +20 | Stress floor: 3
- **slums_studio_400** — Studio — $400/month  |  Bare minimum, rough street
  - Landlord: `landlord_basement` | WP cap: 85 | WP recovery: +25 | Stress floor: 2
- **slums_house_500** — Derelict House — $500/month  |  Three rooms, falling apart, truly cheap
  - Landlord: `landlord_basement` | WP cap: 95 | WP recovery: +40 | Stress floor: 0
- **slums_1bed_600** — 1-Bedroom — $600/month  |  Best of a bad situation
  - Landlord: `landlord_basement` | WP cap: 90 | WP recovery: +35 | Stress floor: 0

## Fields Reference

```yaml
id:                  # unique ID, matches filename
label:               # shown in housing menu
landlord_npc:        # NPC id from npcs/
rent:                # monthly rent in game currency
unit_type:           # basement / shared / studio / 1bed / house
neighbourhood:       # display name
neighbourhood_trait: # trait added to player (neighbourhood_respectable etc)
unit_trait:          # trait added to player (lives_studio etc)
stat_changes:        # happiness/confidence applied on move-in
willpower_cap:       # max willpower while living here
willpower_recovery:  # willpower gained per sleep
stress_min:          # stress never drops below this
stress_reduction:    # stress removed each new day
move_in_scene:       # scene ID to play when moving in
```
