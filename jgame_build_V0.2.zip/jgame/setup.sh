#!/bin/bash
echo "Checking dependencies..."

if ! command -v java &> /dev/null; then
    echo "Java not found. Installing..."
    sudo apt install -y default-jdk
fi

JAR="lib/snakeyaml-2.2.jar"
if [ ! -f "$JAR" ]; then
    echo "Downloading SnakeYAML..."
    wget -q -O "$JAR" "https://repo1.maven.org/maven2/org/yaml/snakeyaml/2.2/snakeyaml-2.2.jar"
    [ $? -eq 0 ] && echo "Done." || { echo "Download failed."; exit 1; }
else
    echo "SnakeYAML already present."
fi

echo "Setup complete. Run ./compile.sh next."
