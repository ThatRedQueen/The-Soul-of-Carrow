# Soul of Carrow — Project Structure

## Finding Things

| System        | Definition files              | Content files                    | Add new by...                          |
|---------------|-------------------------------|----------------------------------|----------------------------------------|
| **Jobs**      | `jobs/{id}.yml`               | `interviews/{id}.yml`            | Drop files in both folders             |
|               | `jobs/JOB_INDEX.md`           | `scenes/work/{id}/`              | + folder in `scenes/work/`             |
|               | `jobs/_TEMPLATE.yml`          | `interviews/_TEMPLATE.yml`       |                                        |
| **Clothing**  | `clothes/{item}.yml`          | —                                | Drop `.yml` anywhere in `clothes/`     |
|               | `clothes/CLOTHING_INDEX.md`   | `clothes/shop/` = buyable        | Loader is recursive, picks it up auto  |
| **Housing**   | `scenes/main/housing*.yml`    | `npcs/landlord_*.yml`            | See `scenes/main/HOUSING_INDEX.md`     |
| **NPCs**      | `npcs/{id}.yml`               | —                                | Drop `.yml` in `npcs/`                 |
| **Scenes**    | `scenes/main/` etc.           | —                                | Drop `.yml` anywhere in `scenes/`      |
| **Activities**| `activities/{id}.yml`         | —                                | Drop `.yml` in `activities/`           |

## Folder Map

```
jobs/               ← job definitions (pay, days, boss NPC)
  JOB_INDEX.md      ← human index of all jobs
  _TEMPLATE.yml     ← copy this to add a job
interviews/         ← interview Q&A for each job (filename = job id)
  _TEMPLATE.yml     ← copy this to add an interview
scenes/
  main/             ← core game scenes (home, housing, shop, etc.)
    HOUSING_INDEX.md
  work/
    bar_staff/      ← work scenes per job (folder name = job id)
    skyline_office/
    velvet_cafe/
    ... etc
clothes/
  CLOTHING_INDEX.md
  shop/             ← purchasable items
  starting/         ← items player starts with
  *.yml             ← other items (gifted, found, etc.)
npcs/               ← all NPCs (landlords, bosses, coworkers, bar NPCs)
activities/         ← activities available from home/city menus
gamedata/
  traits.yml        ← all MC traits and their effects
src/                ← Java source (engine, loaders, UI)
```

## What's Hardcoded vs Data-Driven

- ✓ **Jobs** — fully data-driven, drop files to add
- ✓ **Clothing** — fully data-driven, recursive folder scan
- ✓ **NPCs** — fully data-driven
- ✓ **Scenes** — fully data-driven, recursive folder scan
- ✓ **Activities** — fully data-driven
- ⚠ **Housing** — mostly scene-driven but `_set_housing_` format is parsed in Engine.java
- ✓ **Raises** — `_apply_raise_N` trait in any scene; persists in save, resets on quit
- ✓ **Seasons** — `gamedata/seasons.yml` (add/rename seasons without touching Java)
