# Mod Assets Guide — The Soul of Carrow

Mods can supply images, sprites, and animated GIFs that display in scenes
and the stats sidebar. No coding required — declare assets in `mod.yml`
and reference them from your scene YAML.

---

## Quick start

```
my_mod/
├── mod.yml            ← required: mod metadata + asset declarations
├── sidebar.yml        ← optional: customize the stats sidebar
├── images/
│   ├── bar_at_night.png
│   ├── portrait.png
│   └── rain_loop.gif
└── scenes/
    └── my_scene.yml
```

---

## 1. Declaring assets in mod.yml

```yaml
id:      my_mod
name:    My Mod
author:  You
version: 1.0.0

# Declare every image/animation the mod provides
assets:
  bar_night_img:   images/bar_at_night.png
  mc_portrait:     images/portrait.png
  rain_loop:       images/rain_loop.gif
  sidebar_bg:      images/sidebar_background.png
```

**Supported formats:** PNG · JPG/JPEG · GIF (animated GIFs work)  
**Path:** relative to your mod's folder  
**Size limits:** Scene images are capped at 800×400 px (auto-scaled).
Sidebar portraits cap at 200×280 px. Sidebar backgrounds cap at 240×600 px.

---

## 2. Adding an image to a scene

In your scene YAML, add `image:` with the asset ID:

```yaml
id: my_bar_scene
text: |
  The bar is warm. Music from the speakers. A drink in your hand.

image: bar_night_img           # asset ID from mod.yml
image_position: top            # top (default) | left | right
image_height: 200              # optional: cap height in pixels
choices:
  - text: Order another.
    next: my_bar_scene_2
```

The image appears above the scene text and is replaced automatically
when the player moves to a different scene.

### image_position values
| Value  | Behaviour |
|--------|-----------|
| `top`  | Image spans the full width above the text *(default)* |
| `left` | Reserved for future use — currently same as `top` |
| `right`| Reserved for future use — currently same as `top` |

---

## 3. Customizing the sidebar (sidebar.yml)

Create `sidebar.yml` in your mod's root to change how the stats panel looks:

```yaml
# sidebar.yml

# Character portrait shown at the top of the stats sidebar
portrait_asset: mc_portrait

# Full-panel background image behind the sidebar
background_asset: sidebar_bg

# Accent color for section headers (hex color)
accent_color: "#8866cc"

# Make the sidebar semi-transparent (requires background_asset)
transparent: true
```

All fields are optional. Last mod loaded wins (mods loaded alphabetically).

---

## 4. Animated GIFs

Animated GIFs work out of the box. Declare them exactly like static images:

```yaml
assets:
  rain_loop: images/rain_loop.gif
```

Then reference in a scene:
```yaml
image: rain_loop
```

The animation plays in a loop while the scene is active and stops when the
player moves to a scene that has no image or a different image.

---

## 5. Mod folder structure reference

```
my_mod/
├── mod.yml                  ← metadata + asset declarations (required)
├── sidebar.yml              ← sidebar customization (optional)
├── images/                  ← your image files (any subdirectory layout works)
│   ├── portraits/
│   │   └── mc.png
│   ├── backgrounds/
│   │   ├── bar.png
│   │   └── home.jpg
│   └── animations/
│       └── rain.gif
├── scenes/                  ← scene YAML files (optional)
├── npcs/                    ← NPC YAML files (optional)
├── clothes/                 ← clothing YAML files (optional)
└── jobs/                    ← job YAML files (optional)
```

---

## 6. Asset ID namespacing

Every asset is registered under both its bare ID and a namespaced version:

- Bare: `bar_night_img`  
- Namespaced: `my_mod:bar_night_img`

If two mods declare the same bare ID, the last-loaded mod wins. Use
namespaced IDs in your scenes to guarantee you get your mod's version:

```yaml
image: my_mod:bar_night_img
```

---

## 7. Error handling

- Missing files produce a warning in `mod_errors.log` — the scene renders without the image.
- Unsupported formats are rejected with a warning.
- Path traversal attempts (`../`) are blocked silently.
- The game never crashes due to a missing or broken asset.


---

For artwork hooks, text pools, soundtrack packs, and modpacks, see **MOD_FULL_GUIDE.md**.
