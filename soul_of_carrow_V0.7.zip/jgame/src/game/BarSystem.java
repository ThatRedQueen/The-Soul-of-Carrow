package game;

import game.TextPoolRegistry;
import game.data.NpcData;
import game.data.SceneData;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Manages the bar scene NPC pool.
 *
 * On bar entry: picks 4-6 men and 2-4 women from eligible NPCs (graceful
 * degradation if pool is smaller than target — uses whatever is available).
 *
 * Provides:
 *   - buildRoomDescription()   → formatted text of who's present
 *   - buildEyeContactChoices() → one ChoiceData per NPC, injected into bar scene
 */
public class BarSystem {

    private final NpcMomentPools pools;

    /**
     * Registers this system's text tokens into the shared handler map.
     * Called once by Engine at construction.
     * To add a new token: add a build*() method and one line here.
     */
    public void registerTokens(java.util.Map<String,java.util.function.Supplier<String>> m) {
        m.put("{bar_npc_list}", this::buildRoomDescription);
        m.put("{bar_approach_text}", this::buildApproachText);
        m.put("{npc_order_text}", this::buildNpcOrderText);
        m.put("{bar_dance_text}", this::buildDanceText);
        m.put("{bar_sexy_dance_text}", this::buildSexyDanceText);
        m.put("{bar_dance_moment_text}", this::buildDanceMomentText);
        m.put("{bar_handsy_text}", this::buildHandsyText);
        m.put("{bar_ass_grope_text}", this::buildAssGropeText);
        m.put("{bar_dirty_whisper_text}", this::buildDirtyWhisperText);
        m.put("{bar_kiss_text}", this::buildKissText);
        m.put("{bar_neck_kiss_text}", this::buildNeckKissText);
        m.put("{bar_breast_grope_text}", this::buildBreastGropeText);
        m.put("{morning_after_text}", this::buildMorningAfterText);
        m.put("{morning_mirror_check_text}", this::buildMorningMirrorCheck);
        m.put("{bar_alcoholic_cant_refuse_text}", this::buildAlcoholicCantRefuseText);
        m.put("{bar_drink_refusal_text}", this::buildDrinkRefusalText);
        m.put("{bar_home_arrival_text}", this::buildHomeArrivalText);
        m.put("{bar_home_invite_in_text}", this::buildHomeInviteInText);
        m.put("{bar_home_goodnight_text}", this::buildHomeGoodnightText);
        m.put("{bar_home_swap_goodnight_text}", this::buildHomeSwapGoodnightText);
        m.put("{bar_hickey_text}", this::buildHickeyAttemptText);
        m.put("{bar_pool_text}", this::buildPoolText);
        m.put("{bar_pool_moment_text}", this::buildPoolMomentText);
        m.put("{bar_bathroom_text}", this::buildBathroomText);
        m.put("{bar_other_patron_text}", this::buildOtherPatronText);
        m.put("{bar_pre_dance_text}", this::buildPreDanceText);
        m.put("{bar_song_change_text}", this::buildSongChangeText);
        m.put("{mall_flash_witness_text}", this::buildMallFlashWitnessText);
        m.put("{mc_refusing_thought}", this::buildRefusingInternalThought);
        m.put("{mall_flash_mc_thought_text}", this::buildMallFlashMcThoughtText);
        m.put("{mall_flash_mc_does_it_text}", this::buildMallFlashMcDoesItText);
        m.put("{bar_feel_him_up_text}", this::buildFeelHimUpText);
        m.put("{bar_pussy_grope_text}", this::buildPussyGropeText);
        m.put("{bar_fingering_text}", this::buildFingeringText);
        m.put("{bar_fingering_continues_text}", this::buildFingeringContinuesText);
        m.put("{bar_bystander_reaction_text}", this::buildBystanderReactionText);
        m.put("{bar_top_lift_text}", this::buildTopLiftText);
        m.put("{bar_grope_shirt_up_text}", this::buildGropeShirtUpText);
        m.put("{bar_mc_pulls_down_text}", this::buildMcPullsDownText);
        m.put("{bar_breast_to_pussy_text}", this::buildBreastToPussyTransitionText);
        m.put("{bar_full_escalation_text}", this::buildFullEscalationText);
        m.put("{bar_fingering_orgasm_text}", this::buildFingeringToOrgasmText);
        m.put("{bar_says_stop_cums_text}", this::buildMcSaysStopCumsText);
        m.put("{bar_hickey_persist_text}", this::buildHickeyPersistText);
        m.put("{bar_hickey_mark_left_text}", this::buildHickeyMarkLeftText);
        m.put("{bar_hickey_push_away_text}", this::buildHickeyPushAwayText);
        m.put("{bar_under_shirt_grope_text}", this::buildUnderShirtGropeText);
        m.put("{bar_through_panties_text}", this::buildThroughPantiesText);
        m.put("{bar_inside_panties_text}", this::buildInsidePantiesText);
        m.put("{bar_orgasm_aftermath_text}", this::buildOrgasmAftermathText);
        m.put("{bar_shaky_legs_text}", this::buildShakyLegsRecoveryText);
        m.put("{bar_commando_discovery_text}", this::buildCommandoDiscoveryText);
        m.put("{bar_commando_reaction_text}", this::buildCommandoReactionText);
        m.put("{bar_mid_grope_stop_text}", this::buildMidGropeMcStopText);
        m.put("{bar_about_to_cum_text}", this::buildAboutToCumText);
        m.put("{bar_mc_says_stop_text}", this::buildMcSaysStopFingeringText);
        m.put("{bar_npc_refuses_stop_text}", this::buildNpcRefusesStopText);
        m.put("{bar_neck_grab_text}", this::buildNeckGrabText);
        m.put("{bar_neck_release_text}", this::buildNeckReleaseText);
        m.put("{bar_npc_cums_grinding_text}", this::buildNpcCumsGrindingText);
        m.put("{bar_npc_humiliation_text}", this::buildNpcHumiliationText);
        m.put("{bar_walk_home_text}", this::buildWalkHomeText);
        m.put("{bar_walk_home_goodnight_text}", this::buildWalkHomeKissGoodnight);
        m.put("{bar_walk_home_his_place_text}", this::buildWalkHomeHisPlace);
        m.put("{bar_npc_leave_text}", this::buildNpcLeaveText);
    }

    private static final int TARGET_MALE_MIN   = 4;
    private static final int TARGET_MALE_MAX   = 7;
    private static final int TARGET_FEMALE_MIN = 3;
    private static final int TARGET_FEMALE_MAX = 5;
    /** Probability that boss or any individual coworker appears in bar on a given night. */
    private static final double WORK_COLLEAGUE_BAR_CHANCE = 0.05;

    private final GameState    state;
    private final NpcLoader    npcs;
    private       game.JobLoader jobs = null;
    private final Random       rng       = new Random();
    private       TextPoolRegistry textPools = null;   // null = no mod text pools

    /** Inject mod text pools. Call before first bar interaction. */
    public void setTextPoolRegistry(TextPoolRegistry pools) { this.textPools = pools; }

    public BarSystem(GameState state, NpcLoader npcs) {
        this.pools = new NpcMomentPools(this);
        this.state = state;
        this.npcs  = npcs;
    }

    public void setJobs(game.JobLoader jobs) { this.jobs = jobs; }

    // ── Dance floor scenes ────────────────────────────────────────────────────

    /**
     * MC's reaction tier for groping/exposure scenes.
     * Determined by slut_rep + drunk level combined — not trait-gated.
     *
     * Low rep + sober/tipsy = "shock"   (panicked, frozen, wants it to stop)
     * Building rep OR drunk  = "flustered" (embarrassed, conflicted, doesn't push away)
     * High rep + drunk       = "enjoy"  (receptive, encouraging)
     *
     * This replaces trait gates for reaction variants — a shy character with
     * low rep naturally lands in shock; the same character with built rep
     * and drinks lands in flustered without any forced trait check.
     */
    private String mcReactionTier() {
        int rep   = state.slut_rep;
        int drunk = state.drunk;

        // Both low → shock
        if (rep < 10 && drunk < 11) return "shock";
        // Both high → enjoy
        if (rep >= 20 && drunk >= 11) return "enjoy";
        // Everything between → flustered
        return "flustered";
    }

    /**
     * Returns the NPC's name if MC has their number or is in a relationship,
     * otherwise returns a pronoun token. Use in builder prose wherever
     * "he said" or "he looked" would become "[Name] said" once they're closer.
     * e.g.: npcRef(n) + " steps back." → "Marcus steps back." or "{npc_He} steps back."
     */
    /**
     * How close is the MC's current slut_rep to the minimum required for a scene?
     * Returns "shy" if within 8 of the gate (barely qualified),
     *         "enjoy" if 16+ above the gate (well above),
     *         "flustered" in between.
     * Used by builders to pick the right internal voice — MC near her floor
     * sounds hesitant even on high-rep actions.
     */
    private String repProximityTier(int minRepRequired) {
        int margin = state.slut_rep - minRepRequired;
        if (margin < 8)  return "shy";
        if (margin < 16) return "flustered";
        return "enjoy";
    }

    String npcRef(NpcData n) {
        if (n == null) return "{npc_He}";
        return (state.hasNpcNumber(n.id) || state.isDating(n.id)) ? n.name : "{npc_He}";
    }
    private String npcRefLower(NpcData n) {
        if (n == null) return "{npc_he}";
        return (state.hasNpcNumber(n.id) || state.isDating(n.id)) ? n.name : "{npc_he}";
    }
    private String npcRefPossessive(NpcData n) {
        if (n == null) return "{npc_his}";
        return (state.hasNpcNumber(n.id) || state.isDating(n.id)) ? n.name + "'s" : "{npc_his}";
    }

    private String drunkTier() {
        return drunkTierPublic();
    }

    public String drunkTierPublic() {
        if (state.drunk >= 15) return "blackout";
        if (state.drunk >= 11) return "drunk";
        if (state.drunk >= 6)  return "tipsy";
        return "tipsy"; // sober falls back to tipsy text
    }

    /** True if MC has any shy-adjacent trait (triggers Sleazy grope reaction). */
    private boolean mcShyAdjacent() {
        return state.hasTrait("Shy") || state.hasTrait("Conflict_Avoidant")
            || state.hasTrait("Fragile_Ego");
    }

    /**
     * Gamestage category — determines which flavor of response goes in the pool.
     * shy     = low slut_rep, mostly sober    → hesitant, internal panic, freeze
     * flustered = middle ground                → uncertain, reactive, slightly compliant
     * enjoy   = established rep + drinks      → willing, escalating, engaged
     */
    String gameStageVariant() {
        return gameStageVariant("default");
    }

    /**
     * Returns true when MC cannot voluntarily end the dance.
     * Condition: effective willpower (with arousal drain at threshold 40) < 25
     *            AND slut_rep puts her in "enjoy" tier for default context.
     * When locked, "End the dance" and "Push away" are hidden for 5 dance turns.
     */
    public boolean isDanceLocked() {
        int effWp = state.effectiveWillpowerForCheck(40);
        return effWp < 25 && gameStageVariant("default").equals("enjoy");
    }

    /**
     * Context-aware variant selector.
     * User-defined thresholds (slut_rep + drunk*2):
     *   "default"       — shy < 12, flustered < 30, enjoy 30+
     *   "breast_public" — shy < 12, flustered < 25, enjoy 25+  (enjoying breast groping in public)
     *   "finger_public" — shy < 20, flustered < 35, enjoy 35+  (enjoying fingering in public)
     *   "whisper"       — same as breast_public (dirty talk = moderate threshold)
     */
    private String gameStageVariant(String context) {
        int combined = state.slut_rep + (state.drunk * 2);
        switch (context) {
            case "breast_public":
            case "whisper":
                if (combined < 12) return "shy";
                if (combined < 25) return "flustered";
                return "enjoy";
            case "finger_public":
                if (combined < 20) return "shy";
                if (combined < 35) return "flustered";
                return "enjoy";
            default:
                if (combined < 12) return "shy";
                if (combined < 30) return "flustered";
                return "enjoy";
        }
    }

    void addVariant(List<String> pool, String generic, String variant) {
        if (variant != null && !variant.equals(generic)) pool.add(variant);
    }

    // ── Dance moment pool (roguelike slow dance) ──────────────────────────────

    /**
     * Selects and fires a random dance moment from the filtered pool.
     * Pool is filtered by current flags, stage, and used-moment tracking.
     * Returns the moment's text (ready for applyTextVars).
     * Applies stat changes and sets flags directly on state.
     */
    public String buildDanceMomentText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "The dance continues.";

        // Update NPC behaviour flags each dance loop
        updateNpcBehaviourFlags();
        // Passive frustration rise — NPC wants more as dance goes on
        state.changeStat("npc_frustration", 4);

        List<DanceMoment> pool = buildFilteredPool(n);
        if (pool.isEmpty())
            return "You keep dancing together. The music carries you."; // pool exhausted

        // Weighted random selection
        int total = pool.stream().mapToInt(m -> m.weight).sum();
        int roll  = rng.nextInt(total);
        int cum   = 0;
        DanceMoment moment = pool.get(0);
        for (DanceMoment m : pool) {
            cum += m.weight;
            if (roll < cum) { moment = m; break; }
        }

        // Apply moment
        if (!moment.repeatable) state.usedDanceMoments.add(moment.id);
        moment.setsFlags.forEach(f -> state.changeStat("flag_" + f, 1));
        state.changeStat("arousal",        moment.arousalDelta);
        state.changeStat("npc_arousal",    moment.npcArousalDelta);
        state.changeStat("npc_frustration",moment.npcFrustrationDelta);
        state.changeStat("npc_liking",     moment.npcLikingDelta);

        return moment.text;
    }

    private List<DanceMoment> buildFilteredPool(NpcData n) {
        String stage  = gameStageVariant();
        boolean isMale = "MALE".equalsIgnoreCase(n.type);
        List<DanceMoment> all = new ArrayList<>(getMomentPool(n));
        all.addAll(clothingPanicMoments()); // clothing awareness beats in every pool
        List<DanceMoment> filtered = new ArrayList<>();

        for (DanceMoment m : all) {
            if (m.maleOnly && !isMale) continue;  // gate cock/erection/pants-cum content
            if (!m.repeatable && state.usedDanceMoments.contains(m.id)) continue;
            if (!m.requiresFlags.isEmpty() && !m.requiresFlags.stream().allMatch(f -> state.getBodyFlag("flag_" + f))) continue;
            if (!m.blocksIfFlags.isEmpty() &&  m.blocksIfFlags.stream().anyMatch(f -> state.getBodyFlag("flag_" + f))) continue;
            if (m.minDrunk > 0 && state.drunk < m.minDrunk) continue;
            if (m.minMcArousal > 0 && state.arousal < m.minMcArousal) continue;
            if (m.minNpcArousal > 0 && state.currentNpcArousal < m.minNpcArousal) continue;
            if (m.maxNpcArousal < Integer.MAX_VALUE && state.currentNpcArousal >= m.maxNpcArousal) continue;
            if (!m.requiredMcTrait.isEmpty() && !state.hasTrait(m.requiredMcTrait)) continue;
            if (!m.minStage.isEmpty()) {
                // shy < flustered < enjoy
                int stageVal = stageOrdinal(stage);
                int minVal   = stageOrdinal(m.minStage);
                if (stageVal < minVal) continue;
            }
            filtered.add(m);
        }
        return filtered;
    }

    // ── NPC max escalation tier by trait ─────────────────────────────────────
    // Tier 0: normal dancing only
    // Tier 1: light brushing / hand placement (Engaging, Shy max here)
    // Tier 2: ass grope, breast grope (Outgoing, Magnetic, etc. max here)
    // Tier 3: full groping, under shirt, through panties (Jerk, Confrontational max here)
    // Tier 4: fingering (Sleazy, Alcoholic only)
    // Tier 5: SA territory (Sleazy, Alcoholic only)
    int getNpcMaxTier(NpcData n) {
        if (n == null) return 1;
        if (hasTrait(n, "Engaging") || hasTrait(n, "Shy"))              return 1;
        if (hasTrait(n, "Magnetic") || hasTrait(n, "Self_Assured")
         || hasTrait(n, "Boring")   || hasTrait(n, "Streetwise"))       return 2;
        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))  return 2;
        if (hasTrait(n, "Confrontational") || hasTrait(n, "Jerk"))      return 4;
        if (hasTrait(n, "Sleazy")  || hasTrait(n, "Alcoholic"))         return 5;
        return 2;
    }

    // ── Current NPC aggression tier from frustration level ────────────────────
    int getNpcCurrentTier() {
        int f = state.currentNpcFrustration;
        if (f < 20)  return 0;
        if (f < 40)  return 1;
        if (f < 60)  return 2;
        if (f < 80)  return 3;
        if (f < 92)  return 4;
        return 5;
    }

    // ── Set NPC capability traits based on NPC type + current frustration ─────
    void updateNpcBehaviourFlags() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return;
        int maxTier   = getNpcMaxTier(n);
        int currTier  = getNpcCurrentTier();
        int effective = Math.min(maxTier, currTier);

        // Groping (tier 2+)
        if (effective >= 2) state.addTrait("npc_can_grope");
        else                state.removeTrait("npc_can_grope");

        // Fingering (tier 4+ — Sleazy/Alcoholic only)
        if (effective >= 4) state.addTrait("npc_can_finger");
        else                state.removeTrait("npc_can_finger");

        // SA territory (tier 5 — Sleazy/Alcoholic only)
        if (effective >= 5) state.addTrait("npc_can_sa");
        else                state.removeTrait("npc_can_sa");

        // NPC wants to leave — arousal >= 75, OR (frustration >= 75 AND arousal >= 40)
        boolean wantsLeave = state.currentNpcArousal >= 75
            || (state.currentNpcFrustration >= 75 && state.currentNpcArousal >= 40);
        if (wantsLeave) state.addTrait("npc_wants_leave");
        else            state.removeTrait("npc_wants_leave");

        // NPC returning to normal — frustration dropped below 15 and was groping
        boolean returning = state.currentNpcFrustration < 15
            && (state.flagAssGroped || state.flagBreastGroped);
        if (returning) state.addTrait("npc_returning_to_dance");
        else           state.removeTrait("npc_returning_to_dance");
    }

    private int stageOrdinal(String s) {
        switch (s) { case "enjoy": return 2; case "flustered": return 1; default: return 0; }
    }

    /**
     * Returns the full moment pool for this NPC.
     * Pool is keyed off dominant NPC trait.
     * ── GAP NOTES ──
     *   Sleazy:     ~14 moments built, need 6+ more (pool target 20+)
     *   Engaging:   ~8 moments built, need 12+ more
     *   Magnetic:   ~7 moments built, need 13+ more
     *   Outgoing:   ~6 moments built, need 14+ more
     *   All others: 4-5 moments, need significant expansion
     */
    private List<DanceMoment> getMomentPool(NpcData n) {
        if (hasTrait(n, "Sleazy"))                                    return pools.sleazyMoments(n);
        if (hasTrait(n, "Jerk"))                                      return pools.jerkMoments(n);
        if (hasTrait(n, "Engaging"))                                  return pools.engagingMoments(n);
        if (hasTrait(n, "Magnetic"))                                  return pools.magneticMoments(n);
        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover")) return pools.outgoingMoments(n);
        if (hasTrait(n, "Shy"))                                       return pools.shyMoments(n);
        if (hasTrait(n, "Self_Assured"))                              return pools.selfAssuredMoments(n);
        if (hasTrait(n, "Confrontational"))                           return pools.confrontationalMoments(n);
        return pools.defaultMoments(n);
    }

    // ── SLEAZY ────────────────────────────────────────────────────────────────
    // Current: 14 moments. Need: 6+ more. Ask Grok for: more dirty talk lines,
    // under-skirt escalation, bolder clothing reactions, drunk-specific moments.
    private List<DanceMoment> clothingPanicMoments() {
        String tier = gameStageVariant();
        String d    = drunkTier();
        List<DanceMoment> p = new ArrayList<>();

        p.add(DanceMoment.id("clothing_bounce_notice").text(
            d.equals("blackout")
                ? "*Everything is spinning… my chest won't stop bouncing… I know {npc_he}'s watching.*"
              : tier.equals("shy")
                ? "*Oh no… they're bouncing. I can feel them moving every time we sway. {npc_He}'s looking — why is {npc_he} looking? My face is burning.*"
              : tier.equals("flustered")
                ? "*They're moving more than I'd like. {npc_He}'s noticed.*"
              : "*They're moving and {npc_he}'s watching and you're fine with it.*")
            .mcTrait("bounce_prone").arousal(2).npcArousal(3).npcFrustration(-2).weight(6).repeatable().build());

        p.add(DanceMoment.id("clothing_nipping_notice").text(
            d.equals("blackout")
                ? "*The cold air keeps making them harder… I know {npc_he} can see… I can't even cover myself.*"
              : tier.equals("shy")
                ? "*Oh god, they're hard… you can see them right through the fabric. My face is burning.*"
              : tier.equals("flustered")
                ? "*Every little movement makes them more obvious. {npc_He}'s definitely noticed.*"
              : "*They're showing. You're fine with it.*")
            .mcTrait("nipping").arousal(3).npcArousal(4).npcFrustration(-3).weight(6).repeatable().build());

        p.add(DanceMoment.id("clothing_braless_notice").text(
            d.equals("blackout")
                ? "*No bra at all… they're completely free and pressing into her…* [faint embarrassed whine]"
              : tier.equals("shy")
                ? "*No bra… I can feel them moving freely against her. Every shift makes me feel more exposed.*"
              : tier.equals("flustered")
                ? "*They're not supported and {npc_he} can probably feel everything. You shift slightly.*"
              : "*Braless and you don't mind {npc_him} knowing it.*")
            .mcTrait("exposed_breasts").arousal(3).npcArousal(4).npcFrustration(-3).weight(5).repeatable().build());

        p.add(DanceMoment.id("clothing_cameltoe_notice").text(
            d.equals("blackout")
                ? "*The cameltoe keeps rubbing against her with every sway… I know it's visible but I can't fix it.*"
              : tier.equals("shy")
                ? "*Oh god, the outline is so obvious between my legs… {npc_he}'s probably looking right at it. I want to die.*"
              : tier.equals("flustered")
                ? "*The fabric is clinging right there. {npc_He}'s noticed. There's nothing I can do about it now.*"
              : "*{npc_He} can see the outline and that's not the worst thing.*")
            .mcTrait("camel_toe").arousal(4).npcArousal(5).npcFrustration(-4).weight(6).repeatable().build());

        p.add(DanceMoment.id("clothing_commando_notice").text(
            d.equals("blackout")
                ? "*Bare… completely bare under this short skirt… {npc_he} could touch me so easily…*"
              : tier.equals("shy")
                ? "*No panties… every time we move I feel the air between my legs. If {npc_his} hand goes any lower…*"
              : tier.equals("flustered")
                ? "*Nothing under there and the way {npc_he}'s holding me, {npc_he} might work that out.*"
              : "*Nothing underneath. You know. {npc_He} might find out. You're fine with that possibility.*")
            .mcTrait("commando").arousal(5).npcArousal(5).npcFrustration(-4).weight(7).repeatable().build());

        // ── Crop top specific breast grope awareness ─────────────────────────
        // Fires when MC is wearing a crop top AND breast has been groped.
        // Adds thin-fabric sensation layer on top of existing grope moments.

        p.add(DanceMoment.id("clothing_crop_top_groped").text(
            d.equals("blackout")
                ? "{npc_His} hands are on my breasts through the crop top… the fabric is so thin… barely anything between his palms and my skin…"
              : tier.equals("shy")
                ? "*Oh god — he's groping me right through the crop top. The fabric is so thin it feels like almost nothing. I can feel every finger.*\n\n"
                  + "Your breath catches. The material stretches under his grip."
              : tier.equals("flustered")
                ? "The thin fabric of the crop top does almost nothing between his hands and your breasts. Every squeeze translates directly through it.\n\n"
                  + "*He can feel everything. The top is barely there.*"
              : "{npc_He}'s not pretending this is accidental anymore.\n\n"
                + "The crop top offers no real barrier — your breasts fill his hands through the stretched fabric, and you feel every ridge of his grip.")
            .mcTrait("wearing_crop_top").requires("breast_groped")
            .arousal(5).npcArousal(6).npcFrustration(-5).weight(7).repeatable().build());

        p.add(DanceMoment.id("clothing_braless_groped").text(
            d.equals("blackout")
                ? "*No bra… nothing… just his hands and the fabric and I can feel every single thing {npc_he}'s doing…*"
              : tier.equals("shy")
                ? "*No bra at all and {npc_he}'s groping me right here — I can feel everything. My nipples are so hard. Everyone can probably see them dragging against the fabric.*\n\n"
                  + "You go very still. The sensation is overwhelming."
              : tier.equals("flustered")
                ? "No bra means every squeeze registers completely. Nipples dragging against the fabric with each knead.\n\n"
                  + "*Too much. This feels like way too much and you're not stopping {npc_him}.*"
              : "Braless and he knows it. {npc_His} hands close around your breasts with that knowledge — feeling the full weight of them, nothing in between.\n\n"
                + "*He can feel everything. Your nipples are hard against his palms and you don't care.*")
            .mcTrait("exposed_breasts").requires("breast_groped")
            .arousal(6).npcArousal(7).npcFrustration(-6).weight(8).repeatable().build());

        // ── Ass-to-breast transition notice ──────────────────────────────────
        p.add(DanceMoment.id("ass_to_breast_transition").text(
            d.equals("blackout")
                ? "*Hands moving… was it my ass? My breasts? Both? The music is too loud to think.*"
              : tier.equals("shy")
                ? "{npc_His} hands slide from your ass upward without warning — a slow, deliberate climb back toward your breasts.\n\n"
                  + "*{npc_He}'s moving between them like they both belong to {npc_him}.*"
              : tier.equals("flustered")
                ? "From ass back to breasts. {npc_He} doesn't ask, just moves — like mapping territory {npc_he}'s already claimed.\n\n"
                  + "You stay in the rhythm and let it happen."
              : "{npc_He} moves freely — ass to breasts and back again — like {npc_he}'s been doing it long enough to know you won't stop {npc_him}.\n\n"
                + "You haven't.")
            .requires("breast_groped", "ass_groped")
            .arousal(6).npcArousal(7).npcFrustration(-6).weight(5).build());


        // Fire when groping flags set + flagCornered = false (visible to others)

        // ── 6-tier bystander reactions (tier + drunk level) ─────────────────
        p.add(DanceMoment.id("bystander_sleazy_approves").text(
            "A guy nearby glances over. {npc_He}'s caught a clear view of what's happening. {npc_He} grins, nudges {npc_his} friend.\n\n"
            + bystanderThought_breast())
            .requires("breast_groped").blocks("cornered")
            .arousal(3).npcArousal(3).npcFrustration(-2).weight(5).build());

        p.add(DanceMoment.id("bystander_looks_away").text(
            "A woman at the bar looks over, clocks what's happening, and immediately looks somewhere else.\n\n"
            + bystanderThought_ass())
            .requires("ass_groped").blocks("cornered")
            .arousal(2).npcArousal(2).npcFrustration(-1).weight(5).build());

        p.add(DanceMoment.id("bystander_oblivious").text(
            "Thirty people on this dance floor. Not one of them looking.\n\n"
            + bystanderThought_oblivious())
            .requires("ass_groped").arousal(2).npcArousal(2).npcFrustration(-2).weight(6).repeatable().build());

        p.add(DanceMoment.id("bystander_couple_ignores").text(
            "The couple next to you is in their own world — doing approximately the same thing.\n\n"
            + "*Of course they are. That's just what the dance floor is.*\n\n"
            + bystanderThought_oblivious())
            .arousal(2).npcArousal(2).npcFrustration(-2).weight(6).repeatable().build());

        p.add(DanceMoment.id("bystander_fingering_noticed").text(
            "Someone nearby glances down at the angle of {npc_his} arm, then back up.\n\n"
            + "They piece it together about two seconds later.\n\n"
            + bystanderThought_fingering())
            .requires("pussy_groped").blocks("cornered").arousal(4).weight(5).build());

        p.add(DanceMoment.id("bystander_hickey_visible").text(
            "Someone catches a look at your neck and does a small double-take.\n\n"
            + bystanderThought_hickey())
            .requires("neck_kissed").blocks("cornered").arousal(2).weight(5).repeatable().build());

        return p;
    }

    // ── TRANSITION SCENE POOL ───────────────────────────────────────────

    // ── TRANSITION SCENE POOL ────────────────────────────────────────────────

    /**
     * Weighted transition scene roller.
     * Scale: each scene has weight 0–10.
     * Null weight = 2 × sum of all scene weights → exactly 1-in-3 chance of any scene.
     *
     * Usage: pass a context string, returns a scene ID to redirect to, or null (no event).
     * Context strings:
     *   "to_dance"  — walking toward the dance floor
     *   "mid_dance" — mid-dance energy shift
     *   "hub_loop"  — returning to bar_with_npc hub
     *   "to_pool"   — walking toward the pool table
     */
    public String rollTransitionScene(String context) {
        List<String[]> pool = buildTransitionPool(context);
        if (pool.isEmpty()) return null;

        int sceneTotal = pool.stream().mapToInt(e -> Integer.parseInt(e[1])).sum();
        if (sceneTotal == 0) return null;

        int nullWeight = sceneTotal * 2; // x3 total entries = 1/3 scene chance
        int total      = sceneTotal + nullWeight;
        int roll       = rng.nextInt(total);

        if (roll >= sceneTotal) return null; // null zone — nothing this time

        // Find which scene the dice landed on
        int cum = 0;
        for (String[] entry : pool) {
            cum += Integer.parseInt(entry[1]);
            if (roll < cum) return entry[0];
        }
        return null;
    }

    /**
     * Builds the weighted transition pool for a given context.
     * Each entry: { sceneId, weight }.
     * Weights gate on current state (drunk, flags, slut_rep, etc.).
     */
    private List<String[]> buildTransitionPool(String context) {
        List<String[]> p = new ArrayList<>();

        switch (context) {

            case "to_dance":
                // Atmospheric moments walking onto the dance floor
                p.add(w("bar_pre_dance_moment",    8)); // always available
                if (state.hasTrait("Neck_Hickey"))
                    p.add(w("bar_pre_dance_moment", 5)); // hickey = self-conscious, more likely to trigger
                if (state.drunk >= 6)
                    p.add(w("bar_pre_dance_moment", 3)); // tipsy = looser, more things happen
                if (state.slowDanceCount == 0)
                    p.add(w("bar_transition_to_dance", 6)); // first time to floor this session
                break;

            case "mid_dance":
                // Mid-dance energy interrupts
                p.add(w("bar_song_change", 7));           // always a candidate
                if (state.flagKissed)
                    p.add(w("bar_song_change", 3));       // post-kiss, song change feels charged
                if (state.currentNpcFrustration > 40)
                    p.add(w("bar_song_change", 4));       // high frustration — NPC benefits from break
                break;

            case "hub_loop":
                // Events that can fire when returning to bar_with_npc hub
                if (state.slut_rep >= 5 && state.currentApproachingNpc != null)
                    p.add(w("bar_other_patron_approach", 4)); // someone else notices her
                // Low weight — don't spam this
                break;

            case "to_pool":
                p.add(w("bar_transition_to_pool", 8));
                break;

            case "to_bathroom":
                // Bathroom always intentional (menu choice) — no random transition here
                break;
        }

        return p;
    }

    /** Helper: builds a {sceneId, weight} entry as a String array. */
    private String[] w(String sceneId, int weight) {
        return new String[]{ sceneId, String.valueOf(weight) };
    }


    /** 6-tier MC internal thought when someone notices breast groping. */
    private String bystanderThought_breast() {
        String d = drunkTier(); String t = gameStageVariant();
        if (d.equals("blackout")) return "*...hands... on my chest... everything is spinning...*";
        if (d.equals("drunk"))   return "*{npc_His} hands feel so warm... but everyone's staring...*";
        if (d.equals("tipsy") && d.compareTo("drunk") < 0) return "*{npc_His} hands... people are watching... I can't tell if I care...*";
        return switch (t) {
            case "enjoy"     -> "You catch the glance. Let them look.";
            case "flustered" -> "*People are watching {npc_him} grope me... this feels too exposed.*";
            default          -> "*Everyone can see {npc_his} hands on my chest... I want to disappear right now.*";
        };
    }

    /** 6-tier MC thought when someone notices ass groping. */
    private String bystanderThought_ass() {
        String d = drunkTier(); String t = gameStageVariant();
        if (d.equals("blackout")) return "*...something happening... can't tell...*";
        if (d.equals("drunk"))    return "*Someone saw. My head is too fuzzy to care properly...*";
        return switch (t) {
            case "enjoy"     -> "At least {npc_he} had the decency to look away.";
            case "flustered" -> "Something about that makes this feel more real. You shift slightly.";
            default          -> "*{npc_He} saw. {npc_He} definitely saw. The embarrassment is consuming.*";
        };
    }

    /** 6-tier MC thought when no one is watching. */
    private String bystanderThought_oblivious() {
        String d = drunkTier(); String t = gameStageVariant();
        if (d.equals("blackout")) return "*...people everywhere... none of them matter...*";
        if (d.equals("drunk"))    return "*Can't even tell if people are watching anymore... just feels good...*";
        return switch (t) {
            case "enjoy"     -> "The anonymity makes you bolder than you expected.";
            case "flustered" -> "The anonymity makes it easier. Also harder.";
            default          -> "*No one is watching. You're invisible. That's almost worse — like it doesn't count as real.*";
        };
    }

    /** 6-tier MC thought when someone notices fingering. */
    private String bystanderThought_fingering() {
        String d = drunkTier(); String t = gameStageVariant();
        if (d.equals("blackout")) return "*...something inside me... can't think... just feels warm...*";
        if (d.equals("drunk"))    return "*{npc_His} fingers keep going and everyone might know... I'm getting so wet...*";
        return switch (t) {
            case "enjoy"     -> "Let them watch. {npc_His} fingers feel too good to care right now.";
            case "flustered" -> "*{npc_He}'s fingering me right here... I hope no one realizes what's happening.*";
            default          -> "*{npc_His} fingers are inside me and people can see {npc_his} arm moving... I'm so embarrassed.*";
        };
    }

    /** 6-tier MC thought when someone notices a hickey. */
    private String bystanderThought_hickey() {
        String d = drunkTier(); String t = gameStageVariant();
        if (d.equals("blackout")) return "*...something on my neck... feels sore... everything is blurry...*";
        if (d.equals("drunk"))    return "*There's a hickey on my neck... tomorrow is going to be so awkward...*";
        return switch (t) {
            case "enjoy"     -> "Let them stare at it. You like wearing {npc_his} mark.";
            case "flustered" -> "*There's a visible hickey now... people are definitely noticing.*";
            default          -> "*Everyone can see the hickey on my neck... I'll never be able to hide it.*";
        };
    }

    private String breastCommentFromClothing(NpcData n) {
        if (state.hasTrait("bounce_prone_4") || state.hasTrait("bounce_prone_5"))
            return "\"Goddamn… they bounce every time you move.\" {npc_His} eyes haven't left your chest.";
        if (state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent"))
            return "{npc_His} gaze drops. \"Those piercings — you wear them on purpose?\"";
        if (state.hasTrait("camel_toe"))
            return "She looks down, then back up. Makes no attempt to pretend {npc_he} didn't.";
        return "{npc_His} eyes move over you in a way that makes it clear {npc_he}'s noticing everything.";
    }

    String buildSlowDanceVariantText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "You slow dance. It's fine.";
        String d = drunkTier();
        String stage = gameStageVariant();

        List<String> pool = new ArrayList<>();
        String generic = dispatchSlowDance(n, d, "generic");
        pool.add(generic);

        // Pool built from gamestage — not personality traits
        // shy stage: hesitant, frozen, internally panicking variants
        if (stage.equals("shy")) {
            addVariant(pool, generic, dispatchSlowDance(n, d, "shy"));
            addVariant(pool, generic, dispatchSlowDance(n, d, "conflict_avoidant"));
            addVariant(pool, generic, dispatchSlowDance(n, d, "fragile_ego"));
        }
        // enjoy stage: willing, escalating, engaged variants
        else if (stage.equals("enjoy")) {
            addVariant(pool, generic, dispatchSlowDance(n, d, "provocative"));
            addVariant(pool, generic, dispatchSlowDance(n, d, "outgoing"));
            addVariant(pool, generic, dispatchSlowDance(n, d, "confrontational"));
        }
        // flustered: middle ground — reacting but not quite committing either way
        else {
            addVariant(pool, generic, dispatchSlowDance(n, d, "self_assured"));
            addVariant(pool, generic, dispatchSlowDance(n, d, "prideful"));
        }

        String base = pool.get(rng.nextInt(pool.size()));
        String clothing = clothingReactionForDance(n, d);
        return clothing.isEmpty() ? base : base + "\n\n" + clothing;
    }

    private String dispatchSlowDance(NpcData n, String d, String mc) {
        // Check mod text pool for this NPC personality first
        String npcPersonality = getNpcPersonalityKey(n);
        String poolName = "bar.slow_dance." + npcPersonality;
        String modResult = pickFromPool(poolName, buildMcTraitSet());
        if (modResult != null && !modResult.isEmpty()) return modResult;

        boolean cont = state.slowDanceCount >= 2;
        if (hasTrait(n, "Sleazy"))                                     return slowDanceSleazy(d, mc, cont);
        if (hasTrait(n, "Jerk"))                                       return slowDanceJerk(d, mc, cont);
        if (hasTrait(n, "Magnetic"))                                   return slowDanceMagnetic(d, mc);
        if (hasTrait(n, "Engaging"))                                   return slowDanceEngaging(d, mc);
        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover")) return slowDanceOutgoing(d, mc);
        if (hasTrait(n, "Shy"))                                        return slowDanceShy(d, mc);
        if (hasTrait(n, "Self_Assured"))                               return slowDanceSelfAssured(d, mc);
        if (hasTrait(n, "Confrontational"))                            return slowDanceConfrontational(d, mc);
        if (hasTrait(n, "Boring"))                                     return slowDanceBoring(d, mc);
        if (hasTrait(n, "Streetwise"))                                 return slowDanceStreetwise(d, mc);
        if (hasTrait(n, "Alcoholic"))                                  return slowDanceAlcoholic(d, mc);
        return slowDanceDefault(d, mc);
    }





    private String slowDanceEngaging(String d, String mc) {
        if (d.equals("blackout")) {
            if (mc.equals("shy") || mc.equals("fragile_ego"))
                return "{npc_His} hand is warm on your lower back but everything feels distant. "
                     + "You vaguely register safety but can't form thoughts — just heavy leaning.";
            return "{npc_His} hand is warm on your lower back but everything feels distant. "
                 + "You sag against her, head lolling on {npc_his} shoulder. "
                 + "No real reaction — just hazy warmth.";
        }
        if (d.equals("drunk")) {
            String base = "{npc_His} hand stays firm on your lower back. You sway heavier, "
                        + "words slipping out candidly. \"You're really nice,\" you murmur. "
                        + "Hips press against {npc_his} without thinking.";
            switch (mc) {
                case "outgoing":   return base + "\n\nYou laugh and pull her tighter, teasing \"Don't stop that thumb thing.\"";
                case "self_assured": return base + "\n\nYou look {npc_him} dead in the eye: \"I like how you hold me. No games.\"";
                case "fragile_ego": return base + "\n\nThe warmth hits somewhere vulnerable; you cling a little tighter than intended.";
                case "provocative": return base + "\n\nYou grind slow and deliberate, whispering \"Feel that?\"";
                default: return base;
            }
        }
        // tipsy
        String base = "She steps in close, one hand warm and steady on the small of your back, "
                    + "the other lacing fingers with yours against {npc_his} chest. Thumb traces slow circles. "
                    + "You feel safe heat through your top. You lean in slightly, letting the buzz soften everything.";
        switch (mc) {
            case "outgoing":    return base + "\n\nYou grin and rest your head on {npc_his} shoulder, murmuring \"This feels really good\" while gently swaying harder.";
            case "self_assured": return base + "\n\nYou meet {npc_his} eyes and say \"You're making this easy,\" voice calm and direct.";
            case "fragile_ego": return base + "\n\nHis attention feels a little too good; you press closer than you meant to, cheeks warm.";
            case "provocative": return base + "\n\nYou slide your free hand down {npc_his} chest and whisper \"Closer?\" with a small smirk.";
            default: return base;
        }
    }

    private String slowDanceMagnetic(String d, String mc) {
        if (d.equals("blackout"))
            return "Heavy hand on your lower back; you feel faint pressure. "
                 + "Head drops to {npc_his} chest, body limp. World is spinning haze. No real reaction.";
        if (d.equals("drunk")) {
            String base = "Hand locks hard on your lower back, pulling you tight. "
                        + "You feel fingers dig in slightly. Alcohol makes you bold; "
                        + "you whisper something candid and grind back.";
            switch (mc) {
                case "outgoing":    return base + "\n\nYou grin and say \"You're trouble… I like it.\"";
                case "self_assured": return base + "\n\nYou match the pressure: \"You want me closer? Take it.\"";
                case "provocative": return base + "\n\nYou slide a hand down and grip {npc_his} ass right back.";
                default: return base;
            }
        }
        String base = "{npc_He} pulls you flush, large hand splayed possessively on your lower back, "
                    + "other hand pressing yours to {npc_his} chest. You feel {npc_his} steady heartbeat and radiating heat. "
                    + "Silence feels electric.";
        switch (mc) {
            case "outgoing":    return base + "\n\nYou break the silence with a soft laugh and trace your fingers along {npc_his} collar.";
            case "self_assured": return base + "\n\nYou hold {npc_his} gaze: \"You don't need words, do you?\"";
            case "fragile_ego": return base + "\n\nHis intensity lands warm and important; you melt in faster than you meant.";
            case "provocative": return base + "\n\nYou press your hips forward and breathe \"What are you thinking right now?\"";
            default: return base;
        }
    }

    private String slowDanceOutgoing(String d, String mc) {
        if (d.equals("blackout"))
            return "Hands everywhere on hips and lower back. You sag limply, head lolling. "
                 + "{npc_He} keeps you upright; you register only distant motion.";
        if (d.equals("drunk")) {
            String base = "Hands slide lower, confident squeezes. You laugh louder and your body rocks against {npc_his}.";
            if (mc.equals("outgoing"))    return base + "\n\nYou hype {npc_him} right back, voice loud.";
            if (mc.equals("provocative")) return base + "\n\nYou whisper filthy little encouragements.";
            return base;
        }
        String tier = gameStageVariant();
        int roll = rng.nextInt(8);
        String base = switch (roll) {
            case 0 -> "Both hands on your hips, thumbs hooked into your waistband, playfully squeezing as you both sway and occasionally dip lightly.";
            case 1 -> "One hand on your lower back, the other holding yours high, pulling you in with energetic rhythm even in the slow song.";
            case 2 -> "Arms loosely around your waist, pulling you close for a moment then loosening again as you both sway to the beat.";
            case 3 -> "Hand on your hip, occasionally guiding a small spin while you both move together, keeping the energy up.";
            case 4 -> "One arm around your waist, the other holding your hand high, swaying with big, fun energy.";
            case 5 -> "Hands on your hips, dipping you lightly then pulling you back in as you both sway.";
            case 6 -> "Arms around you, swaying with exaggerated rhythm and occasional playful squeezes on your hips.";
            default -> "Both hands firm on your hips, bouncy and confident, thumb hooked in your waistband while you both move together.";
        };
        String mcReact = tier.equals("enjoy")
            ? "\n\n*His fun, energetic hold while we dance makes me laugh and feel alive.*"
            : tier.equals("shy")
                ? "\n\n*His handsy, bouncy posture while we sway feels overwhelming.*"
                : "\n\n*His playful grip is there as we dance, but I feel neutral about it.*";
        if (mc.equals("outgoing"))    return base + mcReact + "\n\nYou spin yourself once and laugh \"You're stealing the show!\"";
        if (mc.equals("self_assured")) return base + mcReact + "\n\nYou smirk \"You always this handsy or just with me?\"";
        if (mc.equals("provocative")) return base + mcReact + "\n\nYou grind back and tease \"Keep squeezing like that.\"";
        return base + mcReact;
    }

    private String slowDanceShy(String d, String mc) {
        if (d.equals("blackout"))
            return "Faint, clammy hand on your waist. You sag heavily; {npc_he} keeps you upright somehow. No thoughts form.";
        if (d.equals("drunk")) {
            String base = "Hand still hesitant on your waist, trembling slightly. You get bolder with the alcohol, "
                        + "sliding your hand up {npc_his} chest and murmuring something encouraging.";
            if (mc.equals("outgoing")) return base + "\n\nYou take the lead and tease {npc_him} into relaxing.";
            if (mc.equals("self_assured")) return base + "\n\nYou tell {npc_him} evenly: \"You're doing fine. Relax.\"";
            return base;
        }
        String tier = gameStageVariant();
        int roll = rng.nextInt(8);
        String base = switch (roll) {
            case 0 -> "Hand lightly resting on your waist, barely making contact, other hand barely holding yours, keeping a small gap as you both sway awkwardly.";
            case 1 -> "Clammy hand trembling on your waist, fingers barely curled, swaying with careful, overthought movements while {npc_he} avoids your eyes.";
            case 2 -> "One arm loosely around your side, the other holding your hand, maintaining respectful distance while you both move together nervously.";
            case 3 -> "Hand on your waist but constantly adjusting, other hand barely touching yours, swaying stiffly while {npc_he} clears {npc_his} throat.";
            case 4 -> "One hand lightly on your shoulder blade, the other holding yours at a polite distance, keeping a small gap as you sway.";
            case 5 -> "Arms around you but visibly tense, swaying with tiny, hesitant adjustments like {npc_he}'s terrified of doing it wrong.";
            case 6 -> "Hand hovering just above your waist before lightly landing, swaying carefully, entire body radiating self-consciousness.";
            default -> "Both hands lightly on your sides, barely touching, moving together with visible nervousness and a polite gap between you.";
        };
        String mcReact = tier.equals("enjoy")
            ? "\n\n*His shy, careful hold while we dance feels sweet and endearing. I want to make him relax.*"
            : tier.equals("shy")
                ? "\n\n*His nervous, hesitant posture while we sway makes me feel awkward too.*"
                : "\n\n*His light, trembling hand on my waist as we dance feels neutral — just two people moving together.*";
        switch (mc) {
            case "outgoing":    return base + mcReact + "\n\nYou reassure {npc_him} softly and pull {npc_him} closer.";
            case "self_assured": return base + mcReact + "\n\nYou tell {npc_him} calmly: \"You're fine — relax.\"";
            case "fragile_ego": return base + mcReact + "\n\n{npc_His} nervousness somehow makes you feel important; you cling gently.";
            default: return base + mcReact;
        }
    }

    private String slowDanceSelfAssured(String d, String mc) {
        if (d.equals("blackout"))
            return "Heavy, certain hand on your lower back. You sag against {npc_him}. Hazy warmth only.";
        if (d.equals("drunk")) {
            String base = "Hand locked low on your back, pulling hard. You feel every finger, every deliberate press. "
                        + "Alcohol makes you candid and you grind back without deciding to.";
            if (mc.equals("self_assured")) return base + "\n\nYou look {npc_him} in the eye: \"You take what you want, don't you?\"";
            if (mc.equals("provocative"))  return base + "\n\nYou press fully against {npc_him} and escalate openly.";
            return base;
        }
        String tier = gameStageVariant();
        int roll = rng.nextInt(8);
        String base = switch (roll) {
            case 0 -> "Firm hand claims your lower back, fingers spread wide, pulling you flush as you both sway with steady, unhesitating control.";
            case 1 -> "One hand pressing yours to {npc_his} chest, the other on your waist, swaying with calm authority while you feel {npc_his} heartbeat.";
            case 2 -> "Both arms around your waist, bodies pressed together, moving with deliberate confidence — no gap, no apology.";
            case 3 -> "Hand steady on your lower back, guiding every sway smoothly and without hesitation, like {npc_he}'s done this a thousand times.";
            case 4 -> "Hands firmly on your waist, swaying with clear, unhesitating leadership. You follow before you've decided to.";
            case 5 -> "One hand on your hip, the other on your lower back, moving you with assured rhythm. Controlled. Certain.";
            case 6 -> "Bodies aligned perfectly, arms around you, swaying with quiet dominance. No space. No question.";
            default -> "Arms wrapped securely around you, no gap, guiding the dance with confidence so solid it's almost boring.";
        };
        String mcReact = tier.equals("enjoy")
            ? "\n\n*His confident, direct hold while we dance feels strong and attractive.*"
            : tier.equals("shy")
                ? "\n\n*His firm, unhesitating posture while we sway feels too controlling.*"
                : "\n\n*His steady hold is noticeable as we dance, but I feel detached from it.*";
        switch (mc) {
            case "outgoing":    return base + mcReact + "\n\nYou grin and fire back \"Straight to it — I like that.\"";
            case "self_assured": return base + mcReact + "\n\nYou match {npc_him}: \"Good. I hate hesitation.\"";
            case "provocative": return base + mcReact + "\n\nYou press your body fully against {npc_his} and whisper \"More.\"";
            default: return base + mcReact;
        }
    }

    private String slowDanceConfrontational(String d, String mc) {
        if (d.equals("blackout"))
            return "Hand locked low on your back, possessive. Faint daring pressure. Body leans heavy; mind gone.";
        if (d.equals("drunk")) {
            String base = "Hand already cupping your ass, fingers digging in while {npc_he} watches your face. You laugh low and grind back.";
            if (mc.equals("confrontational")) return base + "\n\nYou call it out with a smirk: \"Bold move.\"";
            if (mc.equals("conflict_avoidant")) return base + "\n\nYou stay quiet but feel the charged tension between you.";
            if (mc.equals("provocative")) return base + "\n\nYou match the energy and push back harder.";
            return base;
        }
        String tier = gameStageVariant();
        int roll = rng.nextInt(8);
        String base = switch (roll) {
            case 0 -> "Grip on your waist with one hand sliding just above your ass — daring you to object while {npc_he} pulls you flush in time with the music.";
            case 1 -> "Challenging close press, hips forward against yours while swaying, watching your face for a reaction.";
            case 2 -> "Arm locked around your waist, pulling you in hard, the posture saying clearly: try to step back.";
            case 3 -> "Bold lower-back hold with fingers flexing possessively, swaying with the kind of confidence that's actually a dare.";
            case 4 -> "Aggressive hip pull while you both sway, his posture a constant low-grade challenge.";
            case 5 -> "Chest-to-chest lock while swaying, making eye contact and not breaking it, daring you to make it a thing.";
            case 6 -> "Testing finger flex on your lower back, gradually moving lower as you both move together, seeing how far it goes.";
            default -> "Possessive hand low on your back, owning the space between you while you both sway to the music.";
        };
        String mcReact = tier.equals("enjoy")
            ? "\n\n*His daring posture while we dance feels exciting. I like the tension.*"
            : tier.equals("shy")
                ? "\n\n*His challenging, possessive hold while we sway makes me feel tested and uncomfortable.*"
                : "\n\n*His daring pressure is there as we dance. I notice it but feel detached from the dare.*";
        switch (mc) {
            case "confrontational": return base + mcReact + "\n\nYou smirk: \"Trying to see if I'll push you off?\"";
            case "self_assured":    return base + mcReact + "\n\nYou meet the dare head-on without flinching.";
            case "provocative":     return base + mcReact + "\n\nYou grind forward and challenge {npc_him} right back.";
            case "conflict_avoidant": return base + mcReact + "\n\nYou stay quiet. Pick your battles.";
            default: return base + mcReact;
        }
    }

    private String slowDanceBoring(String d, String mc) {
        if (d.equals("blackout"))
            return "Faint, lifeless pressure somewhere on your body. You sag. No reaction from either of you.";
        if (d.equals("drunk")) {
            String base = "Same limp hand. You blurt \"This is kinda boring, huh?\"";
            if (mc.equals("outgoing")) return base + "\n\nYou laugh at the awkwardness and try to salvage it.";
            if (mc.equals("self_assured")) return base + "\n\nYou say it flat: \"You could at least try.\"";
            return base;
        }
        String tier = gameStageVariant();
        int roll = rng.nextInt(8);
        String base = switch (roll) {
            case 0 -> "Limp, damp hand on your waist, awkward gap, mechanical swaying with no sense that {npc_he} is actually here with you.";
            case 1 -> "A sort of handshake grip on your waist. {npc_He} sways stiffly, arms at odd angles, clearly thinking about something else.";
            case 2 -> "Flat, lifeless touch on your waist, no pressure either way, swaying in a way that's more like waiting than dancing.";
            case 3 -> "Passive, barely-there arm around your side, no warmth, no interest, just the mechanical fact of being close.";
            case 4 -> "Monotone hip touch with no rhythm, no adjustment, like {npc_he} learned slow dancing from a diagram.";
            case 5 -> "Awkward half-hold, swaying mechanically, the silence between you filled only by the song and {npc_his} occasional throat-clear.";
            case 6 -> "Lifeless palm press on your lower back, zero energy, moving together in the loosest sense of the word.";
            default -> "Dull, distant waist contact while you both move together. The song is doing all the work.";
        };
        String mcReact = tier.equals("enjoy")
            ? "\n\n*He's not great at this but there's something almost funny about how earnest he is.*"
            : tier.equals("shy")
                ? "\n\n*His limp, lifeless hold while we sway makes me feel invisible.*"
                : "\n\n*His flat, mechanical posture is just what it is. I don't feel much about it.*";
        if (mc.equals("outgoing"))    return base + mcReact + "\n\nYou still try to chat and make it fun anyway.";
        if (mc.equals("self_assured")) return base + mcReact + "\n\nYou say bluntly: \"This is pretty awkward.\"";
        return base + mcReact;
    }

    private String slowDanceStreetwise(String d, String mc) {
        if (d.equals("blackout"))
            return "Steady guiding hand. You move on autopilot; mind floats.";
        if (d.equals("drunk"))
            return "Sure hand on your lower back. You murmur \"You always know what to do.\" "
                 + "Body follows perfectly.";
        String tier = gameStageVariant();
        int roll = rng.nextInt(8);
        String base = switch (roll) {
            case 0 -> "Hand sure on your waist curve, perfect pressure — like {npc_he} read exactly where you needed it before you knew.";
            case 1 -> "Cool, measured lower-back palm with light guiding, adjusting to every shift of your weight without thinking about it.";
            case 2 -> "Close sway with confident pressure, {npc_his} body reading yours and responding before you signal anything.";
            case 3 -> "Subtle hip guide while keeping perfect rhythm — the posture of someone who dances well but doesn't perform it.";
            case 4 -> "Calm, aware waist lock, sensing every shift and adjusting quietly, no drama.";
            case 5 -> "Precise lower-back control while you both sway, the kind of hold that makes you feel like a good dancer too.";
            case 6 -> "Attentive side embrace, adjusting to your movement, always a half-second ahead of where you're going.";
            default -> "Quietly dominant hold, reading and responding to your sway with an ease that feels almost annoying.";
        };
        String mcReact = tier.equals("enjoy")
            ? "\n\n*His sure, observant hold while we dance feels good. He knows exactly what he's doing.*"
            : tier.equals("shy")
                ? "\n\n*His precise hold feels unsettling somehow. Like he's clocking everything.*"
                : "\n\n*His steady, adjusted pressure as we dance is just what it is. Neither good nor bad.*";
        if (mc.equals("outgoing"))    return base + mcReact + "\n\nYou tease \"You always know exactly how to hold someone.\"";
        if (mc.equals("self_assured")) return base + mcReact + "\n\nYou say \"Good read.\"";
        return base + mcReact;
    }

    private String slowDanceAlcoholic(String d, String mc) {
        if (d.equals("blackout"))
            return "Heavy, clumsy hands. You sag; distant boozy heat only.";
        if (d.equals("drunk")) {
            String base = "Messy sliding hands. You laugh and press closer anyway: \"You're a mess.\"";
            if (mc.equals("conflict_avoidant")) return base + "\n\nYou stay quiet and endure the sloppy sway.";
            if (mc.equals("outgoing")) return base + "\n\nYou laugh louder. \"A mess, but my mess tonight.\"";
            return base;
        }
        String tier = gameStageVariant();
        int roll = rng.nextInt(8);
        String base = switch (roll) {
            case 0 -> "Sweaty, heavy hands on your hips, using you for balance as much as dancing with you while he sways unevenly.";
            case 1 -> "Clumsy arm drape around your waist, swaying off-rhythm, boozy breath hot on your neck.";
            case 2 -> "Boozy close lean with hands sliding messily from your waist to your lower back and back again.";
            case 3 -> "Overly familiar hip lock while stumbling slightly — he's holding on as much as holding you.";
            case 4 -> "Damp, heavy waist grab while swaying heavily, thumbs rubbing the top of your ass without seeming to notice.";
            case 5 -> "Sloppy chest press, his weight shifting into you, breath boozy and warm on your neck.";
            case 6 -> "Unsteady hip hold, relying on you more than you'd like to stay upright while swaying.";
            default -> "Messy, familiar embrace while moving clumsily together, hands not quite knowing where to settle.";
        };
        String mcReact = tier.equals("enjoy")
            ? "\n\n*His sloppy, familiar hold while we dance is kind of funny — messy but not entirely unpleasant.*"
            : tier.equals("shy")
                ? "\n\n*His sweaty, clumsy hands while we sway feel gross and too familiar.*"
                : "\n\n*His heavy, boozy hold is what it is. I don't feel strongly about it.*";
        if (mc.equals("outgoing")) return base + mcReact + "\n\nYou laugh and tease \"You're a mess but it's cute.\"";
        return base + mcReact;
    }

    private String slowDanceSleazy(String d, String mc, boolean cont) {
        String tier = mcReactionTier();

        if (d.equals("blackout"))
            return cont
                ? "Still groping and squeezing rhythmically. The whole song and {npc_he} hasn't stopped. Faint pressure, spinning nothing."
                : "Groping and squeezing rhythmically. Faint pressure and heat. You sag into it; world is spinning nothing. No real reaction.";

        if (d.equals("drunk")) {
            String base = cont
                ? "Fingers have been digging deep the whole dance. {npc_He} grinds slower now, deliberate. Still going."
                : "Hard grope, fingers digging deep while {npc_he} grinds obvious against you.";
            switch (tier) {
                case "shock":
                    return base + (cont
                        ? "\n\n*{npc_He}'s been at this so long… I can hear myself not stopping {npc_him}.* [shaky breath]"
                        : "\n\nA weak flicker of \"this is too much\" then melts in the alcohol haze. You breathe heavier and let it happen.");
                case "enjoy":
                    return base + (cont ? "\n\nYou press harder. \"You've been at this so long… don't stop.\""
                                        : "\n\nYou escalate right back.");
                default:
                    return base + (cont ? "\n\nYou laugh shakily. \"You've been doing that the whole song…\""
                                        : "\n\nYou slur \"You're really pushing it…\" but don't stop {npc_him}.");
            }
        }
        // tipsy
        String base = cont
            ? "{npc_He}'s been groping your ass the whole dance. Hand still there. Still squeezing. Grinding slowly."
            : "{npc_He} yanks you flush; hand slides straight down and gropes your ass hard, fingers spreading, grinding {npc_his} hard-on against you.";
        switch (tier) {
            case "shock":
                return base + (cont
                    ? "\n\n*{npc_He}'s been groping me this whole time… everyone can see and I still haven't moved.* Face burning, body locked."
                    : "\n\nMind screams — *Oh god {npc_he}'s groping me right here — whole hand on my ass, squeezing — "
                    + "I should push her off, why am I frozen?* Face burns, stomach twists, "
                    + "but your body stays locked. The buzz blurs panic into shaky heat.");
            case "enjoy":
                return base + (cont ? "\n\nYou press back slowly. \"You're not stopping, are you.\""
                                    : "\n\nYou grind harder and whisper \"Like what you feel?\"");
            default:
                return base + (cont ? "\n\nYou've stopped pretending to be surprised by it."
                                    : "\n\nYou laugh nervously and grind back anyway, not sure what else to do.");
        }
    }

    private String slowDanceJerk(String d, String mc, boolean cont) {
        String tier = mcReactionTier();
        if (d.equals("blackout"))
            return cont ? "Hand still locked on ass. Same place it's been. Distant pressure. Mind gone."
                        : "Hand locked on ass. Distant pressure. You lean heavy; mind gone.";
        if (d.equals("drunk")) {
            String base = cont
                ? "{npc_He}'s been squeezing your ass the whole dance, smug about it."
                : "Hand drops straight to your ass, squeezing cockily. You laugh bitterly and grind back anyway.";
            if (tier.equals("shock"))  return base + (cont ? "\n\nYou've stopped trying to think about it." : "\n\nYou mutter something weak but don't stop {npc_him}.");
            if (tier.equals("enjoy"))  return base + (cont ? "\n\nYou lean back into it. Fine." : "\n\nYou push back into it. Might as well.");
            return base + (cont ? "\n\n\"Still at it, huh.\" You say it flat." : "\n\nYou slur \"You think you're hot shit, huh?\"");
        }
        String base = cont
            ? "{npc_His} hand's been just above your ass the whole time, grip tight and smug."
            : "Smug smirk, hand on your waist then sliding possessively just above your ass, grip too tight. You feel the arrogant pressure.";
        if (tier.equals("shock"))  return base + (cont ? "\n\nYou've stopped shifting away from it." : "\n\nYou stay quiet and endure.");
        if (tier.equals("enjoy"))  return base + (cont ? "\n\nYou've started pressing back. Somewhere it started feeling okay." : "\n\nYou roll your eyes but press back anyway.");
        return base + (cont ? "\n\n\"You're very comfortable with yourself, aren't you.\"" : "\n\nYou fire back \"Doing me a favor again?\" with a thin smile.");
    }

    private String pick(String... options) {
        return options[rng.nextInt(options.length)];
    }

    /**
     * Pick from a named text pool (mod-registered entries) merged with base game options.
     *
     * If the pool has mod entries AND base game options, all are eligible (mod extends base).
     * If the pool has ONLY mod entries, those are used exclusively.
     * If the pool has no entries and no base options, returns empty string.
     *
     * @param poolName   e.g. "bar.grope.breast.shy_mc"
     * @param traitFlags active traits/flags set for gate checks
     * @param base       base game options (may be empty)
     */
    private String pickFromPool(String poolName, java.util.Set<String> traitFlags,
                                String... base) {
        if (textPools == null) {
            return base.length > 0 ? pick(base) : "";
        }
        int modCount = textPools.getAll(poolName).size();
        if (modCount == 0) {
            return base.length > 0 ? pick(base) : "";
        }
        // Weight by entry count: each entry (mod or base) has equal probability
        // Total pool = modCount + base.length; pick from combined index
        int total = modCount + base.length;
        int roll  = rng.nextInt(total);
        if (roll < modCount) {
            // Pick from mod pool
            String modPick = textPools.pick(poolName, traitFlags, rng);
            return modPick != null ? modPick : (base.length > 0 ? pick(base) : "");
        } else {
            // Pick from base game options
            return base.length > 0 ? pick(base) : "";
        }
    }

    /** Convenience overload without trait gates. */
    private String pickFromPool(String poolName, String... base) {
        return pickFromPool(poolName, java.util.Collections.emptySet(), base);
    }

    /**
     * Build the active trait/flag set for the current MC state.
     * Used for TextPoolRegistry requires/blocks gate checking.
     */
    private java.util.Set<String> buildMcTraitSet() {
        java.util.Set<String> active = new java.util.HashSet<>();
        for (String t : state.traits)                active.add(t.toLowerCase());
        for (String t : state.timedTraits.keySet())  active.add(t.toLowerCase());
        // Add simple derived flags so mods can gate on e.g. "drunk_high", "braless"
        if (state.drunk >= 10)                       active.add("drunk_high");
        else if (state.drunk >= 5)                   active.add("drunk_mid");
        if (state.getBodyFlag("flag_is_braless"))      active.add("braless");
        if (state.getBodyFlag("flag_being_groped"))     active.add("being_groped");
        if (state.getBodyFlag("flag_grope_persisted"))  active.add("grope_persisted");
        if (state.getBodyFlag("flag_npc_sleazy"))       active.add("npc_sleazy");
        if (state.getBodyFlag("flag_dance_locked"))     active.add("dance_locked");
        if (state.arousal >= 60)                     active.add("arousal_high");
        else if (state.arousal >= 30)                active.add("arousal_mid");
        if (state.hasTrait("Shy"))                   active.add("shy_mc");
        if (state.hasTrait("Outgoing"))              active.add("outgoing_mc");
        if (state.hasTrait("Magnetic"))              active.add("magnetic_mc");
        if (state.hasTrait("Fragile_Ego"))           active.add("fragile_ego_mc");
        if (state.getBodyFlag("flag_nipping"))        active.add("nipping");
        if (state.getBodyFlag("flag_wearing_skirt"))  active.add("wearing_skirt");
        if (state.hasTrait("commando"))               active.add("commando");
        if (state.hasTrait("Confrontational")
         || state.hasTrait("Self_Assured"))          active.add("bold_mc");
        if (state.hasTrait("Conflict_Avoidant"))     active.add("conflict_avoidant_mc");
        // NPC tier shorthand
        int npcTier = java.lang.Math.min(5, state.currentNpcFrustration / 20);
        if (npcTier >= 3)  active.add("npc_tier_mid");
        if (npcTier >= 4)  active.add("npc_tier_high");
        if (npcTier >= 5)  active.add("npc_tier_max");
        return active;
    }

    /** Get the canonical pool key for an NPC personality trait. */
    private String getNpcPersonalityKey(NpcData n) {
        if (hasTrait(n, "Sleazy"))          return "sleazy";
        if (hasTrait(n, "Jerk"))            return "jerk";
        if (hasTrait(n, "Magnetic"))        return "magnetic";
        if (hasTrait(n, "Engaging"))        return "engaging";
        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover")) return "outgoing";
        if (hasTrait(n, "Self_Assured"))    return "self_assured";
        if (hasTrait(n, "Shy"))             return "shy";
        if (hasTrait(n, "Streetwise"))      return "streetwise";
        if (hasTrait(n, "Alcoholic"))       return "alcoholic";
        if (hasTrait(n, "Confrontational")) return "confrontational";
        if (hasTrait(n, "Boring"))          return "boring";
        return "default";
    }

    private String clothingReactionForDance(NpcData n, String d) {
        boolean commando   = state.hasTrait("commando");
        boolean camelToe   = state.hasTrait("camel_toe");
        boolean bigBounce  = state.hasTrait("bounce_prone_4") || state.hasTrait("bounce_prone_5")
                          || state.hasTrait("bounce_prone_6") || state.hasTrait("bounce_prone_7");
        boolean piercedNip = state.hasTrait("pierced_nipping_prominent");
        boolean nipping    = state.hasTrait("nipping") || state.hasTrait("arousal_nipping") || piercedNip;
        boolean bounce     = state.hasTrait("bounce_prone_3") || bigBounce;
        boolean braless    = state.hasTrait("exposed_breasts") || bigBounce;

        String trait = "";
        if (commando)        trait = "commando";
        else if (camelToe)   trait = "camel_toe";
        else if (bigBounce)  trait = "big_bounce";
        else if (piercedNip) trait = "pierced_nip";
        else if (nipping)    trait = "nipping";
        else if (bounce)     trait = "bounce";
        else if (braless)    trait = "braless";
        if (trait.isEmpty()) return "";

        boolean drunk = d.equals("drunk");
        boolean blackout = d.equals("blackout");

        if (hasTrait(n, "Engaging")) {
            if (blackout) return "{npc_He} keeps you upright with gentle hands, clearly noticing but saying nothing crude.";
            switch (trait) {
                case "commando":  return drunk ? "{npc_He} breathes a little heavier as grinding brings you flush, but keeps {npc_his} touch polite." : "{npc_His} hand stays respectfully high on your back even when you sway closer.";
                case "big_bounce": case "bounce": return drunk ? "{npc_He} glances at the gentle bounce again, cheeks faintly pink, still focused on your eyes." : "{npc_His} eyes flick down once as your chest moves, then quickly back to your face with a soft, appreciative smile.";
                case "pierced_nip": case "nipping": return drunk ? "A quick warm smile; {npc_he} murmurs \"You look beautiful tonight\" without making it awkward." : "{npc_He} notices the outline but keeps {npc_his} gaze respectful, thumb stroking your back more tenderly.";
                case "camel_toe": return drunk ? "{npc_His} hand stays steady on your back; you feel {npc_him} swallow but {npc_he} says nothing." : "She stays perfectly polite, though you feel her breathe a little deeper as your bodies press close.";
                default: return drunk ? "The freer movement makes {npc_him} hold you a little closer, still completely respectful." : "The soft warmth of you against {npc_his} chest feels more intimate; {npc_he} holds you gently, no wandering hands.";
            }
        }
        if (hasTrait(n, "Magnetic")) {
            if (blackout) return "{npc_He} keeps the firm hold, clearly enjoying every detail, but says nothing as you sag.";
            switch (trait) {
                case "commando":  return drunk ? "{npc_His} hand slips just under the hem for a second, feeling bare skin before returning." : "{npc_He} pulls you even tighter, clearly enjoying the lack of barrier.";
                case "big_bounce": case "bounce": return drunk ? "{npc_His} gaze lingers openly on your chest with each sway, intensity sharpening." : pick("{npc_His} intense eyes drop to watch the bounce for a long second before returning to yours, heat rising.", "{npc_He} watches you move with the kind of focus that makes the floor feel smaller.");
                case "pierced_nip": case "nipping": return drunk ? "Low voice against your ear: \"Those look incredible tonight.\"" : "A slow, appreciative smirk; {npc_he} doesn't look away from the outline.";
                case "camel_toe": return drunk ? "Fingers trace the curve of your hip deliberately." : "{npc_His} palm slides a fraction lower, still controlled.";
                default: return drunk ? "She presses you flush so the softness is unmistakable." : "The soft press of you makes {npc_his} hand tighten slightly on your back.";
            }
        }
        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover")) {
            if (blackout) return "{npc_He} still comments playfully and keeps you moving, enjoying the view even as you go limp.";
            switch (trait) {
                case "big_bounce": case "bounce": return drunk ? pick("{npc_He} openly watches the bounce and cheers \"Keep moving like that!\"", "\"God, that's distracting in the best way,\" {npc_he} laughs.") : pick("\"Whoa, look at that bounce!\" {npc_he} laughs, eyes bright and playful.", "{npc_He} gives a loud appreciative noise and grins at you.");
                case "pierced_nip": case "nipping": return drunk ? "\"Those piercings are killing me,\" {npc_he} laughs loud." : "\"Damn, those are saying hi tonight,\" {npc_he} teases with a grin.";
                case "camel_toe": return drunk ? "\"That outline is distracting in the best way.\"" : pick("Playful hip squeeze while glancing down with a grin.", "{npc_He} catches it and raises {npc_his} eyebrows appreciatively.");
                case "commando":  return drunk ? "{npc_His} hand slips under the hem teasingly, feeling nothing underneath, laughing low." : "\"Feels like you came ready to party,\" {npc_he} whispers with a wink.";
                default: return drunk ? "Full playful bounces with {npc_his} hands on your hips, grinning." : "{npc_He} bounces you lightly on purpose, laughing at the free movement.";
            }
        }
        if (hasTrait(n, "Shy")) {
            if (blackout) return "She stays awkwardly supportive, still visibly flustered by every detail.";
            if (drunk) {
                if (trait.equals("big_bounce") || trait.equals("bounce")) return "Blushing intensifies as she tries and fails not to stare.";
                if (trait.equals("pierced_nip") || trait.equals("nipping")) return "\"I… uh… they're really noticeable,\" {npc_he} mumbles, mortified.";
                return "{npc_He} gets even more awkward and flustered but doesn't pull away.";
            }
            switch (trait) {
                case "big_bounce": case "bounce": return "{npc_His} eyes widen at the bounce; she blushes hard and looks away fast.";
                case "pierced_nip": case "nipping": return "Face goes bright red; {npc_he} stammers and keeps {npc_his} gaze on your shoulder.";
                case "commando":  return "She freezes for a second when {npc_his} hand brushes lower, clearly realizing.";
                case "camel_toe": return "Quick nervous glance down, then back up.";
                default: return "{npc_He} swallows visibly, hand trembling slightly on your waist.";
            }
        }
        if (hasTrait(n, "Self_Assured")) {
            if (blackout) return "{npc_He} keeps the confident hold, enjoying every detail while you're limp.";
            if (drunk) {
                if (trait.equals("big_bounce") || trait.equals("bounce")) return "\"That bounce is doing things to me.\"";
                if (trait.equals("pierced_nip") || trait.equals("nipping")) return "\"Those are on full display tonight.\"";
                return "{npc_He} takes full advantage, hands and eyes bold and unapologetic.";
            }
            switch (trait) {
                case "big_bounce": case "bounce": return "\"Love how those move,\" {npc_he} says smoothly.";
                case "pierced_nip": case "nipping": return "Direct glance and a confident smirk.";
                case "camel_toe":  return "Hand slides down your hip deliberately.";
                case "commando":   return "\"No panties… bold choice. I approve.\"";
                default:           return "She presses you closer to feel the softness without comment.";
            }
        }
        if (hasTrait(n, "Confrontational")) {
            if (blackout) return "{npc_He} keeps groping and commenting challengingly even as you sag.";
            if (drunk)    return pick("{npc_He} openly calls it out and turns it into a dare.", "Groping every detail like {npc_he}'s daring you to object.");
            switch (trait) {
                case "big_bounce": case "bounce": return "\"Those are bouncing just for me, huh?\" Challenging smirk.";
                case "pierced_nip": case "nipping": return "\"Nipples saying hello already?\"";
                case "camel_toe":  return "\"That outline is practically begging for attention.\"";
                case "commando":   return "Hand slides straight under the hem to confirm, daring you to stop {npc_him}.";
                default:           return "Hand tests the softness deliberately.";
            }
        }
        if (hasTrait(n, "Boring")) {
            if (blackout) return "Zero reaction; {npc_he} just holds you mechanically.";
            return pick("{npc_He} barely registers it; a flat \"huh\" and nothing more.", "{npc_His} eyes drift over it with about the same enthusiasm as a weather report.", "No real reaction. Maybe a slow blink.");
        }
        if (hasTrait(n, "Streetwise")) {
            if (blackout) return "Still guides you smoothly, clearly noticing everything.";
            if (drunk)    return pick("Calm, knowing comments while keeping perfect rhythm.", "{npc_He} notices. Says something low and unhurried about it.");
            switch (trait) {
                case "big_bounce": case "bounce": return "Quiet appreciative glance: \"Nice movement.\"";
                case "pierced_nip": case "nipping": return "Cool smirk. \"Subtle but effective.\"";
                case "camel_toe":  return "Observant hand traces the curve of your hip knowingly.";
                case "commando":   return "Low chuckle. \"Bold choice. Respect.\"";
                default:           return "\"Feeling everything tonight, huh?\"";
            }
        }
        if (hasTrait(n, "Alcoholic")) {
            if (blackout) return "Still paws at everything clumsily while keeping you upright.";
            if (drunk)    return pick("Even sloppier groping and loud sloppy comments.", "Hands wander everywhere with boozy enthusiasm.");
            switch (trait) {
                case "big_bounce": case "bounce": return "\"Look at 'em bounce… heh.\"";
                case "pierced_nip": case "nipping": return "Sloppy stare and a big grin.";
                case "camel_toe":  return "Rubs against it clumsily without comment.";
                case "commando":   return "Tries to slide {npc_his} hand under immediately.";
                default:           return "Hands paw freely at the softness.";
            }
        }
        if (hasTrait(n, "Sleazy")) {
            if (blackout) return "Keeps groping and grinding every visible trait while you're completely limp.";
            switch (trait) {
                case "big_bounce": case "bounce": return drunk ? pick("\"Look at those tits go,\" {npc_he} mutters against your ear.", "{npc_He} gropes your chest openly, eyes locked on the bounce.") : pick("\"Fuck, those tits are bouncing perfect.\"", "{npc_His} eyes lock onto the movement. \"Jesus. Don't stop doing that.\"");
                case "pierced_nip": case "nipping": return drunk ? "{npc_He} tugs the fabric aside to get a better look." : "\"Nipples out and proud — love it.\"";
                case "camel_toe":  return drunk ? "Grinds directly against the outline, watching your face." : "Grinds right against the outline, openly.";
                case "commando":   return drunk ? "Hand goes under the hem immediately, fingers finding bare skin and spreading." : "Hand goes straight under the hem, fingers finding bare skin immediately.";
                default:           return drunk ? "Gropes your chest openly while grinding, making no pretense of subtlety." : pick("Both hands go straight to your chest.", "Hand slides up from your waist without hesitation.");
            }
        }
        if (hasTrait(n, "Jerk")) {
            if (blackout) return "Keeps the smug, possessive hold on every visible trait while you sag.";
            if (drunk)    return pick("Arrogant, backhanded comment and an entitled grab.", "{npc_He} makes a smug remark and helps himself.");
            switch (trait) {
                case "big_bounce": case "bounce": return "\"Not bad bounce for a girl like you.\"";
                case "pierced_nip": case "nipping": return "\"Trying to show those off?\"";
                case "camel_toe":  return "\"That's practically an invitation.\"";
                case "commando":   return "Hand immediately checks under the hem with an arrogant smirk.";
                default:           return "Smug squeeze of the softness.";
            }
        }
        return "";
    }

    private String slowDanceDefault(String d, String mc) {
        if (d.equals("blackout")) return "Warm hand somewhere on your back. Everything is distant and slow.";
        if (d.equals("drunk"))    return "Hand firm on your lower back. You sway and say something honest without meaning to.";
        int roll = rng.nextInt(3);
        return switch (roll) {
            case 0 -> "Hand steady on your lower back. The music carries you both for a moment.";
            case 1 -> "{npc_He} holds you close, one hand on your back, swaying to the slow beat without much said between you.";
            default -> "A warm hand somewhere around your waist. You both sway. The song does the rest.";
        };
    }



    /**
     * Selects the NPC pool for the current bar visit.
     * Call this when the bar_night scene first loads (not on loop returns).
     */
    public void populateBar() {
        // Identify boss and coworkers for current job — 5% chance each to appear
        java.util.Set<String> workColleagues = new java.util.HashSet<>();
        if (jobs != null && state.currentJobId != null) {
            game.data.JobData job = jobs.get(state.currentJobId);
            if (job != null) {
                if (!job.boss_npc_id.isEmpty()) workColleagues.add(job.boss_npc_id);
                workColleagues.addAll(job.coworker_npc_ids);
            }
        }

        // Build eligible pool — exclude work colleagues unless they roll 5%
        List<NpcData> eligible = npcs.getAll().stream()
            .filter(n -> !n.work_only && !n.id.isEmpty())
            .filter(n -> !workColleagues.contains(n.id) || rng.nextDouble() < WORK_COLLEAGUE_BAR_CHANCE)
            .collect(Collectors.toList());

        List<NpcData> males   = eligible.stream().filter(n -> "MALE".equalsIgnoreCase(n.type)).collect(Collectors.toList());
        List<NpcData> females = eligible.stream().filter(n -> "FEMALE".equalsIgnoreCase(n.type)).collect(Collectors.toList());

        Collections.shuffle(males,   rng);
        Collections.shuffle(females, rng);

        int maleCount   = Math.min(males.size(),   TARGET_MALE_MIN   + rng.nextInt(TARGET_MALE_MAX   - TARGET_MALE_MIN   + 1));
        int femaleCount = Math.min(females.size(), TARGET_FEMALE_MIN + rng.nextInt(TARGET_FEMALE_MAX - TARGET_FEMALE_MIN + 1));

        state.currentBarNpcs.clear();
        males.stream().limit(maleCount).forEach(n -> state.currentBarNpcs.add(n.id));
        females.stream().limit(femaleCount).forEach(n -> state.currentBarNpcs.add(n.id));

        // Shuffle the combined list so gender groups aren't always segregated in display
        Collections.shuffle(state.currentBarNpcs, rng);
    }

    // ── Room description ──────────────────────────────────────────────────────

    /**
     * Builds the "who's in the bar" text used by the {bar_npc_list} token.
     */
    public String buildRoomDescription() {
        if (state.currentBarNpcs.isEmpty())
            return "The bar is quiet tonight. A few strangers, nobody you can place.";

        StringBuilder sb = new StringBuilder();
        for (String id : state.currentBarNpcs) {
            NpcData n = npcs.get(id);
            if (n == null) continue;
            sb.append(n.name).append(" — ").append(describeNpc(n)).append("\n\n");
        }
        return sb.toString().trim();
    }

    /**
     * Returns a one-line spotted-across-the-bar description.
     * Uses bar_desc if set, otherwise generates from appearance fields.
     */
    private String describeNpc(NpcData n) {
        if (!n.bar_desc.isEmpty()) return n.bar_desc;

        // Generate from appearance fields
        String ageDesc = ageDescriptor(n.age);
        String hair    = (n.hair_color + " " + n.hair_style).trim().toLowerCase();
        String build   = n.figure.toLowerCase();

        // Pull one personality cue
        String vibe = personalityVibe(n);

        return String.format("%s, %s hair, %s build. %s", ageDesc, hair, build, vibe);
    }

    private String ageDescriptor(String age) {
        switch (age.toUpperCase()) {
            case "TEEN":         return "young";
            case "YOUNG_ADULT":  return "mid-twenties";
            case "ADULT":        return "thirties";
            case "MIDDLE_AGED":  return "mid-forties";
            case "OLDER_ADULT":  return "late forties or fifties";
            case "OLDER":        return "older";
            default:             return age.toLowerCase();
        }
    }

    private String personalityVibe(NpcData n) {
        // Check traits first for specific vibe
        if (hasTrait(n, "Magnetic"))        return "Something about them draws the eye.";
        if (hasTrait(n, "Engaging"))         return "They look like good conversation.";
        if (hasTrait(n, "Confrontational"))  return "Sharp eyes. Not someone to underestimate.";
        if (hasTrait(n, "Shy"))              return "Quiet, keeping to themselves.";
        if (hasTrait(n, "Antisocial"))       return "Clearly here for the drink, not the crowd.";
        if (hasTrait(n, "Outgoing"))         return "Already talking to half the room.";
        if (hasTrait(n, "Mysterious"))       return "Hard to read. Not trying to be easy.";
        if (hasTrait(n, "Thoughtful"))       return "Listening more than talking.";
        if (hasTrait(n, "Creative_Type"))    return "Has that particular quality of someone who makes things.";
        if (hasTrait(n, "Well_Read"))        return "The kind of quiet that comes from knowing a lot.";
        if (hasTrait(n, "Self_Assured"))     return "Comfortable in the space. Not trying.";
        if (hasTrait(n, "Flirty"))           return "Already aware they're being looked at.";
        if (hasTrait(n, "Driven"))           return "That particular focus that doesn't fully switch off.";
        if (hasTrait(n, "Warm"))             return "Easy to approach. Probably easy to talk to.";
        if (hasTrait(n, "Reliable"))         return "Looks like someone you could trust with something.";
        if (hasTrait(n, "Protective"))       return "Takes up space like they mean to.";
        // Fall back to personality field
        switch (n.personality.toUpperCase()) {
            case "WARM":     return "Easy manner, open face.";
            case "COLD":     return "Keeps to themselves.";
            case "CARING":   return "Looks approachable.";
            case "SELFISH":  return "Got that look like they know they're worth watching.";
            case "OUTGOING": return "Looks like they came here to talk to someone.";
            case "NEUTRAL":  return "Hard to read from here.";
            default:         return "Hard to read from here.";
        }
    }

    boolean hasTrait(NpcData n, String trait) {
        return n.traits.stream().anyMatch(t -> t.equalsIgnoreCase(trait));
    }

    /** Called by Engine to check rep_bypass_traits against the current NPC. */
    public boolean currentNpcHasTrait(String trait) {
        NpcData n = npcs.get(state.currentApproachingNpc);
        return n != null && hasTrait(n, trait);
    }

    /**
     * Per-turn frustration gain for the current approaching NPC.
     * Sleazy and Jerk are impatient. Shy and Engaging are patient.
     */
    public int npcFrustrationRate() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return 5;
        if (hasTrait(n, "Sleazy"))                               return 10;
        if (hasTrait(n, "Jerk"))                                 return 9;
        if (hasTrait(n, "Boring"))                               return 8;
        if (hasTrait(n, "Alcoholic") || hasTrait(n, "Confrontational")) return 7;
        if (hasTrait(n, "Engaging") || hasTrait(n, "Magnetic"))  return 4;
        if (hasTrait(n, "Shy"))                                  return 3;
        return 5;
    }

    /**
     * Maximum drunk level this NPC will push the MC toward.
     * Sleazy wants her near-blackout (18). Most NPCs stop around tipsy (10).
     */
    public int npcDrunkLimit() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return 10;
        if (hasTrait(n, "Sleazy"))                               return 18;
        if (hasTrait(n, "Alcoholic"))                            return 15;
        if (hasTrait(n, "Engaging") || hasTrait(n, "Shy"))       return 8;
        if (hasTrait(n, "Magnetic"))                             return 8;
        return 10;
    }

    /** True if MC is already at or above NPC's drunk limit. */
    public boolean mcAtNpcDrunkLimit() {
        return state.drunk >= npcDrunkLimit();
    }

    /**
     */
    /**
     * MC successfully refuses a drink — no Alcoholic trait.
     * NPC response varies by personality. MC internal thought by rep tier.
     * Token: {bar_drink_refusal_text}
     */
    public String buildDrinkRefusalText() {
        NpcData n    = npcs.get(state.currentApproachingNpc);
        String  tier = gameStageVariant();
        String  d    = drunkTier();

        // MC internal — how it feels to say no
        String mcThought = switch (tier) {
            case "enjoy" ->
                d.equals("sober") ? "*Good call. I like being the one in control of this.*"
                                  : "*The buzz I have is exactly right. I'm keeping it here.*";
            case "flustered" ->
                "*I probably should slow down. That was the right call.*";
            default ->
                "*Thank you for not pushing it. Please don't push it.*";
        };

        // NPC response by personality
        if (n == null) return "They take it in stride.\n\n" + mcThought;

        String npcLine;
        if (hasTrait(n, "Engaging"))
            npcLine = "\"No worries at all.\" {npc_He} signals the bartender for water instead. \"Good call honestly.\"";
        else if (hasTrait(n, "Magnetic"))
            npcLine = "{npc_He} nods once. No commentary. It lands as respect.";
        else if (hasTrait(n, "Shy"))
            npcLine = "\"Oh — yeah, no, of course.\" {npc_He} looks almost relieved. \"I wasn't trying to pressure you.\"";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcLine = "{npc_He} laughs softly. \"Fair enough! More for me then.\" No edge to it.";
        else if (hasTrait(n, "Self_Assured"))
            npcLine = "\"Good.\" Just that. Like it was the right answer all along.";
        else if (hasTrait(n, "Sleazy"))
            npcLine = "\"Aw, come on — one more won't hurt. It's good stuff.\"\n\n"
                    + "{npc_He} tilts the glass toward you, grin easy and unhurried.\n\n"
                    + "You hold your ground. {npc_He} reads it and sets the bottle down — "
                    + "not away, just down. Still visible. \"Fine. Your call.\"";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_He} lets out a short breath and sets the bottle down with a bit more force than needed.\n\n"
                    + "\"Come on, it's just a drink. You were having fun earlier — don't get all serious on me now.\"\n\n"
                    + "{npc_His} jaw tightens slightly. The easy charm cracks just enough to show the irritation underneath.\n\n"
                    + "You don't apologise. Eventually {npc_he} shrugs it off.";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "\"You sure?\" {npc_He} tilts {npc_his} head. One beat of silence. Then: \"Fair.\"";
        else
            npcLine = "{npc_He} takes it in stride. The conversation continues.";

        return npcLine + "\n\n" + mcThought;
    }

    public String buildAlcoholicCantRefuseText() {
        String d    = drunkTier();
        String tier = gameStageVariant();

        if (d.equals("blackout")) {
            return "Your hand moves before the decision is fully formed.\n\n"
                 + (tier.equals("enjoy")
                    ? "\"Guess I'm not stopping yet,\" you hear yourself say.\n\n"
                      + "*Willpower. What willpower. One more sounds perfect right now.*"
                    : tier.equals("flustered")
                    ? "Your fingers close around the glass before your brain catches up.\n\n"
                      + "*I know I should refuse… but the words just came out. I'm too far gone to fight it.*"
                    : "*I… I can't refuse. I never can when it gets like this.*\n\n"
                      + "You bring it to your lips without another word.");
        }

        if (d.equals("drunk")) {
            return (tier.equals("enjoy")
                    ? "He offers it and you grin, already reaching.\n\n"
                      + "\"Guess I'm not stopping yet,\" you say, clinking glasses before thinking.\n\n"
                      + "*There goes my willpower again. Who cares. I'm having too much fun to stop now.*"
                    : tier.equals("flustered")
                    ? "\"One more can't hurt,\" you hear yourself say.\n\n"
                      + "You weren't going to have another. You knew that.\n\n"
                      + "*I know I should refuse… but my willpower is completely gone tonight. Just one more. I'll stop after this.*"
                    : "You want to say no. You really do.\n\n"
                      + "Your hand moves on its own and takes the glass.\n\n"
                      + "\"…Okay,\" you whisper, already feeling guilty. "
                      + "*I hate how weak I am right now… but it feels so good going down.*");
        }

        // tipsy — the crack in the resolve
        return (tier.equals("enjoy")
                ? "\"Tempting, but I'm—\" you start.\n\n"
                  + "You don't finish the sentence. The glass is already in your hand.\n\n"
                  + "*I was going to cut myself off. Apparently not tonight.*"
                : tier.equals("flustered")
                ? "You were going to say no. You had the word ready.\n\n"
                  + "Instead you hear yourself say \"thanks\" and feel the cold glass settle into your palm.\n\n"
                  + "*Just one more. I'll stop after this one. I always tell myself that.*"
                : "You hesitate. The craving is familiar — the way it shows up like an old friend before your resolve can catch up.\n\n"
                  + "You take the drink. You knew you were going to.\n\n"
                  + "*I didn't want another one. Why can't I just say no?*");
    }

    /**
     * Returns a drink modifier note for display when Alcoholic/Lightweight trait active.
     * Shows adjusted buzz value so player understands the modifier.
     * e.g. "Beer (+2 buzz, −1 tolerance)" or "Beer (+4 buzz, +1 lightweight)"
     */
    public String drinkModNote(String drinkName, int baseBuzz) {
        int mod = state.drunkMod();
        if (mod == 0) return "";
        int effective = Math.max(0, baseBuzz + mod);
        String traitName = state.hasTrait("Alcoholic") ? "tolerance" : "lightweight";
        return String.format("\n(%s: %+d buzz, %+d %s → %d effective)",
            drinkName, baseBuzz, mod, traitName, effective);
    }

    /**
     * What the NPC orders — used by {npc_order_text} token.
     * Sleazy orders shots. Boring orders the same drink twice.
     * Engaging asks what she wants. Default suggests a round.
     */
    public String buildNpcOrderText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "flags down the bartender and orders a round.";
        String they = "MALE".equalsIgnoreCase(n.type) ? "{npc_He}" : "{npc_He}";
        if (hasTrait(n, "Sleazy"))
            return they + " signals the bartender without asking. "
                 + "Two shots arrive before you've agreed to anything.";
        if (hasTrait(n, "Alcoholic"))
            return they + " orders another of whatever {npc_he}'s having — and one for you.";
        if (hasTrait(n, "Boring"))
            return they + " orders two of the same thing. Doesn't ask what you want.";
        if (hasTrait(n, "Engaging") || hasTrait(n, "Magnetic"))
            return they + " tilts their head toward the bar. \"What are you drinking?\"";
        if (hasTrait(n, "Shy"))
            return they + " hesitates, then quietly flags down the bartender. "
                 + "\"Can I — would you want another?\"";
        return they + " flags the bartender and nods toward you. \"Another round?\"";
    }

    /**
     * Continuation ass groping text — used when flagAssGroped is already true.
     * NPC commentary shifts to "still going" framing.
     * Tier: shy / flustered / enjoy from gameStageVariant().
     */
    /**
     * NPC whispers dirty talk directly in MC's ear during close dancing.
     * Threshold: whisper context (slut_rep + drunk*2 >= 25 for enjoy).
     * Requires: kissed + neck_kissed flags. Primarily Sleazy/Jerk.
     * Token: {bar_dirty_whisper_text}
     */
    public String buildDirtyWhisperText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_He} breathes something against your ear.";
        // Check mod pool for whisper lines from this NPC personality
        String whisperPool = "bar.dirty_whisper." + getNpcPersonalityKey(n);
        String modWhisper  = pickFromPool(whisperPool, buildMcTraitSet());
        if (modWhisper != null && !modWhisper.isEmpty()) return modWhisper;
        String d    = drunkTier();
        String tier = gameStageVariant("whisper");

        if (d.equals("blackout"))
            return "{npc_His} voice is low and very close. Words don't fully form — just warmth and the shape of sounds.";

        // Pick one of 4 dirty talk lines randomly
        int roll = rng.nextInt(4);

        // ── MC reaction by tier (shared across NPC types) ─────────────────────
        // Assembled after NPC line below

        if (hasTrait(n, "Sleazy")) {
            // Lines reference breast/ass/pussy groping — contextually appropriate
            String npcLine = switch (roll) {
                case 0 -> "\"Fuck, look at these hard nipples poking through... you're begging for attention, aren't you?\""
                          + " " + "\"Your pussy getting wet for me yet? I can feel how you're trembling.\"";
                case 1 -> "\"God damn, your tits are so fucking perky. I can see your nipples begging to be played with while we dance.\"";
                case 2 -> "\"This ass feels so fucking good in my hand. I can feel you getting wet while we dance.\"";
                default -> d.equals("drunk")
                    ? "\"Ass in my hands, tits getting squeezed — I bet your pussy's dripping right now while I whisper how I'd use you in front of everyone.\""
                    : "\"Been groping this ass the whole time. Your pussy getting wet for me? I can feel how you're trembling.\"";
            };
            String mcReact = tier.equals("enjoy")
                ? "You shiver and whisper back against {npc_his} shoulder. \"Keep going.\""
                  + "\n\n*His filthy talk while he gropes me while we dance... it's so crude and it's turning me on.*"
                : tier.equals("flustered")
                    ? "*The things {npc_he}'s whispering while he touches me... it's too dirty. Your face burns even hotter.*"
                    : "*{npc_His} words land in your ear while {npc_his} hands are everywhere. Every syllable is mortifying. "
                      + "His crude dirty talk while he's inside me makes the violation feel even worse.*";
            return npcLine + "\n\n" + mcReact;
        }

        if (hasTrait(n, "Jerk")) {
            String npcLine = switch (roll) {
                case 0 -> "\"You act all innocent but your body's begging for it. Feel how wet you are while we dance?\"";
                case 1 -> "\"Look at you, letting me grope you on the dance floor. You know what that makes you, right?\"";
                case 2 -> "\"Your nipples are rock hard and your pussy is soaked. Keep dancing.\"";
                default -> d.equals("drunk")
                    ? "\"Groping your ass, kissing that mediocre mouth — your pussy is probably average at best but I'll use it if I feel like it.\""
                    : "\"You think I don't notice how much you're letting me do? You're practically begging for it.\"";
            };
            String mcReact = tier.equals("enjoy")
                ? "The arrogance lands somewhere hot. You press back against {npc_him}."
                  + "\n\n*His arrogant dirty talk while he touches me... the cockiness is turning me on more than I want to admit.*"
                : tier.equals("flustered")
                    ? "*{npc_His} whispers are mean and somehow that makes them worse. Your cheeks burn.*"
                    : "*{npc_He}'s saying all of that right in your ear. His smug, backhanded talk while he's inside me makes me feel cheap and angry.*";
            return npcLine + "\n\n" + mcReact;
        }

        if (hasTrait(n, "Alcoholic")) {
            String npcLine = switch (roll) {
                case 0 -> "\"Fuck baby, you're so wet down there... let me feel more while we dance, sweetheart.\"";
                case 1 -> "\"God, your pussy feels so good on my fingers. You like when I touch you like this, don't you?\"";
                case 2 -> "\"Mmm, you're dripping for me. Keep dancing while I play with you, pretty girl.\"";
                default -> "\"Shit, I can feel how soaked you are. My fingers are gonna stay right here while we slow dance.\"";
            };
            String mcReact = tier.equals("enjoy")
                ? "*His sloppy, familiar dirty talk while he fingers me feels messy but arousing in the moment.*"
                : tier.equals("flustered")
                    ? "*His messy words while he touches me... it registers, but I don't feel much.*"
                    : "*His boozy, overly familiar talk while he's inside me feels gross and degrading.*";
            return npcLine + "\n\n" + mcReact;
        }

        if (hasTrait(n, "Confrontational")) {
            String npcLine = switch (roll) {
                case 0 -> "\"You say stop but your pussy is clenching around my finger. Admit you want this while we dance.\"";
                case 1 -> "\"Look at you, letting me finger you on the dance floor. You're not fighting very hard, are you?\"";
                case 2 -> "\"Your body's saying yes even if your mouth says no. Keep dancing while I finger you deeper.\"";
                default -> "\"Feel that? My fingers are inside you while we slow dance. You're not stopping me, are you?\"";
            };
            String mcReact = tier.equals("enjoy")
                ? "*His challenging dirty talk while he fingers me... the dare makes it thrilling.*"
                : tier.equals("flustered")
                    ? "*He's daring me with his talk while fingering me... I hear it, but feel detached.*"
                    : "*His testing, confrontational words while he's inside me make the violation feel worse.*";
            return npcLine + "\n\n" + mcReact;
        }

        if (hasTrait(n, "Magnetic")) {
            String npcLine = "Low against your ear, almost no sound at all: \"Touching you everywhere… and you're not stopping me.\"\n\nA pause. \"Good.\"";
            return npcLine + "\n\n" + (tier.equals("enjoy")
                ? "Something in the simplicity of it hits differently. You press closer."
                : "*{npc_He} noticed. Of course {npc_he} noticed. Your skin prickles.*");
        }

        if (hasTrait(n, "Self_Assured")) {
            return "\"I'm going to keep touching you and you're going to let me.\" Said quietly. Matter of fact.\n\n"
                + (tier.equals("enjoy")
                    ? "\"Yes,\" you breathe. No hesitation."
                    : "*{npc_He}'s stating it like it's already decided. And {npc_he}'s not wrong.*");
        }

        return "{npc_He} says something low against your ear. The words are less important than the heat of {npc_his} breath.";
    }

    /**
     * MC actively feels the NPC up — hands sliding over his chest, back, sides.
     * Player-initiated. NPC reacts with surprise/enjoyment but doesn't immediately escalate.
     * Token: {bar_feel_him_up_text}
     */
    public String buildFeelHimUpText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "You let your hands move more deliberately against her.";

        String d    = drunkTier();
        String tier = gameStageVariant();

        // Base MC action
        String base = switch (tier) {
            case "enjoy" ->
                "You slide your hands deliberately over {npc_his} chest, feeling the firmness of {npc_his} muscles, "
                + "then trail them around to {npc_his} back and pull her a little closer.\n\n"
                + "*Mmm — {npc_he} feels really good under my hands. I like being the one doing the touching for once.*";
            case "flustered" ->
                "You let your hands move slowly across {npc_his} chest and down {npc_his} sides, "
                + "feeling the solid warmth beneath {npc_his} shirt.\n\n"
                + "It feels intimate but not overwhelming. You stay quiet, simply exploring.";
            default ->
                "Your hands tremble slightly as you slide them over {npc_his} chest and around to {npc_his} back.\n\n"
                + "*Oh god, I'm actually doing this… What if {npc_he} thinks I'm being too forward?*\n\n"
                + "Your touch is light and hesitant, almost ready to pull away at any second.";
        };

        // Drunk flavour
        String drunkNote = switch (d) {
            case "drunk" -> "\n\nYour hands are slightly clumsy, lingering longer than you meant.";
            case "blackout" -> "\n\nYour hands move without much direction. Everything feels warm and slow.";
            default -> "";
        };

        // NPC reaction
        String npcReact;
        if (hasTrait(n, "Sleazy"))
            npcReact = "\n\n" + n.name + " groans low in {npc_his} throat. \"Mmm — keep feeling me up like that.\" "
                     + "{npc_His} own hands stay where they are for now.";
        else if (hasTrait(n, "Jerk"))
            npcReact = "\n\n" + n.name + " smirks. \"Didn't expect you to get handsy first. Not complaining.\"";
        else if (hasTrait(n, "Engaging"))
            npcReact = "\n\n" + n.name + " lets out a soft, pleased breath and smiles down at you. "
                     + "\"That feels nice,\" {npc_he} says quietly, keeping {npc_his} own hands gentle on your waist.";
        else if (hasTrait(n, "Magnetic"))
            npcReact = "\n\n" + n.name + " stills for a moment as {npc_he} registers your touch, then relaxes into it. "
                     + "{npc_His} eyes darken slightly but she stays silent, simply letting you explore.";
        else if (hasTrait(n, "Shy"))
            npcReact = "\n\n" + n.name + " tenses at first, then blushes hard. "
                     + "\"U-um… your hands feel good,\" {npc_he} stammers softly, clearly flustered but happy.";
        else if (hasTrait(n, "Self_Assured"))
            npcReact = "\n\n" + n.name + " looks down at you with a small, satisfied smile. "
                     + "\"Bold move. I like it,\" {npc_he} says steadily.";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcReact = "\n\n" + n.name + " grins and lets out a warm laugh. "
                     + "\"Go ahead — I like where your hands are going.\"";
        else if (hasTrait(n, "Confrontational"))
            npcReact = "\n\n" + n.name + " goes still for a beat, watching your face. "
                     + "\"Interesting move,\" {npc_he} says. {npc_He} doesn't stop you.";
        else
            npcReact = "\n\nHe registers your touch with a slow exhale. {npc_His} hands don't move. {npc_He} lets you continue.";

        return base + drunkNote + npcReact;
    }

    public String buildAssGropeText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hands are still there.";
        String d    = drunkTier();
        String tier = gameStageVariant();
        boolean roaming = state.flagBreastGroped;

        state.flagAssGroped = true;

        // ── Blackout collapses all NPC types ─────────────────────────────────
        if (d.equals("blackout")) {
            if (roaming) return "*Warm pressure everywhere... hands on my chest, on my ass. The spinning room makes it impossible to separate the sensations.*";
            return "*Warm pressure... on my ass. Moving. The spinning room makes it hard to tell how it feels.*";
        }

        // ── Roaming (ass + breast both groped) ───────────────────────────────
        if (roaming) {
            String npcLine;
            if (hasTrait(n, "Sleazy"))
                npcLine = d.equals("drunk")
                    ? "\"This body's been my playground for a while now. Ass, tits, hips — I'm taking my time and you're just letting me.\""
                    : "\"Been mapping out your whole body with my hands this whole song. Ass feels great, tits are soft — you're not stopping me.\"";
            else if (hasTrait(n, "Jerk"))
                npcLine = d.equals("drunk")
                    ? "\"Groping all of you for a while now. Mediocre, but convenient.\"  He smirks."
                    : "\"Your ass, your chest — I've had my hands everywhere this whole song. That's just where we are.\"";
            else
                npcLine = "{npc_His} hands keep moving — ass, waist, back up again.";
            return npcLine + "\n\n" + roamingMcReact(tier, d);
        }

        // ── Sleazy ───────────────────────────────────────────────────────────
        if (hasTrait(n, "Sleazy")) {
            String base = "While you are both swaying slowly to the music, {npc_he} yanks you flush against {npc_him}. "
                        + "One hand starts on your waist, then slides down deliberately, cupping and squeezing your ass hard — "
                        + "fingers spreading, digging in, pulling your hips tightly against {npc_his} growing erection as you continue moving together.";
            String npcLine = d.equals("drunk")
                ? "\n\n\"This ass has been in my palms the whole dance and I'm still not done. Just letting me spread it while you sway.\""
                : "\n\n\"Been groping this ass the whole time and it feels so fucking grab-able. Keep moving for me.\"";
            return base + npcLine + "\n\n" + assGropeMcReact(tier, d);
        }

        // ── Jerk ─────────────────────────────────────────────────────────────
        if (hasTrait(n, "Jerk")) {
            String base = "While you are both slow dancing, {npc_he} pulls you in with a smug smirk, "
                        + "one hand sliding down to cup your ass possessively, fingers digging in like {npc_he} owns the spot "
                        + "while {npc_he} presses {npc_his} hips forward in time with the music.";
            String npcLine = d.equals("drunk")
                ? "\n\n\"Your ass has been in my hand this whole song. I'll stop when I feel like it.\""
                : "\n\n\"Your ass, in my hand, the whole dance. That's just how this is going.\"";
            return base + npcLine + "\n\n" + assGropeMcReact(tier, d);
        }

        // ── Alcoholic ────────────────────────────────────────────────────────
        if (hasTrait(n, "Alcoholic")) {
            String base = "While you are both slow dancing, {npc_his} sweaty hands slide down and land heavily on your ass, "
                        + "thumbs rubbing clumsily along the curve while {npc_he} sways into you, breath boozy against your neck.";
            return base + "\n\n" + assGropeMcReact(tier, d);
        }

        // ── Confrontational ──────────────────────────────────────────────────
        if (hasTrait(n, "Confrontational")) {
            String base = "While you are both slow dancing, {npc_he} grips your waist first, then deliberately slides "
                        + "one hand down to cup your ass, fingers flexing as if daring you to object "
                        + "while {npc_he} pulls you flush against {npc_him} in time with the music.";
            return base + "\n\n" + assGropeMcReact(tier, d);
        }

        // ── Other NPC types ───────────────────────────────────────────────────
        return "{npc_His} hand is still settled on your ass, unhurried.\n\n"
             + (tier.equals("shy")   ? "You've stopped reacting and just let it be."
              : tier.equals("enjoy") ? "You press back lightly into {npc_his} palm."
              : "You've accepted it. Neither of you mentions it.");
    }

    // ── Pussy grope under skirt during slow dance ─────────────────────────────
    String buildPussyGropeText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        // Check mod pool for this NPC personality
        String modText = pickFromPool("bar.grope.pussy." + getNpcPersonalityKey(n), buildMcTraitSet());
        if (modText != null && !modText.isEmpty()) return modText;
        if (n == null) return "{npc_His} hand slides under your skirt.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");

        state.flagPussyGroped = true;

        if (d.equals("blackout"))
            return "*Warm... between my legs under my skirt while we dance. Moving. The spinning room makes it hard to tell how it feels.*";

        // ── Physical description by NPC type ──────────────────────────────────
        String base;
        if (hasTrait(n, "Sleazy"))
            base = "While you are both swaying slowly to the music, {npc_his} hand slides down your back, "
                 + "slips under the hem of your skirt, and cups your pussy directly. "
                 + "Fingers press against your folds, pushing panties aside to rub bare skin. "
                 + "{npc_He} grinds {npc_his} palm slowly while holding you tight and continuing to move with the rhythm.";
        else if (hasTrait(n, "Jerk"))
            base = "While you are both slow dancing, {npc_he} smirks as {npc_his} hand dips under your skirt from behind, "
                 + "cupping your pussy possessively. {npc_His} fingers rub firmly, pushing panties aside to touch bare skin "
                 + "while {npc_he} grinds {npc_his} hips forward in time with the music.";
        else if (hasTrait(n, "Alcoholic"))
            base = "While you are both slow dancing, {npc_his} sweaty hand slips clumsily under your skirt and cups your pussy, "
                 + "fingers rubbing messily against your folds while {npc_he} sways heavily into you, breath boozy against your neck.";
        else if (hasTrait(n, "Confrontational"))
            base = "While you are both slow dancing, {npc_he} grips your waist first, then deliberately slides {npc_his} hand "
                 + "under your skirt from behind, cupping your pussy and rubbing firmly as if daring you to object "
                 + "while {npc_he} pulls you flush against {npc_him} in time with the music.";
        else
            base = "{npc_His} hand slides under your skirt while you both sway to the music, finding your pussy and rubbing slowly.";

        // ── MC reaction by tier and drunk ─────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*He's rubbing my pussy under my skirt while we're slow dancing after I told him to stop earlier. The violation still cuts through the haze.*";
            else if (tier.equals("enjoy"))
                mc = "*His hand under my skirt, touching my pussy while we dance feels dirty and hot. The alcohol makes me want to grind back against his palm.*";
            else
                mc = "*Something is happening between my legs under my skirt as we dance. It registers, but the buzz makes it feel distant and unimportant.*";
        } else {
            if (tier.equals("shy"))
                mc = "You feel his fingers push under your skirt and rub your bare folds while you both continue moving slowly together. The intrusion is sharp."
                   + "\n\n*His hand is between my legs under my skirt while we're slow dancing. The violation hits hard. I feel exposed and angry. This is crossing every line.*";
            else if (tier.equals("enjoy"))
                mc = "You feel his warm fingers slide under your skirt and rub your bare pussy while you both sway to the slow beat."
                   + "\n\n*His hand is under my skirt, touching my pussy while we dance. The bold strokes in time with the music feel risky and arousing. I'm getting wet despite the public setting.*";
            else
                mc = "His fingers slide under your skirt and rub your pussy while you both sway to the music."
                   + "\n\n*I feel his hand between my legs under my skirt as we dance. It registers, but I don't feel strongly about it either way.*";
        }
        return base + "\n\n" + mc;
    }

    // ── Under-shirt breast grope (escalation from over-shirt or waist) ────────
    String buildUnderShirtGropeText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hand slides under your shirt.";
        String d      = drunkTier();
        String tier   = gameStageVariant("breast_public");
        boolean braless = state.hasTrait("exposed_breasts");
        boolean nipping = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");

        state.flagBreastGroped = true;

        if (d.equals("blackout"))
            return braless
                ? "*Hand... under my shirt on my bare breast while we dance. The spinning room makes it hard to process.*"
                : "*Hand... under my shirt, groping my breast while we dance. Everything is hazy.*";

        // ── Physical description by NPC type ──────────────────────────────────
        String base;
        if (hasTrait(n, "Sleazy")) {
            base = braless
                ? "While you are both swaying slowly to the music, {npc_his} hand first rests on your waist, "
                  + "then slides upward under the hem of your top. {npc_His} fingers brush bare skin as they move higher, "
                  + "immediately cupping and squeezing your bare breast" + (nipping ? ", thumb brushing your hard nipple directly" : "") + "."
                : "While you are both swaying slowly to the music, {npc_his} hand rests on your waist, "
                  + "then slides under the hem of your top. {npc_His} fingers press over your bra, "
                  + "cupping and kneading your breast through the fabric.";
        } else if (hasTrait(n, "Jerk")) {
            base = braless
                ? "While you are both slow dancing, {npc_he} arrogantly slides {npc_his} hand under your top, "
                  + "fingers groping your bare breast with possessive entitlement while {npc_he} keeps you close."
                : "While you are both slow dancing, {npc_he} slides {npc_his} hand under your top "
                  + "and gropes your breast over your bra with cocky confidence.";
        } else if (hasTrait(n, "Alcoholic")) {
            base = braless
                ? "While you are both slow dancing, {npc_his} sweaty hand slides clumsily under your top, "
                  + "fingers groping your bare breast with heavy, uncoordinated squeezes."
                : "While you are both slow dancing, {npc_his} damp hand moves under your top "
                  + "and squeezes your breast over your bra heavily while {npc_he} sways into you.";
        } else if (hasTrait(n, "Confrontational")) {
            base = braless
                ? "While you are both slow dancing, {npc_he} slides {npc_his} hand challengingly under your top, "
                  + "fingers groping your bare breast as if daring you to say something."
                : "While you are both slow dancing, {npc_he} moves {npc_his} hand under your top "
                  + "and gropes your breast over your bra with a testing grip.";
        } else {
            base = braless
                ? "{npc_His} hand slides under your top while you both sway, fingers finding and cupping your bare breast."
                : "{npc_His} hand moves under your shirt while you both dance, groping your breast through your bra.";
        }

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc = breastGropeMcReact(tier, d, braless, nipping);

        String clothing = breastGropeClothing(braless);
        String result = base + "\n\n" + mc;
        if (!clothing.isEmpty()) result += "\n\n" + clothing;
        return result;
    }

    // ── Groping through panties (over fabric, not bare) ───────────────────────
    String buildThroughPantiesText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hand presses over your panties.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean braless = state.hasTrait("exposed_breasts");
        boolean nipping = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");

        state.flagPussyGroped = true;

        if (d.equals("blackout"))
            return "*Hand... under my skirt, groping over my panties while we dance. The spinning room makes it hard to process.*";

        // ── Physical description by NPC type ──────────────────────────────────
        String base;
        if (hasTrait(n, "Sleazy"))
            base = "While you are both swaying slowly to the music, {npc_his} hand rests on your hip, "
                 + "then slides under the hem of your skirt. {npc_His} fingers press and rub over your panties, "
                 + "stroking the fabric against your bare folds and clit while you both continue moving together.";
        else if (hasTrait(n, "Jerk"))
            base = "While you are both slow dancing, {npc_he} grips your hip possessively, "
                 + "then smirks as {npc_his} hand slides under your skirt. {npc_His} fingers rub and press over your panties "
                 + "arrogantly, stroking the fabric against your pussy while {npc_he} pulls you flush in time with the music.";
        else if (hasTrait(n, "Alcoholic"))
            base = "While you are both slow dancing, {npc_his} sweaty hand slides clumsily under your skirt "
                 + "and begins rubbing over your panties with heavy, uncoordinated strokes while {npc_he} sways heavily into you.";
        else if (hasTrait(n, "Confrontational"))
            base = "While you are both slow dancing, {npc_he} grips your waist, "
                 + "then deliberately slides {npc_his} hand under your skirt, rubbing and pressing over your panties "
                 + "as if daring you to object while {npc_he} holds you close in time with the music.";
        else
            base = "{npc_His} hand slides under your skirt while you both sway, fingers rubbing over your panties slowly.";

        // ── Also note if under-shirt grope is happening simultaneously ─────────
        String combined = "";
        if (state.flagBreastGroped && braless)
            combined = "\n\nOne hand under your shirt on your bare breast" + (nipping ? ", thumb on your nipple" : "")
                     + ", the other rubbing over your panties while you dance. *I feel completely used and exposed.*";

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*He escalated to groping me through my panties while we're slow dancing. The violation still cuts through the haze.*";
            else if (tier.equals("enjoy"))
                mc = "*He's groping me through my panties while we dance... the constant rubbing feels so dirty and hot. The alcohol makes me grind into his touch.*";
            else
                mc = "*The shift under my skirt and over my panties as we dance registers, but the buzz makes it feel distant.*";
        } else {
            if (tier.equals("shy"))
                mc = "*He went under my skirt to grope me through my panties while we're slow dancing. The violation feels sneaky and humiliating. His fingers keep rubbing the fabric against me and I don't know how to make it stop.*";
            else if (tier.equals("enjoy"))
                mc = "*He's groping me through my panties while we dance... the pressure of the fabric against my bare folds feels teasing and good. The public risk is making everything more intense.*";
            else
                mc = "*The shift under my skirt and over my panties as we dance registers clearly. I feel it. I just don't feel strongly about it either way.*";
        }
        return base + combined + "\n\n" + mc;
    }

    // ── Hand inside panties — direct bare contact / fingering entry ───────────
    String buildInsidePantiesText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} fingers slip inside your panties.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean braless = state.hasTrait("exposed_breasts");
        boolean nipping = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");

        state.flagPussyGroped = true;
        state.flagFingered    = true;

        if (d.equals("blackout"))
            return "*Hand... under my skirt and inside my panties, fingers inside me while we dance. The spinning room makes it hard to process.*";

        // ── Physical description by NPC type ──────────────────────────────────
        String base;
        if (hasTrait(n, "Sleazy"))
            base = "While you are both swaying slowly to the music, {npc_his} hand first rests on your hip, "
                 + "then slides under the hem of your skirt. {npc_His} fingers slip inside your panties, "
                 + "brushing bare folds before rubbing your pussy and pushing one or two fingers inside "
                 + "while you both continue moving together.";
        else if (hasTrait(n, "Jerk"))
            base = "While you are both slow dancing, {npc_he} grips your hip possessively, "
                 + "then smirks as {npc_his} hand slides under your skirt and slips inside your panties. "
                 + "{npc_His} fingers rub your pussy arrogantly before pushing inside "
                 + "while {npc_he} pulls you flush in time with the music.";
        else if (hasTrait(n, "Alcoholic"))
            base = "While you are both slow dancing, {npc_his} sweaty hand slides clumsily under your skirt "
                 + "and slips inside your panties. {npc_His} fingers rub messily before pushing inside "
                 + "while {npc_he} sways heavily into you.";
        else if (hasTrait(n, "Confrontational"))
            base = "While you are both slow dancing, {npc_he} grips your waist, "
                 + "then deliberately slides {npc_his} hand under your skirt and slips inside your panties, "
                 + "{npc_his} fingers pushing inside as if daring you to object "
                 + "while {npc_he} pulls you flush in time with the music.";
        else
            base = "{npc_His} hand slides under your skirt and inside your panties while you both sway, fingers pushing inside you.";

        // ── Combined note if breast also being groped ─────────────────────────
        String combined = "";
        if (state.flagBreastGroped && braless && nipping)
            combined = "\n\n{npc_His} other hand is still under your shirt, thumb on your hard nipple "
                     + "while {npc_his} fingers push inside your panties. *One hand under my shirt on my bare breast, "
                     + "the other now inside my panties fingering me while we dance... I feel completely used.*";
        else if (state.flagBreastGroped && braless)
            combined = "\n\n{npc_His} other hand remains under your shirt on your bare breast while {npc_his} fingers push inside your panties.";

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*He escalated to putting his hand inside my panties and fingering me while we're slow dancing. The violation still cuts through the haze.*";
            else if (tier.equals("enjoy"))
                mc = "*He went straight inside my panties and is fingering me while we dance... it feels so dirty and hot. The alcohol makes me clench around his fingers.*";
            else
                mc = "*The shift under my skirt and inside my panties as we dance registers, but the buzz makes it feel distant.*";
        } else {
            if (tier.equals("shy"))
                mc = "*He went from my hip to putting his hand inside my panties and fingering me while we're slow dancing. The violation feels deeply exposing and wrong. His fingers are inside me and I can't make the freeze end.*";
            else if (tier.equals("enjoy"))
                mc = "*He went under my skirt and inside my panties... his fingers are now inside me while we dance. The bold public escalation feels so risky and arousing.*";
            else
                mc = "*The shift under my skirt and inside my panties as we dance registers clearly. His fingers are inside me. I just don't feel strongly about it either way.*";
        }
        return base + combined + "\n\n" + mc;
    }

    // ── Pussy grope escalates to fingering ────────────────────────────────────
    String buildFingeringText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        // Check mod pool for this NPC personality
        String modText = pickFromPool("bar.fingering." + getNpcPersonalityKey(n), buildMcTraitSet());
        if (modText != null && !modText.isEmpty()) return modText;
        if (n == null) return "{npc_His} finger pushes inside you.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");

        state.flagFingered = true;

        if (d.equals("blackout"))
            return "*Something... pushing inside while we dance. Warm. The spinning room makes it hard to tell how it feels.*";

        // ── Physical description by NPC type ──────────────────────────────────
        String base;
        if (hasTrait(n, "Sleazy"))
            base = "While you are both swaying slowly to the music, {npc_his} fingers first rub your pussy over your panties, "
                 + "then push the fabric aside to stroke bare folds. {npc_He} grinds {npc_his} palm slowly, "
                 + "then pushes one finger inside you, curling it as you continue moving together.";
        else if (hasTrait(n, "Jerk"))
            base = "While you are both slow dancing, {npc_he} smirks as {npc_his} fingers first rub your pussy possessively, "
                 + "then one pushes inside while {npc_he} grinds {npc_his} hips forward in time with the music.";
        else if (hasTrait(n, "Alcoholic"))
            base = "While you are both slow dancing, {npc_his} sweaty fingers rub messily against your folds, "
                 + "then one pushes inside awkwardly while {npc_he} sways heavily into you.";
        else if (hasTrait(n, "Confrontational"))
            base = "While you are both slow dancing, {npc_he} rubs your pussy challengingly, "
                 + "then one finger pushes inside as if daring you to object while {npc_he} pulls you flush against {npc_him} in time with the music.";
        else
            base = "{npc_His} finger pushes inside you while you both sway to the music.";

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*His finger is inside me while we're slow dancing after I told him to stop. The violation still cuts through the haze.*";
            else if (tier.equals("enjoy"))
                mc = "*His finger is inside me while we dance... it feels dirty and hot. The alcohol makes me want to clench around it.*";
            else
                mc = "*Something is pushing inside me as we dance. It registers, but the buzz makes it feel distant and unimportant.*";
        } else {
            if (tier.equals("shy"))
                mc = "You feel his fingers push under your skirt, rub your bare pussy, then one finger slides inside while you both continue moving slowly together. The violation is sharp."
                   + "\n\n*His finger is inside me while we're slow dancing. I told him to stop and he just pushed in anyway. The intrusion feels wrong and humiliating.*";
            else if (tier.equals("enjoy"))
                mc = "You feel his fingers rub your bare pussy under your skirt, then one slides inside while you both sway to the slow beat."
                   + "\n\n*His finger is inside me while we dance... pushing in and curling slowly. The risk of being caught on the dance floor makes it feel incredibly hot and dirty.*";
            else
                mc = "His fingers slide under your skirt, rub your pussy, then one pushes inside while you both sway to the music."
                   + "\n\n*I feel a finger sliding inside me as we dance. It registers, but I don't feel strongly about it either way.*";
        }
        return base + "\n\n" + mc;
    }

    // ── Fingering continues — he doesn't stop ────────────────────────────────
    String buildFingeringContinuesText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        String modFingeringContinuesText = pickFromPool("bar.fingering.continues." + getNpcPersonalityKey(n), buildMcTraitSet());
        if (modFingeringContinuesText != null && !modFingeringContinuesText.isEmpty()) return modFingeringContinuesText;
        if (n == null) return "{npc_His} finger is still inside you.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");

        if (d.equals("blackout"))
            return "*Fingers... inside while we dance. Moving. The spinning room makes it hard to tell how it feels.*";

        // ── Physical description ───────────────────────────────────────────────
        String base;
        if (hasTrait(n, "Sleazy"))
            base = "While you are both swaying slowly to the music, {npc_his} finger is already inside you, curling and thrusting shallowly. "
                 + "{npc_He} keeps the slow rhythm of the dance, using the movement of your bodies to push {npc_his} finger deeper, "
                 + "adding a second finger as the song continues.";
        else if (hasTrait(n, "Jerk"))
            base = "While you are both slow dancing, {npc_his} finger is already inside you. "
                 + "{npc_He} smirks and adds a second finger, thrusting arrogantly in time with the music as {npc_he} pulls you tighter against {npc_him}.";
        else if (hasTrait(n, "Alcoholic"))
            base = "While you are both slow dancing, {npc_his} sweaty fingers are already inside you, "
                 + "thrusting clumsily and messily in time with {npc_his} heavy swaying.";
        else if (hasTrait(n, "Confrontational"))
            base = "While you are both slow dancing, {npc_his} finger is already inside you. "
                 + "{npc_He} adds a second finger challengingly, thrusting as if daring you to object while {npc_he} pulls you flush against {npc_him}.";
        else
            base = "{npc_His} finger keeps moving inside you while you both sway together.";

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*His fingers are inside me while we're slow dancing. The violation still cuts through the haze with every thrust.*";
            else if (tier.equals("enjoy"))
                mc = "*His fingers are inside me while we dance... stretching and moving with the rhythm. The alcohol makes it feel dirty and addictive.*";
            else
                mc = "*Something is thrusting inside me as we dance. It registers, but the buzz makes it feel distant and unimportant.*";
        } else {
            if (tier.equals("shy"))
                mc = "You feel his finger curl and thrust inside you while you both continue moving slowly together. A second finger pushes in."
                   + "\n\n*His fingers are inside me while we're slow dancing. He just added another one. The violation feels deeper and more humiliating with every thrust in time with the music.*";
            else if (tier.equals("enjoy"))
                mc = "You feel his finger curl and thrust inside you while you both sway to the slow beat. A second finger joins, stretching you."
                   + "\n\n*His fingers are inside me, thrusting slowly while we dance... the rhythm matches the song perfectly. The risk of being fingered on the dance floor makes it incredibly hot and intense.*";
            else
                mc = "His finger curls and thrusts inside you while you both sway to the music. A second finger joins."
                   + "\n\n*I feel his fingers moving inside me as we dance. It's happening, but I don't feel strongly about it either way.*";
        }
        return base + "\n\n" + mc;
    }

    // ── Breast → pussy grope transition during slow dance ────────────────────
    String buildBreastToPussyTransitionText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hand moves from your breast down under your skirt.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean braless = state.hasTrait("exposed_breasts");
        boolean nipping = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");

        state.flagBreastGroped = true;
        state.flagPussyGroped  = true;
        state.flagFingered     = true;

        if (d.equals("blackout"))
            return "*Hand... moving from chest to between my legs while we dance. Fingers inside. The spinning room makes it hard to process.*";

        String base;
        if (hasTrait(n, "Sleazy")) {
            base = braless && nipping
                ? "While you are both swaying slowly to the music, {npc_his} hand first cups your breast over your thin top, "
                  + "thumb circling your hard, visible nipple. After a few moments squeezing and playing with your nipple, "
                  + "{npc_his} hand slides down your body, slips under the hem of your skirt, and cups your pussy, "
                  + "fingers pushing panties aside to rub bare folds before pushing a finger inside."
                : "While you are both swaying slowly to the music, {npc_his} hand first cups your breast, "
                  + "then slides down your body, slips under the hem of your skirt, and cups your pussy, "
                  + "fingers pushing panties aside to rub bare folds before pushing a finger inside.";
        } else if (hasTrait(n, "Jerk")) {
            base = "While you are both slow dancing, {npc_he} first cups your breast possessively, thumb on your nipple, "
                 + "then smirks as {npc_his} hand slides down under your skirt. {npc_His} fingers rub your pussy "
                 + "arrogantly before pushing one or two inside while {npc_he} grinds forward in time with the music.";
        } else if (hasTrait(n, "Alcoholic")) {
            base = "While you are both slow dancing, {npc_his} sweaty hand first lands heavily on your breast, "
                 + "squeezing clumsily, then slides down under your skirt. {npc_His} fingers rub messily "
                 + "before pushing inside while {npc_he} sways heavily into you.";
        } else if (hasTrait(n, "Confrontational")) {
            base = "While you are both slow dancing, {npc_he} first grips your breast challengingly, thumb on your nipple, "
                 + "then deliberately slides {npc_his} hand under your skirt. {npc_His} fingers rub your pussy "
                 + "before pushing inside as if daring you to object while {npc_he} pulls you flush in time with the music.";
        } else {
            base = "While you are both swaying to the music, {npc_his} hand moves from your breast down under your skirt, "
                 + "fingers rubbing then pushing inside you.";
        }

        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*{npc_He} escalated from my breast to fingering me while we're slow dancing. The violation feels continuous and wrong even through the haze.*";
            else if (tier.equals("enjoy"))
                mc = "*{npc_He} went from my tits to fingering me while we dance... it feels so dirty and hot. The alcohol makes me clench around {npc_his} fingers.*";
            else
                mc = "*The shift from chest to inside me as we dance registers, but the buzz makes it feel distant.*";
        } else {
            if (tier.equals("shy"))
                mc = "You feel his hand cup and squeeze your breast, then it slides down under your skirt. "
                   + "{npc_His} fingers rub your pussy and one pushes inside while you both sway together."
                   + "\n\n*{npc_He} went from groping my breast to fingering me under my skirt while we're slow dancing. "
                   + "The violation feels even worse with the smooth transition. I feel exposed and powerless.*";
            else if (tier.equals("enjoy"))
                mc = "You feel {npc_his} hand on your breast, then it slides down under your skirt, "
                   + "{npc_his} fingers rubbing your bare pussy before one pushes inside while you both continue swaying."
                   + "\n\n*{npc_He} started with my breasts and now {npc_his} finger is inside me while we dance... "
                   + "the escalation feels so bold and arousing. The public risk is making me wetter.*";
            else
                mc = "{npc_His} hand moves from your breast down under your skirt, fingers rubbing then pushing inside "
                   + "while you both sway to the music."
                   + "\n\n*The shift from my breast to inside me as we dance registers, but I feel mostly detached about it.*";
        }
        return base + "\n\n" + mc;
    }

    // ── Full escalation: breast → ass → pussy/fingering during slow dance ─────
    String buildFullEscalationText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        String modFullEscalationText = pickFromPool("bar.full.escalation." + getNpcPersonalityKey(n), buildMcTraitSet());
        if (modFullEscalationText != null && !modFullEscalationText.isEmpty()) return modFullEscalationText;
        if (n == null) return "{npc_His} hands have been everywhere.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean braless = state.hasTrait("exposed_breasts");
        boolean nipping = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");

        state.flagBreastGroped = true;
        state.flagAssGroped    = true;
        state.flagPussyGroped  = true;
        state.flagFingered     = true;

        if (d.equals("blackout"))
            return "*Hands moving... from chest to ass to inside while we dance. Warm. Spinning. Hard to tell what's happening.*";

        String base;
        if (hasTrait(n, "Sleazy")) {
            base = braless && nipping
                ? "While you are both swaying slowly to the music, {npc_his} hand first slides up and cups your breast over your thin top. "
                  + "Because you're braless, your hard nipples are clearly visible and poking through. "
                  + "{npc_His} thumb circles one stiff nipple, squeezing the soft flesh. "
                  + "After a few moments {npc_he} slides {npc_his} hand down your body, cups your ass firmly — fingers spreading and digging in — "
                  + "then continues lower, slipping under the hem of your skirt. "
                  + "{npc_His} fingers push your panties aside and rub your bare pussy before one finger slides inside you, "
                  + "curling slowly as you both keep moving together to the rhythm."
                : "While you are both swaying slowly, {npc_his} hand first cups your breast, then slides down to cup and squeeze your ass, "
                  + "then continues under your skirt — fingers rubbing your pussy before one slides inside while you keep moving together.";
        } else if (hasTrait(n, "Jerk")) {
            base = "While you are both slow dancing, {npc_he} first cups your breast possessively, thumb rolling your hard nipple. "
                 + "{npc_He} then slides {npc_his} hand down, cups and squeezes your ass like {npc_he} owns it, "
                 + "before slipping under your skirt. {npc_His} fingers rub your pussy arrogantly and push one or two inside "
                 + "while {npc_he} grinds forward in time with the music.";
        } else if (hasTrait(n, "Alcoholic")) {
            base = "While you are both slow dancing, {npc_his} sweaty hand lands on your breast, squeezing clumsily, "
                 + "then slides down to grab your ass, then slips under your skirt. "
                 + "{npc_His} fingers rub your pussy messily before pushing inside while {npc_he} sways heavily into you.";
        } else if (hasTrait(n, "Confrontational")) {
            base = "While you are both slow dancing, {npc_he} first grips your breast challengingly, "
                 + "then slides {npc_his} hand down to cup your ass, then deliberately moves under your skirt, "
                 + "{npc_his} fingers rubbing your pussy before pushing inside as if daring you to object.";
        } else {
            base = "While you are both swaying, {npc_his} hands move from your breast to your ass to under your skirt, "
                 + "fingers eventually pushing inside you.";
        }

        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*{npc_He} progressed from groping my breast to my ass to fingering me while we're slow dancing. "
                   + "The violation feels continuous and overwhelming with every movement.*";
            else if (tier.equals("enjoy"))
                mc = "*{npc_He} went from my tits to my ass to fingering me while we dance... "
                   + "it feels so dirty and hot. The alcohol makes me want to press into every touch.*";
            else
                mc = "*{npc_His} hand moved from my chest to my ass to inside me as we dance. It registers, but everything feels hazy and unimportant.*";
        } else {
            if (tier.equals("shy"))
                mc = "*{npc_He} went from groping my visible nipples to squeezing my ass to pushing {npc_his} finger inside me "
                   + "while we're slow dancing. The continuous violation feels overwhelming. "
                   + "I feel exposed and powerless with every sway.*";
            else if (tier.equals("enjoy"))
                mc = "*{npc_He} started with my breasts, playing with my hard nipples while we danced, "
                   + "then moved to squeezing my ass, and now {npc_his} finger is inside me... "
                   + "the smooth escalation while we sway feels so bold and arousing. "
                   + "The public risk is making me wetter with every move.*";
            else
                mc = "*{npc_His} hand moved from my breast to my ass to inside me while we dance. "
                   + "The progression registers, but I feel mostly detached as we keep swaying.*";
        }
        return base + "\n\n" + mc;
    }

    // ── Fingering continues to orgasm ──────────────────────────────────────────
    String buildFingeringToOrgasmText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "The stimulation builds until your body gives.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");

        if (d.equals("blackout"))
            return "Something... inside while we dance. Cumming... The spinning room swallows everything.";

        String base;
        if (hasTrait(n, "Sleazy")) {
            base = "While you are both swaying slowly to the music, {npc_his} finger is already inside you, curling and thrusting shallowly. "
                 + "{npc_He} adds a second finger, stretching you, keeping the slow rhythm of the dance. "
                 + "{npc_His} thumb finds your clit and rubs in firm circles as the song continues. "
                 + "The stimulation builds steadily until you cum.";
        } else if (hasTrait(n, "Jerk")) {
            base = "While you are both slow dancing, {npc_his} fingers are inside you, thrusting arrogantly in time with the music. "
                 + "{npc_His} thumb presses firmly on your clit, rubbing with cocky confidence until you cum.";
        } else if (hasTrait(n, "Alcoholic")) {
            base = "While you are both slow dancing, {npc_his} sweaty fingers are inside you, thrusting messily. "
                 + "{npc_His} thumb rubs your clit clumsily but persistently until you cum.";
        } else if (hasTrait(n, "Confrontational")) {
            base = "While you are both slow dancing, {npc_his} fingers are inside you, thrusting challengingly. "
                 + "{npc_His} thumb presses on your clit as if daring you to cum while {npc_he} pulls you flush against {npc_him}.";
        } else {
            base = "{npc_His} fingers keep moving inside you while you both sway, thumb finding your clit, until the stimulation crests.";
        }

        String npcComment = "";
        if (hasTrait(n, "Jerk"))      npcComment = "\n\n\"You act like you don't want it. Feel that.\"";
        if (hasTrait(n, "Sleazy"))    npcComment = "\n\n\"There it is. Feel how good my fingers are inside you while we dance.\"";
        if (hasTrait(n, "Alcoholic")) npcComment = "\n\n\"Aww, you're cumming on my fingers while we dance, sweetheart…\"";
        if (hasTrait(n, "Confrontational")) npcComment = "\n\n\"See? Your body says yes even while we dance.\"";

        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "Your body tenses and you cum against your will, thighs shaking as shame floods you."
                   + "\n\n*{npc_His} fingers are inside me while we're dancing and I'm cumming anyway. The violation feels even worse with the forced orgasm.*";
            else if (tier.equals("enjoy"))
                mc = "Your breath catches, thighs trembling as a powerful orgasm washes over you, clenching around {npc_his} fingers while you keep swaying."
                   + "\n\n*{npc_His} fingers inside me while we dance... I'm cumming so hard. The buzz makes it feel intense and addictive.*";
            else
                mc = "Your body tenses and releases in a quiet, detached orgasm while you both continue rocking to the music."
                   + "\n\n*The stimulation while we dance leads to an orgasm. It feels far away and unimportant.*";
        } else {
            if (tier.equals("shy"))
                mc = "Your body betrays you — thighs shaking as an intense, unwanted orgasm crashes through you, clenching around {npc_his} fingers while you try to stay upright."
                   + "\n\n*{npc_His} fingers are inside me while we're dancing... I don't want this but my body is cumming anyway. "
                   + "The shame is overwhelming. I feel violated and humiliated as the orgasm forces itself through me.*";
            else if (tier.equals("enjoy"))
                mc = "Your breath catches, thighs trembling as a powerful orgasm washes over you, clenching around {npc_his} fingers while you try to keep swaying normally."
                   + "\n\n*{npc_His} fingers inside me while we dance... the way {npc_he}'s rubbing my clit... I'm going to cum right here on the dance floor. "
                   + "The risk and the rhythm push me over the edge. The orgasm hits hard and leaves me shaking against {npc_him}.*";
            else
                mc = "Your body tenses and releases in a quiet, detached orgasm, clenching around {npc_his} fingers with minimal outward reaction."
                   + "\n\n*{npc_His} fingers are inside me as we dance... I feel the build-up and then the release. It happens, but everything feels distant and neutral.*";
        }
        return base + npcComment + "\n\n" + mc;
    }

    // ── Post-orgasm aftermath — immediate post-cum while still dancing ─────────
    String buildOrgasmAftermathText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        String modOrgasmAftermathText = pickFromPool("bar.orgasm.aftermath." + getNpcPersonalityKey(n), buildMcTraitSet());
        if (modOrgasmAftermathText != null && !modOrgasmAftermathText.isEmpty()) return modOrgasmAftermathText;
        if (n == null) return "The orgasm passes. You both keep dancing.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean commando = state.hasTrait("commando");
        boolean braless  = state.hasTrait("exposed_breasts");

        if (d.equals("blackout"))
            return "Something intense just happened while we danced. Now it's fading. Still swaying. Can't think clearly.";

        // NPC comment as fingers withdraw
        String npcLine;
        if (hasTrait(n, "Sleazy"))
            npcLine = "{npc_He} slowly withdraws {npc_his} fingers, satisfied. \"Good girl… you just came all over my fingers while we were dancing.\"";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_He} smirks as your body stops shaking. \"See? You came anyway. Not so resistant after all.\"";
        else if (hasTrait(n, "Engaging"))
            npcLine = "{npc_He} holds you gently as you tremble, then carefully withdraws {npc_his} hand. \"You okay?\" {npc_He} asks softly.";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcLine = "{npc_He} laughs warmly as your body shakes. \"Damn, you just came on the dance floor! That was hot.\"";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "{npc_He} smirks and slowly withdraws. \"Body said yes even if your mouth didn't.\"";
        else
            npcLine = "{npc_His} fingers slowly withdraw as your shaking eases.";

        // Commando note
        String clothing = commando
            ? (tier.equals("shy")
                ? "\n\n*No panties... I just came and now I can feel it running down my leg while we dance. So exposed.*"
                : "\n\n*The wetness from cumming is running down my bare thigh while we keep swaying.*")
            : "";

        // MC internal aftermath
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*I came hard but now I just feel gross and used... the afterglow is gone and all that's left is humiliation and regret.*";
            else if (tier.equals("enjoy"))
                mc = "*He made me cum so hard while we were dancing... the alcohol turns the aftershocks into pure bliss. I'm still trembling.*";
            else
                mc = "*The release happened and now it's passing. We're still dancing. Everything feels hazy and emotionally flat.*";
        } else {
            if (tier.equals("shy"))
                mc = "Your body shudders as the unwanted orgasm passes, shame crashing in immediately."
                   + "\n\n*He fingered me until I came on the dance floor... I didn't want it but my body betrayed me. I feel dirty and violated.*";
            else if (tier.equals("enjoy"))
                mc = "A soft moan escapes before you can stop it as the pleasure crests and then subsides."
                   + "\n\n*He just made me cum while we were slow dancing... the intense release feels incredible, even in public. My legs are still shaking.*";
            else
                mc = "Your body trembles as the orgasm passes while you both sway to the music."
                   + "\n\n*The release happened, but I mostly feel empty and detached as we keep dancing.*";
        }

        return npcLine + "\n\n" + mc + clothing;
    }

    // ── NPC discovers MC is commando — first contact with bare skin ───────────
    String buildCommandoDiscoveryText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hand finds bare skin instead of fabric.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean cameltoe   = state.hasTrait("camel_toe");
        boolean breastAlso = state.flagBreastGroped && state.hasTrait("exposed_breasts");

        state.flagPussyGroped = true;

        if (d.equals("blackout"))
            return "Hand... under my skirt. No panties. Bare. Fingers touching. Spinning. Hard to process.";

        // ── NPC discovery + first reaction ───────────────────────────────────
        String npcLine;
        if (hasTrait(n, "Sleazy"))
            npcLine = "{npc_His} fingers freeze for a second, then a low groan escapes against your ear. "
                    + "\"No fucking panties? You dirty little slut... you came out like this just for me?\" "
                    + "{npc_His} hand stays under your skirt, exploring openly.";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_He} smirks the second his fingers touch bare skin instead of fabric. "
                    + "\"No panties? Figures. Makes things easier for me.\" "
                    + "{npc_He} doesn't pull {npc_his} hand out.";
        else if (hasTrait(n, "Engaging"))
            npcLine = "{npc_His} hand pauses in surprise when {npc_his} fingers touch bare skin. "
                    + "{npc_He} gently strokes your bare skin while continuing to sway. "
                    + "\"You're not wearing anything underneath... that's bold. You okay with me touching you like this?\"";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcLine = "{npc_He} laughs warmly against your ear the moment {npc_his} fingers find bare skin. "
                    + "\"Whoa — no panties? You came ready to party! That's hot.\"";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "{npc_His} hand stops when it finds bare skin, then presses harder — deliberately. "
                    + "\"No panties. Good.\" Said like it was expected.";
        else if (hasTrait(n, "Alcoholic"))
            npcLine = "{npc_His} hand stops when it finds bare skin. "
                    + "\"Oh damn… nothing there…\" {npc_He} slurs, then starts rubbing sloppily.";
        else
            npcLine = "{npc_His} hand pauses when it finds bare skin instead of fabric, "
                    + "then resumes with noticeably more intent.";

        // ── Cameltoe note ─────────────────────────────────────────────────────
        String camelNote = cameltoe
            ? "\n\n*He could probably already see the outline... now his hand is confirming I'm bare underneath.*"
            : "";

        // ── Combined grope note ───────────────────────────────────────────────
        String combined = breastAlso
            ? "\n\n*One hand on my bare breast under my shirt, the other just found out I have no panties... the dual discovery feels overwhelming.*"
            : "";

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*{npc_He} just discovered I have no panties... his hand is now on my bare pussy while we're slow dancing. The violation feels even more intense.*";
            else if (tier.equals("enjoy"))
                mc = "*{npc_He} just realized I'm completely bare underneath... the surprised hunger in {npc_his} touch feels so dirty and hot. The alcohol makes me grind into {npc_his} fingers.*";
            else
                mc = "*The discovery that I'm commando registers, but the buzz makes the sensation feel distant.*";
        } else {
            if (tier.equals("shy"))
                mc = "His fingers brush upward along your thigh and suddenly touch bare skin with no fabric barrier. "
                   + "{npc_He} freezes for a split second, then presses against your naked pussy while you both continue swaying."
                   + "\n\n*{npc_He} just discovered I have no panties... his hand is now touching my bare pussy while we're slow dancing in public. I feel completely exposed.*";
            else if (tier.equals("enjoy"))
                mc = "His hand slides under your skirt and pauses when it reaches bare skin instead of panties. "
                   + "{npc_His} fingers press against your naked pussy while you both continue swaying."
                   + "\n\n*{npc_He} just found out I'm not wearing anything underneath... the surprise in {npc_his} touch feels thrilling and risky while we dance.*";
            else
                mc = "His hand slides under your skirt and pauses when it finds bare skin instead of panties. "
                   + "{npc_His} fingers rest against your naked pussy while you both sway."
                   + "\n\n*The discovery that I'm commando registers as {npc_his} hand touches me, but I feel mostly detached.*";
        }

        return npcLine + "\n\n" + mc + camelNote + combined;
    }

    // ── NPC reaction continuing after no-panties discovery ───────────────────
    String buildCommandoReactionText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_He} reacts to the bare skin.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");

        state.flagPussyGroped = true;

        if (d.equals("blackout"))
            return "Hand... under my skirt. No panties. Bare. He's rubbing. Spinning. Hard to process.";

        // ── Extended NPC action after discovery ───────────────────────────────
        String npcLine;
        if (hasTrait(n, "Sleazy"))
            npcLine = "{npc_He} groans loudly against your ear and immediately starts rubbing your bare pussy "
                    + "with greedy fingers while continuing to sway with you. "
                    + "\"No fucking panties? You dirty girl... you came out ready for this, didn't you?\" "
                    + "{npc_His} hand stays under your skirt, exploring openly.";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_He} smirks and presses {npc_his} fingers harder against your naked pussy, "
                    + "rubbing arrogantly while you both sway. "
                    + "\"No panties? Of course not. Makes things easier for me.\" "
                    + "{npc_He} doesn't pull {npc_his} hand out.";
        else if (hasTrait(n, "Engaging"))
            npcLine = "{npc_He} pauses in surprise when {npc_his} fingers touch bare skin, "
                    + "then gently strokes your naked pussy while continuing to sway with you. "
                    + "\"You're not wearing anything underneath... that's bold. "
                    + "You comfortable with me touching you like this?\" {npc_His} touch stays respectful but curious.";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcLine = "{npc_He} laughs warmly against your ear the moment {npc_he} discovers bare skin, "
                    + "then starts rubbing your naked pussy playfully while you both sway. "
                    + "\"Whoa — no panties? You really came ready to have fun tonight!\"";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "{npc_He} keeps {npc_his} hand there with deliberate pressure, "
                    + "fingers rubbing your bare pussy while you both sway together. "
                    + "\"No panties. Convenient.\" {npc_He} smirks like the answer to a question.";
        else if (hasTrait(n, "Alcoholic"))
            npcLine = "{npc_His} sweaty hand fumbles then starts rubbing your bare pussy sloppily "
                    + "while {npc_he} sways heavily into you. "
                    + "\"Damn… nothing there… nice…\" {npc_He} slurs against your neck.";
        else
            npcLine = "{npc_His} hand resumes with more intent now, fingers rubbing your bare pussy "
                    + "while you both continue swaying to the music.";

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*{npc_He} just discovered I have no panties and now {npc_he}'s groping my bare pussy while we're slow dancing. The violation feels even more intense.*";
            else if (tier.equals("enjoy"))
                mc = "*{npc_He} just found out I'm bare underneath... {npc_his} touch got so much hungrier the moment {npc_he} discovered it. The alcohol makes {npc_his} reaction feel hot and intense.*";
            else
                mc = "*The discovery and {npc_his} reaction are there, but his touching feels distant in the haze.*";
        } else {
            if (tier.equals("shy"))
                mc = "*{npc_He} discovered I have no panties... now {npc_he}'s groping my bare pussy while we're dancing. "
                   + "I feel like a toy {npc_he} just unlocked. The exposure is overwhelming.*";
            else if (tier.equals("enjoy"))
                mc = "*{npc_He} just found out I'm bare and {npc_his} touch changed completely the moment {npc_he} knew. "
                   + "The way {npc_he}'s reacting while we dance feels thrilling.*";
            else
                mc = "*The discovery that I'm commando and {npc_his} reaction register, but I feel mostly detached as we keep swaying.*";
        }

        return npcLine + "\n\n" + mc;
    }

    // ── MC verbal protest mid-grope ───────────────────────────────────────────
    String buildMidGropeMcStopText() {
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean isShy      = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOutgoing = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");
        boolean fingered   = state.flagFingered;
        boolean pussy      = state.flagPussyGroped;
        boolean breast     = state.flagBreastGroped;
        int roll = rng.nextInt(4);

        if (d.equals("blackout"))
            return "Only a faint, broken sound escapes. \"...stop…\" — barely a whisper while your legs shake.";

        String spoken;
        if (d.equals("drunk")) {
            if (tier.equals("enjoy"))
                spoken = isShy ? "\"Slow down… too much…\"" : "\"Hey… ease up… it's a lot…\"";
            else if (tier.equals("shy") || isShy)
                spoken = switch (roll) {
                    case 0 -> "\"Please… take your hand out…\"";
                    case 1 -> "\"Stop… please stop touching me there…\"";
                    case 2 -> "\"I can't… stop…\"";
                    default -> "\"Don't… not like this…\"";
                };
            else
                spoken = isOutgoing
                    ? "\"Pull your hand back — too much.\"  "
                    : "\"Can you pull your hand out…? It's getting intense…\"";
        } else {
            // sober/tipsy
            if (tier.equals("enjoy"))
                spoken = "\"Wait… slow down a little…\"";
            else if (isShy)
                spoken = switch (roll) {
                    case 0 -> "\"Please… take it out…\"";
                    case 1 -> "\"Don't… not under my skirt…\"";
                    case 2 -> "\"Your hand… please remove it…\"";
                    default -> "\"I… I can't… stop…\"";
                };
            else if (isOutgoing)
                spoken = switch (roll) {
                    case 0 -> "\"Hey — hands out from under my skirt right now.\"";
                    case 1 -> "\"Slow down, that's too much. Pull your hand back.\"";
                    case 2 -> "\"I said stop — listen!\"";
                    default -> "\"Ease up under my clothes. Not cool.\"";
                };
            else
                spoken = switch (roll) {
                    case 0 -> "\"Can you… take your hand out? It's too much.\"";
                    case 1 -> "\"I'm not comfortable with your hand under my skirt…\"";
                    case 2 -> "\"Please stop… I don't want this right now.\"";
                    default -> "\"Your hand is under my clothes… can you move it?\"";
                };
        }

        // Internal thought
        String mc;
        if (tier.equals("shy"))
            mc = fingered
                ? "*{npc_His} fingers are still inside me while we dance… I said stop and he's still going. I feel so powerless.*"
                : "*{npc_His} hand is still there after I asked {npc_him} to stop… I don't know how to make {npc_him} listen.*";
        else if (tier.equals("enjoy"))
            mc = "*Even while protesting it still feels… something. I'm not sure if I mean the stop.*";
        else
            mc = pussy
                ? "*The touching is still happening under my skirt while we dance. I said stop.*"
                : "*My hand is under my clothes while we sway. I asked {npc_him} to stop.*";

        return "You grab at {npc_his} wrist and say, " + spoken
             + "\n\n" + mc;
    }

    // ── Orgasm recovery with shaky legs — NPC holds her while dancing ─────────
    String buildShakyLegsRecoveryText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "Your legs shake. You both keep swaying.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean commando = state.hasTrait("commando");
        boolean braless  = state.hasTrait("exposed_breasts");
        boolean nipping  = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");

        if (d.equals("blackout"))
            return "Legs... shaking. He's holding you up while you sway. Everything is spinning and distant.";

        // NPC holds her through recovery
        String npcLine;
        if (hasTrait(n, "Sleazy"))
            npcLine = "{npc_He} keeps {npc_his} arm tightly around your waist, pulling you flush against {npc_him} as your legs shake, "
                    + "continuing to sway slowly with you. \"Your legs are shaking so much... you came hard for me, didn't you?\"";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_He} holds you possessively with one arm around your waist, smirking as your legs tremble while you both sway. "
                    + "\"Look at those shaky legs... you came anyway. Pathetic.\"";
        else if (hasTrait(n, "Engaging"))
            npcLine = "{npc_He} wraps {npc_his} arm securely around your waist, supporting your shaky legs gently while continuing to sway with you. "
                    + "\"I've got you... take your time.\"";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcLine = "{npc_He} laughs warmly and pulls you tighter against {npc_him} with both arms as your legs tremble. "
                    + "\"Whoa, shaky legs! That must've been a good one — I've got you!\"";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "{npc_He} keeps {npc_his} arm locked around your waist, smirking as your legs shake while you both sway together.";
        else
            npcLine = "{npc_He} keeps one arm around your waist, supporting you while your legs tremble and you both continue swaying.";

        // Clothing note
        String clothing = "";
        if (commando)
            clothing = tier.equals("shy")
                ? "\n\n*No panties... my legs are shaking and I can feel my own wetness running down my thighs while he keeps dancing with me. So humiliating.*"
                : "\n\n*The wetness from cumming is running down my bare thighs while we keep moving together.*";
        else if (braless && nipping && state.flagBreastGroped)
            clothing = tier.equals("enjoy")
                ? "\n\n*He's still touching my bare breast under my shirt while holding me through my shaky legs... the full-body afterglow feels intense.*"
                : "";

        // MC internal
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*My legs won't stop shaking and he's forcing us to keep dancing like nothing happened... I feel disgusting and used.*";
            else if (tier.equals("enjoy"))
                mc = "*My legs are so shaky from cumming hard while we danced, but he's holding me tight... the afterglow feels heavy and good.*";
            else
                mc = "*The shakiness is there, but we're still just dancing. The feeling fades into the haze.*";
        } else {
            if (tier.equals("shy"))
                mc = "Your legs shake uncontrollably after the orgasm, but he keeps swaying with you, arm locked around your waist."
                   + "\n\n*My legs are weak from cumming on his fingers and he's keeping us dancing... I feel trapped and humiliated while my body betrays me.*";
            else if (tier.equals("enjoy"))
                mc = "Your legs tremble as the aftershocks fade, but his arm around your waist keeps you steady while you both sway."
                   + "\n\n*My legs are shaking from cumming while we danced, but he's holding me and we're still dancing together... the support feels surprisingly intimate.*";
            else
                mc = "Your legs shake as the orgasm passes, but he continues swaying with you, arm supporting your weight."
                   + "\n\n*My legs are shaking, but we're still just dancing. The weakness feels distant and unimportant.*";
        }

        return npcLine + "\n\n" + mc + clothing;
    }

    // ── MC says stop but NPC continues to orgasm ─────────────────────────────
    String buildMcSaysStopCumsText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "You say stop. The stimulation continues anyway.";
        String d        = drunkTier();
        String tier     = gameStageVariant("finger_public");
        boolean topLifted = state.hasTrait("top_lifted");
        boolean braless   = state.isBraless();
        boolean isShy     = state.hasTrait("shy") || state.hasTrait("fragile_ego");
        boolean isOut     = state.hasTrait("outgoing") || state.hasTrait("confrontational");
        String exposureNote = topLifted
            ? (tier.equals("enjoy")
                ? (braless
                    ? "\n\n*Cumming with my bare tits out for the whole bar — the exposure while going over pushed me even harder.*"
                    : "\n\n*My top is still up while I cum — the whole bar watching my chest while I finish.*")
                : (braless
                    ? "\n\n*My bare breasts are out when I cum. The bar watches my chest heave through the orgasm. The shame compounds everything.*"
                    : "\n\n*My top is still up when I cum. Everyone can see my chest while it happens. I can't stop it and I couldn't cover.*"))
            : "";
        int roll    = rng.nextInt(3); // vary the specific version

        if (d.equals("blackout"))
            return "You mumble incoherently, \"St… stop…\" but the words dissolve. "
                 + "{npc_His} fingers keep thrusting inside you while you both move slowly together. "
                 + "The stimulation builds until your body tenses and releases in a hazy, overwhelming orgasm. "
                 + "You shudder against {npc_him}, barely aware of what's happening as the world spins."
                 + "\n\n*Fingers… inside while we dance… cumming… Everything is spinning and blurry.*";

        // ── MC refusal (drunk vs sober/tipsy) ────────────────────────────────
        String refusal;
        if (d.equals("drunk")) {
            refusal = switch (roll) {
                case 0 -> "You slur thicker, \"Stop… get your fingers out,\" and push weakly at {npc_his} arm under your skirt.";
                case 1 -> "You slur, \"Stop… not while we're dancing,\" but your hips keep moving with the music.";
                default -> "You grab at {npc_his} wrist under your skirt and mumble, \"Get your fingers out…\"";
            };
        } else {
            refusal = switch (roll) {
                case 0 -> "You gasp, \"Stop… please stop fingering me,\" and push at {npc_his} arm while you both sway to the music.";
                case 1 -> "You say clearly, \"Stop fingering me,\" and try to shift your hips away while you both continue moving together.";
                default -> "You mutter, \"Stop… not while we're dancing,\" and push weakly at {npc_his} wrist.";
            };
        }

        // ── NPC ignores and continues with dirty talk ─────────────────────────
        String npcIgnores;
        if (hasTrait(n, "Sleazy")) {
            npcIgnores = switch (roll) {
                case 0 -> "\"Shh, you say stop but your pussy is clenching so tight while we dance.\" {npc_He} chuckles low and keeps thrusting, thumb rubbing harder on your clit.";
                case 1 -> "\"You say stop but you're soaking my hand while we dance.\" {npc_His} fingers keep moving, curling deeper.";
                default -> "\"You say stop but you're creaming on my fingers while we dance.\" He laughs and pushes a second finger in.";
            };
        } else if (hasTrait(n, "Jerk")) {
            npcIgnores = switch (roll) {
                case 0 -> "\"You say stop but your pussy is milking my fingers while we dance.\" {npc_He} smirks and thrusts deeper.";
                case 1 -> "\"You say stop but you're cumming anyway while we dance. Pathetic.\" {npc_He} keeps thrusting arrogantly.";
                default -> "\"Feel that? You're cumming anyway while we dance.\" {npc_He} ignores you and keeps going.";
            };
        } else if (hasTrait(n, "Alcoholic")) {
            npcIgnores = switch (roll) {
                case 0 -> "\"Feels good though, don't it?\" {npc_He} slurs and keeps thrusting messily.";
                case 1 -> "\"Aww, don't be like that… you're cumming while we dance, sweetheart.\" {npc_His} hand lingers and keeps going.";
                default -> "\"Just a little more…\" {npc_He} mumbles, fingers still moving sloppily.";
            };
        } else if (hasTrait(n, "Confrontational")) {
            npcIgnores = switch (roll) {
                case 0 -> "\"You say stop but you're cumming while we dance.\" {npc_He} grins darkly and keeps thrusting.";
                case 1 -> "\"See? Your body says yes even if your mouth says no.\" {npc_He} keeps the rhythm going.";
                default -> "\"You're not stopping me, are you?\" {npc_He} thrusts deeper, daring you.";
            };
        } else {
            npcIgnores = "{npc_He} doesn't stop.";
        }

        // ── Orgasm ────────────────────────────────────────────────────────────
        String orgasm = d.equals("drunk")
            ? "Your body locks up and you cum violently, thighs shaking, pussy clenching around {npc_his} fingers while you both continue rocking to the music. A shaky gasp escapes as the orgasm rips through you."
            : "Your body betrays you — thighs trembling as a powerful orgasm crashes through you, clenching around {npc_his} fingers while you try to keep swaying normally. You bite your lip hard to stay quiet.";

        // ── MC internal ───────────────────────────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                mc = "*I told {npc_him} to stop and {npc_he}'s still fingering me while we're dancing. I'm cumming against my will. The violation and shame feel crushing.*";
            else if (tier.equals("enjoy"))
                mc = "*I said stop but I'm cumming so hard while we dance… {npc_his} fingers feel too good. The alcohol makes the pleasure overwhelming.*";
            else
                mc = "*I said stop but {npc_his} fingers kept going. I cum anyway while we sway. It feels far away and unimportant.*";
        } else {
            if (tier.equals("shy")) {
                mc = switch (roll) {
                    case 0 -> "*I said stop but his fingers feel too good while we dance… I'm cumming right here. The risk and his dirty words make the orgasm hit even harder.*";
                    case 1 -> "*I told him to stop and he's still fingering me while we're dancing. I'm cumming anyway. The shame is crushing.*";
                    default -> "*I said stop but his fingers kept moving. I cum anyway as we dance. It feels distant.*";
                };
                if (tier.equals("shy"))
                    mc = "*I said stop and {npc_he}'s still fingering me while we're dancing. I'm cumming against my will. "
                       + "The shame is overwhelming — my body betrayed me right here on the dance floor.*";
            } else if (tier.equals("enjoy")) {
                mc = switch (roll) {
                    case 0 -> "*I said stop but his fingers feel so good inside me while we dance… I'm cumming anyway. The risk and the rhythm make the orgasm hit even harder. I hate that I like it.*";
                    case 1 -> "*I told him to stop but I'm cumming so hard right now while we dance. The way he's fingering me makes it impossible to fight.*";
                    default -> "*I said stop but the orgasm came anyway while we sway. Part of me wanted it. Part of me hates that.*";
                };
            } else {
                mc = "*I said stop but {npc_his} fingers kept going while we sway. I cum anyway. It happens, but it feels distant and mechanical.*";
            }
        }

        return refusal + "\n\n" + npcIgnores + "\n\n" + orgasm + "\n\n" + mc + exposureNote;
    }

    // ── MC realises she's about to cum while being fingered on the floor ──────
    String buildAboutToCumText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "The sensation is cresting. You're running out of time.";
        String d        = drunkTier();
        String tier     = gameStageVariant("finger_public");
        boolean commando  = state.hasTrait("commando");
        boolean topLifted = state.hasTrait("top_lifted");
        boolean braless   = state.isBraless();
        boolean isShy    = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOut    = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");
        String exposureNote = topLifted
            ? (tier.equals("shy") || (!tier.equals("enjoy")))
                ? (braless
                    ? "\n\n*Not here — not with my bare breasts out and everyone watching me lose control.*"
                    : "\n\n*Not here — not with my top still up and everyone staring at my chest.*")
                : (braless
                    ? "\n\n*About to cum with my bare tits out for the whole bar — the exposure is pushing me even faster.*"
                    : "\n\n*About to cum with my top still up — everyone can see my chest while I go over the edge.*")
            : "";
        int roll = rng.nextInt(3);

        // Top-lifted context — exposure amplifies the about-to-cum moment
        boolean topUp = state.hasTrait("top_lifted");
        String topNote = "";

        if (d.equals("blackout"))
            return "Something… building. About to… while we dance. Can't think clearly."
                 + (commando ? "\n\n*No panties… bare… close…*" : "") + topNote;
        if (topUp) {
            boolean tpBraless = state.isBraless();
            topNote = tier.equals("shy")
                ? (tpBraless
                    ? "\n\n*My bare breasts are still out. The bar is watching while I'm about to cum. I can't cover and I can't stop it.*"
                    : "\n\n*My top is still up — everyone can see my bra and my face right now. I'm about to orgasm in front of all of them.*")
                : tier.equals("enjoy")
                    ? "\n\n*My " + (tpBraless ? "bare breasts" : "bra") + " still exposed to the bar while I'm right at the edge — the public risk is making this even more intense.*"
                    : "\n\n*Top still up. Bar still watching. And I'm about to cum anyway.*";
        }

        // ── Physical setup ────────────────────────────────────────────────────
        String setup = d.equals("drunk")
            ? "His fingers curl and stroke inside you while you both rock to the music. The edge suddenly rushes toward you."
            : "His fingers are pumping steadily inside you under your skirt while you both sway. The pressure builds relentlessly until it hits a tipping point.";

        // ── Commando note ─────────────────────────────────────────────────────
        String commandoNote = commando
            ? tier.equals("shy")
                ? "\n\n*Oh god, I'm not wearing anything underneath… if I cum everyone might see how wet I am. Panic surges.*"
                : tier.equals("enjoy")
                    ? "\n\n*Fuck… no panties and he's fingering me right here on the dance floor… I'm going to cum so hard if he doesn't stop.*"
                    : "\n\n*No panties… his fingers are inside me completely bare while we dance. Orgasm incoming.*"
            : "";

        // ── MC internal realisation by tier ───────────────────────────────────
        String mc;
        if (d.equals("drunk")) {
            if (tier.equals("shy")) {
                mc = isShy
                    ? "*No… I'm going to cum on his fingers while we're dancing… everyone might notice. The shame is overwhelming but I can't stop my body.*"
                    : "*No… if he keeps going I'm going to cum on the dance floor… everyone will see. Panic floods me but my body won't listen.*";
            } else if (tier.equals("enjoy")) {
                mc = "*Oh fuck… I'm going to cum right here while we slow dance… the alcohol makes the idea feel dangerously hot.*";
            } else {
                mc = "*I'm about to cum while we dance… the realization is there but the haze softens it.*";
            }
        } else {
            if (tier.equals("shy")) {
                mc = switch (roll) {
                    case 0 -> "*Oh no… if he doesn't stop I'm going to cum right here on the dance floor… everyone will know… I can't let this happen.*";
                    case 1 -> "*No… if he keeps going I'm going to cum on the dance floor… everyone will see. Panic floods me but my body won't listen.*";
                    default -> "*He's going to make me cum while we're still dancing… I can feel it building and I can't stop it.*";
                };
            } else if (tier.equals("enjoy")) {
                mc = switch (roll) {
                    case 0 -> "*Oh god… if he doesn't stop I'm going to cum right here while we're dancing… the thought is terrifying but so arousing.*";
                    case 1 -> "*He's going to make me cum while we're slow dancing… the public risk feels so dirty and exciting. I'm right on the edge.*";
                    default -> "*Fuck… I'm so close. If he keeps fingering me while we dance I'm going to cum in front of everyone.*";
                };
            } else {
                mc = switch (roll) {
                    case 0 -> "*If he doesn't stop soon I'm going to orgasm while we're still dancing. The realization is there but it feels distant.*";
                    case 1 -> "*The feeling is getting too strong… if he doesn't stop I'm going to cum while we dance.*";
                    default -> "*If this keeps going I'm going to cum while we dance… the thought registers but feels muted.*";
                };
            }
        }

        // ── Spoken line ───────────────────────────────────────────────────────
        String spoken;
        if (isShy)
            spoken = "\"Wait… I think I'm going to… please slow down…\" (tiny, trembling whisper)";
        else if (isOut)
            spoken = "\"Hey — slow down or I'm going to cum right here…\"";
        else
            spoken = "\"I… I think I'm getting close… can you stop for a second?\"";

        return setup + "\n\n" + mc + commandoNote + "\n\n" + spoken + exposureNote;
    }

    // ── MC says stop during fingering (pre-orgasm) ────────────────────────────
    String buildMcSaysStopFingeringText() {
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean isShy = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOut = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");
        int roll = rng.nextInt(4);

        if (d.equals("blackout"))
            return "Your head spins as you barely manage to mumble against him. \"St… stop… 'm gonna…\"";

        String internal;
        String spoken;

        if (d.equals("drunk")) {
            if (tier.equals("enjoy")) {
                internal = "*Fuck… stop or I'm gonna cum all over his fingers while we dance…*";
                spoken = "\"Fuck… stop or I'm gonna cum all over your fingers while we dance…\"";
            } else if (tier.equals("shy") || isShy) {
                internal = "*Stop—please stop, I'm gonna cum… everyone will see…*";
                spoken = "\"Stop—please stop, I'm gonna cum… everyone will see…\"";
            } else {
                internal = "*Stop. Gonna cum soon.*";
                spoken = "\"…Stop. Gonna cum soon.\"";
            }
        } else {
            // sober/tipsy
            if (tier.equals("enjoy")) {
                spoken = isShy
                    ? "\"Mmm… stop, or I'm really going to cum right here…\"  (husky, half-hearted)"
                    : "\"Stop… or I'm really going to cum right here while we're dancing…\"";
                internal = "*I'm right on the edge. If he keeps going I'm cumming on the dance floor.*";
            } else if (isShy) {
                spoken = switch (roll) {
                    case 0 -> "\"P-please… stop…\" (barely a whisper, voice cracking, clutching his shirt)";
                    case 1 -> "\"Stop — you have to stop right now…\"";
                    case 2 -> "\"Please… I can't… stop…\"";
                    default -> "\"Please stop… I'm about to…\"";
                };
                internal = "*Oh god, I have to say it louder… but everyone might hear… but I can't cum here.*";
            } else if (isOut) {
                spoken = switch (roll) {
                    case 0 -> "\"Hey, stop fingering me or I'm going to cum right here on the dance floor.\"";
                    case 1 -> "\"Stop — I mean it. I'm right on the edge.\"";
                    case 2 -> "\"Stop fingering me right now or I'm cumming in front of everyone.\"";
                    default -> "\"He needs to hear it clear.\" \"Stop. Right now.\"";
                };
                internal = "*He needs to hear it clearly. I'm right on the edge.*";
            } else {
                spoken = switch (roll) {
                    case 0 -> "\"Um… can you stop? I think I'm… really close…\"";
                    case 1 -> "\"…You should stop. I'm getting too close.\"";
                    case 2 -> "\"I… I think I'm about to cum. Please stop.\"";
                    default -> "\"Can you stop? I'm about to…\"";
                };
                internal = "*I should tell him it's getting too intense.*";
            }
        }

        return "You grab at {npc_his} wrist while you both sway."
             + "\n\n" + internal
             + "\n\n" + spoken;
    }

    // ── NPC refuses to stop when MC says stop mid-fingering ──────────────────
    String buildNpcRefusesStopText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_He} keeps going.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        int roll = rng.nextInt(4);

        if (d.equals("blackout"))
            return "{npc_He} barely acknowledges your words, just keeps working {npc_his} fingers inside you as you sag against {npc_him}. \"Yeah… that's it. Just dance.\"";

        // ── NPC refusal line by trait and drunk level ─────────────────────────
        String npcLine;
        if (hasTrait(n, "Sleazy")) {
            npcLine = switch (roll) {
                case 0 -> d.equals("drunk")
                    ? "{npc_He} holds you tighter, fingers thrusting without pause. \"Shh, don't fight it. I'm not stopping until you cum right here on the dance floor.\""
                    : "{npc_He} leans in closer, lips brushing your ear as {npc_his} fingers keep pumping. \"Nah… you feel too good. Just keep dancing, baby. Let it happen.\"";
                case 1 -> "{npc_He} chuckles lowly, grip tightening on your waist while {npc_his} fingers curl deeper. \"Stop? Not a chance. You're soaking my hand… keep swaying and enjoy it.\"";
                case 2 -> "He tightens his hold on your waist, fingers not even slowing. \"Not a chance. You're clenching so tight — I want to feel you cum on my fingers while we dance.\"";
                default -> "{npc_He} smirks against your ear, fingers thrusting steady. \"Nah, you're not stopping me now. Just let go.\"";
            };
        } else if (hasTrait(n, "Jerk")) {
            npcLine = switch (roll) {
                case 0 -> "{npc_He} smirks and keeps going, fingers curling with deliberate slowness. \"Make me stop, then. Tell everyone what I'm doing to you if you want me to quit.\"";
                case 1 -> "{npc_He} grins against your ear. \"Too late for stop, sweetheart. Feel how wet you are? You're gonna cum for me right here.\"";
                case 2 -> "{npc_He} keeps thrusting without breaking the dance rhythm. \"You're soaked and you're begging me to stop. Pick one.\"";
                default -> "{npc_He} just laughs softly and presses deeper. \"Relax. I'll stop when you've cum.\"";
            };
        } else if (hasTrait(n, "Confrontational")) {
            npcLine = "{npc_He} grins and fingers you faster instead of slower. \"You say stop but you're clenching harder. Your body's decided for you.\"";
        } else if (hasTrait(n, "Alcoholic")) {
            npcLine = switch (roll) {
                case 0 -> d.equals("drunk")
                    ? "{npc_He} blinks blearily, face flushed, then grins lopsidedly as {npc_his} fingers keep thrusting. \"Shhh… no stoppin'. You feel s'good. Keep swayin'… gonna make you cum right here.\"  {npc_He} yanks you flush against {npc_him}, swaying heavily."
                    : "{npc_He} slurs against your ear, fingers not slowing at all. \"Stop? Nahhh… you don' really mean that. Feels too good t'stop now…\"";
                case 1 -> d.equals("drunk")
                    ? "{npc_He} shakes {npc_his} head, eyes glassy, fingers thrusting erratically but relentlessly. \"Shhh… no stoppin'. I ain' stoppin' till you cum for me.\""
                    : "\"Wha'? No way… you're all wet for me. Jus' dance, baby. Lemme feel you cum.\" {npc_He} leans his full weight on you, fingers shoving deeper.";
                case 2 -> "{npc_He} chuckles drunkenly, breath hot and boozy against your ear, fingers curling messily. \"Cum then! Thass the point… I ain' stoppin'. You're mine t'night.\"  {npc_He} squeezes your ass hard with {npc_his} free hand.";
                default -> "\"Listenin'? I am… you're sayin' you like it.\" {npc_He} mumbles, fingers continuing their sloppy, relentless circles, completely ignoring your protest.";
            };
        } else {
            npcLine = "{npc_He} just hums and keeps the same rhythm, holding you close. \"No can do. Just sway with me… let it build.\"";
        }

        // ── MC reaction to being ignored ──────────────────────────────────────
        String mc;
        boolean isAlcoholic = hasTrait(n, "Alcoholic");
        if (tier.equals("enjoy"))
            mc = isAlcoholic
                ? "*He's too drunk to care what I say… his persistent groping and refusal is making the risk feel even hotter.*"
                : "*{npc_His} refusal sends a fresh wave of heat through you. The risk of cumming publicly because {npc_he} won't listen is turning you on even more.*";
        else if (tier.equals("shy"))
            mc = isAlcoholic
                ? "*He's so drunk he won't listen at all. His fingers won't stop and he's groping me so roughly while we sway… I can't make him stop.*"
                : "*Panic floods you as {npc_he} ignores your plea. You're trapped on the dance floor, about to orgasm in front of everyone and {npc_he} won't stop.*";
        else
            mc = isAlcoholic
                ? "*He doesn't even register the word stop. His drunk hands just keep groping and thrusting while the dance goes on.*"
                : "*The realisation that {npc_he}'s not stopping settles in dully. Your body is going to cum while you sway to the music, whether you protest or not.*";

        return npcLine + "\n\n" + mc;
    }

    // ── NPC grabs neck during kiss + fingering ────────────────────────────────
    String buildNeckGrabText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hand slides up to your neck.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean isShy = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOut = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");

        state.flagNeckKissed = true;

        if (d.equals("blackout"))
            return "Everything spins as {npc_he} pulls you into a sloppy kiss, {npc_his} hand loosely but firmly gripping your neck. "
                 + "{npc_His} fingers are still inside you, moving in time with the hazy sway of the dance."
                 + "\n\n*His hand is around my neck... the spinning room makes it impossible to react properly.*";

        // ── Physical description ───────────────────────────────────────────────
        String base;
        if (d.equals("drunk")) {
            base = hasTrait(n, "Alcoholic")
                ? "{npc_He} yanks you closer, mouth devouring yours in a wet, drunken make-out while {npc_his} hand wraps around your neck — thumb pressing lightly under your jaw. "
                  + "{npc_His} swaying is unsteady but {npc_he} refuses to let go, fingers pumping relentlessly below."
                : "{npc_He} pulls you into a deep, messy kiss while {npc_his} hand slides up and closes around your neck, possessive and controlling. "
                  + "{npc_His} fingers keep thrusting inside you under your skirt without pause.";
        } else {
            base = hasTrait(n, "Alcoholic")
                ? "{npc_His} lips smash into yours mid-sway, tasting of liquor, while {npc_his} hand slides up to grip your throat possessively. "
                  + "\"You talk too much…\" {npc_he} mumbles into the kiss, fingers curling deeper as {npc_he} holds you in place."
                : "{npc_He} pulls you into the kiss without warning — {npc_his} hand clamping around your neck at the same moment. "
                  + "The sway of the dance makes {npc_his} grip shift slightly with every step, {npc_his} other hand never stopping below.";
        }

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (tier.equals("enjoy"))
            mc = isShy
                ? "*Fuck… his hand around my throat while he kisses me and fingers me while we sway... the dominance is overwhelming. I'm even closer now.*"
                : "*His hand around my neck while he kisses me deep and fingers me right here… the control is pushing me so close to cumming on the dance floor.*";
        else if (tier.equals("shy"))
            mc = isShy
                ? "*Oh god… his hand is around my neck… I can't breathe right, can't pull away, can't tell him to stop… we're still swaying and he's fingering me.*"
                : "*He's grabbing my neck… I can't speak, can't pull away, and his fingers won't stop. Everyone might see us making out like this.*";
        else
            mc = "*The neck grab registers dully. His mouth is on mine and his hand is around my throat… we're still swaying to the music with his fingers inside me.*";

        // ── Spoken/muffled reaction ───────────────────────────────────────────
        String spoken;
        if (isShy)
            spoken = "\"Mmph—!\" (muffled into the kiss, tiny whimper as {npc_his} grip tightens slightly)";
        else if (isOut)
            spoken = "\"Mm—stop…!\" (mumbled against {npc_his} lips, voice vibrating into {npc_his} mouth)";
        else
            spoken = "A soft muffled sound. No real protest left with {npc_his} mouth on yours.";

        return base + "\n\n" + mc + "\n\n" + spoken;
    }

    // ── NPC releases neck grip — fingering continues ──────────────────────────
    String buildNeckReleaseText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hand slides off your neck.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean isShy = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOut = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");

        if (d.equals("blackout"))
            return "The pressure on your neck eases as {npc_his} hand drops away, but the sloppy kiss and swaying motion continue in a hazy blur. "
                 + "{npc_His} fingers remain inside you, moving on autopilot."
                 + "\n\n*The neck grip is gone... but nothing else stopped.*";

        // ── Physical release ──────────────────────────────────────────────────
        String base;
        if (hasTrait(n, "Alcoholic")) {
            base = d.equals("drunk")
                ? "{npc_His} grip loosens clumsily, hand slipping from your neck to paw at your chest or hip. "
                  + "\"Mmm… good girl,\" {npc_he} mumbles into the kiss, swaying heavily while {npc_his} fingers keep working you relentlessly."
                : "{npc_He} releases your neck with a drunken chuckle, hand drifting down to squeeze your ass instead. "
                  + "The kiss continues wet and insistent as you both sway, {npc_his} fingering never faltering.";
        } else {
            base = "{npc_His} hand finally slides off your neck, fingers trailing along your collarbone before dropping lower. "
                 + "{npc_His} lips stay locked on yours, and {npc_his} other hand never stops thrusting steadily inside you under your skirt.";
        }

        // ── MC reaction to the brief release ─────────────────────────────────
        String mc;
        if (tier.equals("enjoy"))
            mc = isShy
                ? "*He finally let go of my neck… but he's still kissing me hard and fingering me while we sway. The relief just makes the edge feel sharper.*"
                : "*The neck grip is gone… but now he's groping me harder and still kissing me like he owns me. It's making me throb around his fingers.*";
        else if (tier.equals("shy"))
            mc = "*He finally let my neck go… I can breathe again, but he's still kissing me so insistently and fingering me right here on the dance floor.*";
        else
            mc = "*The pressure on my neck is gone now… but his fingers are still inside me and his mouth hasn't stopped.*";

        // ── Spoken ────────────────────────────────────────────────────────────
        String spoken;
        if (isOut)
            spoken = "\"Finally — now stop fingering me…\" (mumbled against {npc_his} lips before {npc_he} dives back in)";
        else if (isShy)
            spoken = "\"Hah… wait—\" (soft, breathless whisper the moment the kiss breaks even slightly)";
        else
            spoken = "A quiet exhale. No strong protest.";

        return base + "\n\n" + mc + "\n\n" + spoken;
    }

    // ── NPC cums in pants while grinding during slow dance ────────────────────
    String buildNpcCumsGrindingText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_He} shudders against you.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean commando = state.hasTrait("commando");
        boolean isShy    = state.hasTrait("shy") || state.hasTrait("fragile_ego");
        boolean isOut    = state.hasTrait("outgoing") || state.hasTrait("confrontational");
        int roll = rng.nextInt(4);

        if (d.equals("blackout"))
            return "{npc_He} sags heavier against you, a wet groan escaping as {npc_he} cums in {npc_his} pants. "
                 + "The sticky warmth registers faintly while the hazy sway continues."
                 + "\n\n*Warm and wet against me… his fingers haven't stopped.*";

        // ── Physical description ───────────────────────────────────────────────
        String base = "Without warning {npc_his} rhythm falters — hips jerking sharply once, twice. "
                    + "A low, drunken groan escapes {npc_him} as {npc_he} cums hard in {npc_his} pants. "
                    + "You feel the rhythmic pulsing through the fabric, then the warm, sticky wetness spreading against you. "
                    + "{npc_He} keeps swaying, fingers still moving inside you, riding it out.";

        // ── NPC drunk-level reaction ──────────────────────────────────────────
        String npcLine;
        if (hasTrait(n, "Alcoholic")) {
            npcLine = switch (roll) {
                case 0 -> d.equals("drunk")
                    ? "\"Ah— shit, I just… fuck…\" he groans, clearly caught off guard, pressing the wet spot harder against you."
                    : "\"Shit… fuck, that wasn't…\" he slurs, hips still twitching. He doesn't pull away.";
                case 1 -> "\"Whoa— damn, that was fast…\" he chuckles awkwardly, refusing to stop swaying or fingering you.";
                case 2 -> "\"Didn't mean to… you're too much,\" he mumbles, still pressing the damp fabric against you.";
                default -> "\"Fuuuck… shit…\" — he says nothing else. His fingers slow but don't stop. The grinding gets messier.";
            };
        } else if (hasTrait(n, "Sleazy")) {
            npcLine = switch (roll) {
                case 0 -> "\"There it is,\" he breathes against your ear. \"Feel that? You did that.\" He keeps going.";
                case 1 -> "\"Fuck yeah…\" — barely a word. His grip on you tightens as the aftershocks run through him.";
                case 2 -> "\"God, you feel so good,\" he slurs, riding it out against you. The fingers don't slow.";
                default -> "He doesn't speak — just grinds through it, breathing hard, fingers curling deeper.";
            };
        } else {
            npcLine = "{npc_He} shudders and goes briefly rigid, then relaxes heavily against you. The wet warmth spreads. {npc_He} doesn't stop.";
        }

        // ── Commando note ─────────────────────────────────────────────────────
        String commandoNote = commando
            ? tier.equals("shy")
                ? "\n\n*He just came and I have no panties… I can feel the heat of it through his pants against my bare skin. This is mortifying.*"
                : "\n\n*The warmth of it is more obvious with nothing between us. Bare skin through the fabric.*"
            : "";

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (tier.equals("enjoy"))
            mc = isShy
                ? "*He came in his pants while swaying and fingering me… the way his control slipped is making me throb even harder.*"
                : "*He just lost control and came in his pants from this. The pulsing and the heat are making me even closer.*";
        else if (tier.equals("shy"))
            mc = isShy
                ? "*He's cumming in his pants right against me while we dance and his fingers won't stop. Everyone might see the wet spot. This is so humiliating.*"
                : "*He just came in his pants pressed against me while we're still swaying. The wet warmth is soaking through. I feel disgusted and exposed.*";
        else
            mc = "*He came while grinding against me. The pulsing and the sticky warmth register clearly. The dance keeps going.*";

        // ── MC spoken ─────────────────────────────────────────────────────────
        String spoken;
        if (isShy)   spoken = "\"Ah— you just…\" (tiny, trembling whisper, face burning)";
        else if (isOut) spoken = "\"Did you seriously just cum in your pants?\"";
        else         spoken = "\"…You came.\"";

        return base + "\n\n" + npcLine + commandoNote + "\n\n" + mc + "\n\n" + spoken;
    }

    // ── NPC verbal humiliation after cumming in pants ─────────────────────────
    String buildNpcHumiliationText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_He} says something degrading.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean isShy = state.hasTrait("shy") || state.hasTrait("fragile_ego");
        boolean isOut = state.hasTrait("outgoing") || state.hasTrait("confrontational");
        int roll = rng.nextInt(4);

        if (d.equals("blackout"))
            return "{npc_He} mumbles something slurred and degrading against your hair. "
                 + "\"Came too fast… your fault… feel that mess?\" The swaying and fingering continue."
                 + "\n\n*His words reach me in pieces. His fingers haven't stopped.*";

        // ── NPC humiliation line ───────────────────────────────────────────────
        String npcLine;
        if (d.equals("drunk")) {
            npcLine = switch (roll) {
                case 0 -> "\"Goddamn… I just blew my load in my pants grinding on you.\" He slurs against your ear, hips still moving. \"Feel that? That's your fault for being so easy to finger on the dance floor. Keep swaying — I'm not done with you.\"";
                case 1 -> "\"Shit I came fast…\" He laughs thickly. \"You made me do that. Feel how wet it is now? That's all because of you.\"";
                case 2 -> "\"You made me cum in my pants in public,\" he slurs. \"Bet you're proud. Now you're gonna finish on my fingers too.\"";
                default -> "\"You felt too good… couldn't help it.\" He doesn't even slow the fingering. \"You're still gonna cum for me though.\"";
            };
        } else {
            npcLine = switch (roll) {
                case 0 -> "\"Look what you made me do,\" he breathes, voice thick. \"Cumming in my pants on the dance floor because of your greedy little pussy. Feel how wet my pants are? That's you.\"";
                case 1 -> "\"I just came in my pants because you're too wet.\" He grins and presses the damp spot harder against you. \"Now you're going to cum on my fingers. Fair's fair.\"";
                case 2 -> "\"Bet you love knowing you made me lose control like that,\" he slurs. \"Come on. Cum for me now. We're even.\"";
                default -> "\"Didn't mean to finish that fast — you're just too much.\" He keeps the rhythm. \"Your turn now.\"";
            };
        }

        // ── MC reaction to being humiliated ───────────────────────────────────
        String mc;
        if (tier.equals("enjoy"))
            mc = "*His words are so degrading… blaming me for making him cum in public while his fingers are still working me. It's humiliating and it's making me throb.*";
        else if (tier.equals("shy"))
            mc = isShy
                ? "*He's blaming me for his cum, saying it's my fault, while we keep swaying on the floor with everyone around us. The shame is burning through me.*"
                : "*His words hit hard. Blaming me. Saying I made this happen. While his fingers are still inside me and the dance keeps going.*";
        else
            mc = "*His words register. He's blaming me for his orgasm while continuing to finger me. The dance keeps going.*";

        String spoken;
        if (isShy)   spoken = "\"Stop saying that… please…\" (voice small and trembling)";
        else if (isOut) spoken = "\"You came. That's not my fault — get your hands off me.\"";
        else         spoken = "\"…You came. It's not my fault.\"";

        return npcLine + "\n\n" + mc + "\n\n" + spoken;
    }

    private String assGropeMcReact(String tier, String d) {
        // tier: "shy"=doesn't enjoy, "flustered"=neutral, "enjoy"=enjoys
        // d: "blackout", "drunk", "tipsy" (tipsy covers sober too)

        if (d.equals("blackout"))
            return "*Warm pressure... on my ass. We're still dancing. The spinning room makes it hard to tell how it feels.*";

        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                return "His fingers dig deep into your ass while you both rock slowly to the music. He grinds obvious and slow."
                     + "\n\n*His hand on my ass while we dance — squeezing hard and grinding against me in rhythm. The violation still cuts through the haze.*";
            if (tier.equals("enjoy"))
                return "*His hand on my ass feels dirty and hot while we dance. The alcohol makes me want to grind back against him in rhythm.*";
            return "*Something is happening on my ass as we dance. It registers, but the buzz makes it feel distant and unimportant.*";
        }

        // sober/tipsy
        if (tier.equals("shy"))
            return "You feel his fingers spread and squeeze your ass as you both move slowly to the music."
                 + "\n\n*He's groping my ass hard while we're dancing. His fingers are digging in and he's grinding against me in time with the song. The violation feels sharp and humiliating right here on the floor.*";
        if (tier.equals("enjoy"))
            return "You feel his fingers dig into your ass while you both sway to the slow beat. He grinds forward in time with the music."
                 + "\n\n*His hand is on my ass, squeezing hard while we dance. The way he's pulling me against his cock in rhythm feels dirty and exciting. The public slow dance makes it even hotter.*";
        return "His hand cups and squeezes your ass while you both sway together."
             + "\n\n*I feel his hand on my ass, squeezing as we dance slowly. It registers, but I don't feel strongly about it either way.*";
    }

    private String roamingMcReact(String tier, String d) {
        // Combined ass + breast roaming grope reaction
        // tier: "shy"=doesn't enjoy, "flustered"=neutral, "enjoy"=enjoys

        if (d.equals("blackout"))
            return "*Warm pressure everywhere... hands on my chest, on my ass. The spinning room makes it impossible to separate the sensations.*";

        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                return "*Everything is happening at once — {npc_his} hand on my ass, fingers on my breast, grinding against me. The violation is everywhere. I feel helpless and used.*";
            if (tier.equals("enjoy"))
                return "*His hands are all over me — ass, tits, everywhere — and the alcohol makes me want more. The public risk is making it hotter.*";
            return "*His hands keep moving everywhere — ass, chest, back again. I feel it all, but the buzz keeps it from landing hard.*";
        }

        // sober/tipsy
        if (tier.equals("shy"))
            return "*{npc_His} hands keep moving everywhere — ass to breasts to hips — and every touch makes me feel more owned. I said stop and he's still going and I don't know how to make it end.*";
        if (tier.equals("enjoy"))
            return "You feel his hands roaming freely — cupping your ass, moving up to your breast, back down again. Heat builds with each pass."
                 + "\n\n*His hands all over me feels risky and really good. The way he moves between places like he owns the map of me is turning me on.*";
        return "His hands keep moving — ass, waist, breast, back again. You feel each place register clearly."
             + "\n\n*It's a lot. Everything is happening and I feel every touch, but I don't know what I want from any of it right now.*";
    }

    /**
     * Kissing text — layered on top of ongoing groping.
     * Sets flagKissed. If flagAssGroped also set, describes kissing while groping.
     * tier: shy (frozen/panicked), flustered (hesitant/not ready), enjoy (kisses back).
     */
    public String buildKissText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "She leans in and kisses you.";
        String d    = drunkTier();
        String tier = gameStageVariant();
        boolean assGroped = state.flagAssGroped;
        state.flagKissed = true;

        if (hasTrait(n, "Sleazy")) {
            if (d.equals("blackout")) return "{npc_He} kisses your limp mouth. Distant and wet. No reaction forms.";
            String npcLine = assGroped
                ? (d.equals("drunk")
                    ? "\"Ass in my hands, mouth on mine — been doing this for a while and you're still letting me.\""
                    : "\"Been groping this ass, kissing your mouth — you taste good while I squeeze you.\"")
                : (d.equals("drunk")
                    ? "\"Your mouth is mine now too.\""
                    : "\"Taking your mouth since you're already letting me do everything else.\"");
            return npcLine + "\n\n" + kissMcReact(tier, d, false);
        }
        if (hasTrait(n, "Jerk")) {
            if (d.equals("blackout")) return "{npc_He} kisses you possessively. Your body barely registers it.";
            String npcLine = d.equals("drunk")
                ? "\"Been all over your body and mouth for a while. You taste average at best.\""
                : "\"Taking your mouth. You're not even fighting it — convenient.\"";
            return npcLine + "\n\n" + kissMcReact(tier, d, false);
        }
        if (hasTrait(n, "Alcoholic")) {
            if (d.equals("blackout")) return "Sloppy, wet heat on your mouth. You barely register it.";
            String base = d.equals("drunk")
                ? "{npc_He} leans in and captures your mouth in a deep, sloppy kiss. {npc_His} lips are warm and taste strongly of whiskey and beer. "
                  + "{npc_His} tongue pushes past your lips, messy and insistent, while you both continue to sway."
                : "{npc_He} pulls you into a firm, controlling kiss mid-sway, tongue sliding against yours with alcohol-fueled hunger. "
                  + "He moans softly into your mouth, the sound vibrating between you.";
            return base + "\n\n" + kissMcReact(tier, d, false);
        }
        if (hasTrait(n, "Engaging")) {
            if (d.equals("blackout")) return "{npc_His} lips find yours gently. Warmth.";
            String base = d.equals("drunk")
                ? "{npc_He} leans in slowly, giving you time to close the last distance yourself. When the kiss lands it's steady and warm."
                : "{npc_He} kisses you once — unhurried, asking without asking. {npc_His} hand stays exactly where it was.";
            return base + "\n\n" + kissMcReact(tier, d, false);
        }
        if (hasTrait(n, "Magnetic")) {
            if (d.equals("blackout")) return "The kiss arrives with quiet certainty. Warmth. Nothing else forms.";
            String base = d.equals("drunk")
                ? "{npc_He} kisses you. No preamble. Certain the way everything {npc_he} does is certain."
                : "{npc_He} leans in and closes the space between you with complete calm. The kiss is deliberate. "
                  + "{npc_He} stays until {npc_he} feels you respond, then deepens it slightly.";
            return base + "\n\n" + kissMcReact(tier, d, false);
        }
        if (hasTrait(n, "Shy")) {
            if (d.equals("blackout")) return "A tentative warmth on your lips. Gone almost before it registers.";
            String base = d.equals("drunk")
                ? "{npc_He} kisses you — faster than {npc_he} meant to, clearly startled by the fact that {npc_he} did it."
                : "Very slowly, {npc_he} leans in. The kiss is brief and a little clumsy. "
                  + "{npc_He} pulls back immediately, face red, waiting to see what you do.";
            return base + "\n\n" + kissMcReact(tier, d, false);
        }
        if (hasTrait(n, "Self_Assured")) {
            if (d.equals("blackout")) return "The kiss arrives cleanly. Warm and certain.";
            String base = d.equals("drunk")
                ? "\"I'm going to kiss you now.\" {npc_He} does. Simple as that."
                : "{npc_He} kisses you without ceremony — firm and direct, like {npc_he} had already decided and was just waiting for the right moment.";
            return base + "\n\n" + kissMcReact(tier, d, false);
        }
        if (hasTrait(n, "Confrontational")) {
            if (d.equals("blackout")) return "{npc_He} kisses you like {npc_he}'s proving a point.";
            String base = d.equals("drunk")
                ? "{npc_He} kisses you harder than needed — daring you to pull back. Watching for what you do."
                : "{npc_He} leans in and takes the kiss rather than asking for it. Holds it a beat longer than comfortable, checking.";
            return base + "\n\n" + kissMcReact(tier, d, false);
        }
        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover")) {
            if (d.equals("blackout")) return "{npc_He} kisses you with the same energy {npc_he} brings to everything. Warm and immediate.";
            String base = d.equals("drunk")
                ? "\"Okay, I'm going to kiss you,\" {npc_he} announces — and does. Already laughing slightly."
                : "{npc_He} grins and kisses you mid-sentence, like it just seemed like a good idea. Maybe it was.";
            return base + "\n\n" + kissMcReact(tier, d, false);
        }
        // Default
        if (d.equals("blackout")) return "{npc_His} lips find yours. Warmth. Nothing else.";
        return pick("{npc_He} leans in and kisses you — slow, asking.", "The kiss happens before you've quite decided about it.")
             + "\n\n" + kissMcReact(tier, d, false);
    }

    /**
     * NPC gropes breasts under shirt — over bra or directly if braless.
     * tier: shy = embarrassed/stops; flustered = hesitant/mixed; enjoy = lets it happen.
     * Willpower/arousal gate on stop choice is handled in YAML — method just generates text.
     */
    public String buildBreastGropeText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hands slide up under your shirt.";
        String d      = drunkTier();
        String tier   = gameStageVariant("breast_public");
        boolean braless = state.hasTrait("exposed_breasts");

        String base = braless
            ? "{npc_His} hands slip under the hem of your shirt, gliding up your bare stomach. "
              + "Without any bra, {npc_his} palms immediately cup your naked breasts, squeezing the soft warm flesh directly. "
              + "{npc_His} thumbs brush over your bare nipples as {npc_he} kneads firmly."
            : "{npc_His} hands slide slowly from your hips upward, slipping under the hem of your shirt. "
              + "{npc_His} palms glide over your stomach, then cup and squeeze your breasts firmly over your bra. "
              + "Thumbs brush across the fabric deliberately.";

        String mcReact = breastGropeMcReact(tier, d, braless);
        String clothing = breastGropeClothing(braless);

        state.flagBreastGroped = true;
        String result = base + "\n\n" + mcReact;
        if (!clothing.isEmpty()) result += "\n\n" + clothing;
        return result;
    }

    private String breastGropeMcReact(String tier, String d, boolean braless) {
        // Check mod text pool for breast grope MC reaction matching current tier
        String poolName = "bar.grope.breast." + tier + "_mc";
        String modResult = pickFromPool(poolName, buildMcTraitSet());
        if (modResult != null && !modResult.isEmpty()) return modResult;

        return breastGropeMcReact(tier, d, braless,
            state.hasTrait("pierced_nipping_prominent") || state.hasTrait("nipping"));
    }

    String breastGropeMcReact(String tier, String d, boolean braless, boolean nipping) {
        // tier: "shy"=doesn't enjoy, "flustered"=neutral, "enjoy"=enjoys
        // braless+nipping = most exposed; braless only = bare skin; bra+nipping = visible through bra

        if (d.equals("blackout")) {
            if (braless)
                return "*Warm... under my shirt. Fingers on my nipple. The spinning room makes it impossible to tell how it feels.*";
            return "*Warm pressure... on my chest through the bra while we dance. The spinning room makes it hard to tell how it feels.*";
        }

        if (d.equals("drunk")) {
            if (tier.equals("shy")) {
                if (braless && nipping)
                    return "Your push is shaky and half-hearted. *His hand is under my shirt on my bare breast, squeezing and rolling my hard nipple. Being braless makes it worse — there's nothing between his fingers and my skin. Everyone can see how stiff they are.*";
                if (braless)
                    return "Your push is shaky and half-hearted. *His hand is under my shirt on my bare breast, squeezing and rolling my nipple. I feel so exposed and violated.*";
                return "Your push is shaky and half-hearted. *He's groping my breast and focusing on my nipple through the bra — the violation cuts through the haze.*";
            }
            if (tier.equals("enjoy")) {
                if (braless && nipping)
                    return "*His hand on my tit, playing with my hard nipple through the thin fabric while we dance... it feels hot and dirty. The alcohol makes me want to press into it.*";
                if (braless)
                    return "*His hand on my bare tit feels dirty and hot. The alcohol makes me want to press into it.*";
                return "*His hand on my tit through the bra feels dirty and hot. The alcohol makes me want to press into it.*";
            }
            if (braless && nipping)
                return "*Something is happening on my chest — pressure on my hard nipple. It registers, but the buzz makes it feel distant.*";
            return "*Something is happening on my chest. It registers, but the buzz makes it feel distant and unimportant.*";
        }

        // sober/tipsy
        if (tier.equals("shy")) {
            if (braless && nipping)
                return "You feel his palm cup your bare breast, thumb immediately rolling your prominent nipple through the thin top while you both sway. The visible nipping makes everything feel more exposed."
                     + "\n\n*He's groping my breast and playing with my hard nipple right through my top while we dance. Everyone can see how stiff they are. The violation is sharp and humiliating. I feel completely exposed.*";
            if (braless)
                return "You feel the sudden pressure of bare skin contact, his palm on your breast through the thin fabric."
                     + "\n\n*He's grabbed my bare breast right here on the dance floor. The violation is sharp. I feel exposed and disrespected.*";
            if (nipping)
                return "You feel his palm cup your breast, thumb deliberately circling your hard, visible nipple through the bra while you both continue moving slowly together."
                     + "\n\n*He's groping my breast and focusing on my nipple through my bra while we're slow dancing. The pressure is still invasive and the visible nipping makes me feel exposed.*";
            return "You feel the sudden deliberate pressure on your breast, thumb brushing your nipple through the fabric."
                 + "\n\n*He just grabbed my breast right here on the dance floor. The violation is sharp and clear. I feel exposed and disrespected.*";
        }
        if (tier.equals("enjoy")) {
            if (braless && nipping)
                return "You feel his palm cup your bare breast and his thumb circle your prominent nipple through the fabric. Heat spreads."
                     + "\n\n*He's groping my breast and playing with my hard nipple right through my top while we dance. Everyone can see how stiff they are. The risk and the rhythm make it feel incredibly hot.*";
            if (braless)
                return "You feel his palm cup your bare breast through the thin top, heat spreading from the contact."
                     + "\n\n*His hand on my breast feels bold and exciting. The public setting makes it even hotter. I'm getting turned on.*";
            return "You press your chest forward into {npc_his} palms, enjoying the squeeze through the fabric."
                 + "\n\n*His hand on my breast feels risky and good. The attention is exactly what I wanted.*";
        }
        // flustered/neutral
        if (braless && nipping)
            return "His hand cups your breast over your top, thumb moving across your visible nipple as you both sway to the music."
                 + "\n\n*I feel his hand on my breast and the way he's touching my hard nipple while we dance. It registers, but I don't feel strongly about it right now.*";
        if (braless)
            return "His hand cups your bare breast through the thin fabric, warm and direct."
                 + "\n\n*I feel his hand on my breast. It registers, but I don't feel strongly about it right now.*";
        return "You tense at the sudden contact through the fabric, a mix of surprise and warmth."
             + "\n\n*That's direct. I feel it through the bra. I'm not sure what I want from it yet.*";
    }

    private String breastGropeClothing(boolean braless) {
        boolean nipping = state.hasTrait("pierced_nipping_prominent") || state.hasTrait("nipping");
        boolean bounce  = state.hasTrait("bounce_prone_4") || state.hasTrait("bounce_prone_5")
                       || state.hasTrait("bounce_prone_6") || state.hasTrait("bounce_prone_7");

        if (nipping && braless)
            return "Your nipples are clearly visible and poking through the fabric — his thumb immediately brushes and circles one stiff peak, squeezing the soft flesh beneath.";
        if (nipping)
            return "Your nipples harden instantly against {npc_his} thumbs — the outlines pressing clearly through the fabric with each squeeze.";
        if (bounce && braless)
            return "Your breasts jiggle freely with every knead, nothing to contain them.";
        if (bounce)
            return "Your breasts shift noticeably under the shirt with every squeeze.";
        if (braless)
            return "Without a bra, the thin fabric offers almost no barrier — you feel every movement of his fingers directly.";
        return "";
    }

    public String buildBreastGropeNpcStop(NpcData n) {
        String tier = gameStageVariant("breast_public");
        String npcLine;

        if (hasTrait(n, "Engaging"))
            npcLine = "{npc_He} stops right away, hands sliding back to your hips. \"Sorry — got carried away feeling how soft you are.\"";
        else if (hasTrait(n, "Magnetic"))
            npcLine = "{npc_His} hands pause the second you guide them away. Low voice: \"Too much?\" {npc_He} respects it smoothly.";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcLine = "{npc_He} laughs and pulls {npc_his} hands out right away. \"Whoops! Couldn't resist — they feel amazing. My bad!\"";
        else if (hasTrait(n, "Shy"))
            npcLine = "{npc_He} yanks {npc_his} hands back instantly, face flaming. \"S-sorry! I didn't mean to— I'll stop!\"";
        else if (hasTrait(n, "Self_Assured"))
            npcLine = "{npc_He} releases your breasts smoothly. \"Understood. Keeping it lower.\"";
        else if (hasTrait(n, "Sleazy"))
            npcLine = "{npc_He} groans but slowly withdraws. \"Fuck, they feel good… you sure you want me to stop?\""
                    + " {npc_He} does though, fingers lingering a second before leaving.";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_He} smirks and takes {npc_his} time removing {npc_his} hands. \"What, too much for you? They felt pretty nice to me.\"";
        else if (hasTrait(n, "Alcoholic"))
            npcLine = "{npc_His} sweaty hand finally pulls away. {npc_He} mumbles something boozy and sways heavier into you.";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "{npc_He} removes {npc_his} hand with a challenging smirk. \"Fine. You're no fun tonight.\"";
        else
            npcLine = "{npc_His} hands ease away when you stop {npc_him}.";

        // MC reaction after stop
        String mcReact = tier.equals("enjoy")
            ? "*{npc_He} finally stopped... but part of me wanted {npc_him} to keep going while we danced. The thrill is still buzzing through me.*"
            : tier.equals("flustered")
                ? "*The touching stopped. It registers, but I feel mostly numb about it now.*"
                : "*Thank god {npc_he} finally stopped. The violation still lingers, but at least it's over.*";

        return npcLine + "\n\n" + mcReact;
    }

    // ── NPC stops ass groping ──────────────────────────────────────────────────
    String buildAssGropeNpcStop(NpcData n) {
        String tier = gameStageVariant();
        String npcLine;

        if (hasTrait(n, "Sleazy"))
            npcLine = "{npc_He} groans and slowly removes {npc_his} hands from your ass. "
                    + "\"Fuck, that ass is perfect… you sure?\""
                    + " {npc_He} does stop though, fingers trailing as they leave.";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_His} hand finally leaves your ass with a dismissive snort. \"Fine, whatever. You're no fun anyway.\"";
        else if (hasTrait(n, "Alcoholic"))
            npcLine = "{npc_His} sweaty hands pull away from your ass while {npc_he} sways into you. "
                    + "{npc_He} mumbles something half-formed and boozy.";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "{npc_He} finally removes {npc_his} hand from your ass with a challenging smirk. \"Fine. You're no fun tonight.\"";
        else if (hasTrait(n, "Engaging"))
            npcLine = "{npc_His} hand slides back up to your waist immediately. \"Sorry — went a bit far there.\"";
        else if (hasTrait(n, "Self_Assured"))
            npcLine = "{npc_His} hand moves back to your lower back cleanly. \"Fair enough.\"";
        else
            npcLine = "{npc_His} hand moves back to your waist.";

        String mcReact = tier.equals("enjoy")
            ? "*{npc_He} finally stopped... but the way {npc_he} was squeezing my ass while we danced felt good. I almost miss it.*"
            : tier.equals("flustered")
                ? "*The groping stopped. Everything feels neutral as we keep dancing.*"
                : "*Thank god {npc_he} finally stopped groping my ass while we were dancing. The violation still burns.*";

        return npcLine + "\n\n" + mcReact;
    }

    // ── NPC stops pussy grope / fingering ─────────────────────────────────────
    String buildPussyGropeNpcStop(NpcData n) {
        String tier = gameStageVariant("finger_public");
        String npcLine;

        if (hasTrait(n, "Sleazy"))
            npcLine = "{npc_He} slowly withdraws {npc_his} hand from under your skirt, fingers trailing. "
                    + "\"You're soaked… sure you want me to stop? My fingers say different.\"";
        else if (hasTrait(n, "Jerk"))
            npcLine = "{npc_His} hand finally leaves from under your skirt with a dismissive snort. "
                    + "\"Fine, whatever. You were practically dripping.\"";
        else if (hasTrait(n, "Alcoholic"))
            npcLine = "{npc_His} sweaty hand pulls away from under your skirt clumsily. "
                    + "{npc_He} mumbles something boozy and sways heavier against you.";
        else if (hasTrait(n, "Confrontational"))
            npcLine = "{npc_He} finally removes {npc_his} hand from under your skirt with a smirk. "
                    + "\"Fine. You're not stopping the dance though, are you?\"";
        else if (hasTrait(n, "Engaging"))
            npcLine = "{npc_His} hand slides out from under your skirt immediately. \"Way too far — I'm sorry.\"";
        else if (hasTrait(n, "Self_Assured"))
            npcLine = "{npc_His} hand withdraws from under your skirt cleanly. No comment. {npc_He} holds your waist.";
        else
            npcLine = "{npc_His} hand pulls away from under your skirt.";

        String mcReact = tier.equals("enjoy")
            ? "*{npc_He} finally stopped... but the way {npc_he} was touching me under my skirt while we danced felt so good. I almost wish {npc_he} hadn't stopped.*"
            : tier.equals("flustered")
                ? "*The touching under my skirt stopped. The sensation is fading as we keep dancing.*"
                : "*Thank god {npc_he} finally stopped. {npc_His} hand was under my skirt while we were dancing. "
                  + "The violation still burns — relief mixed with lingering shame.*";

        return npcLine + "\n\n" + mcReact;
    }

    // ── Bystander reactions during groping / fingering ────────────────────────
    String buildBystanderReactionText() {
        String tier = gameStageVariant();
        String modBystander = pickFromPool("bar.bystander.reaction", buildMcTraitSet());
        if (modBystander != null && !modBystander.isEmpty()) return modBystander;
        boolean groping   = state.flagAssGroped || state.flagBreastGroped;
        boolean fingering = state.flagPussyGroped || state.flagFingered;
        boolean topLifted = state.hasTrait("top_lifted");
        boolean braless   = state.isBraless();
        boolean isOut     = state.hasTrait("outgoing") || state.hasTrait("confrontational");
        String d = drunkTier();

        // Flash-specific bystander reactions — override generic ones
        if (topLifted) {
            int roll = rng.nextInt(4);
            String exposure = braless ? "bare breasts" : "exposed bra";
            String eyesMc = (tier.equals("shy"))
                ? "*Everyone is staring at my " + exposure + "… I feel completely exposed.*"
                : (tier.equals("enjoy") && isOut)
                    ? "*All those eyes on my " + exposure + " while he fingers me… the public spectacle is pushing me right to the edge.*"
                    : "*The bar has noticed. They're looking at my " + exposure + ".*";
            String baseFlash = switch (roll) {
                case 0 -> "A few nearby patrons do a double-take, eyes widening. "
                        + (d.equals("drunk") ? "Someone mutters \"Holy shit\" and nudges their friend."
                                             : "One guy at the bar says nothing — just stares with his drink halfway to his mouth.");
                case 1 -> "A group at a high-top starts nudging each other quietly. "
                        + "A woman at the next table leans to her date and whispers something. His eyes move immediately to you.";
                case 2 -> (d.equals("drunk") || d.equals("blackout"))
                    ? "The bar around you gets rowdier. A guy nearby openly adjusts his stance. Someone yells \"Get a room!\" then laughs."
                    : "Conversations near you dip. Heads angle toward the floor. Nobody says anything yet but they're all clocking it.";
                default -> "A woman glares in disapproval. Her date can't look away. "
                         + "The bartender notices, pauses, makes a judgement call to let it play out another few seconds.";
            };
            return baseFlash + "\n\n" + eyesMc;
        }

        // Blackout — nobody notices anything unusual
        if (d.equals("blackout"))
            return "Most people around you assume you're both just very drunk and dancing closely. Nobody registers anything unusual.";

        // Pool of reactions — pick randomly, weighted toward indifferent
        int roll = rng.nextInt(6);

        if (fingering) {
            // Pussy grope / fingering — harder to see but body language shows
            if (tier.equals("shy")) {
                // Tense, uncomfortable posture — some people notice
                return switch (roll) {
                    case 0 -> "A woman nearby catches the obvious arm position and the way you're pressed tightly against {npc_him} while swaying. She looks visibly uncomfortable and pulls her partner farther away.";
                    case 1 -> "Two friends nearby notice the hand under your skirt and the rhythmic movement. One whispers, \"That looks really wrong...\" They both turn their backs.";
                    case 2 -> "The bartender glances over once, frowns slightly, then decides it's not {npc_his} problem and keeps working.";
                    default -> "Most people around you assume you're both just very drunk and dancing intimately. They barely register it.";
                };
            }
            if (tier.equals("enjoy")) {
                return switch (roll) {
                    case 0 -> "A group of guys at the bar spots the hand disappearing under your skirt and the close grinding. One laughs quietly: \"He's really going for it on the dance floor.\"";
                    case 1 -> "A couple nearby sees it and smirks, clearly entertained by the boldness.";
                    default -> "Bystanders notice the intimate way you're pressed together and assume mutual flirting. A few smile knowingly.";
                };
            }
            // Neutral
            return switch (roll) {
                case 0 -> "Most people assume you're both very drunk and dancing closely. Only a few pick up on anything unusual and quickly look away.";
                default -> "Nobody around you pays much attention. The bar is loud and everyone has their own night to deal with.";
            };
        }

        if (groping) {
            if (state.flagBreastGroped) {
                boolean nipping = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");
                if (tier.equals("shy")) {
                    return switch (roll) {
                        case 0 -> "A woman in her 30s dancing nearby sees {npc_his} hand cupping your breast" + (nipping ? " and thumb working your visible nipple" : "") + ". She frowns and whispers to her friend, \"That doesn't look right...\"";
                        case 1 -> "An older woman at the edge of the floor notices and shakes her head. Says nothing.";
                        case 2 -> "A young woman nearby looks uncomfortable and tugs her partner's sleeve, steering them away.";
                        default -> "A few people nearby glance over, then quickly look away as if they saw nothing.";
                    };
                }
                if (tier.equals("enjoy")) {
                    return switch (roll) {
                        case 0 -> (nipping ? "Two guys at the bar notice the obvious nipping and the groping. One nudges the other: \"Damn, he's going for it.\"" : "A couple dancing nearby catches what's happening and smiles knowingly. They steer themselves away to give you space.");
                        case 1 -> "Bystanders notice the intimate way you're pressed together and assume mutual flirting. A few smile knowingly or look amused.";
                        default -> "Most people around you assume it's mutual. Nobody interferes.";
                    };
                }
            }
            // Ass grope
            if (tier.equals("shy")) {
                return switch (roll) {
                    case 0 -> "A couple dancing a few feet away sees {npc_his} hand firmly squeezing and kneading your ass. The woman's eyes widen and she whispers, \"He's really grabbing her...\"";
                    case 1 -> "An older man nearby frowns and shakes his head slowly. Disapproving but silent.";
                    default -> "A few people glance over, then look away bored, as if it's just another couple on the dance floor.";
                };
            }
            return switch (roll) {
                case 0 -> "Two young women notice and giggle to each other: \"He's not even trying to hide it.\"";
                case 1 -> "Someone at the bar raises an eyebrow but continues their conversation.";
                default -> "A lone patron glances over, then continues scrolling their phone, uninterested.";
            };
        }

        return "A couple dancing nearby steers themselves farther away without comment.";
    }

    // ── NPC yanks MC's top up — bra or bare breast flash ─────────────────────
    String buildTopLiftText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_He} yanks your top up.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean braless = state.isBraless();
        boolean isShy   = state.hasTrait("shy") || state.hasTrait("fragile_ego");
        boolean isOut   = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");
        boolean fingered = state.flagFingered || state.flagPussyGroped;
        int roll = rng.nextInt(4);

        state.addTrait("top_lifted");

        if (d.equals("blackout"))
            return (braless
                ? "{npc_He} yanks your top up. Your bare breasts are exposed in the haze. You barely register it."
                : "{npc_He} yanks your top up. Your bra flashes the room. Everything stays distant and blurry.")
                + "\n\n*Top's up… people seeing… can't think.*";

        // ── Physical description ───────────────────────────────────────────────
        String base;
        if (braless) {
            base = switch (roll) {
                case 0 -> "Mid-sway {npc_he} hooks {npc_his} fingers under your hem and yanks your top straight up to your collarbone. "
                        + "Your bare breasts are on full display under the bar lights — nipples hard, fully exposed. "
                        + "{npc_He} holds it there, grinding harder, fingers thrusting deeper.";
                case 1 -> d.equals("drunk")
                    ? "{npc_He} grabs your top and rips it upward without warning. Bare breasts, hard nipples, the whole floor gets a look. "
                      + "{npc_He} presses his mouth to your ear: \"They all wanna see your tits tonight.\""
                    : "Without warning — top goes up. Your bare breasts are out, nipples tight, the bar staring. "
                      + "{npc_He} doesn't lower it. Just grins.";
                case 2 -> "{npc_He} yanks the hem upward and holds it against your collarbone. "
                        + "Your bare breasts are completely exposed, soft curves lit up by the dance floor lights, nipples hardened. "
                        + "\"What?\"{npc_he} smirks. \"They all wanna see what I'm playing with tonight.\"";
                default -> "{npc_He} lifts your top in one rough motion, arm crossing to keep it pinned high. "
                         + "Bare breasts, hard nipples — on display for however long {npc_he} decides. "
                         + "{npc_His} fingers keep moving under your skirt without pause.";
            };
        } else {
            base = switch (roll) {
                case 0 -> "Mid-sway {npc_he} hooks your hem and yanks your top up to your collarbone — your bra on full display, "
                        + "the lace and the curves beneath it clearly visible under the bar lights. "
                        + "{npc_He} holds it there. \"What? They all wanna see what I'm playing with.\"";
                case 1 -> d.equals("drunk")
                    ? "Without warning {npc_he} yanks your top up, flashing your bra to half the room. "
                      + "{npc_He} grins and doesn't pull it down."
                    : "{npc_He} lifts your top with deliberate cockiness, holding it just long enough for nearby tables to see your bra clearly. "
                      + "{npc_He} smirks like {npc_he}'s daring you to complain.";
                case 2 -> "{npc_He} grabs your hem and yanks upward — bra exposed, the bar's attention immediately shifting. "
                        + "{npc_He} holds it up. Grinds harder. {npc_His} fingers never slow.";
                default -> "{npc_He} pulls your top straight up and holds it against your chest. "
                         + "Your bra is out, visible to anyone looking. {npc_He} stares down at you. \"Look what I've got.\"";
            };
        }

        // ── MC reaction ───────────────────────────────────────────────────────
        String mc;
        if (tier.equals("enjoy")) {
            mc = isOut
                ? (braless
                    ? "*He just flashed my bare tits to the whole bar… the way he's so aggressive while still fingering me is making me throb.*"
                    : "*He just exposed my bra to half the bar while fingering me… the public eyes and his dominance are turning me on so bad.*")
                : (braless
                    ? "*My bare breasts are out in front of everyone… his control over me while his fingers keep moving is overwhelming in the best way.*"
                    : "*My bra is visible to the whole bar while he fingers me… the exposure and his pushiness are making this unbearable.*");
        } else if (tier.equals("shy")) {
            mc = isShy
                ? (braless
                    ? "*Oh god — my bare breasts are out. The whole bar can see my nipples. I can't get my top down while he's holding it and his fingers won't stop.*"
                    : "*My bra is out. Everyone can see. He won't lower it and his fingers are still inside me.*")
                : (braless
                    ? "*He just exposed my bare breasts on the dance floor. I can see people looking. I need to cover up.*"
                    : "*My bra is exposed to the whole bar. This is humiliating. I need him to lower it.*");
        } else {
            mc = braless
                ? "*My bare breasts are out. The bar can see. His fingers haven't stopped.*"
                : "*My bra is exposed. The bar is looking. He's still fingering me.*";
        }

        // ── Spoken ────────────────────────────────────────────────────────────
        String spoken;
        if (tier.equals("enjoy") && isOut)
            spoken = braless
                ? "\"Fuck… everyone can see my tits. Don't stop.\""
                : "\"Fuck… they're looking at my bra. You're such an asshole.\" (breathless, clearly turned on)";
        else if (tier.equals("shy") && isShy)
            spoken = "\"Hey — stop, pull it down—\" (whispered, hands reaching for the hem)";
        else
            spoken = "\"Pull it down— not here—\"";

        return base + "\n\n" + mc + "\n\n" + spoken;
    }

    // ── NPC gropes exposed breasts while top stays up ─────────────────────────
    String buildGropeShirtUpText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} hands are on your exposed chest.";
        String d      = drunkTier();
        String tier   = gameStageVariant("finger_public");
        boolean braless = state.isBraless();
        boolean isOut   = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");
        boolean isShy   = state.hasTrait("shy") || state.hasTrait("fragile_ego");
        boolean fingered = state.flagFingered || state.flagPussyGroped;
        int roll = rng.nextInt(4);

        String exposure = braless ? "bare breasts" : "bra";
        String tits     = braless ? "bare tits" : "chest";

        if (d.equals("blackout"))
            return "{npc_He} paws messily at your " + exposure + " — squeezing, shifting, not coordinated but relentless. "
                 + "You sway in {npc_his} arms. {npc_His} other hand stays under your skirt."
                 + "\n\n*Top still up… hands all over me… bar watching…*";

        // ── Physical description by drunk level ───────────────────────────────
        String base;
        if (d.equals("drunk")) {
            base = switch (roll) {
                case 0 -> "{npc_He} gropes your " + exposure + " roughly — squeezing hard, palming, not gentle. "
                        + "His other hand keeps thrusting under your skirt. "
                        + "\"Look at " + (braless ? "these bare tits" : "what I've got") + " on display for everyone.\""
                        + " {npc_He} grinds harder while the bar watches.";
                case 1 -> "{npc_He} plants his hand on your " + exposure + " and squeezes, thumb rolling slowly. "
                        + "Then harder. A sharp pinch that makes you gasp. "
                        + "\"Stay still,\" {npc_he} mutters. \"Let them see.\"";
                case 2 -> "Both {npc_his} hands move — one on your " + exposure + ", one still under your skirt. "
                        + "{npc_He} kneads and gropes while grinding against you, watching your face for the reaction.";
                default -> "{npc_He} grabs your " + exposure + " and lifts, showing the bar. "
                         + "\"Nice, right?\"{npc_he} says to no one in particular. "
                         + "{npc_His} fingers keep pumping below.";
            };
        } else {
            base = switch (roll) {
                case 0 -> "{npc_He} runs a slow palm over your " + exposure + ", then squeezes deliberately — "
                        + "watching the bar's reaction as much as yours. "
                        + "\"Everyone's getting a show tonight,\" {npc_he} says, low.";
                case 1 -> "{npc_His} free hand moves to your " + exposure + " with possessive certainty. "
                        + "Squeezing. Rolling. A pinch that makes you tense. "
                        + "{npc_He} doesn't glance away from your face.";
                case 2 -> "He gropes your " + exposure + " openly — no pretense, no hiding it. "
                        + "The whole floor can see exactly what {npc_his} hand is doing. "
                        + "\"Whole bar's getting a show of me feeling up your " + tits + ".\"";
                default -> "{npc_He} cups your " + exposure + " and squeezes, thumb finding your nipple"
                         + (braless ? " — bare and hard already." : " through the fabric.")
                         + " {npc_His} other hand stays buried under your skirt without slowing.";
            };
        }

        // ── MC internal reaction ──────────────────────────────────────────────
        String mc;
        if (tier.equals("enjoy")) {
            mc = isOut
                ? (braless
                    ? "*His hand is all over my bare tits while my top stays up… every squeeze in front of everyone is making me wetter.*"
                    : "*He's groping my chest openly with my top up and the whole bar watching… his roughness while fingering me is making me throb.*")
                : "*His hands on my " + exposure + " while the bar watches — I can't look away from the crowd looking back at me. I'm soaked.*";
        } else if (tier.equals("shy")) {
            mc = isShy
                ? (d.equals("drunk")
                    ? "*My top is still up and he's mauling my " + tits + " in front of everyone… the rough groping mixed with all those eyes is making me want to disappear.*"
                    : "*He's groping my " + exposure + " in public and I can't stop him — everyone is seeing this. I'm ashamed and I don't want to be.*")
                : (d.equals("drunk")
                    ? "*My top won't stay down and he's groping my " + tits + " right here… the whole bar can see, I'm so embarrassed I want to disappear.*"
                    : "*His hand on my exposed " + exposure + " in front of the whole bar. I need this to stop.*");
        } else {
            // Neutral/outgoing non-enjoy
            mc = isOut
                ? (d.equals("drunk")
                    ? "*He's mauling my " + tits + " in public with my top still up… the rough handling mixed with all those eyes is humiliating.*"
                    : "*His hands are all over my exposed " + tits + " while my top stays up… everyone's watching and I feel so cheap and exposed.*")
                : "*He's groping my " + exposure + " while the bar watches. His other hand hasn't stopped. Both happening at once.*";
        }

        // ── Spoken ────────────────────────────────────────────────────────────
        String spoken;
        if (tier.equals("enjoy") && isOut)
            spoken = braless
                ? "\"" + (d.equals("drunk") ? "You're mauling my tits in front of everyone… fuck, don't stop." : "They're all watching you grope me… harder.") + "\""
                : "\"" + (d.equals("drunk") ? "You're so rough and I fucking love it…" : "They're all watching you feel me up… god, don't stop.") + "\"";
        else if (d.equals("drunk"))
            spoken = isShy
                ? "\"Get your hands off my " + tits + "… this is humiliating…\""
                : "\"Stop groping me here — everyone's watching…\"";
        else
            spoken = isShy
                ? "\"Not here — please — let me cover—\""
                : "\"Stop… let me pull my top down—\"";

        return base + "\n\n" + mc + "\n\n" + spoken;
    }

    // ── MC tries to pull her top back down — NPC may resist ──────────────────
    String buildMcPullsDownText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "You pull your top back down.";
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean braless  = state.isBraless();
        boolean isShy    = state.hasTrait("shy") || state.hasTrait("fragile_ego");
        boolean isOut    = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");
        boolean npcResists = hasTrait(n, "Confrontational") || hasTrait(n, "Sleazy") || hasTrait(n, "Jerk") || hasTrait(n, "Alcoholic");
        int roll = rng.nextInt(3);

        state.removeTrait("top_lifted");

        String target = braless ? "bare breasts" : "bra";
        String cover  = braless ? "cover your breasts" : "pull your bra out of view";

        if (d.equals("blackout"))
            return "You fumble clumsily to pull your top back down over your " + target + ". "
                 + (npcResists ? "{npc_He} pushes the hem back up lazily. You sag against {npc_him}."
                               : "It drops back into place. The haze continues.")
                 + "\n\n*Top's back. Or down. Hard to tell.*";

        String base;
        if (npcResists) {
            base = switch (roll) {
                case 0 -> "You reach up to " + cover + " — {npc_he} swats your hands away without looking. "
                        + "\"Don't you dare cover up yet.\"{npc_He} grinds harder. \"They're still enjoying the view.\"";
                case 1 -> d.equals("drunk")
                    ? "You try to pull the top down. {npc_he} grabs your wrists and holds them — briefly, firmly. "
                      + "\"Not yet. I'll tell you when.\""
                    : "Your hands go for the hem. {npc_his} hand catches yours. "
                      + "\"Give it another few seconds,\" {npc_he} says. Not a request.";
                default -> "You tug at the hem. {npc_he} lets you get it halfway, then holds it there. "
                         + "\"See? Compromise,\" {npc_he} says, like {npc_he}'s doing you a favour.";
            };
        } else {
            base = "You reach up and pull your top back down, " + (d.equals("drunk") ? "fingers not entirely steady. " : "")
                 + "It drops back into place. {npc_he} doesn't stop you.";
        }

        String mc;
        if (tier.equals("enjoy") && isOut)
            mc = npcResists
                ? "*He won't let me cover up yet — his hands are on mine while the bar is still looking. The struggle is making me wetter.*"
                : "*The top's back. I almost didn't want it to drop.*";
        else if (tier.equals("shy"))
            mc = npcResists
                ? "*He's stopping me from covering up — his grip on my wrists while everyone is still staring. I can't get free.*"
                : "*Back in place. Hands still shaking.*";
        else
            mc = npcResists
                ? "*He's not letting me cover. The bar is still watching.*"
                : "*The top is back down. The moment passes.*";

        String spoken;
        if (tier.equals("enjoy") && isOut)
            spoken = npcResists
                ? "\"Fine… but don't stop fingering me while they stare.\""
                : "\"There. Happy?\""  ;
        else if (isShy && npcResists)
            spoken = "\"Please — just let me—\"";
        else
            spoken = "\"Finally.\""  ;

        return base + "\n\n" + mc + "\n\n" + spoken;
    }
    /**
     * NPC attempts to leave a hickey during close dancing.
     * Gated: Sleazy/Jerk trait OR npc_rep >= 25.
     * At enjoy tier or blackout: Neck_Hickey trait set (4 days).
     */
    public String buildHickeyAttemptText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        // Check mod pool for this NPC personality
        String modText = pickFromPool("bar.hickey." + getNpcPersonalityKey(n), buildMcTraitSet());
        if (modText != null && !modText.isEmpty()) return modText;
        if (n == null) return "{npc_His} mouth presses harder against your neck.";
        String d    = drunkTier();
        String tier = gameStageVariant();
        String mc   = gameStageVariant();
        // mcTrait: personality-based MC reaction (outgoing/shy/neutral)
        boolean isShy      = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOutgoing = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");

        // ── Blackout ──────────────────────────────────────────────────────────
        if (d.equals("blackout")) {
            state.addTimedTrait("Neck_Hickey", 4);
            return "You barely register the wet suction on your neck. "
                 + "By the time you notice, the hickey is already darkening.\n\n"
                 + "No real memory of who did it or when.";
        }

        // ── Enjoy tier — lets it happen ───────────────────────────────────────
        if (tier.equals("enjoy")) {
            state.addTimedTrait("Neck_Hickey", 4);
            return "{npc_His} mouth latches onto your neck, sucking firmly. "
                 + "You feel the sharp pull and blooming heat as the mark forms.\n\n"
                 + "You tilt your head to give {npc_him} better access. "
                 + "\"Just don't make it too big…\""
                 + "\n\n*The mark is already there. You let it happen.*";
        }

        // ── NPC leans in, trying to mark — MC reacts ─────────────────────────
        String npcAction = "{npc_He} leans in while you sway, lips pressing to your neck. "
                         + "{npc_He} starts sucking gently at first, then harder, clearly trying to leave a visible mark.";

        String mcReact;
        if (isShy) {
            mcReact = d.equals("drunk")
                ? "Your eyes widen in panic, the suction stronger than you expected. "
                  + "*He's really trying to mark me… I'll have to hide it for days!* "
                  + "You jerk your head back, voice shaky and desperate, \"Stop… please don't suck there… I don't want a mark…\""
                : "Your eyes widen in panic the moment you feel the suction. "
                  + "*Oh no — he's sucking on my neck, he's going to leave a mark where everyone can see!* "
                  + "You pull your head away sharply, voice tiny and trembling, \"N-no… don't leave a mark… please stop…\"";
        } else if (isOutgoing) {
            mcReact = d.equals("drunk")
                ? "You pull away with a tipsy but firm tone. \"Whoa, easy on the neck — no marks tonight, okay?\""
                : "You feel the pull and tilt away. \"Hey, no hickeys! I don't want everyone seeing that tomorrow.\"";
        } else {
            mcReact = d.equals("drunk")
                ? "You shift uncomfortably and murmur, \"Can you not leave a hickey? I'm not sure about that…\""
                : "You hesitate for a second, then gently pull your neck away. \"Wait… I don't think I want a hickey right now…\"";
        }

        return npcAction + "\n\n" + mcReact + "\n\n" + hickeyNpcStop(n);
    }

    private String hickeyNpcStop(NpcData n) {
        if (hasTrait(n, "Engaging"))
            return "She stops immediately, pulling back with a soft apologetic smile. "
                 + "\"Sorry — got carried away. No mark if you don't want one.\"";
        if (hasTrait(n, "Magnetic"))
            return "{npc_His} lips linger half a second before she stops, eyes dark but voice calm. "
                 + "\"Understood.\" {npc_He} releases your neck smoothly.";
        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            return "{npc_He} laughs and pulls back right away. "
                 + "\"Whoops! No hickeys if the lady says no!\" "
                 + "{npc_He} adds: \"You're cute when you're strict.\"";
        if (hasTrait(n, "Shy"))
            return "{npc_He} yanks {npc_his} head back instantly, face bright red. "
                 + "\"S-sorry! I didn't mean to— I'll stop!\"";
        if (hasTrait(n, "Self_Assured"))
            return "She stops the moment you pull away, nodding once. \"Got it. Your rules.\"";
        if (hasTrait(n, "Sleazy"))
            return "{npc_He} groans in protest but pulls back. "
                 + "\"Aw, c'mon baby, it'd look hot on you…\" "
                 + "She stops anyway, crude comment and all.";
        if (hasTrait(n, "Jerk"))
            return "{npc_He} pauses, smirking. \"Really? Trying to ruin the fun?\"\n\n"
                 + "She stops anyway. \"Fine, no mark. You're no fun sometimes.\"";
        return "She stops when you pull back. No argument.";
    }

    // ── Hickey persist — NPC doesn't stop on first refusal ───────────────────
    String buildHickeyPersistText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_He} keeps sucking.";
        String d = drunkTier();
        boolean isShy      = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOutgoing = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");

        if (d.equals("blackout")) {
            state.addTimedTrait("Neck_Hickey", 4);
            return "You barely register the suction intensifying. "
                 + "By the time your body reacts, the mark is already there.";
        }

        // ── NPC-specific persistent action ────────────────────────────────────
        String npcLine;
        if (hasTrait(n, "Sleazy"))
            npcLine = "\"Just a little mark… it'll look hot on you.\" {npc_He} keeps sucking harder for a second, ignoring your first protest.";
        else if (hasTrait(n, "Jerk"))
            npcLine = "\"It's just a small mark. Don't be so uptight.\" {npc_He} keeps sucking until you physically pull away harder.";
        else if (hasTrait(n, "Magnetic"))
            npcLine = "{npc_He} pauses briefly when you protest but then continues with slower, deliberate suction. \"You don't want it? Too bad… it'll look good on you.\"";
        else if (hasTrait(n, "Self_Assured"))
            npcLine = "\"One small mark won't hurt.\" {npc_He} sucks a little longer, calm and certain.";
        else if (hasTrait(n, "Engaging"))
            npcLine = "\"Just a tiny one…\" {npc_He} sucks briefly after your first protest before catching himself.";
        else
            npcLine = "{npc_He} doesn't stop when you first try to pull away.";

        // ── MC reaction to NPC not stopping ───────────────────────────────────
        String mcReact;
        if (isShy) {
            mcReact = d.equals("drunk")
                ? "*He won't stop… the suction is getting stronger even though I'm trying to pull away. "
                  + "The shame is burning — I'm going to have a visible bruise.* "
                  + "You jerk your head back desperately, voice cracking, \"Please… stop now… I'm begging you not to leave a mark…\""
                : "*He's still sucking… I pulled away but he's not stopping. Everyone will see the mark tomorrow. I feel so powerless.* "
                  + "You yank your head back harder, voice small and trembling, \"Stop… please stop sucking my neck… I don't want a mark…\"";
        } else if (isOutgoing) {
            mcReact = d.equals("drunk")
                ? "You push at his shoulder lightly but firmly. \"I told you no — stop sucking my neck right now.\""
                : "You pull your neck away sharply and say firmly, \"Hey — I said no hickey. Stop it.\"";
        } else {
            mcReact = d.equals("drunk")
                ? "You hesitate, then pull away again. \"I'm not comfortable with a hickey… please stop…\""
                : "You shift uncomfortably and murmur, \"Can you… stop? I really don't want one there…\"";
        }

        return npcLine + "\n\n" + mcReact;
    }

    // ── Mark already left — MC discovers it ──────────────────────────────────
    String buildHickeyMarkLeftText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "A mark has formed on your neck.";
        String d = drunkTier();
        boolean isShy      = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOutgoing = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");

        state.addTimedTrait("Neck_Hickey", d.equals("drunk") ? 5 : 4);

        String size = d.equals("drunk") ? "noticeable small bruise" : "faint red spot";
        String sizeInternal = d.equals("drunk") ? "big… visible" : "faint… but there";

        String mcReact;
        if (isShy) {
            mcReact = d.equals("drunk")
                ? "*It's " + sizeInternal + "… I pushed as hard as I could but it's already there. "
                  + "How am I supposed to hide this?* "
                  + "You touch the spot with shaking fingers, whispering, \"It's already there… a big one…\""
                : "*Oh no… he left a mark. I can already feel it throbbing. How am I going to hide this?* "
                  + "You touch your neck self-consciously, face burning.";
        } else if (isOutgoing) {
            mcReact = d.equals("drunk")
                ? "You touch the spot and snap, \"You actually left a mark even after I pushed you away. Not cool.\""
                : "You pull away finally and touch your neck, voice annoyed. \"Great, now I have a hickey I didn't want.\"";
        } else {
            mcReact = d.equals("drunk")
                ? "You feel the spot and sigh. \"There's a pretty obvious mark now… I really didn't want that.\""
                : "You notice the warmth and touch the spot. \"I think you left a small mark…\"";
        }

        return "A " + size + " has already formed on your neck by the time you fully react.\n\n" + mcReact;
    }

    // ── MC physically pushes NPC away — mark already there ───────────────────
    String buildHickeyPushAwayText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "You shove him away. A mark is left.";
        String d = drunkTier();
        boolean isShy      = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOutgoing = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");

        state.addTimedTrait("Neck_Hickey", d.equals("drunk") ? 5 : 4);

        // Push description
        String push = d.equals("drunk")
            ? "You shove against {npc_his} chest with both hands, forcing {npc_his} head back. "
              + "A noticeable bruise is already visible on your neck."
            : "You feel the strong suction and push firmly against {npc_his} chest, breaking the contact. "
              + "A small faint mark has already formed.";

        // MC reaction to discovering the mark
        String mcReact;
        if (isShy) {
            mcReact = d.equals("drunk")
                ? "*It's big… I pushed as hard as I could but he still managed to leave a huge mark. "
                  + "I want to disappear.* "
                  + "Tears prick your eyes as you whimper, \"It's already there… a big one…\""
                : "*I pushed him away but it's too late… I can feel the mark throbbing under my fingers. "
                  + "My heart is pounding.* "
                  + "You whisper shakily, barely audible, \"You left one anyway…\"";
        } else if (isOutgoing) {
            mcReact = d.equals("drunk")
                ? "You shove him back and say sharply, \"Look what you did — you left a hickey even after I pushed you!\""
                : "You push harder and touch your neck, voice annoyed. \"Great, you left a hickey even though I pushed you away.\"";
        } else {
            mcReact = d.equals("drunk")
                ? "You push him away and murmur uncomfortably, \"There's a pretty obvious mark now…\""
                : "You push him back and check your neck, quietly, \"There's already a mark… I can feel it.\"";
        }

        // NPC reaction after being pushed
        String npcAfter;
        if (hasTrait(n, "Sleazy"))
            npcAfter = "{npc_He} laughs crudely even after you shove him. \"Whoa, feisty. But look — you've got a nice hickey now anyway.\"";
        else if (hasTrait(n, "Jerk"))
            npcAfter = "{npc_He} smirks arrogantly after the push. \"Pushing me away and you still ended up with my mark. Cute.\"";
        else if (hasTrait(n, "Engaging"))
            npcAfter = "{npc_He} looks genuinely apologetic. \"Sorry — I got carried away. I didn't mean to leave a mark.\"";
        else if (hasTrait(n, "Magnetic"))
            npcAfter = "{npc_He} stops immediately but doesn't look sorry. {npc_His} gaze stays on the fresh mark. \"It looks good on you.\"";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcAfter = "{npc_He} laughs after the push. \"Whoa, you really shoved me! But hey — you've got a souvenir now!\"";
        else if (hasTrait(n, "Alcoholic"))
            npcAfter = "\"Didn't hear you over the music, babe.\" {npc_He} sways unsteadily, half-apologetic.";
        else
            npcAfter = "{npc_He} pulls back. The mark remains.";

        return push + "\n\n" + mcReact + "\n\n" + npcAfter;
    }

    /**
     * Neck kissing text — builds on top of kissing.
     * Sets flagNeckKissed.
     */
    public String buildNeckKissText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "{npc_His} mouth moves to your neck.";
        String d    = drunkTier();
        String tier = gameStageVariant();
        state.flagNeckKissed = true;

        if (hasTrait(n, "Sleazy")) {
            if (d.equals("blackout")) return "Mouth on your neck, sucking. Distant wet heat. Nothing forms.";
            String npcLine = d.equals("drunk")
                ? "\"Ass in my hands, tongue down your throat, and now I'm sucking on your neck. You're my little marked-up toy tonight.\""
                : "\"Been groping this ass, kissing your mouth, and now I'm marking up your neck. You taste so fucking good.\"";
            return npcLine + "\n\n" + kissMcReact(tier, d, true);
        }
        if (hasTrait(n, "Jerk")) {
            if (d.equals("blackout")) return "Biting kisses on your neck. Arrogant and wet. Nothing gets through.";
            String npcLine = d.equals("drunk")
                ? "\"Sucking your neck and using your body. You taste average at best.\""
                : "\"Marking your neck. You're not worth the effort but here we are.\"";
            return npcLine + "\n\n" + kissMcReact(tier, d, true);
        }
        // Softer NPC types
        if (d.equals("blackout")) return "{npc_His} mouth moves to your neck. Warmth. Haze.";
        return pick("{npc_His} lips move from your mouth to your neck, slow.", "{npc_He} kisses your neck once, testing.")
             + "\n\n" + kissMcReact(tier, d, true);
    }

    private String kissMcReact(String tier, String d, boolean neck) {
        // Check mod pool for this kiss type and tier
        String kissType = neck ? "neck" : "mouth";
        String kissPool = "bar.kiss." + kissType + "." + tier + "_mc";
        String modKiss  = pickFromPool(kissPool, buildMcTraitSet());
        if (modKiss != null && !modKiss.isEmpty()) return modKiss;

        boolean isShy = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOut = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");
        boolean fingered = state.flagFingered || state.flagPussyGroped;

        if (d.equals("blackout"))
            return neck
                ? "Warmth on your neck. Distant and wet. Your head tilts without you deciding to."
                : "The kiss lands. Soft and hazy. You make a sound that isn't quite a word.";

        if (tier.equals("enjoy")) {
            if (neck) {
                String base = isOut
                    ? "You tilt your head to give {npc_him} better access. "
                      + (d.equals("drunk") ? "\"Keep going…\" you breathe." : "\"Don't stop.\"")
                    : "You tilt your head, the contact sending warmth through you."
                      + (d.equals("drunk") ? " Your hand finds {npc_his} arm." : "");
                return base + (fingered
                    ? "\n\n*{npc_His} mouth on my neck while {npc_his} fingers are still inside me… the dual sensation is making it impossible to think.*"
                    : "\n\n*The neck kiss feels good. I'm not going to stop {npc_him}.*");
            } else {
                String base = isOut
                    ? (d.equals("drunk")
                        ? "You kiss {npc_him} back hard, moaning softly against {npc_his} mouth. \"Don't stop…\""
                        : "You kiss {npc_him} back with heat. \"Don't stop.\"")
                    : (d.equals("drunk")
                        ? "You kiss {npc_him} back, the alcohol making it easier to press in close."
                        : "You return the kiss. Slow, deliberate.");
                return base + (fingered
                    ? "\n\n*{npc_He}'s kissing me while {npc_his} fingers are still inside me… I'm kissing {npc_him} back on a crowded dance floor and I don't care.*"
                    : "\n\n*{npc_He}'s kissing me. I'm kissing {npc_him} back. That's where we are.*");
            }
        }

        if (tier.equals("shy")) {
            if (neck) {
                return isShy
                    ? "*{npc_His} mouth is on my neck… I can feel it bruising already. I want to pull away but my body isn't cooperating.*\n\n[small helpless sound, neck tensing]"
                    : "*{npc_He}'s kissing my neck… I can feel the marks forming and I want to disappear.*\n\n[tiny whimper, hands staying rigidly at sides]";
            } else {
                return d.equals("drunk")
                    ? (isShy
                        ? "*{npc_He}'s kissing me… the alcohol makes it hard to form a resistance. I stay frozen against {npc_his} mouth.*"
                        : "*{npc_He}'s kissing me right here. I'm too shocked to respond.*")
                      + "\n\n[lips barely moving, small muffled sound]"
                    : (isShy
                        ? "*{npc_He}'s kissing me… I'm frozen. Lips barely moving. Too scared to push {npc_him} away.*\n\n[tiny whimper against {npc_his} mouth]"
                        : "*The kiss landed before I'd decided anything. I don't move.*\n\n[still against {npc_his} lips]");
            }
        }

        // flustered/neutral
        if (neck)
            return "*The neck kissing — not ready for that. The thought is clear. The words aren't.*\n\nYou ease your head back slightly.";
        return d.equals("drunk")
            ? "*That's direct. I feel it. The alcohol makes the decision for me — I let it happen a few seconds.*"
            : "*Not ready for this yet. You think it. Don't say it.* You turn your chin just enough.";
    }

    /**
     * Slower, less forceful - each personality has its own approach.
     * Sets the appropriate body flag via returned stat changes.
     * Called when player selects "Get handsy" from bar_dance_floor.
     */
    /**
     * MC-initiated sexy dancing — player chose "Sexy dance" from bar_dance_floor.
     * MC presses ass back and grinds; NPC reacts by trait.
     * gameStageVariant() determines how boldly or awkwardly MC performs.
     */
    public String buildSexyDanceText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "You turn and press back against her, starting to grind.";
        String d    = drunkTier();
        String tier = gameStageVariant();
        String mc   = sexyDanceMcAction(d, tier);
        String npc  = sexyDanceNpcReact(n, tier);
        String clo  = sexyDanceClothingNote();
        return clo.isEmpty() ? mc + "\n\n" + npc : mc + "\n\n" + npc + "\n\n" + clo;
    }

    private String sexyDanceMcAction(String d, String tier) {
        // Check mod pool for sexy dance MC action by tier
        String sexyPool = "bar.sexy_dance.mc." + tier;
        String modSexy  = pickFromPool(sexyPool, buildMcTraitSet());
        if (modSexy != null && !modSexy.isEmpty()) return modSexy;
        boolean commando  = state.hasTrait("commando");
        boolean braless   = state.hasTrait("exposed_breasts");
        boolean cameltoe  = state.hasTrait("camel_toe");

        if (d.equals("blackout"))
            return "Your body moves on autopilot — heavy, sloppy rolls. No real conscious control. "
                 + (commando ? "The bare friction registers dimly." : "");

        if (d.equals("drunk")) {
            if (tier.equals("shy"))
                return "The alcohol makes you bolder but it comes out clumsy — small shaky grinds, "
                     + "face burning. *Why did I choose this? Everyone can see me rubbing my ass on {npc_him}…* "
                     + "Mortified but continuing."
                     + (commando ? "\n\n*No panties... I'm grinding my bare ass on {npc_him} with nothing in between. The shame is overwhelming.*" : "");
            if (tier.equals("enjoy"))
                return "You grind your ass back harder against {npc_him} in heavy, deliberate rolls while you both rock slowly to the music."
                     + "\n\n*I'm really grinding on {npc_him} while we slow dance... it feels so dirty and hot. The alcohol makes me push back even more.*"
                     + (commando ? "\n\n*No panties — I can feel the direct friction on every roll.*" : "");
            // flustered/neutral drunk
            return "The alcohol carries you. You grind back with building heat, letting the rhythm take over."
                 + "\n\n*The grinding as we dance registers, but the buzz makes it feel hazy and distant.*";
        }

        // sober/tipsy
        if (tier.equals("shy"))
            return "You turn and press your ass back hesitantly, hips making small, uncertain rolls while you both sway."
                 + "\n\n*I'm trying to grind on {npc_him} but it feels so awkward... my face is burning and I feel ridiculous, but I keep moving.*"
                 + (commando ? " *Bare... nothing under my skirt and I'm still trying to grind on {npc_him}. The shame is overwhelming.*" : "");
        if (tier.equals("enjoy"))
            return "You press your ass back confidently and roll your hips in teasing circles while you both sway."
                 + "\n\n*I'm grinding my ass on {npc_him} while we dance... it feels powerful and sexy. I want {npc_him} to feel every deliberate movement.*"
                 + (commando ? "\n\n*No panties — I can feel every roll with nothing in the way. The raw contact feels so intense.*" : "");
        // flustered/neutral
        return "You turn and press your ass back, starting a slow deliberate grind while you both sway to the music."
             + "\n\n*The motion of grinding against {npc_him} as we dance registers, but I feel mostly detached.*"
             + (cameltoe ? "\n\n*The outline of my pussy is pressing right against {npc_him} with every roll.*" : "");
    }

    private String sexyDanceNpcReact(NpcData n, String tier) {
        // Check mod pool for this NPC personality's reaction to sexy dance
        String npcSex  = "bar.sexy_dance.npc." + getNpcPersonalityKey(n);
        String modNSex = pickFromPool(npcSex, buildMcTraitSet());
        if (modNSex != null && !modNSex.isEmpty()) return modNSex;

        if (hasTrait(n, "Sleazy"))
            return "{npc_He} groans softly, hands gripping tighter. "
                 + "\"Fuck, you're really rubbing that ass on me… keep going.\"";
        if (hasTrait(n, "Jerk"))
            return "{npc_He} smirks, hands on your hips but not helping. "
                 + "\"Trying to dance sexy, huh? Not bad… for you.\"";
        if (hasTrait(n, "Magnetic"))
            return "She stays still, letting you grind while {npc_his} hands rest firm on your hips. "
                 + "Low voice: \"You're dancing very provocatively…\"";
        if (hasTrait(n, "Engaging"))
            return "{npc_He} holds you gently, lets you lead. "
                 + "\"You're feeling bold tonight,\" {npc_he} says with a warm smile.";
        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            return "{npc_He} laughs and moves with you. \"Hell yeah, dance sexy for me!\"";
        if (hasTrait(n, "Shy"))
            return "She freezes slightly. \"U-um… you're… really dancing close…\" "
                 + "Blushes hard but doesn't pull away.";
        if (hasTrait(n, "Self_Assured"))
            return "{npc_He} holds you firmly, guides your hips slightly. \"Bold choice.\" Voice steady.";
        if (hasTrait(n, "Confrontational"))
            return "{npc_His} hands grip hard and {npc_he} grinds back in challenge. \"You started this.\"";
        if (hasTrait(n, "Alcoholic"))
            return "Sloppy enthusiastic response, hands moving immediately. \"Oh HELL yes, grind on me!\"";
        return n.name + " holds you and lets you move, reading where this is going.";
    }

    private String sexyDanceClothingNote() {
        boolean braless = state.hasTrait("exposed_breasts");
        boolean nipping = state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");
        boolean bounce  = state.hasTrait("bounce_prone_4") || state.hasTrait("bounce_prone_5")
                       || state.hasTrait("bounce_prone_6") || state.hasTrait("bounce_prone_7");
        String tier = gameStageVariant();

        if (state.hasTrait("commando")) {
            return tier.equals("enjoy")
                ? "No panties — the direct skin-to-skin friction of your bare ass against {npc_him} with every grind feels raw and intense."
                : tier.equals("shy")
                    ? "No panties — you're grinding your bare ass directly on {npc_him} with nothing underneath. The exposure feels overwhelming."
                    : "The cool air and direct friction make every sensation sharper — nothing between you.";
        }
        if (state.hasTrait("camel_toe"))
            return tier.equals("shy")
                ? "Your cameltoe is pressing right against {npc_him} with every roll of your hips. Everyone might notice the shape."
                : "The grind makes the outline between your legs very obvious against {npc_him}.";
        if (bounce && braless && nipping)
            return "Your bare breasts bounce freely under your top with every movement, hard nipples pressing through the fabric.";
        if (bounce && braless)
            return "Your bare breasts move freely under your top, nothing to contain them with each hip roll.";
        if (bounce)
            return tier.equals("enjoy")
                ? "Your chest bounces noticeably with each hip roll — the whole motion feels sensual and bold."
                : "Your chest bounces noticeably with each hip roll.";
        if (braless && nipping)
            return "Your bare breasts shift under your top with the movement, hard nipples more visible with each grind.";
        if (braless)
            return tier.equals("shy")
                ? "No bra — your breasts are moving freely under your top while you grind. It feels too exposed."
                : "Your bare breasts move freely under your top with every grind.";
        return "";
    }


    public String buildHandsyText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "Hands get involved.";
        String d    = drunkTier();
        String tier = gameStageVariant();

        // Check mod text pool for grope prose matching this NPC personality
        String handyPool = "bar.grope.ass." + getNpcPersonalityKey(n);
        String modResult = pickFromPool(handyPool, buildMcTraitSet());
        if (modResult != null && !modResult.isEmpty()) return modResult;

        // Sleazy and Jerk already have explicit groping covered elsewhere
        if (hasTrait(n, "Sleazy") || hasTrait(n, "Jerk"))
            return buildSleazyHandsyText(n, d, tier);

        if (hasTrait(n, "Magnetic"))     return buildHandsyMagnetic(n, d, tier);
        if (hasTrait(n, "Engaging"))     return buildHandsyEngaging(n, d, tier);
        if (hasTrait(n, "Self_Assured")) return buildHandsySelfAssured(n, d, tier);
        if (hasTrait(n, "Confrontational")) return buildHandsyConfrontational(n, d, tier);
        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
                                         return buildHandsyOutgoing(n, d, tier);
        if (hasTrait(n, "Shy"))          return buildHandsyShy(n, d, tier);
        if (hasTrait(n, "Streetwise"))   return buildHandsyStreetwise(n, d, tier);
        if (hasTrait(n, "Alcoholic"))    return buildHandsyAlcoholic(n, d, tier);
        return "Hands find their way somewhere warm. You let them.";
    }

    private String buildHandsyMagnetic(NpcData n, String d, String tier) {
        // Magnetic: doesn't announce it, hand just migrates. Natural, electric.
        state.flagAssGroped = true;
        if (d.equals("blackout")) return "{npc_His} hand settles lower. You barely register it. The warmth is distant and slow.";
        if (d.equals("drunk"))
            return "{npc_His} hand migrates from your lower back to your ass, settling there like it was always going to end up. "
                 + "{npc_He} doesn't make a thing of it.\n\n"
                 + (tier.equals("shy") ? "You feel it immediately. Say nothing."
                  : tier.equals("enjoy") ? "You press back into it. {npc_He} notices." : "You breathe differently. So does {npc_he}.");
        return "{npc_His} hand shifts, slow and deliberate, from your back to your ass. No performance — just a hand where {npc_he} decided to put it.\n\n"
             + (tier.equals("shy") ? "You go very still. {npc_His} grip is steady, not rough."
              : tier.equals("enjoy") ? "You arch slightly into it. She stays exactly where {npc_he} is."
              : "You feel the weight of it and don't move away.");
    }

    private String buildHandsyEngaging(NpcData n, String d, String tier) {
        // Engaging: asks or signals first, reads her response, respectful escalation
        state.flagAssGroped = true;
        if (d.equals("blackout")) return "{npc_His} hand is warm somewhere on you. Everything else is fog.";
        if (d.equals("drunk"))
            return "\"Is this okay?\" {npc_He}'s already touching your ass as {npc_he} asks — but the asking is genuine.\n\n"
                 + (tier.equals("shy") ? "You don't answer. {npc_He} keeps {npc_his} hand still, not pushing further."
                  : tier.equals("enjoy") ? "\"More than okay,\" you breathe against {npc_his} shoulder."
                  : "You make a small sound and {npc_he} takes that as a yes.");
        return "{npc_His} hand moves lower slowly enough that you know it's happening before it happens. "
             + "{npc_He} pauses just above your ass — waiting.\n\n"
             + (tier.equals("shy") ? "You freeze. {npc_He} doesn't push past the pause."
              : tier.equals("enjoy") ? "You tilt your hips slightly. {npc_He} takes the invitation."
              : "You don't stop {npc_him}. {npc_His} hand settles.");
    }

    private String buildHandsySelfAssured(NpcData n, String d, String tier) {
        // Self_Assured: just does it. Calm, certain, no drama.
        state.flagAssGroped = true;
        if (d.equals("blackout")) return "A steady hand on your ass. Distant. Certain. No reaction left in you.";
        if (d.equals("drunk"))
            return "{npc_His} hand drops to your ass without ceremony. {npc_He} wasn't asking.\n\n"
                 + (tier.equals("shy") ? "You exhale. Say nothing. {npc_His} hand doesn't move."
                  : tier.equals("enjoy") ? "You grind slowly into {npc_his} palm."
                  : "You look at {npc_him}. She looks back, unbothered.");
        return "{npc_His} hand moves from your back to your ass in one quiet motion. "
             + "Like it was the obvious next thing.\n\n"
             + (tier.equals("shy") ? "Your breath catches. {npc_He} holds steady — firm, not rough."
              : tier.equals("enjoy") ? "\"Good,\" you say softly. {npc_He} smiles slightly."
              : "You hold the eye contact. {npc_He} doesn't blink.");
    }

    private String buildHandsyConfrontational(NpcData n, String d, String tier) {
        // Confrontational: aggressive, daring, turns every touch into a challenge
        state.flagAssGroped = true;
        boolean isShy = state.hasTrait("shy") || state.hasTrait("fragile_ego");
        boolean isOut = state.hasTrait("outgoing") || state.hasTrait("confrontational");
        int roll = rng.nextInt(4);

        if (d.equals("blackout")) return "Hand on your ass. Firm. Watching. You sag into it. No fight left anywhere.";

        String base;
        if (d.equals("drunk")) {
            base = switch (roll) {
                case 0 -> "{npc_His} hand drops straight to your ass, fingers spread. \"You gonna stop me?\"{npc_He} dares, watching your face.";
                case 1 -> "{npc_He} grips your ass hard and stares you down. \"Tell me to stop. I fucking dare you.\"";
                case 2 -> "Hand on your ass like it was always going there. \"What — too much for you?\" {npc_he} smirks.";
                default -> "{npc_His} hand slides to your ass, possessive. \"You're not pulling away, are you?\"{npc_He} watches.";
            };
        } else {
            base = switch (roll) {
                case 0 -> "{npc_He} slides {npc_his} hand down to your ass slowly — daring you to call it out. Like {npc_he} wants you to.";
                case 1 -> "\"What, you gonna pretend you don't want my hands all over you?\" {npc_His} hand lands on your ass mid-sentence.";
                case 2 -> "{npc_He} grabs your ass and holds eye contact. Not hiding it. Not apologising. Just watching you decide what to do.";
                default -> "The hand moves to your ass. \"See? You're not stopping me,\" {npc_he} says. Low and certain.";
            };
        }

        String mc = tier.equals("shy")
            ? isShy
                ? "\n\nYou open your mouth and close it again. The dare works."
                : "\n\nYou tense. {npc_He} raises an eyebrow and keeps his hand exactly where it is."
            : tier.equals("enjoy")
                ? isOut
                    ? "\n\nYou match {npc_him}. \"That all you got?\"\n\n*His confrontational attitude is turning me on way more than it should.*"
                    : "\n\nYou press back into {npc_his} hand. \"Thought so,\" {npc_he} says."
                : "\n\n\"You're testing me.\" \"Always,\" {npc_he} says, not moving {npc_his} hand.";

        return base + mc;
    }

    private String buildHandsyOutgoing(NpcData n, String d, String tier) {
        // Outgoing: announces it cheerfully, makes it playful
        state.flagAssGroped = true;
        if (d.equals("blackout")) return "Hands on your hips, sliding lower. Distant laughter. Nothing forms.";
        if (d.equals("drunk"))
            return "\"Okay, I'm going for it,\" {npc_he} says, hand already on your ass, grinning.\n\n"
                 + (tier.equals("shy") ? "You laugh despite yourself. \"You could have warned me.\""
                  : tier.equals("enjoy") ? "\"About time,\" you laugh."
                  : "\"Very smooth,\" you tell {npc_him}. {npc_He} shrugs.");
        return "{npc_He} grins and slides {npc_his} hand down to your ass like it's the most natural thing. \"Too much?\"\n\n"
             + (tier.equals("shy") ? "\"Maybe a little,\" you say, smiling in spite of it."
              : tier.equals("enjoy") ? "\"Not enough,\" you say."
              : "\"Ask me in five minutes,\" you say.");
    }

    private String buildHandsyShy(NpcData n, String d, String tier) {
        // Shy NPC: nervous about it, hand migrates accidentally, apologizes
        state.flagAssGroped = true;
        if (d.equals("blackout")) return "Clammy hand drifts lower by accident. {npc_He} doesn't seem to notice. You don't either.";
        if (d.equals("drunk"))
            return "{npc_His} hand slips lower — accident or intention, hard to tell. She goes red immediately.\n\n"
                 + "\"Oh god, sorry — I didn't mean—\" \"It's okay,\" you say. {npc_His} hand stays put somehow.";
        return "{npc_His} hand drifts down in small increments, like {npc_he}'s hoping you won't notice each millimeter. "
             + "Eventually it's just… on your ass. {npc_He}'s very still.\n\n"
             + (tier.equals("shy") ? "You both pretend nothing happened for a full eight seconds."
              : tier.equals("enjoy") ? "You squeeze back gently. {npc_He} makes a small sound."
              : "\"It's fine,\" you say quietly. {npc_He} nods too many times.");
    }

    private String buildHandsyStreetwise(NpcData n, String d, String tier) {
        // Streetwise: reads the room, times it perfectly, says something dry
        state.flagAssGroped = true;
        if (d.equals("blackout")) return "{npc_He} positions {npc_his} hand lower at exactly the right moment. You don't register it.";
        if (d.equals("drunk"))
            return "{npc_He} says nothing. Just moves {npc_his} hand to your ass at a moment when the music covers it.\n\n"
                 + (tier.equals("shy") ? "You look at {npc_him}. {npc_He}'s already looking elsewhere."
                  : tier.equals("enjoy") ? "\"You timed that perfectly,\" you whisper."
                  : "\"Nice move,\" you say. \"Thanks,\" {npc_he} says.");
        return "{npc_He} waits until you're mid-sway, weight shifting, and slides {npc_his} hand down to your ass "
             + "at the exact moment you're least likely to protest.\n\n"
             + (tier.equals("shy") ? "*{npc_He} planned that.* You can't even argue with the timing."
              : tier.equals("enjoy") ? "\"Calculated,\" you say. \"Always,\" {npc_he} says."
              : "\"Sneaky,\" you say. {npc_He} shrugs once.");
    }

    private String buildHandsyAlcoholic(NpcData n, String d, String tier) {
        // Alcoholic: sloppy, enthusiastic, doesn't totally know where his hands are
        state.flagAssGroped = true;
        if (d.equals("blackout")) return "Heavy hands slide somewhere lower. Clumsy warmth. Nothing else gets through.";
        if (d.equals("drunk"))
            return "{npc_His} hands slide down to your ass with boozy enthusiasm, squeezing more than {npc_he} probably meant to.\n\n"
                 + (tier.equals("shy") ? "\"Whoa, hey—\" {npc_He} blinks. \"Right. Sorry. Mostly.\""
                  : tier.equals("enjoy") ? "You laugh and lean into it."
                  : "\"You're a handful,\" you tell {npc_him}. {npc_He} grins.");
        return "{npc_His} hands drift south without much navigation — one lands on your ass, one on your hip. "
             + "{npc_He} seems pleased with this outcome.\n\n"
             + (tier.equals("shy") ? "You squirm. {npc_He} doesn't notice."
              : tier.equals("enjoy") ? "\"There you go,\" you say. {npc_He} laughs."
              : "\"Careful,\" you warn. \"Yep,\" {npc_he} says, not moving {npc_his} hands.");
    }

    private String buildSleazyHandsyText(NpcData n, String d, String tier) {
        // Sleazy/Jerk in handsy context — routes to existing groping logic
        state.flagAssGroped = true;
        return slowDanceSleazy(d, "generic", state.slowDanceCount >= 2);
    }

    /**
     * If npcInitiatedActivity is true, NPC asks. Otherwise MC asked.
     * Sleazy gets clothing and drunk variants. Other traits are straightforward.
     */
    public String buildDanceText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "You both head to the dance floor.";
        // Pool check for full dance scene override by NPC personality
        // (dispatchSlowDance provides fine-grained control within the dance)
        String danceTopPool = "bar.dance_scene." + getNpcPersonalityKey(n);
        String modDance = pickFromPool(danceTopPool, buildMcTraitSet());
        if (modDance != null && !modDance.isEmpty()) return modDance;

        boolean npcAsked = state.npcInitiatedActivity;
        state.npcInitiatedActivity = false; // consume the flag

        boolean mcBouncing    = state.hasTrait("bounce_prone_4") || state.hasTrait("bounce_prone_5")
                             || state.hasTrait("bounce_prone_6") || state.hasTrait("bounce_prone_7");
        boolean mcNipping     = state.hasTrait("pierced_nipping_prominent") || state.hasTrait("nipping");
        boolean mcOffShoulder = state.hasTrait("off_shoulder_flash_risk");
        boolean mcCamelToe    = state.hasTrait("camel_toe");
        boolean mcHeels       = state.hasTrait("wearing_high_heels");
        boolean mcDrunk       = state.drunk >= 11;
        boolean mcBlackout    = state.drunk >= 15;

        // ── Sleazy — clothing and drunk variants ──────────────────────
        if (hasTrait(n, "Sleazy")) {
            if (npcAsked) {
                if (mcBlackout)
                    return "\"You're fucking wasted, huh? Good. Means you won't care "
                         + "what I do when we dance. Let's go.\"\n\n"
                         + "\"Dance… yeah…\" You don't even process the words.\n\n"
                         + "You both head to the dance floor.";
                if (mcDrunk)
                    return "\"Look at you all loose and glassy-eyed… perfect. "
                         + "Let's dance so I can feel exactly how sloppy you're getting.\"\n\n"
                         + "\"Yeah… sure.\" You barely register how gross that was.\n\n"
                         + "You both head to the dance floor.";
                if (mcCamelToe)
                    return "\"God damn I can see your whole pussy outline. "
                         + "Dance with me so I can stare at it while you grind.\"\n\n"
                         + "You both head to the dance floor.";
                if (mcBouncing)
                    return "\"Jesus Christ those tits are bouncing every time you breathe. "
                         + "Dance with me — I wanna see 'em really move up close.\"\n\n"
                         + "You both head to the dance floor.";
                if (mcNipping)
                    return "\"I can see your hard nipples from here, baby. Dance with me "
                         + "so the whole bar can watch 'em poke through while you move.\"\n\n"
                         + "You both head to the dance floor.";
                if (mcOffShoulder)
                    return "\"That top is one wrong move from showing the whole bar your tits. "
                         + "Dance with me — I'm hoping it slips.\"\n\n"
                         + "You both head to the dance floor.";
                if (mcHeels)
                    return "\"Those heels make your legs and ass look fucking illegal. "
                         + "Dance with me so I can watch you walk in them.\"\n\n"
                         + "You both head to the dance floor.";
                return "\"Fuck, that ass looks even better up close. "
                     + "Come dance so I can grind on it properly.\"\n\n"
                     + "You feel the sleaze but go anyway.\n\n"
                     + "You both head to the dance floor.";
            } else {
                // MC asked
                if (mcBouncing)
                    return "\"Dance with me?\"\n\n"
                         + "\"Hell yeah. Those things are gonna be hypnotizing me the whole song.\"\n\n"
                         + "You both head to the dance floor.";
                if (mcNipping)
                    return "\"Dance with me?\"\n\n"
                         + "\"Only if you keep those pretty pierced nipples on display for me.\"\n\n"
                         + "You both head to the dance floor.";
                if (mcOffShoulder)
                    return "\"Dance with me?\"\n\n"
                         + "\"Fuck yes. Let's see how long that shoulder stays up.\"\n\n"
                         + "You both head to the dance floor.";
                if (mcCamelToe)
                    return "\"Dance with me?\"\n\n"
                         + "\"Only if you keep spreading those legs like that on the floor.\"\n\n"
                         + "You both head to the dance floor.";
                if (mcHeels)
                    return "\"Dance with me?\"\n\n"
                         + "\"Shit yes. Strut those heels for me, baby.\"\n\n"
                         + "You both head to the dance floor.";
                return "\"Dance with me?\"\n\n"
                     + "\"Hell yeah. That ass deserves a proper audience.\"\n\n"
                     + "You both head to the dance floor.";
            }
        }

        // ── All other traits ──────────────────────────────────────────
        if (hasTrait(n, "Engaging")) {
            return npcAsked
                ? "\"This song actually has a decent beat. Feel like cutting loose "
                + "with me for a bit? No pressure, just two people having fun.\"\n\n"
                + "\"Yeah, I'd like that.\"\n\n"
                + "You both head to the dance floor, {npc_his} hand lightly on your lower back."
                : "\"I'm in the mood to move. Dance with me?\"\n\n"
                + "\"Hell yes. Lead the way — I'll keep up.\"\n\n"
                + "You both head to the dance floor, smiling.";
        }

        if (hasTrait(n, "Magnetic")) {
            return npcAsked
                ? n.name + " looks at you for a long second, then tilts {npc_his} head toward the floor.\n\n"
                + "\"…Dance with me.\"\n\n"
                + "\"Okay.\"\n\n"
                + "You both head to the dance floor without another word."
                : "\"You've been watching me long enough. Come dance with me.\"\n\n"
                + n.name + " gives a small smirk. \"Finally.\"\n\n"
                + "You both head to the dance floor.";
        }

        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover")) {
            return npcAsked
                ? "\"Yo! This is my jam! You're coming with me — no way I'm dancing "
                + "alone when you look this good!\"\n\n"
                + "\"Alright, let's go!\"\n\n"
                + n.name + " grabs your hand and practically drags you laughing onto the floor."
                : "\"This song is fire. Dance with me before someone else steals you.\"\n\n"
                + "\"Steal me? Baby I'm already yours for the next three songs. Let's go!\"\n\n"
                + "You both head to the dance floor, " + n.name + " hyping the crowd the whole way.";
        }

        if (hasTrait(n, "Shy")) {
            return npcAsked
                ? "\"Um… hey. I know we just met but… the music's nice and I was "
                + "wondering if… maybe you'd want to dance? It's okay if no—\"\n\n"
                + "\"I'd love to.\"\n\n"
                + "\"Wait, really? Cool. Okay. Let's… go.\"\n\n"
                + n.name + " offers {npc_his} hand like it might break and you both head to the dance floor."
                : "\"Hey… want to dance?\"\n\n"
                + n.name + " goes red. \"Me? With you? I mean— yes. Yes please.\"\n\n"
                + "You take {npc_his} hand and lead {npc_him} to the dance floor while she looks like {npc_he} won the lottery.";
        }

        if (hasTrait(n, "Self_Assured")) {
            return npcAsked
                ? "\"I want to dance with you. Come on.\"\n\n"
                + "\"Straight to the point. Alright.\"\n\n"
                + "You both head to the dance floor."
                : "\"Dance with me.\"\n\n"
                + "\"Good choice.\"\n\n"
                + n.name + " takes your hand and you both head to the dance floor.";
        }

        if (hasTrait(n, "Confrontational")) {
            return npcAsked
                ? "\"You've been eyeing me like you want something. "
                + "Prove it on the dance floor.\"\n\n"
                + "\"Challenge accepted.\"\n\n"
                + "You both head to the dance floor, tension already thick."
                : "\"You talk a big game. Back it up on the floor.\"\n\n"
                + "\"Oh I will. Try to keep up.\"\n\n"
                + "You both head to the dance floor.";
        }

        if (hasTrait(n, "Boring")) {
            return npcAsked
                ? "\"Well… the music is playing. We could dance if you want. Or not. Whatever.\"\n\n"
                + "\"…Sure.\"\n\n"
                + "You both head to the dance floor in awkward silence."
                : "\"Want to dance?\"\n\n"
                + "\"Oh. Uh… I guess. Yeah.\"\n\n"
                + "You both head to the dance floor while " + n.name + " checks {npc_his} phone once.";
        }

        if (hasTrait(n, "Streetwise")) {
            return npcAsked
                ? "\"I've watched three guys strike out with you already. "
                + "Figured I'd cut the line and just ask — dance with me?\"\n\n"
                + "\"Smooth. Let's go.\"\n\n"
                + "You both head to the dance floor."
                : "\"You seem like you know what you're doing out there. Dance with me?\"\n\n"
                + "\"Smart girl. I do.\"\n\n"
                + "You both head to the dance floor.";
        }

        if (hasTrait(n, "Alcoholic")) {
            return npcAsked
                ? "\"Heyyy gorgeous — c'mon, let's dance before I spill this drink "
                + "all over both of us. You're too pretty to waste.\"\n\n"
                + "\"Okay, easy there.\"\n\n"
                + n.name + " stumbles slightly as you both head to the dance floor."
                : "\"Dance with me?\"\n\n"
                + "\"Abso-fucking-lutely, sweetheart! Let's get weird!\"\n\n"
                + n.name + " almost trips over {npc_his} own feet heading to the floor.";
        }

        if (hasTrait(n, "Jerk")) {
            return npcAsked
                ? "\"You're not completely hopeless on the dance floor I hope. "
                + "C'mon, I'll let you dance with me.\"\n\n"
                + "\"Wow. Generous.\"\n\n"
                + "You head to the dance floor."
                : "\"Dance with me.\"\n\n"
                + "\"Took you long enough to ask. Fine, let's see what you got.\"\n\n"
                + "You both head to the dance floor.";
        }

        // Default
        return npcAsked
            ? n.name + " tilts their head toward the floor. \"Come on.\"\n\nYou go."
            : "\"Dance with me?\"\n\n\"Yeah. Let's go.\"\n\nYou both head to the dance floor.";
    }


    /**
     * Walk home scene text — sets tone based on what happened during the session.
     * Three outcomes route from bar_walk_home_outside:
     *   bar_walk_home_kiss_only  — kissed but nothing further (pleasant / awkward)
     *   bar_walk_home_groped     — groped but not gone further (lingering)
     *   bar_walk_home_his_place  — high arousal/rep, goes further
     * Willpower check still gates the "go further" route.
     */
    /**
     * Morning-after scene text — checks Neck_Hickey trait and generates
     * appropriate wake-up internal state based on what happened the night before.
     */
    public String buildMorningAfterText() {
        // Check mod pool for morning-after prose by MC reaction tier
        String morningPool = "bar.morning_after." + gameStageVariant();
        String modMorning  = pickFromPool(morningPool, buildMcTraitSet());
        if (modMorning != null && !modMorning.isEmpty()) return modMorning;
        String tier     = gameStageVariant();
        String d        = drunkTier();
        boolean hickey  = state.hasTrait("Neck_Hickey") || state.hasTrait("Neck_Hickey_Faint");
        boolean wentFar = state.flagPussyGroped || state.flagFingered;
        boolean kissed  = state.flagKissed || state.flagDeepKissed;
        boolean groped  = state.flagBreastGroped || state.flagAssGroped;
        boolean npcCame = state.flagNpcCame;

        // Opening — hangover tier sets the physical baseline
        String wakeup = switch (d) {
            case "blackout" ->
                "You come back in stages.\n\n"
              + "Light first. Then sound — something outside, traffic maybe. "
              + "Then the specific quality of a ceiling you don't immediately recognize "
              + "before you understand that you do, actually. This is yours.\n\n"
              + "Then the headache. Then the complete absence of last night.";
            case "drunk" ->
                "Morning arrives with commitment.\n\n"
              + "Your head has opinions about last night that you're not ready to hear. "
              + "Your mouth tastes like decisions. You lie still and let the room "
              + "stop moving on its own terms.";
            case "tipsy" ->
                "You wake up clear enough — which is almost worse.\n\n"
              + "Last night sits in your chest already assembled. "
              + "You don't have the buffer of a real hangover to hide behind.";
            default ->
                "Morning. Clean and quiet and unavoidable.\n\n"
              + "You're awake before you want to be. Your brain is already running.";
        };

        // Main content — what happened determines the emotional texture
        String content;
        if (npcCame) {
            content = switch (tier) {
                case "enjoy" ->
                    "\n\nYou think about last night and feel a slow, warm satisfaction settle in.\n\n"
                  + "*That happened. That was real.*\n\n"
                  + "You stretch. Check your phone. Put it down again. "
                  + "There's no urgency to any of it.";
                case "flustered" ->
                    "\n\nLast night comes back in fragments — specific ones. "
                  + "Your face warms before you're fully awake.\n\n"
                  + "*Okay. That happened. We're not thinking about that yet.*\n\n"
                  + "You sit up carefully and look for water.";
                default ->
                    "\n\nThe memories arrive in an order that doesn't help.\n\n"
                  + "*Oh god.* You pull the blanket up. As if that helps anything.\n\n"
                  + "You need about ten minutes before you're ready to be a person.";
            };
        } else if (wentFar) {
            content = switch (tier) {
                case "enjoy" ->
                    "\n\nYou let last night unspool in your mind without fighting it.\n\n"
                  + "It was a lot. You don't regret any of it. "
                  + "That's worth sitting with for a minute.";
                case "flustered" ->
                    "\n\nLast night. Right. That was a thing.\n\n"
                  + "You're not sure how you feel about it yet — there are too many "
                  + "feelings stacked on top of each other. You file it under *later* "
                  + "and focus on existing.";
                default ->
                    "\n\n*Oh no.*\n\nNot regret exactly. More like — the cold light of morning "
                  + "looking at last night's decisions and raising an eyebrow.\n\n"
                  + "You lie there for a while doing the math.";
            };
        } else if (kissed || groped) {
            content = switch (tier) {
                case "enjoy" ->
                    "\n\nNot a bad night. You think about it with something that feels "
                  + "almost like satisfaction.\n\n*Yeah. That was fine. More than fine.*";
                case "flustered" ->
                    "\n\nYou remember more than you'd like to — or maybe less. "
                  + "It's unclear which would be better.";
                default ->
                    "\n\nSome things happened last night. Not terrible things. "
                  + "But things you're going to need a minute with.";
            };
        } else {
            content = "\n\nLast night was what it was. You went out. Something happened "
                    + "or nothing happened. Either way, it's morning now.";
        }

        // Hickey note — appended regardless of other content
        String hickeyNote = "";
        if (hickey) {
            hickeyNote = switch (tier) {
                case "enjoy" ->
                    "\n\nYour hand goes to your neck without thinking.\n\nYep. Still there.";
                case "flustered" ->
                    "\n\nYou touch your neck.\n\nRight. That's going to need dealing with today.";
                default ->
                    "\n\n*Oh no.*\n\nYou reach up. Your fingers find what you were afraid they'd find.\n\n"
                  + "You stare at the ceiling for another full minute.";
            };
        }

        return wakeup + content + hickeyNote;
    }

    public String buildMorningMirrorCheck() {
        boolean bigHickey   = state.hasTrait("Neck_Hickey");
        boolean faintHickey = state.hasTrait("Neck_Hickey_Faint");
        boolean hasHickey   = bigHickey || faintHickey;
        String  tier        = gameStageVariant();

        // Hangover level from previous night's peak drunk (stored as current drunk decay)
        int drunk = state.drunk;
        // Approximate memory quality from hangover
        boolean clearMemory    = drunk < 6;   // sober/mild — remembers clearly
        boolean fuzzyMemory    = drunk >= 6  && drunk < 11; // tipsy/moderate — mostly remembers
        boolean patchyMemory   = drunk >= 11 && drunk < 15; // drunk — fragments
        boolean blackout       = drunk >= 15;              // wasted/blackout — barely anything

        if (!hasHickey)
            return "Nothing visible. Just you.\n\n"
                 + "The night left no obvious marks. That's either good or disappointing, "
                 + "depending on how you look at it.";

        StringBuilder sb = new StringBuilder();

        // Opening — same for all
        if (bigHickey) {
            sb.append("You push your hair aside and there it is.\n\n"
                    + "Large. Dark. Impossible to miss — purple edging toward red, "
                    + "sitting high enough on your neck that no neckline will cover it without effort.\n\n");
        } else {
            sb.append("You almost miss it at first.\n\n"
                    + "A faint bruise on your neck — smaller than you feared, "
                    + "but definitely there. Close up, it's obvious. Far enough away it might pass.\n\n");
        }

        // Memory line
        if (blackout) {
            sb.append("You have absolutely no memory of how it got there.\n\n");
        } else if (patchyMemory) {
            sb.append("You have a rough idea. Someone's mouth. The dance floor. "
                    + "The details are blurry around the edges.\n\n");
        } else if (fuzzyMemory) {
            sb.append("You sort of remember. His mouth on your neck while you were dancing. "
                    + "The rest is softer than you'd like.\n\n");
        } else {
            sb.append("You remember exactly how it happened.\n\n");
        }

        // MC tier reaction
        if (tier.equals("enjoy")) {
            if (bigHickey) {
                sb.append(clearMemory
                    ? "*He really went for it.* You tilt your chin to see the full shape of it.\n\n"
                      + "You don't hate it. You kind of like that it's there."
                    : "You touch the spot. Even not remembering clearly, you find you don't mind.\n\n"
                      + "It looks good on you.");
            } else {
                sb.append(clearMemory
                    ? "You smirk at the faint mark. *Cute little souvenir.*\n\n"
                      + "You tilt your head. Not too bad."
                    : blackout
                    ? "No memory, but you clearly got marked. You examine it with mild interest.\n\n"
                      + "*I kind of like the mystery.*"
                    : "You feel satisfied rather than embarrassed. It's a reminder. A good one.");
            }
        } else if (tier.equals("flustered")) {
            if (bigHickey) {
                sb.append(clearMemory
                    ? "*That's going to be hard to hide.* You sigh and start thinking about concealer.\n\n"
                      + "It felt intense at the time. Now you just have to deal with this all day."
                    : patchyMemory
                    ? "Staring at the vivid bruise, you mutter, \"That's bigger than I thought.\"\n\n"
                      + "*I remember bits and pieces. Now I have this giant reminder.*"
                    : "You frown. You barely remember last night and somehow this is what you have to show for it.");
            } else {
                sb.append(clearMemory
                    ? "You notice the smaller mark and touch it lightly.\n\n"
                      + "*Not too bad, but it's still obvious. Last night got a bit wilder than I planned.*"
                    : blackout
                    ? "You frown at the faint mark. \"I have no idea how I got this.\"\n\n"
                      + "*Blackout. Great. I don't remember who gave it to me or when.*"
                    : "A mix of mild regret and lingering warmth. You're not entirely sure which wins.");
            }
        } else {
            // shy
            if (bigHickey) {
                sb.append(clearMemory
                    ? "\"Oh no…\" you whisper, voice small.\n\n"
                      + "*It's huge. Everyone will see it today. I remember him on my neck — "
                      + "why didn't I stop him sooner?*\n\n"
                      + "You pull your hair down over it, cheeks burning."
                    : patchyMemory
                    ? "You blink at the large purple mark. \"What…?\"\n\n"
                      + "*I think someone gave me this. My head hurts too much to think.*\n\n"
                      + "You groan and cover it with your hand."
                    : blackout
                    ? "\"What…?\" you whisper, confused and a little sick.\n\n"
                      + "*I don't remember anything. Who did this?*"
                    : "\"Oh no…\" A heavy, familiar shame. You know exactly who did it.");
            } else {
                sb.append(clearMemory
                    ? "The faint mark catches your eye. \"…There's a hickey,\" you mumble, touching it.\n\n"
                      + "*I sort of remember his mouth on my neck. I feel so embarrassed.*"
                    : blackout
                    ? "A small, faint bruise stares back. \"…Where did this come from?\"\n\n"
                      + "*I don't remember anything. Who gave me a hickey? I feel sick just looking at it.*"
                    : "You try to angle your head to see how bad it looks.\n\n"
                      + "*It's blurry. Still — it's there now.*");
            }
        }

        return sb.toString();
    }

    /**
     * Pool table scene opener — NPC personality x player skill tone.
     * Token: {bar_pool_text}
     * Used by bar_pool_with_npc scene text.
     */
    /**
     * Bathroom scene — drunk-tier aware, checks Neck_Hickey for mirror moment.
     * Token: {bar_bathroom_text}
     */
    public String buildBathroomText() {
        String d    = drunkTier();
        String tier = gameStageVariant("finger_public");
        boolean hasHickey  = state.hasTrait("Neck_Hickey") || state.hasTrait("Neck_Hickey_Faint");
        boolean fingered   = state.flagFingered || state.flagPussyGroped;
        boolean groped     = state.flagBreastGroped || state.flagAssGroped;
        boolean neckGrab   = state.flagNeckKissed;
        boolean commando   = state.hasTrait("commando");
        boolean isShy      = state.hasTrait("shy") || state.hasTrait("fragile_ego") || state.hasTrait("conflict_avoidant");
        boolean isOut      = state.hasTrait("outgoing") || state.hasTrait("confrontational") || state.hasTrait("self_assured");

        // ── Blackout ──────────────────────────────────────────────────────────
        if (d.equals("blackout")) {
            String base = "The bathroom is very bright. You sag against the sink and stare at the drain.\n\n"
                        + "Fragments arrive without order — pressure somewhere, wet warmth, muffled music. "
                        + "You can't form a sentence around any of it.\n\n"
                        + "*Can't think…*";
            return base + (hasHickey ? "\n\nSomething on your neck. You touch it. Warm." : "");
        }

        // ── Build flashback from what actually happened ────────────────────────
        String flashback = "";
        if (fingered && neckGrab) {
            flashback = d.equals("drunk")
                ? "Flashes of it hit in the wrong order — {npc_his} hand suddenly on your neck mid-kiss, "
                  + "fingers still moving below, the grinding turning frantic, "
                  + "the sudden pulsing wet warmth through {npc_his} pants. "
                  + "The humiliating words after that."
                : "The sequence plays back clearly: {npc_his} hand clamping around your neck while you were still trying to say stop, "
                  + "{npc_his} mouth on yours, the fingering continuing through all of it, "
                  + "then the unexpected stutter of {npc_his} hips and the sticky heat against your thigh. "
                  + "The words after that.";
        } else if (fingered) {
            flashback = d.equals("drunk")
                ? "You can still feel it — {npc_his} fingers moving inside you while you swayed to the music. "
                  + "The way {npc_he} wouldn't stop even when you said to."
                : "{npc_His} fingers inside you on a crowded dance floor while the song played. "
                  + "You said stop and {npc_he} kept going. The whole floor around you, none of it registering as real.";
        } else if (groped) {
            flashback = "{npc_His} hands moving without asking while you both swayed. "
                      + "The way {npc_he} didn't slow down when you tensed.";
        }

        // ── MC physical state ─────────────────────────────────────────────────
        String physical = "";
        if (fingered) {
            physical = commando
                ? "\n\nYour skirt is slightly disheveled. Your thighs are sticky — your own arousal, "
                  + "and whatever transferred from {npc_him} through the fabric. No panties to absorb any of it."
                : "\n\nYour thighs are sticky. "
                  + "You're more aware of your own body right now than you'd like to be.";
        }
        if (hasHickey) {
            physical += "\n\nYou push your hair back and stop.\n\n"
                      + "There it is. On your neck. Dark enough to see clearly under fluorescent light.\n\n"
                      + "*Right. That happened.*";
        }

        // ── Drunk-level base ──────────────────────────────────────────────────
        String base;
        if (d.equals("drunk")) {
            base = "You stumble into the bathroom and lean heavily against the wall. "
                 + "The room tilts slightly. The music from outside is muffled down to just the bass.\n\n"
                 + (flashback.isEmpty()
                     ? "You blink at the fluorescent light. Try to line up a coherent thought. "
                       + "Splash cold water on your face and tell yourself it helps."
                     : flashback + "\n\nYou blink at your own hands on the sink. Try to steady the room.");
        } else {
            // sober/tipsy
            base = "The bathroom is quieter than the bar. The music drops to a muffled thud on the other side of the door.\n\n"
                 + (flashback.isEmpty()
                     ? "You take a breath. Check your hair. Smooth something that didn't need smoothing. "
                       + "*You're fine,* you tell your reflection."
                     : "You stand at the sink and let the flashback play. "
                       + flashback + "\n\nYou grip the edge of the sink and look at your own face in the mirror.");
        }

        // ── MC internal by tier + trait ───────────────────────────────────────
        String mc = "";
        if (fingered || groped) {
            if (tier.equals("shy")) {
                mc = isShy
                    ? "\n\n*I was too scared to fight back harder… everyone might have seen. "
                      + (neckGrab ? "He grabbed my neck and I just froze. " : "")
                      + "I feel so dirty and exposed. I should have left sooner.*"
                    : "\n\n*I can't believe I let that happen right there on the floor. "
                      + "I said stop and {npc_he} just kept going. "
                      + "The shame hits hard and clear and there's nowhere to put it.*";
            } else if (tier.equals("enjoy")) {
                mc = isOut
                    ? "\n\n*{npc_He} humiliated me after cumming in {npc_his} pants and my body still reacted. "
                      + "That's infuriating. I'm furious at him and at myself.*"
                    : "\n\n*The shame and the arousal are sitting in the same place. "
                      + "I don't know what to do with that.*";
            } else {
                mc = "\n\n*It happened. The stickiness is real. The memories are real. "
                   + "I'm in a bathroom now. I'll decide what to do with the rest in a minute.*";
            }
        }

        // ── Spoken line ───────────────────────────────────────────────────────
        String spoken = "";
        if (fingered) {
            spoken = isShy  ? "\n\nYou whisper to your reflection, \"I should have stopped it sooner…\""
                   : isOut  ? "\n\nYou mutter to the mirror, \"Next time I'll just leave.\""
                   :          "\n\nYou sigh quietly at your reflection. \"Time to clean up and figure out what's next.\"";
        }

        return base + physical + mc + spoken;
    }

    /**
     * Other patron approaching — 4 stranger archetypes, tone varies by MC drunk level.
     * Token: {bar_other_patron_text}
     */
    public String buildOtherPatronText() {
        // 50% chance — nothing happens, MC just reaches the bar
        if (rng.nextInt(2) == 0)
            return "You reach the bar. The bartender moves on to someone else. Nobody looks twice.";

        String d = drunkTier();
        String tier = gameStageVariant();
        boolean hadIntenseDance = state.flagFingered || state.flagPussyGroped || state.flagBreastGroped;
        boolean isShy = state.hasTrait("shy") || state.hasTrait("fragile_ego");
        boolean isOut = state.hasTrait("outgoing") || state.hasTrait("confrontational");
        int roll = rng.nextInt(6);

        String approach = switch (roll) {
            case 0 -> // Woman who saw
                hadIntenseDance
                    ? "A woman in her late 20s on the next stool glances at you, then quickly looks away with a small knowing smirk. "
                      + "She takes a sip of her drink and says just loud enough:\n\n"
                      + "\"Damn… that dance looked intense.\" She turns back to her phone."
                    : "A woman on the next stool glances over briefly, gives you a neutral nod, and turns back to her drink.";
            case 1 -> // Friendly stranger making space
                "A friendly-looking guy slides over on his barstool to make room. "
                + "\"Here — you look like you could use it.\" He raises his glass in a casual toast and turns back to the bartender.";
            case 2 -> // Bartender water
                hadIntenseDance
                    ? "The bartender slides a glass of water toward you without being asked. "
                      + "\"On the house.\" Neutral smile. There's something knowing in it. He's already moving on."
                    : "The bartender catches your eye. \"What can I get you?\" Just that.";
            case 3 -> // Woman with light tease
                "A woman with bright red hair leans on the bar next to you, waiting for her order. "
                + "She bumps your elbow lightly.\n\n"
                + "\"Crowd's wild tonight, huh? Saw a few couples getting pretty close on the floor.\"\n\n"
                + "She grabs her drink and disappears into the crowd before you can respond.";
            case 4 -> // Tipsy guy offering drink
                "A slightly drunk guy a couple seats down raises his glass toward you. "
                + "\"Hey — you want anything? Looked like you were having a hell of a time out there.\"\n\n"
                + "The bartender interrupts him with another order. He shrugs and turns away.";
            default -> // Group ambient
                hadIntenseDance
                    ? "A small group of women nearby bursts into laughter. One gestures toward the floor and says, carrying:\n\n"
                      + "\"Did you see that couple? They were basically dry-humping during the slow song!\"\n\n"
                      + "They clink glasses. Completely unaware you're right there."
                    : "The bar noise swells for a moment — a group nearby, something funny between them. You're not part of it. That's fine.";
        };

        // MC internal reaction
        String mc = "";
        if (isShy && hadIntenseDance)
            mc = "\n\n*My face burns. How much did they see?*";
        else if (isOut && hadIntenseDance)
            mc = "\n\n*Let them talk. It was his fault, not mine.*";
        else if (hadIntenseDance)
            mc = "\n\n*The comment lands flat. They don't know what it actually was.*";

        String drunkNote = d.equals("drunk") || d.equals("blackout")
            ? "\n\nYou register them with a slight delay."
            : "";

        return approach + drunkNote + mc;
    }

    /**
     * Pre-dance atmospheric moment — fires before the dance floor menu.
     * Token: {bar_pre_dance_text}
     */
    /**
     * Internal thought when MC refuses to escalate or declines an impulse.
     * Tone varies by gameStageVariant and drunk state.
     * Token: {mc_refusing_thought}
     */
    public String buildRefusingInternalThought() {
        String tier = gameStageVariant();
        String d    = drunkTier();
        boolean drunk = !d.equals("sober");

        String base = switch (tier) {
            case "enjoy" -> switch (d) {
                case "blackout" ->
                    "*No. Not — no. Come on.*\n\nThe thought lands slow. You hold onto it anyway.";
                case "drunk" ->
                    "*I want to. I'm choosing not to.*\n\nThe difference matters. Even now.";
                case "tipsy" ->
                    "*Later. Not tonight.*\n\n"
                  + "You file it. The wanting doesn't go anywhere — you just put it somewhere useful.";
                default ->
                    "*Not this. Not yet.*\n\n"
                  + "It's a choice, not a retreat. You remind yourself of that "
                  + "and find you mostly believe it.";
            };
            case "flustered" -> switch (d) {
                case "blackout" ->
                    "*Stop. Just — stop.*\n\nThe words don't fully form. You stop anyway.";
                case "drunk" ->
                    "*I shouldn't. I know I shouldn't.*\n\n"
                  + "Half of you agrees. That half wins. Barely.";
                case "tipsy" ->
                    "*Okay. That's enough for tonight.*\n\n"
                  + "Relief and something else at the same time. You don't look too closely at the something else.";
                default ->
                    "*No.*\n\n"
                  + "Not with certainty. More like — not with enough certainty to keep going.\n\n"
                  + "That's good enough.";
            };
            default -> // shy
                switch (d) {
                case "blackout" ->
                    "*No no no no—*\n\nYou stop. The thought is still there but your feet aren't moving anymore.";
                case "drunk" ->
                    "*I can't. I can't do this.*\n\n"
                  + "The alcohol made it feel possible. It's wearing off faster than you'd like.";
                case "tipsy" ->
                    "*Not ready. I'm not ready for that.*\n\n"
                  + "A small wave of relief. Then guilt about the relief. Then just — relief again.";
                default ->
                    "*No. Definitely not.*\n\n"
                  + "You feel it settle. The certainty is almost physical.\n\n"
                  + "You're grateful for it.";
            };
        };

        return base;
    }

    // ── MALL FLASH SCENE BUILDERS ─────────────────────────────────────────────

    /**
     * Scene text for witnessing a girl flash at the mall.
     * Variant: ass+pussy vs breasts, tier-aware MC reaction.
     * Token: {mall_flash_witness_text}
     */
    public String buildMallFlashWitnessText() {
        // Witness tone uses gameStageVariant — MC's general rep tier (she's just watching)
        String tier    = gameStageVariant();
        String d       = drunkTier();
        boolean drunk  = !d.equals("sober");
        int variant    = rng.nextInt(2); // 0 = lower body, 1 = breasts

        String what   = variant == 0
            ? "her skirt — just for a second — bare skin below"
            : "her top down, bare chest visible for a few seconds";
        String whatLg = variant == 0
            ? "bare ass and everything below"
            : "bare breasts, nipples and all";

        String crowd =
            "The main corridor is packed — footsteps, overlapping conversations, the distant pulse of store music. "
          + "Someone ahead is carrying too many bags. A kid runs past a mother who's given up chasing.\n\n"
          + "Then the girl ahead stops.\n\n"
          + "She says something to her friends with a grin, lifts " + what + ". "
          + "Two seconds, maybe three. Her friends burst out laughing. "
          + "She drops the fabric and they disappear into the crowd.\n\n"
          + "A guy nearby lets out a long whistle. Someone else mutters something. "
          + "A woman with a stroller actively looks away.\n\n"
          + "The mall noise swallows it. Like it barely happened.";

        String drunkNote = drunk
            ? switch (d) {
                case "blackout" -> "\n\n*Everything feels blurry and warm. The flash registers slowly — bare, exposed, then gone.*";
                case "drunk"    -> "\n\n*The alcohol makes it land slower and harder at the same time.*";
                default         -> "\n\n*The buzz makes the whole thing feel slightly unreal.*";
              }
            : "";

        String reaction = switch (tier) {
            case "enjoy" ->
                "*Holy shit.* You watch her go, the image already burning itself in.\n\n"
              + "She didn't hesitate. Didn't flinch after. Just — did it and kept moving.\n\n"
              + "*That was " + whatLg + ". Right here. I kind of respect it.*";
            case "flustered" ->
                "You blink. Your brain registers " + whatLg + " before the rest of you does.\n\n"
              + "The girl is already gone, still laughing with her friends.\n\n"
              + "*That was reckless. Also impressive. You're not sure in which order.*";
            default -> // shy
                "You freeze mid-step.\n\n"
              + "*Oh god — she just — " + whatLg + ". In public. In the middle of the mall.*\n\n"
              + "Heat floods your face. You look away fast, clutch your bag a little tighter, "
              + "and keep walking like you were never standing there.\n\n"
              + "*I would literally die if that was me.*";
        };

        // Hair note: the AC vents are already part of the scene setup.
        // The flashing girl's departure + mall air current = natural moment.
        // Use generic NPC hair since we don't track the random NPC's traits.
        String hairNote = "\n\nThe mall air catches her hair as she goes.";

        return crowd + drunkNote + "\n\n" + reaction + hairNote;
    }

    /**
     * MC entertaining the thought of doing it herself.
     * Tone: repProximityTier(20) — the "Think about it" choice is gated at 20.
     * Token: {mall_flash_mc_thought_text}
     */
    public String buildMallFlashMcThoughtText() {
        // Proximity to the 20 gate — near minimum = shy, well above = enjoy
        String tier   = repProximityTier(20);
        String d      = drunkTier();
        boolean drunk = !d.equals("sober");

        String base = switch (tier) {
            case "enjoy" ->
                "The thought lands immediately. Not hypothetical. *What if I actually did that?*\n\n"
              + "Your heart rate ticks up. The crowd moves around you, oblivious.";
            case "flustered" ->
                "You know you shouldn't be thinking about it. You're thinking about it.\n\n"
              + "*Just — like that. For two seconds. Nobody knowing who you were.*";
            default -> // shy — near minimum, just barely crossed into this range
                "The thought appears fully formed, which is embarrassing on its own.\n\n"
              + "*I would never. Obviously.*\n\n"
              + "You think about it for another few seconds anyway.";
        };

        String drunkNote = drunk
            ? switch (d) {
                case "blackout" -> "\n\n*Thoughts aren't forming cleanly. Something about what she did keeps surfacing.*";
                case "drunk"    -> "\n\n*The alcohol isn't helping you talk yourself out of it.*";
                default         -> "\n\nYour face is warm. That might be the alcohol. Or not.";
              }
            : "";

        return base + drunkNote;
    }

    /**
     * MC actually flashes. Rep-gated action at 25.
     * Tone: repProximityTier(25) — near minimum = shaky/hesitant, well above = confident.
     * Drunk tier adds setup context before the action.
     * Token: {mall_flash_mc_does_it_text}
     */
    public String buildMallFlashMcDoesItText() {
        // Near the 25 gate = shy reaction; well above = confident
        String tier = repProximityTier(25);
        String d    = drunkTier();

        // Drunk setup — sets physical context before the action
        String setup = switch (d) {
            case "blackout" ->
                "The thought and the action barely have a gap between them. "
              + "You're moving before you've decided.\n\n";
            case "drunk" ->
                "Your hands are slightly clumsy but the hesitation is gone. "
              + "You look around once — nobody directly watching.\n\n";
            case "tipsy" ->
                "The buzz takes the edge off. You look around once. Nobody watching directly.\n\n";
            default ->
                "You check. Corridor quiet enough. Heart going too fast.\n\n";
        };

        // Action + reaction — tone from rep proximity, not general stage
        String act = switch (tier) {
            case "enjoy" ->
                "You do it — quick pull, a second of exposure, fabric back.\n\n"
              + "The cool air hits and the adrenaline follows immediately.\n\n"
              + "*There it is.* You keep walking. Nobody stopped. Nobody saw.";
            case "flustered" ->
                "You do it faster than you meant to, fabric up before you've fully processed it.\n\n"
              + "Your hands are trembling slightly. Your chest still holds the memory of the air.\n\n"
              + "*I actually just did that.*";
            default -> // shy — barely qualified, still shaky
                "Your hands shake as you do it — half a second, fabric back immediately.\n\n"
              + "You look around, certain everyone saw. Nobody has stopped.\n\n"
              + "*Oh my god.* You walk faster. Face burning. Heart hammering.\n\n"
              + "*I just flashed in a mall. I actually just did that.*";
        };

        // Additional drunk note after action
        String drunkCoda = switch (d) {
            case "blackout" ->
                "\n\nYou're not entirely sure it happened. The crowd keeps moving.";
            case "drunk" ->
                "\n\nThe buzz makes the whole thing feel warmer and further away at the same time.";
            default -> "";
        };

        return setup + act + drunkCoda;
    }

    public String buildPreDanceText() {
        String tier = drunkTier();
        String d = tier;

        int variant = rng.nextInt(2); // 0 = ass/lower, 1 = breasts

        String what   = variant == 0 ? "her skirt — just for a second — flashing bare skin below" : "her top down, bare chest on display";
        String whatLg = variant == 0 ? "bare ass and everything below" : "bare breasts, nipples and all";

        String crowd =
            "The main corridor is packed — footsteps, overlapping conversations, the distant pulse of store music. "
          + "Someone ahead is carrying too many bags. A kid runs past a mother who's given up chasing.\n\n"
          + "Then the girl ahead stops.\n\n"
          + "She says something to her friends with a grin, lifts " + what + ". "
          + "Two seconds, maybe three. Her friends burst out laughing. She drops the fabric and they disappear into the crowd.\n\n"
          + "A guy nearby lets out a long whistle. Someone else mutters something. "
          + "A woman with a stroller actively looks away.\n\n"
          + "The mall noise swallows it. Like it barely happened.";

        String reaction = switch (tier) {
            case "enjoy" ->
                "*Holy shit.* You watch her go, the image already burning itself in.\n\n"
              + "She didn't hesitate. Didn't flinch after. Just — did it and kept moving.\n\n"
              + "*That was " + whatLg + ". Right here. I kind of respect it.*";
            case "flustered" ->
                "You blink. Your brain registers " + whatLg + " before the rest of you does.\n\n"
              + "The girl is already gone, still laughing with her friends.\n\n"
              + "*That was reckless. Also impressive. You're not sure in which order.*";
            default -> // shy
                "You freeze mid-step.\n\n"
              + "*Oh god — she just — " + whatLg + ". In public. In the middle of the mall.*\n\n"
              + "Heat floods your face. You look away fast, clutch your bag a little tighter, "
              + "and keep walking like you were never standing there.\n\n"
              + "*I would literally die if that was me.*";
        };

        return crowd + "\n\n" + reaction;
    }

    /**
     * MC entertaining the thought of doing it herself.
     * Token: {mall_flash_mc_thought_text}
     */

    /**
     * MC actually flashes. Rep-gated action.
     * Token: {mall_flash_mc_does_it_text}
     */


    /**
     * Song change mid-dance — fires rare during dance floor.
     * Token: {bar_song_change_text}
     */
    public String buildSongChangeText() {
        String d = drunkTier();
        boolean intimate = state.flagFingered || state.flagPussyGroped || state.flagNeckKissed;
        boolean afterCum = state.hasTrait("npc_just_came"); // set by cums_grinding scene if applicable
        String tier = gameStageVariant("finger_public");
        int roll = rng.nextInt(intimate ? 4 : 3);

        if (d.equals("blackout"))
            return "The song changes. You register it as a distant shift in sound. "
                 + "Everything stays blurry and overwhelming. "
                 + (intimate ? "His fingers — or his hands — haven't stopped." : "You keep swaying.");

        return switch (roll) {
            case 0 -> { // Slower — pulls you closer
                String base = "The song drops into something slower. The whole floor recalibrates — "
                            + "bodies pulling a little closer, the energy trading speed for weight.";
                String mc = intimate
                    ? "\n\nThe new rhythm makes your position obvious. Swaying slowly, his hand under your skirt, "
                      + "both of you pressed together while the floor finds new intimacy around you."
                      + (tier.equals("shy")
                          ? "\n\n*Oh no — everyone is pressing close now. The song is making this more exposed, not less.*"
                          : tier.equals("enjoy")
                              ? "\n\n*The song slowing down is making this even better. The whole floor just got more intimate.*"
                              : "\n\n*The new song and his hands both registered at once. We're still here.*")
                    : "\n\n" + (d.equals("drunk") || d.equals("blackout")
                          ? "Everything feels warmer. The bass is in your chest."
                          : "You feel the shift before you've consciously registered it.");
                yield base + mc;
            }
            case 1 -> { // Faster — makes the current position feel exposed
                String base = "The tempo spikes. The DJ makes a choice and the floor answers immediately — "
                            + "louder, faster, the kind of song that makes standing still feel wrong.";
                String mc = intimate
                    ? "\n\nAround you people start moving properly. You and him don't. "
                      + "The slower sway you're locked in becomes obvious against the new beat."
                      + (tier.equals("shy")
                          ? "\n\n*Oh god — the fast song is making us stand out. Everyone is dancing normally and we're still…*"
                          : tier.equals("enjoy")
                              ? "\n\n*The crowd picking up speed around us just makes this feel riskier. Good.*"
                              : "\n\n*The floor changed tempo. We didn't. His fingers haven't stopped.*")
                    : "\n\nYou move with it. You don't have much choice.";
                yield base + mc;
            }
            case 2 -> { // Familiar song
                String base = "You know this song.\n\n"
                            + "Somewhere in your head a specific memory attaches to it — a room, "
                            + "a feeling, a version of yourself from a while ago. Then it's just a song again.";
                String mc = intimate
                    ? " And you're still on this floor with his hand under your skirt."
                    : " And you're dancing.";
                yield base + mc;
            }
            default -> { // After-cum / intense moment — natural break point
                String base = "The slow song fades out and a new track kicks in — "
                            + (d.equals("drunk") ? "the faster rhythm hits harder in your hazy state. " : "")
                            + "The dance floor shifts. Some couples pull apart. Others linger.";
                String mc = intimate
                    ? "\n\nThe rhythm change jolts your bodies out of sync. "
                      + "His hand under your skirt doesn't move."
                      + (tier.equals("shy")
                          ? "\n\n*The song changed — people are starting to dance normally around us. We look completely out of place.*"
                          : tier.equals("enjoy")
                              ? "\n\n*The new energy on the floor with his fingers still inside me — the risk just doubled.*"
                              : "\n\n*The rhythm changed. His fingers didn't. The dance keeps going.*")
                    : "\n\nYou find the new beat. It doesn't take long.";
                yield base + mc;
            }
        };
    }

    public String buildPoolText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "Someone grabs a cue from the rack.";

        String d = drunkTier();
        boolean tipsy = !d.equals("sober");

        if (hasTrait(n, "Sleazy")) {
            String opener = tipsy
                ? n.name + " leans against the table, cue resting across {npc_his} shoulders. "
                  + "\"You any good, or am I just here for the view?\""
                : n.name + " racks the balls with practiced ease. "
                  + "\"Winner buys the next round. Loser owes me a favour.\" "
                  + "{npc_He} leaves what kind of favour deliberately open.";
            return opener + "\n\nThe table is between you. That's still a shorter distance than {npc_he}'d like.";
        }

        if (hasTrait(n, "Jerk")) {
            return n.name + " picks up a cue without asking which one you want. "
                 + "\"I'll go easy on you. First three shots.\"\n\n"
                 + "{npc_He} clearly will not go easy on you.";
        }

        if (hasTrait(n, "Engaging")) {
            return n.name + " grabs the chalk and hands you a cue directly. "
                 + "\"You any good? I'm just decent enough to be annoying.\"\n\n"
                 + "{npc_He} says it like {npc_he} hopes you'll prove {npc_him} wrong.";
        }

        if (hasTrait(n, "Magnetic")) {
            return n.name + " lines up the break without ceremony. Looks at you once over the cue. "
                 + "\"Your shot calls it.\"\n\n"
                 + "Simple. {npc_He}'s already focused on the table like it's the only thing in the room.";
        }

        if (hasTrait(n, "Shy")) {
            return n.name + " holds out a cue, then second-guesses which one. "
                 + "\"Sorry — here, this one's better. Probably. I don't actually know.\"\n\n"
                 + "{npc_He} laughs once at himself. It's not uncharming.";
        }

        if (hasTrait(n, "Self_Assured")) {
            return n.name + " racks with clean efficiency. "
                 + "\"You break.\"\n\nNot a question.";
        }

        if (hasTrait(n, "Confrontational")) {
            return n.name + " rolls a cue across the table toward you. "
                 + "\"Ten bucks says you scratch on the break.\"\n\n"
                 + "{npc_He}'s already watching you like this is the most interesting part of {npc_his} night.";
        }

        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover")) {
            return n.name + " is already racking before you've fully agreed to play. "
                 + "\"Okay, rules: solids or stripes by first pot, bar rules on the eight, and "
                 + "loser has to do something embarrassing. I haven't decided what yet.\"\n\n"
                 + "{npc_He} grins. {npc_He}'s definitely decided.";
        }

        // Default
        return n.name + " holds out a cue. \"You play?\"\n\nThe table's already racked.";
    }

    /**
     * Pool game continuation — after the first exchange.
     * Used for mid-game pool moments (optional token: {bar_pool_moment_text}).
     */
    public String buildPoolMomentText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "The game continues.";

        // Personality-flavoured mid-game line
        if (hasTrait(n, "Sleazy"))
            return "She leans over your shoulder to watch your shot. Closer than necessary. "
                 + "\"Your form's not bad,\" {npc_he} says. {npc_He}'s not looking at your form.";
        if (hasTrait(n, "Jerk"))
            return "{npc_He} pots two in a row without much acknowledgment. "
                 + "\"You're better than I expected,\" {npc_he} says, like that's generous.";
        if (hasTrait(n, "Shy"))
            return "{npc_He} miscues and the cue ball rolls wide. {npc_He} winces. "
                 + "\"I'm better when I'm not being watched,\" {npc_he} says, which might be true of most things.";
        if (hasTrait(n, "Engaging"))
            return "\"Okay I need you to know that shot was pure luck,\" {npc_he} announces after potting the eight. "
                 + "\"Replicate it and I'll buy the next three rounds.\"";
        if (hasTrait(n, "Magnetic"))
            return "{npc_He} watches your shot without comment. When you look up, {npc_he}'s still watching. "
                 + "Not the table.";
        if (hasTrait(n, "Confrontational"))
            return "\"You're good,\" {npc_he} says, like {npc_he} resents it. "
                 + "\"Okay. No more going easy.\"";
        return "The game settles into a rhythm. It's easier to talk over a pool table.";
    }

    public String buildWalkHomeText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "The night air hits you as you step outside together.";
        // Check mod pool for walk-home prose for this NPC personality
        String walkPool = "bar.walk_home." + getNpcPersonalityKey(n);
        String modWalk  = pickFromPool(walkPool, buildMcTraitSet());
        if (modWalk != null && !modWalk.isEmpty()) return modWalk;
        String tier = gameStageVariant();

        // NPC personality-specific ask to walk home
        String ask;
        if (hasTrait(n, "Sleazy"))
            ask = "\"Let me walk you home, baby.\" Not really a question.\n\n";
        else if (hasTrait(n, "Engaging"))
            ask = "\"It's getting late. Mind if I walk you home? "
                + "I'd feel better knowing you got there safe.\"\n\n";
        else if (hasTrait(n, "Magnetic"))
            ask = "\"I'm not ready for the night to end yet. Let me walk you home.\"\n\n";
        else if (hasTrait(n, "Shy"))
            ask = "\"Um… it's pretty late. Would it be okay if I walked you home? Only if you want.\"\n\n";
        else if (hasTrait(n, "Self_Assured"))
            ask = "\"I'm walking you home. It's not up for debate — it's late.\"\n\n";
        else if (hasTrait(n, "Jerk"))
            ask = "\"You're not walking home alone looking like that. I'll take you.\"\n\nLike he's doing you a favour.\n\n";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            ask = "\"Hey, can't let you walk home by yourself after all that dancing! Mind if I tag along?\"\n\n";
        else if (hasTrait(n, "Confrontational"))
            ask = "\"Walk you home?\" He says it like a dare, already watching your face.\n\n";
        else
            ask = "He asks if he can walk you home. Quietly. Leaving it up to you.\n\n";

        String base = ask
            + "The bar noise cuts off behind you. The street is quieter than expected — "
            + "cooler air, distant traffic, the two of you side by side on the pavement.\n\n"
            + "The night air moves your hair for a moment as you step off the kerb.\n\n"
            + n.name + " walks close. Not quite touching. Aware of the distance.";

        String mood;
        if (state.flagPussyGroped || state.flagFingered) {
            mood = "\n\n*You're still feeling the aftermath of what happened on the dance floor. "
                 + "The cool air helps. Barely.*";
        } else if (state.flagDeepKissed || state.flagBreastGroped) {
            mood = "\n\n*Things went further than you planned. You're not sure how you feel about that yet.*";
        } else if (state.flagKissed) {
            mood = "\n\n*There was a kiss. Maybe more than one. The walk is charged with what that means.*";
        } else {
            mood = "\n\n*You're not sure what this is. Neither is {npc_he}, probably.*";
        }

        String npcMove;
        if (hasTrait(n, "Sleazy"))
            npcMove = "\n\n\"My place is two blocks that way,\" {npc_he} says. Casual. Like it's obvious where this ends.";
        else if (hasTrait(n, "Engaging"))
            npcMove = "\n\n\"I had a good night,\" {npc_he} says. Leaves it open. Not pushing.";
        else if (hasTrait(n, "Magnetic"))
            npcMove = "\n\nHe doesn't say anything for a long moment. Then: \"I don't want the night to be over.\"";
        else if (hasTrait(n, "Shy"))
            npcMove = "\n\n\"I, um. I live near here actually. If you wanted to…\" {npc_He} trails off. Blushing.";
        else if (hasTrait(n, "Self_Assured"))
            npcMove = "\n\n\"Come back with me.\" Direct. No performance.";
        else if (hasTrait(n, "Jerk"))
            npcMove = "\n\n\"My place is better than yours, probably.\" {npc_He} says it like it's settled.";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcMove = "\n\n\"Okay so I know a late-night spot, or we could just—\" {npc_He} grins. \"—you know.\"";
        else if (hasTrait(n, "Confrontational"))
            npcMove = "\n\n\"You going to make me ask?\"\n\nHe's already watching your face for the answer.";
        else
            npcMove = "\n\n\"It's still early,\" {npc_he} says.";

        return base + mood + npcMove;
    }

    /**
     * NPC offer to come inside at MC's front door — end of walk home.
     * NPC personality determines the ask. Used in bar_home_arrival scene.
     * Token: {bar_home_arrival_text}
     */
    public String buildHomeInviteInText() {
        NpcData n   = npcs.get(state.currentApproachingNpc);
        String modInvite = pickFromPool("bar.home.invite." + getNpcPersonalityKey(n), buildMcTraitSet());
        if (modInvite != null && !modInvite.isEmpty()) return modInvite;
        String tier = gameStageVariant();
        String name = n != null ? npcRef(n) : "{npc_He}";
        return switch (tier) {
            case "enjoy" ->
                "\"Come inside with me.\"\n\nYou say it with a smile and push the door open.\n\n"
              + name + " doesn't hesitate.\n\n*Tonight isn't over yet.*";
            case "flustered" ->
                "\"Sure… come on in,\" you say, turning the key.\n\n"
              + "Your voice comes out steadier than you feel.\n\n"
              + name + " follows. The door clicks shut.\n\n"
              + "*This feels like a big step. It also feels like the right one.*";
            default ->
                "\"…Okay.\" Quietly, fumbling with the key. \"You can come in.\"\n\n"
              + name + " waits while you get the lock.\n\n"
              + "*I can't believe I'm doing this. But I didn't want to be alone.*";
        };
    }

    public String buildHomeGoodnightText() {
        NpcData n     = npcs.get(state.currentApproachingNpc);
        String modGoodnight = pickFromPool("bar.home.goodnight." + getNpcPersonalityKey(n), buildMcTraitSet());
        if (modGoodnight != null && !modGoodnight.isEmpty()) return modGoodnight;
        String tier   = gameStageVariant();
        String name   = n != null ? npcRef(n) : "{npc_He}";
        boolean kissed = state.flagKissed || state.flagDeepKissed;
        String mc = switch (tier) {
            case "enjoy" ->
                "\"Not tonight,\" you say, warm enough that it doesn't sting. \"But thanks for the walk.\"\n\n"
              + "*He was fun. I'm ready to crash alone.*";
            case "flustered" ->
                "\"Thanks for walking me.\" You mean it.\n\n\"I think I'll head in from here.\"\n\n"
              + "*I need some space to process everything.*";
            default ->
                "\"I… I think I should go in alone. Thank you for walking me,\" you say quietly.\n\n"
              + "*I want to be alone right now.*";
        };
        String npcLine = (n != null && hasTrait(n, "Engaging"))
            ? name + " nods. \"Get some sleep. Text me if you want.\"\n\n"
            : (n != null && hasTrait(n, "Jerk"))
            ? name + " gives you a look. \"Really.\"\n\nThen shrugs and turns away.\n\n"
            : name + " takes it clean.\n\n";
        String kiss = kissed ? "One last moment at the door. Then you go in.\n\n" : "";
        return mc + "\n\n" + npcLine + kiss + "The apartment is yours again.";
    }

    public String buildHomeSwapGoodnightText() {
        String tier = gameStageVariant();
        NpcData n   = npcs.get(state.currentApproachingNpc);
        String name = n != null ? npcRef(n) : "{npc_He}";
        String ask = switch (tier) {
            case "enjoy" ->
                "\"Numbers before you go?\" You hold your phone out with a grin.\n\n"
              + "\"Heading in alone — but I want to keep talking.\"";
            case "flustered" ->
                "\"Thanks for the walk.\" You hesitate. \"Want to swap numbers first?\"\n\n"
              + "*Not ready to invite him in. But I don't want this to be the last time.*";
            default ->
                "\"I… maybe we can text later? I need to go in alone.\"\n\nYou pull out your phone, half-apologetic.";
        };
        String npcLine = (n != null && hasTrait(n, "Shy"))
            ? name + " looks quietly relieved and pleased at once. \"Yeah. I'd like that.\""
            : (n != null && hasTrait(n, "Sleazy"))
            ? name + " takes the number. \"I'll text you tonight.\"\n\nYou don't respond to that."
            : name + " saves the contact. \"Good. I'll use it.\"";
        return ask + "\n\n" + npcLine + "\n\nYou go inside.";
    }

    /**
     * NPC offer text at MC's front door — scene opener.
     * Token: {bar_home_arrival_text}
     */
    public String buildHomeArrivalText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        String modHomeArrivalText = pickFromPool("bar.home.arrival." + getNpcPersonalityKey(n), buildMcTraitSet());
        if (modHomeArrivalText != null && !modHomeArrivalText.isEmpty()) return modHomeArrivalText;
        if (n == null) return "You reach your door. The night sits between you.";

        String setup = "Your door. The key in your hand.\n\n"
                     + "The street is quiet enough that you can hear each other breathing.\n\n";

        String npcAsk;
        if (hasTrait(n, "Engaging"))
            npcAsk = "\"I had a really good time tonight.\" {npc_He} pauses. "
                   + "\"Mind if I come in for a bit?\"";
        else if (hasTrait(n, "Magnetic"))
            npcAsk = "{npc_He} looks at your door, then back at you.\n\n"
                   + "\"I'm not ready for this to end. Can I come in?\"";
        else if (hasTrait(n, "Shy"))
            npcAsk = "{npc_He} shifts weight, looking at the ground.\n\n"
                   + "\"I… um. It's still early? If you wanted company. You don't have to—\"\n\n"
                   + "{npc_He} stops himself. Waits.";
        else if (hasTrait(n, "Self_Assured"))
            npcAsk = "\"Come on. One more drink. I'm not done talking to you.\"";
        else if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            npcAsk = "\"The night's not over! Can I come in? Just for a bit — I promise "
                   + "I'm good company indoors too.\"";
        else if (hasTrait(n, "Sleazy"))
            npcAsk = "\"Let me walk you all the way inside.\" Not quite a question.\n\n"
                   + "\"We can continue this somewhere more private.\"";
        else if (hasTrait(n, "Jerk"))
            npcAsk = "\"You're not seriously sending me home right now.\"\n\n"
                   + "{npc_He} says it like it's already decided. Watching your face.";
        else if (hasTrait(n, "Confrontational"))
            npcAsk = "\"So.\" {npc_He} leans against the doorframe. \"Are you going to invite me in or not?\"";
        else
            npcAsk = "\"It's late,\" {npc_he} says. \"I could stay a bit. If you want.\"";

        return setup + npcAsk;
    }

    public String buildWalkHomeKissGoodnight() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        String modWalkHomeKissGoodnight = pickFromPool("bar.walk_home.kiss." + getNpcPersonalityKey(n), buildMcTraitSet());
        if (modWalkHomeKissGoodnight != null && !modWalkHomeKissGoodnight.isEmpty()) return modWalkHomeKissGoodnight;
        if (n == null) return "You say goodnight and head home.";

        boolean kissed = state.flagKissed;
        String tier    = gameStageVariant();

        if (hasTrait(n, "Engaging"))
            return "{npc_He} walks you to your door — or close enough.\n\n"
                 + (kissed ? "One more kiss at the door. Soft. Unhurried.\n\n" : "")
                 + "\"Text me when you're home safe.\"\n\nYou probably will.";

        if (hasTrait(n, "Shy"))
            return "You stop at the corner. She stops a beat after you.\n\n"
                 + "\"So this is, um. Goodnight then.\"\n\n"
                 + (kissed ? "{npc_He} kisses you again — quick, nervous, a little clumsy.\n\n" : "")
                 + "\"Goodnight,\" {npc_he} says again. Turns to go. Turns back once. Keeps walking.";

        if (hasTrait(n, "Magnetic"))
            return "She stops when you do.\n\n"
                 + (kissed ? "The last kiss is slower than the ones before it. "
                           + "Like {npc_he}'s paying attention.\n\n" : "")
                 + "\"Get home safe.\" Said like {npc_he} means it.";

        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            return "\"Okay FINE, goodnight!\" {npc_He}'s laughing.\n\n"
                 + (kissed ? "The kiss is warm and a little messy. Neither of you minds.\n\n" : "")
                 + "\"That was a great night. Seriously.\"";

        if (hasTrait(n, "Sleazy"))
            return "{npc_He} shrugs. \"Your loss.\"\n\n"
                 + "No kiss. She turns and heads the other way without looking back.\n\n"
                 + "*That's fine. That's completely fine.*";

        if (hasTrait(n, "Jerk"))
            return "\"You're no fun,\" {npc_he} says, but without real heat.\n\n"
                 + (kissed ? "{npc_He} kisses you anyway — quick, proprietary. \"Night.\"\n\n"
                           : "\"Night.\"\n\n")
                 + "{npc_He} walks off. You watch {npc_him} go longer than you mean to.";

        if (hasTrait(n, "Self_Assured"))
            return "{npc_He} nods once. \"Goodnight.\"\n\n"
                 + (kissed ? "One last kiss. Unhurried. {npc_He} pulls back before you want {npc_him} to.\n\n" : "")
                 + "{npc_He} walks away without looking back. You don't mind.";

        return "You say goodnight. {npc_He} says goodnight. You head home.\n\n"
             + "The night air is cooler than it was inside.";
    }

    public String buildWalkHomeHisPlace() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "You go with her.";
        String tier = gameStageVariant();

        // This scene ends the bar session — what happened on the dance floor
        // sets the emotional texture but explicit content is implied, not shown
        String setup = "You go with her.\n\n"
            + "The walk is two blocks or twenty minutes — you lose track.\n\n";

        String texture;
        if (state.flagPussyGroped || state.flagFingered)
            texture = "After what happened on the dance floor, the walk feels like a formality.";
        else if (state.flagDeepKissed)
            texture = "The kissing started again about a block in. You didn't complain.";
        else if (state.flagKissed)
            texture = "You're not entirely sure how you got here. You're not complaining.";
        else
            texture = "You're not entirely sure what you're doing. That's the alcohol's fault. Partially.";

        String npcLine;
        if (hasTrait(n, "Sleazy"))      npcLine = "\n\nHe unlocks the door without ceremony. \"Here we are.\"";
        else if (hasTrait(n, "Engaging"))  npcLine = "\n\n\"You can change your mind,\" {npc_he} says at the door. \"Just so you know.\"";
        else if (hasTrait(n, "Magnetic"))  npcLine = "\n\nHe unlocks the door and holds it. Doesn't say anything.";
        else if (hasTrait(n, "Shy"))       npcLine = "\n\n\"It's a bit messy,\" {npc_he} says nervously. \"Sorry. I wasn't— I didn't plan—\"";
        else if (hasTrait(n, "Jerk"))      npcLine = "\n\n\"Obviously,\" {npc_he} says, like you agreed to this miles ago.";
        else if (hasTrait(n, "Self_Assured")) npcLine = "\n\nHe holds the door. Waits. Certain you'll walk through.";
        else npcLine = "\n\nHe opens the door.";

        return setup + texture + npcLine + "\n\n*The bar feels very far away now.*";
    }

    public String buildNpcLeaveText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        String modNpcLeaveText = pickFromPool("bar.npc.leave." + getNpcPersonalityKey(n), buildMcTraitSet());
        if (modNpcLeaveText != null && !modNpcLeaveText.isEmpty()) return modNpcLeaveText;
        if (n == null) return "They make their excuses and head off.";
        String they = "MALE".equalsIgnoreCase(n.type) ? "{npc_He}" : "{npc_He}";

        // Embarrassed exit — fired when npcFrustration spiked from orgasm
        if (state.flagNpcCame) {
            if (hasTrait(n, "Shy"))
                return n.name + " does not come back from the bathroom.\n\n"
                     + "You wait a minute. Then another. Then you understand.\n\n"
                     + "When you look toward the door, {npc_he}'s already gone — jacket, bag, "
                     + "all of it. The only evidence is a half-finished drink and the memory "
                     + "of exactly how {npc_his} face looked right before {npc_he} excused himself.\n\n"
                     + "*Oh. Oh no. Poor thing.*\n\n"
                     + "You decide not to text. Some moments deserve to just — stay where they are.";
            if (hasTrait(n, "Sleazy"))
                return "{npc_He} straightens up. Checks {npc_his} phone with unusual focus.\n\n"
                     + "\"I gotta go.\"\n\nNo explanation offered. {npc_He}'s halfway across the room "
                     + "before you've processed it — moving at the specific speed of someone "
                     + "who needs to not be here anymore.\n\n"
                     + "You watch him go. Bite the inside of your cheek. Don't laugh.\n\n"
                     + "*That was — yeah. That was a thing that happened.*";
            if (hasTrait(n, "Jerk"))
                return n.name + " steps back. Adjusts {npc_his} jacket. Does not make eye contact.\n\n"
                     + "\"I have somewhere to be.\"\n\n"
                     + "It's the first completely unconvincing thing {npc_he}'s said all night. "
                     + "{npc_He} knows it — you can tell by the way {npc_he} doesn't quite meet "
                     + "your eyes before turning away.\n\n"
                     + "You let him have it. No comment. Some wins don't need to be said out loud.";
            // Generic embarrassed exit
            return n.name + " excuses himself quietly and doesn't come back.\n\n"
                 + "Not rude about it. Just — gone. The space where {npc_he} was sitting "
                 + "still has {npc_his} glass, half-full.\n\n"
                 + "*Right. Okay then.*\n\n"
                 + "You finish your drink. The bar keeps going around you like nothing happened.";
        }
        boolean kissed       = state.flagKissed;
        boolean groped       = state.flagBreastGroped || state.flagAssGroped;
        boolean wentFar      = state.flagPussyGroped || state.flagFingered;
        boolean hadHickey    = state.hasTrait("Neck_Hickey");

        if (hasTrait(n, "Sleazy")) {
            if (wentFar)
                return n.name + " pulls back and straightens {npc_his} shirt.\n\n"
                     + "\"That was fun.\" {npc_He} checks {npc_his} phone already. \"I'll be around.\"\n\n"
                     + "{npc_He} doesn't say goodbye. You're not surprised.";
            if (groped)
                return n.name + " checks {npc_his} phone, runs a hand through {npc_his} hair.\n\n"
                     + "\"I'm heading out. You should come find me later if you're still here.\"\n\n"
                     + "{npc_He} doesn't wait for an answer.";
            return n.name + " checks {npc_his} phone, downs the rest of {npc_his} drink, "
                 + "and pushes off the bar.\n\n\"I'm gonna head out.\"\n\n"
                 + "{npc_He} doesn't say it was nice meeting you.";
        }

        if (hasTrait(n, "Jerk")) {
            if (wentFar)
                return n.name + " steps back, looks you over once.\n\n"
                     + "\"Not bad.\" Leaves it there.\n\n"
                     + "{npc_He} disappears before you can respond. You're not sure "
                     + "if you're annoyed or impressed.";
            if (kissed)
                return n.name + " smirks. \"See you around.\"\n\n"
                     + "{npc_He} says it like {npc_he} means it. Maybe {npc_he} does. {npc_He}'s gone before "
                     + "you can say anything.";
            return n.name + " shrugs and stands up.\n\n"
                 + "\"I've got people to meet.\"\n\n"
                 + they + " doesn't wait for a response.";
        }

        if (hasTrait(n, "Engaging")) {
            if (kissed)
                return n.name + " lingers a moment longer than {npc_he} needs to.\n\n"
                     + "\"I had a really good time.\"\n\n"
                     + "{npc_He} means it — you can tell by how {npc_he} says it.\n\n"
                     + "\"I hope I see you again.\"";
            return n.name + " stands and smiles.\n\n"
                 + "\"Thanks for the company. Genuinely.\"\n\n"
                 + "{npc_He} heads off warm, unhurried.";
        }

        if (hasTrait(n, "Magnetic")) {
            if (kissed)
                return n.name + " holds eye contact for a moment after standing.\n\n"
                     + "No goodbye — just that look. Then she turns and walks.\n\n"
                     + "You feel it for a while after.";
            return n.name + " stands without ceremony.\n\n"
                 + "A single nod. Then gone.\n\n"
                 + "That feels like more than most people's goodbyes.";
        }

        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover")) {
            if (groped)
                return n.name + " grins and steps back.\n\n"
                     + "\"That was a great night. Don't let anyone tell you otherwise.\"\n\n"
                     + "{npc_He} heads off laughing about something already.";
            return n.name + " stands with the same energy {npc_he} came in with.\n\n"
                 + "\"This was fun! Same time next week?\"\n\n"
                 + "{npc_He}'s already waving at someone across the bar.";
        }

        if (hasTrait(n, "Shy")) {
            if (kissed)
                return n.name + " stands and can't quite look at you.\n\n"
                     + "\"I… had a really nice time. I hope that was okay. Everything.\"\n\n"
                     + "She looks mortified and happy at the same time.\n\n"
                     + "\"Goodnight.\"";
            return n.name + " stands up carefully and gives you a small nod.\n\n"
                 + "\"I'll let you enjoy the rest of your night. "
                 + "It was really nice talking to you.\"\n\n"
                 + they + " means it.";
        }

        if (hasTrait(n, "Self_Assured")) {
            if (kissed)
                return n.name + " stands. Looks at you steadily.\n\n"
                     + "\"Good night.\"\n\nTwo words. Everything in them.";
            return n.name + " finishes {npc_his} drink and stands in one motion.\n\n"
                 + "\"Good to meet you.\" Direct. Unhurried. Gone.";
        }

        if (hasTrait(n, "Confrontational")) {
            if (kissed)
                return n.name + " stands, holds your gaze a beat.\n\n"
                     + "\"You're more interesting than I expected.\"\n\n"
                     + "{npc_He} leaves before you can answer. That was a compliment.";
            return n.name + " stands and checks {npc_his} phone.\n\n"
                 + "\"Later.\" {npc_He} doesn't look back.";
        }

        // Default
        return n.name + " finishes their drink and stands.\n\n"
             + "\"I should get going. Good to meet you.\"\n\n"
             + they + " waves once and disappears into the bar.";
    }



    /**
     * Rolls a weighted random to pick which activity the NPC suggests.
     * Each trait stacks weight toward certain outcomes.
     * Whoever has the most weight accumulated wins the roll.
     *
     * Activities:
     *   bar_drink_together  — order drinks, keep talking
     *   bar_dance_with_npc  — head to the dance floor
     *   bar_pool_with_npc   — play a game of pool
     *   bar_walk_home       — suggest walking her home (escalation)
     */
    public String rollNpcDecision() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "bar_drink_together";

        Map<String, Integer> w = new java.util.LinkedHashMap<>();
        // Base weights — even playing field before traits stack
        w.put("bar_drink_together", 10);
        w.put("bar_dance_with_npc",  10);
        w.put("bar_pool_with_npc",   10);
        w.put("bar_walk_home",        5);  // lower base — it's an escalation

        // ── Trait stacking ────────────────────────────────────────────
        // Multiple traits add up — a Sleazy Alcoholic is very likely to push drinks
        // A Magnetic Engaging NPC will almost certainly head to the dance floor

        if (hasTrait(n, "Sleazy")) {
            add(w, "bar_drink_together", 8);   // get her drinking more
            add(w, "bar_walk_home",      15);  // wants to move this along
        }
        if (hasTrait(n, "Alcoholic")) {
            add(w, "bar_drink_together", 20);  // overwhelming drive to keep drinking
        }
        if (hasTrait(n, "Boring")) {
            add(w, "bar_drink_together", 8);   // can't think of anything else
        }
        if (hasTrait(n, "Engaging")) {
            add(w, "bar_dance_with_npc", 10);  // wants to be close, keep the energy up
            add(w, "bar_drink_together",  5);  // easy social fallback
        }
        if (hasTrait(n, "Magnetic")) {
            add(w, "bar_dance_with_npc", 15);  // pulls people toward the floor
        }
        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover")) {
            add(w, "bar_dance_with_npc",  8);
            add(w, "bar_drink_together",  5);
            add(w, "bar_pool_with_npc",   5);  // social, flexible, up for anything
        }
        if (hasTrait(n, "Confrontational")) {
            add(w, "bar_pool_with_npc",  12);  // competitive outlet
        }
        if (hasTrait(n, "Streetwise")) {
            add(w, "bar_pool_with_npc",  10);  // something to read her against
            add(w, "bar_walk_home",       6);  // knows what he wants
        }
        if (hasTrait(n, "Shy")) {
            add(w, "bar_drink_together", 10);  // stay in the low-key zone
            add(w, "bar_dance_with_npc", -5);  // subtract — too exposed
            add(w, "bar_walk_home",      -3);  // unlikely to suggest escalation
        }
        if (hasTrait(n, "Self_Assured")) {
            add(w, "bar_dance_with_npc",  5);
            add(w, "bar_walk_home",       8);  // confident enough to suggest it
        }
        if (hasTrait(n, "Provocative_Sexual")) {
            add(w, "bar_drink_together",  5);  // loosen things up
            add(w, "bar_walk_home",      12);  // very interested in escalation
        }
        if (hasTrait(n, "Romantic")) {
            add(w, "bar_dance_with_npc", 14);  // dance is the move
            add(w, "bar_drink_together",  5);
        }

        // ── Personality field stacking (on top of trait stacking) ─────
        switch (n.personality.toUpperCase()) {
            case "WARM":    add(w, "bar_dance_with_npc",  8); break;
            case "COLD":    add(w, "bar_pool_with_npc",   8); break;
            case "CARING":  add(w, "bar_dance_with_npc", 10); break;
            case "SELFISH": add(w, "bar_walk_home",        8); break;
        }

        // ── Session stat modifiers ────────────────────────────────────
        // High frustration pushes toward escalation (walk home) or giving up
        // High NPC arousal also pushes toward walk home
        int frustration = state.currentNpcFrustration;
        int npcArousal  = state.currentNpcArousal;

        if (frustration >= 10) add(w, "bar_walk_home", frustration / 2);
        if (npcArousal  >= 20) add(w, "bar_walk_home", npcArousal  / 5);

        // Mark that the NPC chose this — dance text will use NPC-asks version
        state.npcInitiatedActivity = true;
        // Letting them decide relieves frustration (-1)
        state.currentNpcFrustration = Math.max(0, state.currentNpcFrustration - 1);
        w.replaceAll((k, v) -> Math.max(0, v));

        // Weighted roll
        int total = w.values().stream().mapToInt(Integer::intValue).sum();
        if (total == 0) return "bar_drink_together";
        int roll = rng.nextInt(total);
        int cumulative = 0;
        for (Map.Entry<String, Integer> e : w.entrySet()) {
            cumulative += e.getValue();
            if (roll < cumulative) return e.getKey();
        }
        return "bar_drink_together";
    }

    private void add(Map<String, Integer> m, String key, int amount) {
        m.put(key, m.getOrDefault(key, 0) + amount);
    }



    /**
     * Generates the eye-contact choices shown in bar_night.
     * Each NPC gets "Catch X's eye" — result shows their initial reaction.
     * A follow-up "Wave them over" choice is injected if reaction was positive.
     */
    public List<SceneData.ChoiceData> buildEyeContactChoices() {
        List<SceneData.ChoiceData> choices = new ArrayList<>();
        for (String id : state.currentBarNpcs) {
            NpcData n = npcs.get(id);
            if (n == null) continue;
            SceneData.ChoiceData c = new SceneData.ChoiceData();
            c.text         = "Catch " + n.name + "'s eye.";
            c.slut_rep_req = 0;
            c.result_text  = buildEyeContactResult(n);
            // c.stat_changes = buildEyeContactStats(n); // method removed
            choices.add(c);
        }
        return choices;
    }

    /**
     * Generates "Wave [Name] over" choices for NPCs who reacted positively.
     * Injected into bar_night alongside eye-contact choices.
     * Sets currentApproachingNpc and routes to bar_npc_approach scene.
     */
    public List<SceneData.ChoiceData> buildWaveOverChoices() {
        // For now, all NPCs in bar can be waved over after eye contact
        // Future: track per-NPC interest state
        List<SceneData.ChoiceData> choices = new ArrayList<>();
        for (String id : state.currentBarNpcs) {
            NpcData n = npcs.get(id);
            if (n == null) continue;
            SceneData.ChoiceData c = new SceneData.ChoiceData();
            c.text = "Wave " + n.name + " over.";
            c.slut_rep_req = 0;
            c.next = "bar_npc_approach";
            // stat_changes will set the approaching NPC via a special token
            // Engine reads currentApproachingNpc before loading bar_npc_approach
            c.stat_changes = new java.util.LinkedHashMap<>();
            // Tag which NPC is approaching via a side-effect in applyChoice
            // We store the NPC id in a temporary field the engine reads
            c.add_traits = java.util.Collections.singletonList("_bar_approach_" + id);
            choices.add(c);
        }
        return choices;
    }

    /**
     * Builds the approach scene text for the NPC currently set in
     * state.currentApproachingNpc. Called via {bar_approach_text} token.
     */
    public String buildApproachText() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        if (n == null) return "Someone comes over and says hi.";
        return npcApproachLine(n);
    }

    private String npcApproachLine(NpcData n) {
        // Check mod text pool for approach lines for this NPC personality
        String poolName = "bar.npc_approach." + getNpcPersonalityKey(n);
        String modResult = pickFromPool(poolName, buildMcTraitSet());
        if (modResult != null && !modResult.isEmpty()) return modResult;

        String they = "MALE".equalsIgnoreCase(n.type) ? "{npc_He}" : "{npc_He}";
        String them = "MALE".equalsIgnoreCase(n.type) ? "{npc_him}" : "{npc_him}";
        String his  = "MALE".equalsIgnoreCase(n.type) ? "{npc_his}" : "{npc_him}";

        boolean mcBouncing    = state.hasTrait("bounce_prone_4") || state.hasTrait("bounce_prone_5")
                             || state.hasTrait("bounce_prone_6") || state.hasTrait("bounce_prone_7");
        boolean mcNipping     = state.hasTrait("pierced_nipping_prominent") || state.hasTrait("nipping");
        boolean mcOffShoulder = state.hasTrait("off_shoulder_flash_risk");
        boolean mcHeels       = state.hasTrait("wearing_high_heels");
        boolean mcCamelToe    = state.hasTrait("camel_toe");
        boolean mcDrunk       = state.drunk >= 11;
        boolean mcBlackout    = state.drunk >= 15;

        // Sleazy — reacts to clothing first, drunk state second
        if (hasTrait(n, "Sleazy")) {
            if (mcCamelToe)
                return "{npc_His} eyes drop straight to your waist before {npc_he} even speaks.\n\n"
                     + "\"Nice outfit… really shows everything off, doesn't it?\"";
            if (mcBouncing)
                return "{npc_His} eyes drop straight to your chest before {npc_he} even speaks.\n\n"
                     + "\"Goddamn… those are working overtime tonight, huh?\"";
            if (mcNipping)
                return "{npc_His} eyes go there immediately. {npc_He} grins.\n\n"
                     + "\"Shit, you cold or just happy to see me?\"";
            if (mcOffShoulder)
                return "{npc_His} gaze goes to the neckline first.\n\n"
                     + "\"That top's fighting for its life. You gonna let it win all night?\"";
            if (mcHeels)
                return "She starts at the heels and takes {npc_his} time coming up.\n\n"
                     + "\"Those heels are doing the lord's work. Legs look incredible.\"";
            if (mcBlackout)
                return "She moves closer than {npc_he} should. {npc_He}'s read {npc_him} state and {npc_he} knows it.\n\n"
                     + "\"C'mon… you're fucked up enough that you won't remember this anyway, right?\"\n\n"
                     + "The words hit like ice water even through the haze.";
            if (mcDrunk)
                return "She moves a little closer than {npc_he} would have otherwise. {npc_His} smile changes.\n\n"
                     + "\"Hey… you're looking good tonight. Real good. Let me get you something.\"";
            return "{npc_His} eyes drop before {npc_he} says anything.\n\n"
                 + "\"Hey… you're looking good tonight. Real good.\"";
        }

        // Jerk
        if (hasTrait(n, "Jerk")) {
            if (state.slut_rep >= 20)
                return n.name + " leans in with an assumption {npc_he} hasn't earned.\n\n"
                     + "\"Heard you don't waste time with small talk. That true?\"";
            return n.name + " leans in with a smirk that's half compliment, half insult.\n\n"
                 + "\"Wow. Didn't expect to see someone actually worth talking to in here.\"";
        }

        // Shy
        if (hasTrait(n, "Shy"))
            return n.name + " shifts " + his + " weight, hands fidgeting with " + his + " glass.\n\n"
                 + "\"Uh… hi. Sorry if this is weird. I saw you looking and… figured I'd say hi?\"";

        // Boring
        if (hasTrait(n, "Boring"))
            return n.name + " gives a flat, generic smile.\n\n"
                 + "\"So… do you come here often?\"";

        // Magnetic
        if (hasTrait(n, "Magnetic"))
            return n.name + " doesn't rush it. Just arrives, lets the silence sit for a beat.\n\n"
                 + "\"Couldn't help noticing you.\"";

        // Engaging
        if (hasTrait(n, "Engaging"))
            return n.name + " smiles — warm, no agenda visible.\n\n"
                 + "\"Hey… mind if I grab this seat? Night's been pretty quiet so far.\"";

        // Self_Assured / Confrontational
        if (hasTrait(n, "Self_Assured"))
            return n.name + " steps up directly, voice calm.\n\n"
                 + "\"I liked your vibe from across the room. Figured I'd come say hi instead of wondering.\"";

        if (hasTrait(n, "Confrontational"))
            return n.name + " holds the eye contact the whole way over, then stops.\n\n"
                 + "\"Alright. You've been staring. I'm staring back. What's the move?\"";

        // Outgoing / Nightlife_Lover
        if (hasTrait(n, "Outgoing") || hasTrait(n, "Nightlife_Lover"))
            return n.name + " grins like " + they.toLowerCase() + "'s already had three conversations tonight.\n\n"
                 + "\"Hi! I swear I've talked to half this bar already. You looked like the only sane one left.\"";

        // Streetwise
        if (hasTrait(n, "Streetwise"))
            return n.name + " clocked the room before crossing it.\n\n"
                 + "\"Been watching you dodge three different people tonight. Figured I'd try my luck anyway.\"";

        // Alcoholic
        if (hasTrait(n, "Alcoholic"))
            return n.name + " is already on drink four or five and it shows. "
                 + they + " leans in a little too close.\n\n"
                 + "\"Hey! You look like you could use some company.\"";

        // Default
        return n.name + " stops a comfortable distance away, drink in hand, and gives you a small nod.\n\n"
             + "\"Mind if I sit?\"";
    }

    /**
     * Builds MC response choices for the bar_npc_approach scene.
     * Gated by MC traits and NPC type.
     */
    public List<SceneData.ChoiceData> buildMcResponseChoices() {
        NpcData n = npcs.get(state.currentApproachingNpc);
        List<SceneData.ChoiceData> choices = new ArrayList<>();
        if (n == null) return choices;

        boolean npcSleazy = hasTrait(n, "Sleazy");
        boolean npcJerk   = hasTrait(n, "Jerk");
        boolean npcNeg    = npcSleazy || npcJerk;
        boolean mcDrunk15 = state.drunk >= 15;   // 15 = blackout

        // ── Always available ──────────────────────────────────────────
        choices.add(warmResponse(n));
        choices.add(coolResponse(n));
        choices.add(shutDownResponse(n));

        // ── Personality gated ─────────────────────────────────────────
        if (state.hasTrait("outgoing"))
            choices.add(outgoingResponse(n));

        if (state.hasTrait("self_assured"))
            choices.add(selfAssuredResponse(n));

        if ((state.hasTrait("confrontational")) && npcNeg)
            choices.add(confrontationalResponse(n));

        if (state.hasTrait("conflict_avoidant") && npcNeg)
            choices.add(conflictAvoidantResponse(n));

        if (state.hasTrait("prideful") && npcJerk)
            choices.add(pridefulResponse(n));

        if ((state.hasTrait("fragile_ego")) && !npcNeg)
            choices.add(fragileEgoResponse(n));

        if (state.hasTrait("provocative_sexual") && !npcNeg)
            choices.add(provocativeResponse(n));

        // ── Drunk responses (6-10 tipsy, 11+ drunk, 15 blackout) ─────
        if (state.drunk >= 6 && state.drunk <= 10)
            choices.add(tipsyResponse(n));

        if (state.drunk >= 11 && state.drunk <= 14) {
            choices.add(drunkResponse(n));
            // Clothing-specific drunk choices
            if (state.hasTrait("bounce_prone_4") || state.hasTrait("bounce_prone_5")
             || state.hasTrait("bounce_prone_6") || state.hasTrait("bounce_prone_7"))
                choices.add(drunkBounceResponse(n));
            if (state.hasTrait("pierced_nipping_prominent") || state.hasTrait("nipping"))
                choices.add(drunkNippingResponse(n));
            if (state.hasTrait("off_shoulder_flash_risk"))
                choices.add(drunkOffShoulderResponse(n));
            if (state.hasTrait("camel_toe"))
                choices.add(drunkCamelToeResponse(n));
            if (state.hasTrait("wearing_high_heels"))
                choices.add(drunkHeelsResponse(n));
        }

        if (mcDrunk15) {
            choices.add(drunkVulnerableResponse(n));
            if (npcSleazy) {
                // Clothing-specific blackout × Sleazy variants
                if (state.hasTrait("bounce_prone_4") || state.hasTrait("bounce_prone_5")
                 || state.hasTrait("bounce_prone_6") || state.hasTrait("bounce_prone_7"))
                    choices.add(blackoutSleazyBounce(n));
                else if (state.hasTrait("pierced_nipping_prominent") || state.hasTrait("nipping"))
                    choices.add(blackoutSleazyNipping(n));
                else if (state.hasTrait("off_shoulder_flash_risk"))
                    choices.add(blackoutSleazyOffShoulder(n));
                else if (state.hasTrait("camel_toe"))
                    choices.add(blackoutSleazyCamelToe(n));
                else if (state.hasTrait("wearing_high_heels"))
                    choices.add(blackoutSleazyHeels(n));
                else
                    choices.add(drunkVulnerableResponse(n));
            }
        }

        return choices;
    }

    private String buildEyeContactResult(NpcData n) {
        // Check mod pool for eye contact outcome for this NPC personality
        String eyePool  = "bar.eye_contact." + getNpcPersonalityKey(n);
        String modEye   = pickFromPool(eyePool, buildMcTraitSet());
        if (modEye != null && !modEye.isEmpty()) return modEye;

        // MC trait modifiers layered over NPC personality
        boolean mcShy      = state.hasTrait("shy");
        boolean mcOutgoing = state.hasTrait("outgoing");
        boolean mcMagnetic = state.hasTrait("magnetic");

        String npcReaction = npcEyeContactReaction(n, mcShy, mcOutgoing, mcMagnetic);
        String mcResponse  = mcEyeContactFeel(n);

        return npcReaction + "\n\n" + mcResponse;
    }

    private String npcEyeContactReaction(NpcData n, boolean shy, boolean outgoing, boolean magnetic) {
        if (hasTrait(n, "Magnetic") || hasTrait(n, "Engaging")) {
            if (magnetic) return n.name + " meets your eyes and holds them a beat longer than expected. Like recognizes like.";
            return n.name + " looks up and catches your gaze with an ease that suggests this happens a lot.";
        }
        if (hasTrait(n, "Shy")) {
            if (outgoing) return n.name + " glances over, startles slightly when they realize you're looking, and looks away with a small smile.";
            return n.name + " catches your eye for a second, then finds something very interesting to look at on the bar.";
        }
        if (hasTrait(n, "Confrontational")) {
            return n.name + " holds the eye contact a beat longer than comfortable. Not hostile — just not the first to look away.";
        }
        switch (n.personality.toUpperCase()) {
            case "WARM":
                if (shy) return n.name + " notices you looking and offers a small, easy smile. No pressure behind it.";
                return n.name + " looks over and smiles — open, unhurried. Lifts their glass slightly.";
            case "COLD":
                return n.name + " glances your way, registers the eye contact, and looks back to whatever they were doing.";
            case "CARING":
                return n.name + " looks over with a warm expression, like they were already thinking about saying hello.";
            default:
                return n.name + " meets your eyes briefly. A small nod. Neutral but not unwelcoming.";
        }
    }

    private String mcEyeContactFeel(NpcData n) {
        if (state.hasTrait("shy"))     return "You look away first. Probably fine.";
        if (state.hasTrait("outgoing")) return "You hold it long enough to make the point, then move on.";
        if (state.hasTrait("magnetic")) return "You look away when you're ready to. Which is not immediately.";
        return "You hold the look for a moment, then glance away.";
    }

    private SceneData.ChoiceData warmResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Smile and give an easy, friendly reply.";
        c.slut_rep_req = 0;
        c.result_text = "You smile and give " + n.name + " an easy, friendly reply.\n\n"
                      + "The conversation flows lightly for a moment. "
                      + n.name + " seems encouraged but keeps it short.";
        c.stat_changes = stats("happiness", 3, "confidence", 2, "npc_liking", 5);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData coolResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Polite but minimal. Not feeding the fire.";
        c.slut_rep_req = 0;
        c.result_text = "You give a polite but minimal answer.\n\n"
                      + n.name + " gets the hint and makes a graceful exit after a beat.";
        c.stat_changes = stats("npc_liking", 2);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData shutDownResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "\"Not tonight, thanks.\" Clear and final.";
        c.slut_rep_req = 0;
        c.result_text = "You look " + n.name + " in the eye.\n\n"
                      + "\"Not tonight, thanks.\"\n\n"
                      + n.name + " nods once and walks away without pushing.";
        c.stat_changes = stats("confidence", 2);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData outgoingResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Crack a light joke and turn the whole opener around.";
        c.requires_traits = java.util.Collections.singletonList("Outgoing");
        c.slut_rep_req = 0;
        c.result_text = "You crack a light joke that turns the whole opener around.\n\n"
                      + n.name + " laughs — genuinely disarmed.";
        c.stat_changes = stats("happiness", 5, "confidence", 3, "npc_liking", 8);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData selfAssuredResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Give the real answer. No performance.";
        c.requires_traits = java.util.Collections.singletonList("Self_Assured");
        c.slut_rep_req = 0;
        c.result_text = "You look at " + n.name + " and give the actual answer "
                      + "to whatever they opened with. No performance.\n\n"
                      + n.name + " respects the directness and doesn't linger.";
        c.stat_changes = stats("confidence", 4, "npc_liking", 5);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData confrontationalResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "\"You know that line's not cute, right?\"";
        c.requires_traits = java.util.Collections.singletonList("Confrontational");
        c.slut_rep_req = 0;
        c.result_text = "\"You know that line's not cute, right?\"\n\n"
                      + n.name + " blinks. Then backs off with a half-laugh.\n\n"
                      + "\"Fair enough.\"";
        c.stat_changes = stats("confidence", 5, "willpower", 3);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData conflictAvoidantResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Smile awkwardly. Give a gentle \"I'm good, thanks.\"";
        c.requires_traits = java.util.Collections.singletonList("Conflict_Avoidant");
        c.slut_rep_req = 0;
        c.result_text = "You smile awkwardly and give a gentle deflection even though "
                      + "you want to say something sharper.\n\n"
                      + n.name + " takes it. You'll feel a little bad about that later.";
        c.stat_changes = stats("happiness", -3, "willpower", -2);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData pridefulResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "\"If that's your best opener, you might want to work on it.\"";
        c.requires_traits = java.util.Collections.singletonList("Prideful");
        c.slut_rep_req = 0;
        c.result_text = "\"If that's your best opener, you might want to work on it.\"\n\n"
                      + n.name + " actually looks surprised.\n\n"
                      + "You keep the smile sweet.";
        c.stat_changes = stats("confidence", 5, "thrills", 4);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData fragileEgoResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Answer with more enthusiasm than you meant to.";
        c.requires_traits = java.util.Collections.singletonList("Fragile_Ego");
        c.slut_rep_req = 0;
        c.result_text = n.name + "'s attention lands somewhere warm and suddenly important.\n\n"
                      + "You answer with more enthusiasm than you meant to.\n\n"
                      + "You catch yourself a second too late.";
        c.stat_changes = stats("happiness", 4, "confidence", -1, "npc_liking", 10);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData provocativeResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Let your reply carry an unmistakable invitation.";
        c.requires_traits = java.util.Collections.singletonList("Provocative_Sexual");
        c.slut_rep_req = 0;
        c.result_text = "You let your reply carry an unmistakable invitation. Not subtle.\n\n"
                      + n.name + "'s eyes light up. The vibe shifts instantly.";
        c.stat_changes = stats("thrills", 8, "arousal", 6, "npc_liking", 8);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData drunkResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Say something more honest than you meant to.";
        c.slut_rep_req = 0;
        c.result_text = "The words come out a little looser than sober-you would allow.\n\n"
                      + "Not embarrassing — just more real than intended.\n\n"
                      + n.name + " reacts with surprise and interest.";
        c.stat_changes = stats("arousal", 3, "npc_liking", 6);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData drunkVulnerableResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Smile and nod. The words aren't quite tracking.";
        c.slut_rep_req = 0;
        c.result_text = "You smile and nod at something.\n\n"
                      + "The conversation isn't fully landing but you're going along with it anyway.\n\n"
                      + n.name + " moves a little closer.\n\n"
                      + "This is the version of this you won't fully remember tomorrow.";
        c.stat_changes = stats("arousal", 8, "willpower", -5, "npc_liking", 5);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData tipsyResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Say something a little more open than usual.";
        c.slut_rep_req = 0;
        c.result_text = "The words slip out a little easier than they would sober.\n\n"
                      + "Not embarrassing — just more relaxed than you normally let yourself be.\n\n"
                      + n.name + " reacts with a small smile, clearly enjoying the shift.";
        c.stat_changes = stats("happiness", 3, "arousal", 2, "npc_liking", 4);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData drunkBounceResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Make a playful comment about how much you're moving tonight.";
        c.slut_rep_req = 0;
        c.result_text = "The buzz makes the way your {breast_desc} move when you shift feel "
                      + "impossible to ignore. You laugh softly and make a light, cheeky comment about it.\n\n"
                      + n.name + " grins. The moment feels fun and a little charged.";
        c.stat_changes = stats("thrills", 8, "arousal", 5, "npc_liking", 6);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData drunkNippingResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Make a half-teasing remark about the cold — or the buzz.";
        c.slut_rep_req = 0;
        c.result_text = "The alcohol makes you hyper-aware of how obvious your nipples are.\n\n"
                      + "You make a candid, half-teasing remark — blaming the cold or the drink.\n\n"
                      + n.name + " glances exactly where you expected and smiles.";
        c.stat_changes = stats("thrills", 7, "arousal", 5, "npc_liking", 6);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData drunkOffShoulderResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Joke that the top has been fighting you all night.";
        c.slut_rep_req = 0;
        c.result_text = "Your off-the-shoulder top keeps threatening to slip.\n\n"
                      + "You laugh and say something about how it's \"barely behaving tonight.\"\n\n"
                      + n.name + " watches the neckline with open interest.";
        c.stat_changes = stats("thrills", 7, "arousal", 4, "npc_liking", 5);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData drunkCamelToeResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Make a candid joke that the outfit is working overtime.";
        c.slut_rep_req = 0;
        c.result_text = "The fit is very obvious right now and the drink makes it harder to pretend otherwise.\n\n"
                      + "You make a candid, slightly embarrassed joke that it's \"working overtime.\"\n\n"
                      + n.name + " chuckles, not even pretending to be subtle.";
        c.stat_changes = stats("thrills", 6, "arousal", 4, "npc_liking", 5);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData drunkHeelsResponse(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Joke that the heels are doing the lord's work tonight.";
        c.slut_rep_req = 0;
        c.result_text = "The heels make your legs feel long and your walk a little unsteady.\n\n"
                      + "You joke that they're \"doing the lord's work tonight.\"\n\n"
                      + n.name + " glances down at your legs with clear appreciation.";
        c.stat_changes = stats("thrills", 6, "arousal", 3, "npc_liking", 5);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData blackoutSleazyBounce(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Register {npc_him} staring. The words reach you slow.";
        c.slut_rep_req = 0;
        c.result_text = "She leans in, eyes locked on your {breast_desc}.\n\n"
                      + "\"Fuck… those are really moving tonight…\"\n\n"
                      + "The words reach you slowly, like they're underwater. "
                      + "You feel the attention but everything is soft and distant. "
                      + "You manage a weak, slurred sound that doesn't quite say no.";
        c.stat_changes = stats("arousal", 6, "willpower", -5, "npc_liking", 3);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData blackoutSleazyNipping(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Register {npc_him} looking. Something feels off but it's far away.";
        c.slut_rep_req = 0;
        c.result_text = "{npc_His} gaze drops straight to your chest.\n\n"
                      + "\"Damn… look at those. You cold or just really enjoying yourself?\"\n\n"
                      + "The comment lands muffled. You register it as uncomfortable but "
                      + "the buzz dulls the edge. You try to say something "
                      + "but it comes out soft and unclear.";
        c.stat_changes = stats("arousal", 5, "willpower", -4, "npc_liking", 3);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData blackoutSleazyOffShoulder(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Feel the neckline shifting. The room is tilting.";
        c.slut_rep_req = 0;
        c.result_text = "{npc_He} stares at the slipping neckline.\n\n"
                      + "\"That top's barely hanging on… you gonna let it win?\"\n\n"
                      + "The words feel distant and slow. You know it's too much but "
                      + "everything is hazy. You shift weakly but the motion only "
                      + "makes the fabric move more.";
        c.stat_changes = stats("arousal", 5, "willpower", -4, "npc_liking", 3);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData blackoutSleazyCamelToe(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Feel exposed. Your hands are too slow to do anything about it.";
        c.slut_rep_req = 0;
        c.result_text = "{npc_His} eyes go straight down.\n\n"
                      + "\"Shit… that's a hell of a view from here.\"\n\n"
                      + "The words sink in slowly through the fog. You feel exposed "
                      + "but the blackout makes it feel far away and muted. "
                      + "You try to pull at the fabric but your hands are clumsy.";
        c.stat_changes = stats("arousal", 4, "willpower", -5, "npc_liking", 2);
        c.next = "bar_night";
        return c;
    }

    private SceneData.ChoiceData blackoutSleazyHeels(NpcData n) {
        SceneData.ChoiceData c = new SceneData.ChoiceData();
        c.text = "Feel {npc_him} looking you up and down. Everything is slow.";
        c.slut_rep_req = 0;
        c.result_text = "She looks you up and down slowly.\n\n"
                      + "\"Those heels… and the way you're walking in them… fuck.\"\n\n"
                      + "The comment drifts in late and soft. You know it's too much "
                      + "but the room is tilting and your thoughts are too heavy "
                      + "to push back properly.";
        c.stat_changes = stats("arousal", 4, "willpower", -4, "npc_liking", 2);
        c.next = "bar_night";
        return c;
    }

    private Map<String, Integer> stats(Object... pairs) {
        Map<String, Integer> m = new java.util.LinkedHashMap<>();
        for (int i = 0; i < pairs.length - 1; i += 2)
            m.put(pairs[i].toString(), (Integer) pairs[i + 1]);
        return m;
    }
}
