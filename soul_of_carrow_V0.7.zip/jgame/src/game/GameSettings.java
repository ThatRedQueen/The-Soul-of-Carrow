package game;

/**
 * All user-configurable settings. One instance shared across the game.
 * Saved to settings.dat. Loaded before anything else.
 */
public class GameSettings {

    // ── Visibility mode ───────────────────────────────────────────────────────
    public enum Visibility { NORMAL, PLAYER, DEV }
    public Visibility visibility = Visibility.NORMAL;

    // ── Text ──────────────────────────────────────────────────────────────────
    /** Scene text font size. Range 12–26. */
    public int    textSize     = 16;
    /** Choice button font size. Range 11–22. */
    public int    choiceSize   = 14;
    /**
     * Font family for scene text. Must be available on the system.
     * Defaults to "SansSerif" (system sans-serif fallback).
     * Options: "SansSerif", "Serif", "Monospaced", or any installed font name.
     */
    public String fontFamily   = "SansSerif";
    /** Font family for choice buttons — usually matches fontFamily. */
    public String choiceFont   = "SansSerif";

    // ── Difficulty ────────────────────────────────────────────────────────────
    /**
     * Slut rep gain multiplier. 1.0 = normal, 2.0 = easy, 4.0 = ultra.
     * Applied in GameState.changeStat() for "slut_rep" key.
     */
    public float slutRepMultiplier = 1.0f;
    /** When ON: clothing lost in scenes is auto-repurchased overnight at store price. */
    public boolean autoRebuyClothing = false;

    /**
     * Willpower drain multiplier. 1.0 = normal, 0.5 = half drain (easier).
     * Applied to negative willpower changes.
     */
    public float willpowerDrainMult = 1.0f;

    /**
     * Stress gain multiplier. 1.0 = normal, 0.5 = half stress (easier).
     * Applied to positive stress changes.
     */
    public float stressMult = 1.0f;

    // ── Key bindings ──────────────────────────────────────────────────────────
    public int keyEscape      = java.awt.event.KeyEvent.VK_ESCAPE;
    public int keyOutfit       = java.awt.event.KeyEvent.VK_O;
    public int keySave         = java.awt.event.KeyEvent.VK_S;    // Ctrl+S
    public int keySettings     = java.awt.event.KeyEvent.VK_COMMA; // Ctrl+,

    // ── Accessibility ─────────────────────────────────────────────────────────
    public boolean highContrast    = false;
    public boolean reduceAnimations = false;

    // ── Display ───────────────────────────────────────────────────────────────
    public boolean showCycleInHeader = true;
    public boolean showMoneyInHeader = true;

    // ── Content filters ───────────────────────────────────────────────────────
    /**
     * When false, scenes tagged `requires_sa_enabled: true` are suppressed entirely —
     * both as triggers and as individual choices. SA arcs cannot fire regardless of
     * any other game state. Enabled by default; the player can turn it off at any time.
     *
     * This setting persists across saves. It can be changed mid-game with immediate effect.
     */
    public boolean saContentEnabled   = true;

    /**
     * When false, content tagged `requires_violence: true` is suppressed.
     * Placeholder for future arc content.
     */
    public boolean violenceEnabled    = true;

    // ── Convenience ───────────────────────────────────────────────────────────

    public boolean isNormal()  { return visibility == Visibility.NORMAL; }
    public boolean isPlayer()  { return visibility == Visibility.PLAYER || visibility == Visibility.DEV; }
    public boolean isDev()     { return visibility == Visibility.DEV; }

    /** Apply slut_rep multiplier to a raw gain value. */
    public int applySlutRepMult(int raw) {
        if (slutRepMultiplier == 1.0f) return raw;
        return (int) Math.round(raw * slutRepMultiplier);
    }

    /** Apply willpower drain multiplier (only for negative WP changes). */
    public int applyWPDrain(int raw) {
        if (raw >= 0 || willpowerDrainMult == 1.0f) return raw;
        return (int) Math.round(raw * willpowerDrainMult);
    }

    /** Apply stress multiplier (only for positive stress). */
    public int applyStress(int raw) {
        if (raw <= 0 || stressMult == 1.0f) return raw;
        return (int) Math.round(raw * stressMult);
    }

    /** Human-readable visibility label. */
    public String visibilityLabel() {
        switch (visibility) {
            case PLAYER: return "Player";
            case DEV:    return "Dev";
            default:     return "Normal";
        }
    }

    /** Returns a Font for scene body text using current settings. */
    public java.awt.Font sceneFont() {
        return new java.awt.Font(fontFamily, java.awt.Font.PLAIN, textSize);
    }

    /** Returns a Font for choice buttons using current settings. */
    public java.awt.Font buttonFont() {
        return new java.awt.Font(choiceFont, java.awt.Font.PLAIN, choiceSize);
    }

    public String slutRepLabel() {
        if (slutRepMultiplier >= 4.0f) return "×4 Ultra Easy";
        if (slutRepMultiplier >= 2.0f) return "×2 Easy";
        return "×1 Normal";
    }
}
