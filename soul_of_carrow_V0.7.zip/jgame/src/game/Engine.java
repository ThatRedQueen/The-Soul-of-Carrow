package game;

import game.data.*;
import java.util.*;

public class Engine {
    private final GameState      state;
    private final SceneLoader    scenes;
    private final NpcLoader      npcs;
    private final ClothingLoader clothes;
    private final BarSystem      bar;
    private       GameSettings   settings = null;
    private final CafeSystem     cafe;
    private final SexSystem      sex;
    private final HairSystem     hair;
    private final JobConversationSystem jobConvo;

    public Engine(GameState state, SceneLoader scenes, NpcLoader npcs, ClothingLoader clothes) {
        this.state    = state;
        this.scenes   = scenes;
        this.npcs     = npcs;
        this.clothes  = clothes;
        this.bar      = new BarSystem(state, npcs);
        this.sex      = new SexSystem(state, npcs);
        this.cafe     = new CafeSystem(state);
        this.hair     = new HairSystem(state);
        this.jobConvo = new JobConversationSystem(npcs, state);
        bar.registerTokens(tokenHandlers);
        sex.registerTokens(tokenHandlers);
        cafe.registerTokens(tokenHandlers);
    }

    /** Call after construction to give Engine access to job data for bar filtering. */
    /** Inject settings so Engine can check content filters. */
    public void setSettings(GameSettings s) { this.settings = s; }

    /** Pass mod text pools to BarSystem and CafeSystem. */
    public void setTextPoolRegistry(TextPoolRegistry pools) {
        if (bar  != null) bar.setTextPoolRegistry(pools);
        if (cafe != null) cafe.setTextPoolRegistry(pools);
    }

    public void setJobs(game.JobLoader jobs) {
        this.bar.setJobs(jobs);
    }

    public SceneData loadCurrent() {
        if (state.currentScene == null || state.currentScene.isEmpty()) return null;
        return scenes.load(state.currentScene, "loadCurrent");
    }

    public SceneData loadScene(String id) {
        return scenes.load(id, "loadScene");
    }

    /** Returns null if not found — for optional checks. */
    public SceneData tryLoadScene(String id) {
        return scenes.tryLoad(id);
    }

    /** True if a scene with this ID exists in the loader. */
    public boolean sceneExists(String id) {
        return scenes.exists(id);
    }

    public String resolveText(SceneData scene) {
        if (scene == null) return "";
        try {
            return resolveTextInternal(scene);
        } catch (Exception e) {
            CrashReporter.reportError("resolveText failed for scene: " + scene.id, e);
            return "[Display error — see crash report]";
        }
    }

    private String resolveTextInternal(SceneData scene) {
        Set<String> dyn = state.computeDynamicTraits(clothes);

        // ── Collect ALL matching non-default variants ────────────────────
        // Then pick one at random so repeat scenes show different text
        // each visit when multiple conditions are true simultaneously.
        java.util.List<String> matches = new java.util.ArrayList<>();
        for (SceneData.TextVariant v : scene.text_variants) {
            if ("default".equalsIgnoreCase(v.requires_trait) && v.requires_flag.isEmpty()) continue;
            boolean flagMatch  = !v.requires_flag.isEmpty() && state.getBodyFlag(v.requires_flag);
            boolean traitMatch = v.requires_flag.isEmpty()
                && !v.requires_trait.isEmpty()
                && (state.hasTrait(v.requires_trait.toLowerCase())
                    || dyn.contains(v.requires_trait.toLowerCase()));
            // Check NPC trait of the current approaching NPC
            boolean npcTraitMatch = v.requires_flag.isEmpty()
                && v.requires_trait.equals("default")
                && !v.requires_npc_trait.isEmpty()
                && !state.currentApproachingNpc.isEmpty()
                && npcs.hasTrait(state.currentApproachingNpc, v.requires_npc_trait);
            if (flagMatch || traitMatch || npcTraitMatch) {
                matches.add(v.text.trim());
            }
        }
        if (!matches.isEmpty()) {
            String picked = matches.get((int)(Math.random() * matches.size()));
            return applyTextVars(picked);
        }

        // ── Fallback: default variant, then base scene text ──────────────
        for (SceneData.TextVariant v : scene.text_variants)
            if ("default".equalsIgnoreCase(v.requires_trait)) return applyTextVars(v.text.trim());
        return scene.text != null ? applyTextVars(scene.text.trim()) : "";
    } // end resolveTextInternal

    /**
     * Replaces dynamic text tokens with runtime values.
     *
     * Supported tokens:
     *   {breast_desc}  — size-appropriate breast descriptor, e.g. "soft breasts"
     *                    Rotates through a pool per cup size (varies by day).
     *
     * Add new tokens here as the system grows.
     */
    private String applyTextVars(String text) {
        if (text == null) return "";
        if (text.contains("{breast_desc}"))
            text = text.replace("{breast_desc}", state.breastDescriptor());
        // ── Dynamic text tokens — bar, café, mall subsystems ─────────────────
        for (java.util.Map.Entry<String,java.util.function.Supplier<String>> e
                : tokenHandlers.entrySet()) {
            if (text.contains(e.getKey()))
                text = text.replace(e.getKey(), applyTextVars(e.getValue().get()));
        }
        if (text.contains("{hair_breeze_text}"))
            text = text.replace("{hair_breeze_text}", hair.buildHairBreezeText());
        if (text.contains("{home_furnish_prompt}"))
            text = text.replace("{home_furnish_prompt}", buildHomeFurnishPrompt());
        if (text.contains("{npc_job_text}"))
            text = text.replace("{npc_job_text}", jobConvo.buildJobText());
        // {npc_hair_breeze_text} requires explicit args — resolved via builder call in YAML
        // Use: scene result_text calling {npc_hair_breeze_text} with hardcoded NPC hair color/type
        if (text.contains("{npc_name}") || text.contains("{npc_he}") || text.contains("{npc_him}")
         || text.contains("{npc_his}") || text.contains("{npc_He}") || text.contains("{npc_Him}") || text.contains("{npc_They}")) {
            // Prefer currently approaching NPC, fall back to dating partner
            String activeNpcId = state.currentApproachingNpc;
            if (activeNpcId == null || activeNpcId.isEmpty()) {
                // Find the dating partner (first match)
                for (java.util.Map.Entry<String,String> e : state.npcMemory.entrySet()) {
                    if (e.getKey().endsWith(":relationship_status") && state.isDating(e.getKey().replace(":relationship_status",""))) {
                        activeNpcId = e.getKey().replace(":relationship_status","");
                        break;
                    }
                }
            }
            game.data.NpcData npc = npcs.get(activeNpcId);
            if (npc != null) {
                boolean male = "MALE".equalsIgnoreCase(npc.type);
                text = text.replace("{npc_name}", npc.name);
                text = text.replace("{npc_he}",  male ? "he"  : "she");
                text = text.replace("{npc_He}",  male ? "He"  : "She");
                text = text.replace("{npc_They}",  male ? "He"  : "She");
                text = text.replace("{npc_him}",  male ? "him"  : "her");
                text = text.replace("{npc_Him}",  male ? "Him"  : "Her");
                text = text.replace("{npc_his}",  male ? "his"  : "her");
                text = text.replace("{npc_His}",  male ? "His"  : "Her");
            }
        }
        // ── Clothing tokens ─────────────────────────────────────────────────────
        if (text.contains("{clothing_")) {
            game.data.ClothingData cu = clothes.get(state.outfitUpper);
            game.data.ClothingData cl = clothes.get(state.outfitLower);
            game.data.ClothingData cb = clothes.get(state.outfitBra);
            game.data.ClothingData co = clothes.get(state.outfitOvercoat);
            game.data.ClothingData cs = clothes.get(state.outfitShoes);
            game.data.ClothingData cw = clothes.get(state.outfitUnderwear);
            text = text.replace("{clothing_upper_name}",     cu!=null&&!cu.name.isEmpty()  ? cu.name  : "top");
            text = text.replace("{clothing_upper_color}",    cu!=null&&!cu.color.isEmpty() ? cu.color : "");
            text = text.replace("{clothing_upper_full}",     cu!=null ? (cu.color.isEmpty()?"":cu.color+" ")+cu.name : "top");
            // Relationship + child tokens
            if (text.contains("{relationship_months}")) {
                String pid = state.getAnyDatingNpcId();
                int months = pid.isEmpty() ? 0 : state.monthsWithNpc(pid);
                text = text.replace("{relationship_months}", String.valueOf(months));
            }
            if (text.contains("{child_count}")) {
                text = text.replace("{child_count}", String.valueOf(state.childCount()));
            }
            if (text.contains("{oldest_child_age}")) {
                text = text.replace("{oldest_child_age}", String.valueOf(state.oldestChildAge()));
            }
            // NPC sex action token
            if (text.contains("{npc_sex_action}")) {
                String a = state.sexState.lastNpcAction;
                String desc = "";
                if ("bra_off".equals(a))        desc = "{npc_name} unclasps your bra.";
                else if ("shirt_lifted".equals(a)) desc = "{npc_name} lifts your shirt.";
                else if ("shirt_off".equals(a)) desc = "{npc_name} pulls your shirt off.";
                else if ("bottom_off".equals(a))   desc = "{npc_name} slides your trousers off.";
                else if ("underwear_off".equals(a)) desc = "{npc_name} removes your underwear.";
                else if ("skirt_hiked".equals(a))  desc = "{npc_name} hikes your skirt up.";
                text = text.replace("{npc_sex_action}", desc);
            }
            // Defense tool result tokens
            if (text.contains("{defense_result}")) {
                boolean hit = state.hasTrait("__defense_hit__");
                boolean miss = state.hasTrait("__defense_miss__");
                state.removeTrait("__defense_hit__");
                state.removeTrait("__defense_miss__");
                text = text.replace("{defense_result}", hit ? "hit" : "miss");
            }
            // Legal result tokens
            if (text.contains("{legal_result}")) {
                boolean win=state.hasTrait("__legal_win__"),miss=state.hasTrait("__legal_miss__");
                state.removeTrait("__legal_win__"); state.removeTrait("__legal_miss__");
                text=text.replace("{legal_result}", win?"win":"miss");
            }
            if (text.contains("{sa_suit_payout}"))
                text=text.replace("{sa_suit_payout}","$"+state.saSuitPayout);
            // Streaming tokens
            if (text.contains("{stream_followers}"))
                text = text.replace("{stream_followers}", String.valueOf(state.streamingFollowers));
            if (text.contains("{stream_weekly}"))
                text = text.replace("{stream_weekly}", "$" + state.streamingWeeklyIncome);
            if (text.contains("{gaming_skill}"))
                text = text.replace("{gaming_skill}", String.valueOf(state.gamingSkill));
            if (text.contains("{stream_gained}")) {
                String _g = "a few";
                for (String _tr : state.traits) {
                    if (_tr.startsWith("__stream_gained__:")) {
                        _g = _tr.replace("__stream_gained__:","");
                        state.removeTrait(_tr); break;
                    }
                }
                text = text.replace("{stream_gained}", _g);
            }
            // SlutFans tokens
            if (text.contains("{sf_followers}"))
                text = text.replace("{sf_followers}", String.valueOf(state.slutFansFollowers));
            if (text.contains("{sf_weekly_income}"))
                text = text.replace("{sf_weekly_income}", "$" + state.slutFansWeeklyIncome);
            if (text.contains("{sf_total_posts}"))
                text = text.replace("{sf_total_posts}", String.valueOf(state.slutFansTotalPosts));
            if (text.contains("{sf_days_inactive}"))
                text = text.replace("{sf_days_inactive}", String.valueOf(state.slutFansDaysSincePost));
            if (text.contains("{sf_content_tier}"))
                text = text.replace("{sf_content_tier}", String.valueOf(state.computeSlutFansTier()));
            if (text.contains("{sf_total_earned}"))
                text = text.replace("{sf_total_earned}", "$" + state.slutFansTotalEarned);
            if (text.contains("{sf_post_gained}")) {
                String _g = "a few";
                for (String _tr : state.traits) {
                    if (_tr.startsWith("__sf_post_gained__:")) {
                        _g = _tr.replace("__sf_post_gained__:","");
                        state.removeTrait(_tr); break;
                    }
                }
                text = text.replace("{sf_post_gained}", _g);
            }
            if (text.contains("{tax_filing_result_text}")) {
                String owedStr = state.getNpcMemory("__tax__","owed");
                int owed = 0;
                try { if (owedStr != null) owed = Integer.parseInt(owedStr); } catch (NumberFormatException ignored) {}
                StringBuilder taxSb = new StringBuilder();
                if (owed > 0) {
                    taxSb.append("Annual income filed: $").append(state.annualGrossEarned).append("\n\n");
                    taxSb.append("Tax withheld: $").append(state.annualTaxWithheld).append("\n\n");
                    taxSb.append("Additional tax owed: $").append(owed).append("\n\nYou pay the difference.");
                } else if (owed < 0) {
                    taxSb.append("Annual income filed: $").append(state.annualGrossEarned).append("\n\n");
                    taxSb.append("Tax withheld: $").append(state.annualTaxWithheld).append("\n\n");
                    taxSb.append("Refund: $").append(-owed).append("\n\nThey withheld more than they needed. It comes back.");
                } else {
                    taxSb.append("Annual income: $").append(state.annualGrossEarned).append("\n\nNothing owed. Nothing refunded. A wash.");
                }
                text = text.replace("{tax_filing_result_text}", taxSb.toString());
            }
            text = text.replace("{clothing_upper_desc}",     cu!=null && cu.description!=null && !cu.description.isEmpty() ? cu.description : (cu!=null ? cu.name : "top"));
            text = text.replace("{clothing_upper_nip}",      cu!=null && cu.isNipRisk() ? "⚠ nipping likely without bra" : "");
            text = text.replace("{clothing_lower_name}",     cl!=null&&!cl.name.isEmpty()  ? cl.name  : "bottoms");
            text = text.replace("{clothing_lower_color}",    cl!=null&&!cl.color.isEmpty() ? cl.color : "");
            text = text.replace("{clothing_lower_full}",     cl!=null ? (cl.color.isEmpty()?"":cl.color+" ")+cl.name : "bottoms");
            text = text.replace("{clothing_bra_name}",       cb!=null&&!cb.name.isEmpty()  ? cb.name  : "bra");
            text = text.replace("{clothing_bra_color}",      cb!=null&&!cb.color.isEmpty() ? cb.color : "");
            text = text.replace("{clothing_shoes_name}",     cs!=null&&!cs.name.isEmpty()  ? cs.name  : "shoes");
            text = text.replace("{clothing_shoes_color}",    cs!=null&&!cs.color.isEmpty() ? cs.color : "");
            text = text.replace("{clothing_outer_name}",     co!=null&&!co.name.isEmpty()  ? co.name  : "jacket");
            text = text.replace("{clothing_outer_color}",    co!=null&&!co.color.isEmpty() ? co.color : "");
            text = text.replace("{clothing_underwear_name}", cw!=null&&!cw.name.isEmpty()  ? cw.name  : "underwear");
            text = text.replace("{clothing_underwear_color}",cw!=null&&!cw.color.isEmpty() ? cw.color : "");
        }
        // ── Child name token ────────────────────────────────────────────────────
        if (text.contains("{child_name}")) {
            text = text.replace("{child_name}",
                state.childExists && !state.childName.isEmpty() ? state.childName : "your child");
        }
        if (text.contains("{child_count}")) {
            int cc = state.childCount();
            text = text.replace("{child_count}", cc == 1 ? "one child" : cc + " children");
        }
        if (text.contains("{child2_name}")) {
            String c2 = "";
            if (state.children.size() >= 2 && !state.children.get(1).givenAway)
                c2 = state.children.get(1).name;
            text = text.replace("{child2_name}", c2.isEmpty() ? "the second one" : c2);
        }
        if (text.contains("{child_age_years}")) {
            int age = 0;
            if (!state.children.isEmpty() && !state.children.get(0).givenAway)
                age = state.children.get(0).ageYears(state.dayCount);
            else if (state.childExists && !state.childGivenAway)
                age = state.childAgeYears();
            text = text.replace("{child_age_years}", age + (age == 1 ? " year old" : " years old"));
        }
        return text;
    }

    /**
     * Called when a new scene loads (not on loop returns within the same scene).
     * Handles one-time setup for special scenes.
     */
    public void onSceneEnter(String sceneId) {
        // Fresh bar visit — populate NPCs and clear session stats
        if ("bar_night".equals(sceneId) && !state.currentScene.equals(sceneId)) {
            bar.populateBar();
            clearNpcSessionStats();
        }
        // Each loop back to bar_with_npc ticks NPC frustration by trait-based rate
        if ("bar_with_npc".equals(sceneId)) {
            state.hubScene = "bar_with_npc";
            state.currentNpcFrustration += bar.npcFrustrationRate();
            // At 100 frustration the NPC leaves
            if (state.currentNpcFrustration >= 100) {
                state.currentScene = "bar_npc_leaves";
                return;
            }
        }
        if ("bar_mc_home".equals(sceneId)) {
            state.hubScene = "bar_mc_home";
        }
        if ("bar_slow_dance".equals(sceneId)) {
            state.slowDanceCount++;
        }

        // ── Dance lock — drunk + enjoying = can't voluntarily stop ────────────
        // When effectiveWP < 25 AND slut_rep in "enjoy" tier:
        //   - flagDanceLocked = true → hides "End the dance" and all push-away choices
        //   - Locked for 5 bar_dance_floor visits, then auto-unlocks
        if ("bar_dance_floor".equals(sceneId) && state.currentApproachingNpc != null) {
            if (state.flagDanceLocked) {
                // Already locked — decrement counter
                state.danceLockTurns--;
                if (state.danceLockTurns <= 0) {
                    state.danceLockTurns  = 0;
                    state.flagDanceLocked = false;
                }
            } else if (bar.isDanceLocked()) {
                // Freshly locked this visit
                state.danceLockTurns  = 5;
                state.flagDanceLocked = true;
            }
        }

        // ── Transition scene injection — weighted pool, 1-in-3 chance ─────────
        // Pool: 0-10 weight per scene, null = 2× scene total → P(scene) = 1/3
        if ("bar_dance_floor".equals(sceneId)) {
            String trigger = state.usedDanceMoments.isEmpty() ? "to_dance" : "mid_dance";
            String redirect = bar.rollTransitionScene(trigger);
            if (redirect != null) {
                state.currentScene = redirect;
                return;
            }
        }
        if ("bar_pool_with_npc".equals(sceneId) && state.usedDanceMoments.isEmpty()) {
            String redirect = bar.rollTransitionScene("to_pool");
            if (redirect != null) {
                state.currentScene = redirect;
                return;
            }
        }
        // Hub loop — rare other-patron event
        if ("bar_with_npc".equals(sceneId) && state.currentNpcArousal < 20) {
            String redirect = bar.rollTransitionScene("hub_loop");
            if (redirect != null) {
                state.currentScene = redirect;
                return;
            }
        }
        // Ditching or going home — flush liking into npc_rep and clear session stats
        if ("bar_night".equals(sceneId) && state.currentScene.equals("bar_with_npc")) {
            flushNpcLiking();
            clearNpcSessionStats();
        }
    }

    /**
     * Returns the internal-monologue text shown during the dance lock loop.
     * Tone shifts based on how many turns remain.
     */
    /** Short prompt shown at end of housing arrival scenes nudging player to furnish. */
    private String buildHomeFurnishPrompt() {
        boolean hasMirror   = state.hasTrait("has_mirror");
        boolean hasTv       = state.hasTrait("has_tv");
        boolean hasDresser  = state.hasTrait("has_dresser_basic")
                           || state.hasTrait("has_dresser_nice")
                           || state.hasTrait("has_wardrobe");
        if (hasMirror && hasTv && hasDresser)
            return "The place is looking settled. You can always add more later.";
        if (!hasMirror && !hasTv && !hasDresser)
            return "You could pick up a few things — a mirror, something for your clothes, "
                 + "maybe a TV. Small improvements. They add up.";
        if (!hasMirror)
            return "A mirror would help. There's a spot that would be perfect for one.";
        if (!hasDresser)
            return "Your clothes are still in the bag. A dresser would fix that.";
        return "There are a few things that would make this feel more permanent.";
    }

    private String buildDanceLockTurnsText() {
        int turns = state.danceLockTurns;
        String d = bar.drunkTierPublic();
        if (d.equals("blackout"))
            return "*Everything is movement. You can't remember why stopping would matter.*";
        switch (turns) {
            case 5:
            case 4:
                return "*Something in you just doesn't want this to end yet. "
                     + "You tell yourself one more song.*";
            case 3:
                return "*You could stop. You're not stopping.*";
            case 2:
                return "*Soon. Just not right now.*";
            case 1:
                return "*Almost. You can feel the end of it approaching.*";
            default:
                return "*You keep moving.*";
        }
    }

    private void clearNpcSessionStats() {
        state.currentNpcFrustration = 0;
        state.currentNpcArousal     = 0;
        state.currentNpcLiking      = 0;
        state.slowDanceCount        = 0;
        state.usedDanceMoments.clear();
        state.flagBreastGroped      = false;
        state.flagAssGroped         = false;
        state.flagPussyGroped       = false;
        state.flagFingered          = false;
        state.flagKissed            = false;
        state.flagNeckKissed        = false;
        state.flagDeepKissed        = false;
        state.flagCornered          = false;  // cornered/hidden on dance floor
        state.flagNpcCame           = false;  // NPC orgasmed — affects exit text, clear per session
        state.flagCookedTonight     = false;  // 1x cook gate resets each bar session
        state.flagDanceLocked       = false;
        state.danceLockTurns        = 0;
        // flagGloryHoleUsed: cleared daily in advanceDay() — persists for morning-after
        // flagCafeJumpFlashed / flagCafeSleazyVisited: cleared daily, not per-session
    }

    /**
     * Converts accumulated liking into a small npc_rep bump.
     * Rep is intentionally hard to build — liking divides down heavily.
     * Roughly: 50 liking points = +1 npc_rep.
     */
    private void flushNpcLiking() {
        if (state.currentApproachingNpc.isEmpty()) return;
        int repGain = state.currentNpcLiking / 50;
        if (repGain > 0)
            state.changeStat("npc_rep_" + state.currentApproachingNpc, repGain);
    }

    public List<SceneData.ChoiceData> availableChoices(SceneData scene) {
        List<SceneData.ChoiceData> out = new ArrayList<>();
        for (SceneData.ChoiceData c : scene.choices) {
            if (isSuppressed(scene, c)) continue;
            // SA content filter
            if (c.requires_sa_enabled && settings != null && !settings.saContentEnabled) continue;   // mod suppress_choices rule
            if (c.wip || c.show_when_locked) {
                out.add(c);  // always include — rendered grey/disabled in UI
            } else if (visible(c)) {
                out.add(c);
            }
        }

        // ── Bar NPC eye-contact injection ─────────────────────────────
        // When in the bar_night scene, append one "Catch X's eye" choice per NPC.
        if ("bar_night".equals(scene.id)) {
            out.addAll(bar.buildEyeContactChoices());
            out.addAll(bar.buildWaveOverChoices());
        }
        if ("bar_npc_approach".equals(scene.id)) {
            out.addAll(bar.buildMcResponseChoices());
        }

        // ── Priority locking ─────────────────────────────────────────
        // If any visible choice has locks_others=true, find the highest
        // such priority and suppress all choices below it.
        int lockPriority = -1;
        for (SceneData.ChoiceData c : out)
            if (c.locks_others && c.priority > lockPriority)
                lockPriority = c.priority;
        if (lockPriority >= 0) {
            final int lp = lockPriority;
            out.removeIf(c -> c.priority < lp);
        }

        return out;
    }

    public  boolean isChoiceVisible(SceneData.ChoiceData c) { return visible(c); }
    private boolean visible(SceneData.ChoiceData c) {
        Set<String> dyn = state.computeDynamicTraits(clothes);

        // ── Hard trait gates (AND logic) ─────────────────────────────
        for (String t : c.requires_traits)
            if (!state.hasTrait(t) && !dyn.contains(t.toLowerCase())) return false;
        for (String t : c.blocks_if_traits)
            if  (state.hasTrait(t) ||  dyn.contains(t.toLowerCase())) return false;

        // ── Trauma suppresses assertive paths ────────────────────────────────────
        // Shaken/Hurt: hides Confrontational, Self_Assured, Driven paths.
        // Broken: additionally hides Outgoing, Provocative paths — MC cannot perform confidence.
        if (dyn.contains("shaken_suppresses_assertive")) {
            java.util.Set<String> suppressed = new java.util.HashSet<>(
                java.util.Arrays.asList("confrontational","self_assured","driven"));
            if (dyn.contains("broken_suppresses_all"))
                suppressed.addAll(java.util.Arrays.asList("outgoing","provocative","magnetic"));
            for (String t : c.requires_traits)
                if (suppressed.contains(t.toLowerCase())) return false;
            if (!c.requires_trait.isEmpty()
                    && suppressed.contains(c.requires_trait.toLowerCase())) return false;
        }

        // ── OR trait gate — at least one must be present ─────────────
        if (!c.requires_any_traits.isEmpty()) {
            boolean any = false;
            for (String t : c.requires_any_traits)
                if (state.hasTrait(t) || dyn.contains(t.toLowerCase())) { any = true; break; }
            if (!any) return false;
        }

        for (Map.Entry<String,List<String>> e : c.requires_npc_traits.entrySet())
            for (String t : e.getValue()) if (!npcs.hasTrait(e.getKey(), t)) return false;

        // ── Slut rep gates ───────────────────────────────────────────
        if (c.slut_rep_req > 0) {
            int effectiveReq = computeEffectiveSlutRepReq(c.slut_rep_req, c.path_traits);
            if (state.slut_rep < effectiveReq) return false;
        }
        if (c.max_slut_rep >= 0 && state.slut_rep > c.max_slut_rep) return false;

        // ── Arousal gate ─────────────────────────────────────────────
        if (c.min_arousal > 0 && state.arousal < c.min_arousal) return false;
        if (c.min_money  > 0 && state.money  < c.min_money)  return false;

        // ── Body-state flag gates ─────────────────────────────────
        if (!c.requires_flag.isEmpty()  && !state.getBodyFlag(c.requires_flag))  return false;
        if (!c.blocks_if_flag.isEmpty() &&  state.getBodyFlag(c.blocks_if_flag)) return false;
        // NPC reputation gate — passes if rep >= threshold OR NPC has a bypass trait
        if (c.min_npc_rep > 0) {
            boolean hasRep     = state.getNpcRep(state.currentApproachingNpc) >= c.min_npc_rep;
            boolean hasBypass  = c.rep_bypass_traits.stream()
                .anyMatch(t -> bar.currentNpcHasTrait(t));
            if (!hasRep && !hasBypass) return false;
        }
        // ── Willpower gate ────────────────────────────────────────────
        if (c.min_willpower > 0 || c.max_willpower >= 0 || c.arousal_wp_drain_above > 0) {
            int wp = state.effectiveWillpowerForCheck(c.arousal_wp_drain_above);
            if (c.min_willpower > 0  && wp <  c.min_willpower) return false;
            if (c.max_willpower >= 0 && wp >  c.max_willpower) return false;
        }

        // ── Work rep gate ─────────────────────────────────────────────
        if (c.min_work_rep > 0 && state.work_rep < c.min_work_rep) return false;

        // ── NPC rep gates ─────────────────────────────────────────────
        for (Map.Entry<String,Integer> e : c.min_npc_rep_map.entrySet())
            if (state.getNpcRep(e.getKey()) < e.getValue()) return false;

        // ── Willpower gate (MC sees likely harassment paths only) ──────
        // Path_Trait_MC_Sees_Likely_Harassment marks choices where MC can
        // recognise she may be harassed and assert herself. Low effective
        // willpower (drunk or baseline) disables the assertive option.
        if (c.path_traits.contains("Path_Trait_MC_Sees_Likely_Harassment")
                && state.effectiveWillpower() < 30)
            return false;

        // ── Clothing gates ────────────────────────────────────────────
        ClothingData upper = effectiveUpper();
        if (upper != null) {
            if (upper.formal_rating   < c.min_formal_rating)  return false;
            if (upper.lewdness_rating < c.min_lewdness_rating) return false;
            if (upper.casual_rating   < c.min_casual_rating)   return false;
            if (c.requires_seethrough && !upper.seethrough
                    && !(state.isWet && upper.seethrough_when_wet)) return false;
        }
        if (c.requires_wet && !state.isWet) return false;
        if (c.requires_fertile_window && !state.isFertileWindow()) return false;
        if (c.requires_period         && !state.isOnPeriod())      return false;
        if (c.requires_not_period     &&  state.isOnPeriod())      return false;
        return true;
    }

    /**
     * Rolls for STD transmission and pregnancy risk after a sex scene.
     * Called from applyChoice() when the completed scene has path_trait "Sex_Scene"
     * and choice has path_trait "Sex_Unprotected" or "Sex_Protected".
     *
     * STD rates:
     *   Unprotected — Sleazy/Jerk NPC: 10% minor, 3% serious
     *                 Outgoing/Nightlife_Lover: 5% minor, 1% serious
     *                 Other: 2% minor, 0.5% serious
     *   Protected (condom) — multiply all rates by 0.15
     *
     * Pregnancy: 15% per encounter if in fertile window and unprotected.
     */
    private void rollSexualHealthConsequences(boolean protectedSex) {
        if (state.hasTrait("STD_minor") || state.hasTrait("STD_serious")) return; // already infected

        String npcId = state.currentApproachingNpc;
        double minorRate, seriousRate;

        if (npcs.hasTrait(npcId, "Sleazy") || npcs.hasTrait(npcId, "Jerk")) {
            minorRate = 0.10; seriousRate = 0.03;
        } else if (npcs.hasTrait(npcId, "Outgoing") || npcs.hasTrait(npcId, "Nightlife_Lover")) {
            minorRate = 0.05; seriousRate = 0.01;
        } else {
            minorRate = 0.02; seriousRate = 0.005;
        }

        if (protectedSex) { minorRate *= 0.15; seriousRate *= 0.15; }

        double roll = Math.random();
        if (roll < seriousRate) {
            state.addTrait("STD_serious");
        } else if (roll < seriousRate + minorRate) {
            state.addTrait("STD_minor");
        }

        // Pregnancy risk — fertile window, unprotected
        if (!protectedSex && state.isFertileWindow() && Math.random() < 0.15) {
            state.addTrait("Pregnant_Risk"); // triggers pregnancy arc (pending implementation)
        }
    }

    /**
     * Checks mod-injected suppress rules for the current scene against a choice.
     * Called from the choice list builder — not from visible() to keep separation clean.
     * Returns true if this choice should be suppressed (hidden).
     */
    private boolean isSuppressed(SceneData scene, SceneData.ChoiceData c) {
        if (scene.suppressRules.isEmpty()) return false;
        String choiceText = c.text.toLowerCase();
        Set<String> dyn = state.computeDynamicTraits(clothes);
        for (SceneData.SuppressRule rule : scene.suppressRules) {
            if (!choiceText.contains(rule.text_contains.toLowerCase())) continue;
            // Rule matches text — check conditions
            boolean condMet = true;
            if (!rule.when_trait.isEmpty())
                condMet = state.hasTrait(rule.when_trait) || dyn.contains(rule.when_trait.toLowerCase());
            if (condMet && !rule.when_flag.isEmpty())
                condMet = state.getBodyFlag(rule.when_flag);
            if (condMet) return true;
        }
        return false;
    }

    /**
     * Computes the effective slut_rep requirement after applying path_trait modifiers.
     *
     * Modifier convention:
     *   Positive multiplier (e.g. 1.5) = harder — req * 1.5
     *   Negative multiplier (e.g. -1.5) = easier — req / 1.5
     * Multiple path_traits stack multiplicatively.
     */
    /**
     * Bonus applied to slut_rep_gain_max_rep based on exhibitionist/shy traits.
     * Max +4 for strong exhibitionist tendencies, up to -4 for strong aversion.
     * Applied per-choice based on which path traits the choice is tagged with.
     */
    private int slutRepGainCeilingBonus(List<String> pathTraits) {
        // Find the most relevant exhibitionist trait for this choice's context
        boolean lowRisk  = pathTraits.contains("Path_Trait_Low_Risk_Exhibitionist");
        boolean highRisk = pathTraits.contains("Path_Trait_High_Risk_Exhibitionist");
        boolean watched  = pathTraits.contains("Path_Trait_Watched_Exhibitionist");

        if (!lowRisk && !highRisk && !watched) return 0;

        if (state.hasTrait("Loves_Being_Watched"))         return 4;
        if (state.hasTrait("Risky_Exhibitionist"))         return watched ? 3 : 2;
        if (state.hasTrait("Secret_Exhibitionist"))        return lowRisk ? 3 : (highRisk ? 1 : 0);
        if (state.hasTrait("Likes_Being_Watched"))         return 2;
        if (state.hasTrait("Hates_Being_Watched"))         return -4;
        if (state.hasTrait("Uncomfortable_Being_Watched")) return watched ? -3 : -1;
        if (state.hasTrait("Shy"))                         return -2;
        return 0;
    }

    private int computeEffectiveSlutRepReq(int baseReq, List<String> pathTraits) {
        double modifier = 1.0;

        // Path trait modifiers (personality/disposition)
        for (String pt : pathTraits) {
            modifier *= pathTraitModifier(pt);
        }

        // Drunk modifier — impaired judgment lowers thresholds
        // Applied after path traits; compound effect for very drunk characters
        double drunkMod = state.drunkSlutRepModifier();
        modifier *= drunkMod;

        // Virginity modifier — first time is harder to cross the threshold
        // (nervousness, not knowing what to do, built-up anxiety)
        if (state.hasTrait("Virgin") && baseReq >= 40) {
            // Only applies to penetration-tier and above
            modifier *= 1.20;
        }

        // Modifier < 1 = easier, > 1 = harder
        int result = (int) Math.round(baseReq * modifier);
        return Math.max(0, result);
    }

    private double pathTraitModifier(String pathTrait) {
        switch (pathTrait) {
            case "Path_Trait_Public": {
                if (state.hasTrait("Shy"))           return 1.5;
                if (state.hasTrait("Fragile_Ego"))   return 1.25;
                if (state.hasTrait("Outgoing"))      return 1.0 / 1.5;   // ×-1.5 = easier
                if (state.hasTrait("Magnetic"))      return 1.0 / 1.25;  // ×-1.25 = easier
                // Self_Assured, Antisocial = no modifier
                return 1.0;
            }
            case "Path_Trait_Public_Exhibitionist": {
                if (state.hasTrait("Hates_Being_Watched"))           return 2.0;
                if (state.hasTrait("Uncomfortable_Being_Watched"))   return 1.5;
                if (state.hasTrait("Secret_Exhibitionist") ||
                    state.hasTrait("Risky_Exhibitionist"))           return 1.5;
                if (state.hasTrait("Loves_Being_Watched"))           return 1.0 / 2.0;  // ×-2
                if (state.hasTrait("Likes_Being_Watched"))           return 1.0 / 1.5;  // ×-1.5
                // Neutral_On_Exhibitionism = no modifier
                return 1.0;
            }
            case "Path_Trait_Low_Risk_Exhibitionist": {
                // Low-risk flash: hidden/empty space, very unlikely to be seen
                // Secret exhibitionists love this — feels thrilling but safe
                if (state.hasTrait("Hates_Being_Watched"))          return 1.5;
                if (state.hasTrait("Secret_Exhibitionist"))         return 1.0 / 2.0;  // half req
                if (state.hasTrait("Risky_Exhibitionist"))          return 1.0 / 1.5;
                if (state.hasTrait("Shy"))                          return 1.25;
                return 1.0;
            }
            case "Path_Trait_High_Risk_Exhibitionist": {
                // High-risk flash: crowd around, real chance of being seen
                if (state.hasTrait("Hates_Being_Watched"))          return 2.0;
                if (state.hasTrait("Uncomfortable_Being_Watched"))  return 1.5;
                if (state.hasTrait("Shy"))                          return 1.5;
                if (state.hasTrait("Risky_Exhibitionist"))          return 1.0 / 1.5;
                if (state.hasTrait("Loves_Being_Watched"))          return 1.0 / 1.5;
                if (state.hasTrait("Secret_Exhibitionist"))         return 1.0 / 1.25;
                return 1.0;
            }
            case "Path_Trait_Watched_Exhibitionist": {
                // Watched flash: deliberate, someone is actively looking
                if (state.hasTrait("Hates_Being_Watched"))          return 3.0;
                if (state.hasTrait("Uncomfortable_Being_Watched"))  return 2.0;
                if (state.hasTrait("Shy"))                          return 2.0;
                if (state.hasTrait("Loves_Being_Watched"))          return 1.0 / 2.0;  // half req
                if (state.hasTrait("Likes_Being_Watched"))          return 1.0 / 1.5;
                if (state.hasTrait("Risky_Exhibitionist"))          return 1.0 / 1.25;
                return 1.0;
            }
            // Path_Trait_MC_Sees_Likely_Harassment has no slut_rep modifier —
            // handled separately via effectiveWillpower() gate

            // ── Sexual intimacy path traits ───────────────────────────────────────────
            // These modify the slut_rep threshold for sex acts.
            // Sexual disposition traits shift how easily MC crosses each threshold.
            case "Path_Trait_Manual_Sex": {
                // Handjob / fingering — lower-stakes physical intimacy
                if (state.hasTrait("Prude"))              return 1.6;
                if (state.hasTrait("Demure"))             return 1.3;
                if (state.hasTrait("Modest"))             return 1.2;
                if (state.hasTrait("Shy"))                return 1.25;
                if (state.hasTrait("Conflict_Avoidant"))  return 0.9;  // goes along easier
                if (state.hasTrait("Provocative_Sexual")) return 0.5;
                if (state.hasTrait("Slut"))               return 0.4;
                if (state.hasTrait("Whore"))              return 0.3;
                if (state.hasTrait("Self_Assured"))       return 0.9;  // comfortable with body
                return 1.0;
            }
            case "Path_Trait_Oral_Sex": {
                // Giving or receiving oral
                if (state.hasTrait("Prude"))              return 2.0;
                if (state.hasTrait("Demure"))             return 1.5;
                if (state.hasTrait("Modest"))             return 1.3;
                if (state.hasTrait("Shy"))                return 1.4;
                if (state.hasTrait("Naive"))              return 1.5;  // unfamiliarity
                if (state.hasTrait("Provocative_Sexual")) return 0.55;
                if (state.hasTrait("Slut"))               return 0.45;
                if (state.hasTrait("Whore"))              return 0.35;
                if (state.hasTrait("Conflict_Avoidant"))  return 0.85;
                if (state.hasTrait("Self_Assured"))       return 0.85;
                return 1.0;
            }
            case "Path_Trait_Penetrative_Sex": {
                // Full intercourse — the primary gateway
                if (state.hasTrait("Prude"))              return 2.2;
                if (state.hasTrait("Demure"))             return 1.6;
                if (state.hasTrait("Modest"))             return 1.35;
                if (state.hasTrait("Shy"))                return 1.5;
                if (state.hasTrait("Fragile_Ego"))        return 1.3;  // insecurity
                if (state.hasTrait("Naive"))              return 1.6;
                if (state.hasTrait("Conflict_Avoidant"))  return 0.8;  // gives in easier
                if (state.hasTrait("Provocative_Sexual")) return 0.55;
                if (state.hasTrait("Slut"))               return 0.4;
                if (state.hasTrait("Whore"))              return 0.3;
                if (state.hasTrait("Self_Assured"))       return 0.8;
                if (state.hasTrait("Sexually_Neutral"))   return 1.0;
                return 1.0;
            }
            case "Path_Trait_Bareback": {
                // Sex without condom — separate consent gate
                if (state.hasTrait("Prude"))              return 2.5;
                if (state.hasTrait("Naive"))              return 0.7;  // less aware of risk
                if (state.hasTrait("Provocative_Sexual")) return 0.6;
                if (state.hasTrait("Slut"))               return 0.5;
                if (state.hasTrait("Whore"))              return 0.4;
                if (state.hasTrait("Shy"))                return 1.3;
                if (state.hasTrait("Self_Assured"))       return 0.9;  // confident choice
                return 1.0;
            }
            case "Path_Trait_Anal_Sex": {
                // Anal — highest threshold
                if (state.hasTrait("Prude"))              return 3.0;
                if (state.hasTrait("Demure"))             return 2.0;
                if (state.hasTrait("Modest"))             return 1.8;
                if (state.hasTrait("Shy"))                return 2.0;
                if (state.hasTrait("Fragile_Ego"))        return 1.5;
                if (state.hasTrait("Provocative_Sexual")) return 0.6;
                if (state.hasTrait("Slut"))               return 0.55;
                if (state.hasTrait("Whore"))              return 0.45;
                if (state.hasTrait("Conflict_Avoidant"))  return 0.8;
                if (state.hasTrait("Sexually_Neutral"))   return 1.2;
                return 1.0;
            }
            case "Path_Trait_Dirty_Talk": {
                if (state.hasTrait("Shy"))                return 1.4;
                if (state.hasTrait("Provocative_Sexual")) return 0.5;
                if (state.hasTrait("Slut"))               return 0.5;
                if (state.hasTrait("Self_Assured"))       return 0.8;
                return 1.0;
            }

            default:
                return 1.0;
        }
    }

    public String applyChoice(SceneData.ChoiceData c) {
        for (Map.Entry<String,Integer> e : c.stat_changes.entrySet()) state.changeStat(e.getKey(), e.getValue());
        for (Map.Entry<String,Integer> e : c.stat_set.entrySet())     state.setStat(e.getKey(), e.getValue());
        // Apply timed traits (format "TraitName:days")
        // NOTE: these go ONLY into timedTraits — NOT into the permanent traits Set.
        // hasTrait() checks both, so gating still works. On expiry they vanish cleanly.
        for (String entry : c.timed_traits) {
            int colon = entry.lastIndexOf(':');
            if (colon > 0) {
                String traitName = entry.substring(0, colon).trim().toLowerCase();
                int days = 1;
                try { days = Integer.parseInt(entry.substring(colon+1).trim()); } catch (Exception ignored) {}
                // Put in timedTraits only — not permanent traits
                state.timedTraits.put(traitName, state.dayCount + days);
            } else {
                state.addTrait(entry); // no duration → permanent
            }
        }
        for (String t : c.add_traits) {
            if (t.startsWith("_bar_approach_")) {
                state.currentApproachingNpc = t.substring("_bar_approach_".length());
            } else if (t.equals("_clear_starting_outfits")) {
                state.startingOutfitsOnly = false;
            } else if (t.startsWith("owns_")) {
                // owns_tank_top → adds "tank_top" to ownedClothing so OutfitPanel can show it
                // Non-clothing owns_* (owns_condoms etc) just add the trait
                String itemId = t.substring("owns_".length());
                if (!itemId.equals("condoms")) {
                    state.ownedClothing.add(itemId);
                    state.startingOutfitsOnly = false;
                }
                state.addTrait(t); // keep trait for gate checks
            } else if (t.equals("_quit_job")) {
                state.quitJob();
            } else if (t.equals("_fire_player")) {
                state.fireFromJob();
            } else if (t.equals("_npc_trauma_current")) {
                // Adds a permanent NPC-specific trauma link for the currently approaching NPC.
                // npc_trauma_{npc_id} — never removed, persists across saves.
                // npc_trauma_timer_{npc_id} — timed, lasts for the combined duration of all
                //   active trauma tiers at the moment of trauma infliction.
                //   While active: intense scared reactions fire.
                //   After expiry: only the permanent mild residual reaction fires.
                String traumaNpcId = state.currentApproachingNpc;
                if (!traumaNpcId.isEmpty()) {
                    state.addTrait("npc_trauma_" + traumaNpcId);
                    // Timer = combined days remaining across all active trauma tiers
                    int timerDays = 0;
                    for (String tier : new String[]{"Broken","Shaken","Hurt","Rattled"})
                        timerDays += state.getTimedTraitDaysLeft(tier);
                    if (timerDays < 1) timerDays = 3; // floor: at least 3 days
                    state.addTimedTrait("npc_trauma_timer_" + traumaNpcId, timerDays);
                }
            // ── Relationship status handlers ──────────────────────────────────
            // ── Location discovery ───────────────────────────────────────
            } else if (t.startsWith("_discover_loc_")) {
                state.discoverLocation(t.substring("_discover_loc_".length()));
            // ── Neighbourhood tracking ────────────────────────────────────
            } else if (t.startsWith("_set_neighbourhood_")) {
                state.currentNeighbourhood = t.substring("_set_neighbourhood_".length()).replace('_',' ');
            // ── Work mode rep/promo trait shorthands ──────────────────────
            } else if (t.startsWith("_add_promo_")) {
                try {
                    int pts = Integer.parseInt(t.substring("_add_promo_".length()));
                    state.applyPromotionGain(pts);
                } catch (NumberFormatException ignored) {}
            } else if (t.startsWith("_rep_penalty_")) {
                try {
                    int pts = Integer.parseInt(t.substring("_rep_penalty_".length()));
                    state.applyOfficeRepGain(-pts);
                } catch (NumberFormatException ignored) {}
            } else if (t.equals("_start_dating_npc")) {
                if (state.currentApproachingNpc != null && !state.currentApproachingNpc.isEmpty())
                    state.setRelationshipStatus(state.currentApproachingNpc, "dating");
            } else if (t.equals("_end_relationship_npc")) {
                if (state.currentApproachingNpc != null && !state.currentApproachingNpc.isEmpty())
                    state.setRelationshipStatus(state.currentApproachingNpc, "");
            } else if (t.equals("_open_relationship_npc")) {
                if (state.currentApproachingNpc != null && !state.currentApproachingNpc.isEmpty())
                    state.setRelationshipStatus(state.currentApproachingNpc, "open_relationship");
            } else if (t.equals("_fwb_npc")) {
                if (state.currentApproachingNpc != null && !state.currentApproachingNpc.isEmpty())
                    state.setRelationshipStatus(state.currentApproachingNpc, "friends_with_benefits");
            } else if (t.startsWith("_apply_raise_")) {
                // Format: _apply_raise_15 → adds 15/day to payPerDayBonus
                try {
                    int amt = Integer.parseInt(t.substring("_apply_raise_".length()));
                    state.applyRaise(amt);
                } catch (NumberFormatException ignored) {}
            } else if (t.startsWith("_set_housing_")) {
                String payload = t.substring("_set_housing_".length());
                int lastUs = payload.lastIndexOf('_');
                if (lastUs >= 0) {
                    state.currentLandlordNpc = payload.substring(0, lastUs);
                    try { state.rent = Integer.parseInt(payload.substring(lastUs + 1)); }
                    catch (NumberFormatException ignored) {}
                }
                state.removeTrait("sleeping_on_floor");
            } else {
                state.addTrait(t);
            }
        }
        for (String t : c.remove_traits) {
            if (t.startsWith("owns_")) {
                // Clothing item loss — track for auto-rebuy
                state.loseClothingItem(t.substring("owns_".length()));
                state.removeTrait(t);
            } else {
                state.removeTrait(t);
            }
        }
        if (c.money_change != 0) state.money += c.money_change;

        // ── Slut rep gain — diminishing returns + lifetime cap by action type ──
        int rawGain     = c.slut_rep_gain;
        int surpriseRaw = c.slut_rep_gain_surprise;

        // Per-choice rep ceiling: if current rep >= max_rep, this action gives nothing
        // Trait modifiers can raise the ceiling by up to +4 for exhibitionist tendencies
        if (c.slut_rep_gain_max_rep > 0) {
            int effectiveCap = c.slut_rep_gain_max_rep + slutRepGainCeilingBonus(c.path_traits);
            if (state.slut_rep >= effectiveCap) {
                rawGain     = 0;
                surpriseRaw = 0;
            }
        }

        // Surprise gain = 50% of face value (floor — so raw 2 → 1, raw 1 → 0)
        // Proximity bonus: if accidental_threshold set and MC is well below it,
        // multiply surprise raw before flooring — more rep when exposure is far
        // outside her comfort zone.
        //   rep < threshold/3  → ×2  (way below: +2 from a normal +1 base)
        //   rep < threshold×⅔  → ×1  (below threshold: no bonus, normal half-rep)
        //   rep ≥ threshold     → ×½  (at or above: old hat, quarter-rep effective)
        if (surpriseRaw > 0 && c.accidental_threshold > 0) {
            int thresh = c.accidental_threshold;
            if      (state.slut_rep < thresh / 3)  surpriseRaw *= 2;
            else if (state.slut_rep >= thresh)      surpriseRaw = Math.max(0, surpriseRaw / 2);
        }
        int effectiveSurprise = (int) Math.floor(surpriseRaw * 0.5);

        int totalRaw = rawGain + effectiveSurprise;

        if (totalRaw > 0) {
            // Infer action type from path_traits if not explicit
            String actionType = c.slut_rep_action_type;
            if (actionType.isEmpty()) {
                boolean pub = c.path_traits.contains("Path_Trait_Public_Exhibitionist");
                boolean low = c.path_traits.contains("Path_Trait_Low_Risk_Exhibitionist");
                boolean har = c.path_traits.contains("Path_Trait_MC_Sees_Likely_Harassment");
                if      (har)        actionType = "public_act";
                else if (pub && low) actionType = "high_risk_flash";
                else if (pub)        actionType = "watched_flash";
                else if (low)        actionType = "low_risk_flash";
                else                 actionType = "public_act";
            }

            // Apply diminishing returns + lifetime cap per action type
            int gain = state.applySlutRepEarned(actionType, totalRaw);

            // Scene cap: max +2 per scene total
            int sceneRemaining = 2 - state.slutRepGainedThisScene;
            gain = Math.min(gain, Math.max(0, sceneRemaining));

            // Daily cap: sex actions use higher cap (12) vs public acts (5)
            boolean isSexAction = actionType != null && actionType.startsWith("sex_");
            int dailyCap = isSexAction ? GameState.SLUT_REP_SEX_DAILY_CAP : GameState.SLUT_REP_DAILY_CAP;
            int dayRemaining = dailyCap - state.slutRepGainedToday;
            gain = Math.min(gain, Math.max(0, dayRemaining));

            if (gain > 0) {
                state.slut_rep = Math.min(100, state.slut_rep + gain);
                state.slutRepGainedThisScene += gain;
                state.slutRepGainedToday     += gain;
            }
        }

        // ── Action dispatch (car, inventory, pharmacy, hair, surgery) ──────────
        if (c.car_action != null && !c.car_action.isEmpty()) {
            String[] parts = c.car_action.split(":");
            String cmd = parts[0];
            // Car
            if ("buy".equals(cmd) && parts.length >= 4) {
                state.buyCar(parts[1], Integer.parseInt(parts[2]), Integer.parseInt(parts[3]));
            } else if ("rent".equals(cmd) && parts.length >= 5) {
                state.rentCar(parts[1], Integer.parseInt(parts[2]),
                              Integer.parseInt(parts[3]), Integer.parseInt(parts[4]));
            } else if ("finance".equals(cmd) && parts.length >= 5) {
                state.financeCar(parts[1], Integer.parseInt(parts[2]),
                                 Integer.parseInt(parts[3]), Integer.parseInt(parts[4]));
            } else if ("finance_pay".equals(cmd)) {
                state.makeFinancePayment();
            } else if ("return_car".equals(cmd)) {
                state.loseCar();
            // Inventory
            } else if ("buy_condoms".equals(cmd)) {
                int qty  = parts.length>1?Integer.parseInt(parts[1]):3;
                int cost = parts.length>2?Integer.parseInt(parts[2]):4;
                state.condomCount += qty;
                state.money       -= cost;
            } else if ("buy_soap".equals(cmd)) {
                state.soapUses += 10;  // 10 uses per bar
                state.money    -= parts.length>1?Integer.parseInt(parts[1]):5;
            } else if ("buy_sunscreen".equals(cmd)) {
                state.sunscreenCount++;
                state.money -= parts.length>1?Integer.parseInt(parts[1]):12;
            // Pharmacy
            } else if ("take_plan_b".equals(cmd)) {
                boolean ok = state.takePlanB();
                state.setNpcMemory("__sys__", "plan_b_result", ok?"success":"failure");
                state.money -= 40;
            } else if ("take_abortion_pill".equals(cmd)) {
                boolean ok = state.takeAbortionPill();
                state.setNpcMemory("__sys__", "abortion_result", ok?"success":"failure");
                state.money -= 1000;
            // Hair
            } else if ("set_hair_length".equals(cmd) && parts.length>1) {
                state.setHairLength(parts[1]);
                state.money -= parts.length>2?Integer.parseInt(parts[2]):40;
            } else if ("set_hair_color".equals(cmd) && parts.length>1) {
                state.setHairColor(parts[1]);
                state.money -= parts.length>2?Integer.parseInt(parts[2]):60;
            // Surgery
            } else if ("breast_surgery".equals(cmd) && parts.length>1) {
                state.changeBreastSize(Integer.parseInt(parts[1]));
            // Pregnancy tracking
            } else if ("npc_came_early".equals(cmd)) {
                state.addTrait("__npc_came_early__");
            } else if ("clean_cum_off_npc".equals(cmd)) {
                // MC cleans NPC off — enables post-cum oral option
                state.addTrait("__npc_cleaned__");
            } else if ("buy_clothing".equals(cmd) && parts.length>1) {
                // Scene-triggered purchase — add to owned, debit already done via stat_changes
                state.ownedClothing.add(parts[1]);
            } else if ("flash_trenchcoat".equals(cmd)) {
                // Open trenchcoat — flashes everything underneath
                state.slut_rep = Math.min(100, state.slut_rep + 5);
                state.addTrait("__coat_flashed__");
            } else if ("set_wet".equals(cmd)) {
                state.isWet = true;
            } else if ("dry_off".equals(cmd)) {
                state.isWet = false;
            } else if ("set_pregnancy_from_sa".equals(cmd)) {
                state.pregnancyFromSA = true;
            } else if ("apply_sunburn".equals(cmd)) {
                state.sunburnDays = 2;
            } else if ("use_sunscreen".equals(cmd)) {
                if (state.sunscreenCount > 0) state.sunscreenCount--;
            } else if ("give_sunscreen".equals(cmd)) {
                // NPC gave sunscreen — no cost
                state.sunscreenCount = Math.max(1, state.sunscreenCount); // ensure tracked
            } else if ("try_on_item".equals(cmd) && parts.length>2) {
                // try_on_item:slot:item_id — temp equip for fitting room
                String _slot = parts[1]; String _item = parts[2];
                // Save previous value of that slot
                String _prev = state.getOutfitSlot(_slot);
                state.setNpcMemory("__tryon__","prev_" + _slot, _prev != null ? _prev : "null");
                state.setOutfitSlot(_slot, "none".equals(_item) ? null : _item);
            } else if ("restore_tryon".equals(cmd)) {
                // Restore all slots saved by try_on_item
                for (String _sl : new String[]{"upper","lower","bra","underwear","shoes","socks","overcoat"}) {
                    String _prev = state.getNpcMemory("__tryon__","prev_" + _sl);
                    if (_prev != null) state.setOutfitSlot(_sl, "null".equals(_prev) ? null : _prev);
                }
            } else if ("set_cum_location".equals(cmd) && parts.length>1) {
                state.sexState.cumLocation = parts[1]; // inside|mouth|facial|chest|outside
            } else if ("set_npc_standing_oral".equals(cmd)) {
                state.sexState.npcStandingDuringOral = true;
            } else if ("set_mc_noticed_close".equals(cmd)) {
                state.sexState.mcNoticedNpcClose = true;
            } else if ("mc_swallowed".equals(cmd)) {
                state.sexState.mcSwallowed = true;
                state.addTimedTrait("Cum_Breath", 1);
            } else if ("push_out_attempt".equals(cmd)) {
                // Slightly reduces pregnancy chance — doesn't eliminate it
                // Modelled by rolling a small reversion chance
                if (state.hasTrait("Pregnant_Unconfirmed") && Math.random() < 0.15) {
                    state.removeTrait("Pregnant");
                    state.removeTrait("Pregnant_Unconfirmed");
                } // else: no effect — already implanted or attempt failed
            } else if ("record_throat_session".equals(cmd)) {
                state.recordThroatSession();
            // ── Oral head-hold actions ───────────────────────────────────
            } else if ("mc_request_no_mouth_cum".equals(cmd)) {
                state.sex.mcRequestedNoMouthCum = true;
            } else if ("npc_agree_no_mouth".equals(cmd)) {
                state.sex.npcAgreedNoMouth = true;
            } else if ("npc_refuse_no_mouth".equals(cmd)) {
                state.sex.npcRefusedMouthRequest = true;
            } else if ("npc_ignored_mouth_request".equals(cmd)) {
                state.sex.npcIgnoredMouthRequest = true;
                state.sex.mcRequestedNoMouthCum = true;
            } else if ("npc_hold_head".equals(cmd)) {
                state.sex.npcHoldingHead = true;
                state.sex.npcDrivingPace = false;
                state.addTrait("__npc_hold_head__");
            } else if ("npc_hold_head_faster".equals(cmd)) {
                state.sex.npcHoldingHead = true;
                state.sex.npcDrivingPace = true;
                state.addTrait("__npc_hold_head_faster__");
            } else if ("npc_hold_head_release".equals(cmd)) {
                state.sex.npcHoldingHead = false;
                state.sex.npcDrivingPace = false;
                state.removeTrait("__npc_hold_head__");
                state.removeTrait("__npc_hold_head_faster__");
            } else if ("npc_holds_during_cum".equals(cmd)) {
                state.sex.npcHeldDuringCum = true;
                state.sex.npcHoldingHead = true;
            } else if ("ff_hair_play".equals(cmd)) {
                state.sex.ffHairPlay = true;
                state.addTrait("__ff_hair_play__");
            } else if ("ff_thigh_squeeze".equals(cmd)) {
                state.sex.ffThighSqueeze = true;
                state.addTrait("__ff_thigh_squeeze__");
            } else if ("npc_remove_bra".equals(cmd)) {
                state.sexState.mcBraOff = true;
                state.sexState.lastNpcAction = "bra_off";
            } else if ("npc_lift_shirt".equals(cmd)) {
                state.sexState.mcShirtLifted = true;
                state.sexState.lastNpcAction = "shirt_lifted";
            } else if ("npc_remove_shirt".equals(cmd)) {
                state.sexState.mcShirtOff = true;
                state.sexState.lastNpcAction = "shirt_off";
            } else if ("npc_remove_bottom".equals(cmd)) {
                state.sexState.mcBottomOff = true;
                state.sexState.lastNpcAction = "bottom_off";
            } else if ("npc_remove_underwear".equals(cmd)) {
                state.sexState.mcUnderwearOff = true;
                state.sexState.lastNpcAction = "underwear_off";
            } else if ("npc_hike_skirt".equals(cmd)) {
                state.sexState.mcSkirtHiked = true;
                state.sexState.lastNpcAction = "skirt_hiked";
            } else if ("edge_npc".equals(cmd)) {
                state.sexState.edgeNow();
            } else if ("tie_npc".equals(cmd)) {
                state.sexState.npcTied = true;
            } else if ("untie_npc".equals(cmd)) {
                state.sexState.npcTied = false;
            } else if ("first_dick_reveal".equals(cmd)) {
                state.sexState.firstDickReveal = true;
            } else if ("record_sex_consent".equals(cmd)) {
                state.videoTakenByNpcId = state.currentApproachingNpc;
                state.videoConsentGiven = true;
                state.videoNoticedByMc  = true;
            } else if ("record_sex_no_consent".equals(cmd)) {
                // Recorded without MC consent — SA-adjacent, gated in scenes
                state.videoTakenByNpcId = state.currentApproachingNpc;
                state.videoConsentGiven = false;
                // Drunk MC: less likely to notice
                state.videoNoticedByMc  = state.drunk < 10;
            } else if ("video_post_online".equals(cmd)) {
                state.videoWasPosted = true;
                state.slut_rep = Math.min(100, state.slut_rep + 15);
            } else if ("video_send_partner".equals(cmd)) {
                state.videoSentToPartner = true;
                state.photoWasLeaked = true; // reuse partner-confrontation trigger
            } else if ("set_partner_called_sex".equals(cmd)) {
                state.partnerCalledDuringSex = true;
            } else if ("clear_video_state".equals(cmd)) {
                state.videoTakenByNpcId = "";
                state.videoConsentGiven = false;
                state.videoWasPosted    = false;
                state.videoSentToPartner = false;
                state.videoNoticedByMc  = false;
                state.partnerCalledDuringSex = false;
            } else if ("set_video_type".equals(cmd) && parts.length > 1) {
                state.videoContentType = parts[1]; // consensual|drunk|coerced|assault
            } else if ("set_video_mc_drunk".equals(cmd)) {
                state.videoMcWasDrunk = true;
            } else if ("employer_found_online".equals(cmd)) {
                state.employerFoundOnlineContent = true;
            } else if ("discover_leak_online".equals(cmd)) {
                state.leakFoundOnline = true;
            } else if ("hire_content_lawyer".equals(cmd) && parts.length > 1) {
                try { state.contentLawyerTier = Integer.parseInt(parts[1]); } catch (Exception e) {}
                state.contentRemovalFiled = true;
                boolean won = state.rollContentRemoval();
                state.contentRemoved = won;
                state.addTrait(won ? "__legal_win__" : "__legal_miss__");
            } else if ("file_sa_suit".equals(cmd) && parts.length > 1) {
                state.saSuitLawyerTier = parts[1];
                state.saSuitFiled = true;
            } else if ("resolve_sa_suit".equals(cmd)) {
                state.saSuitResolved = true;
                boolean won = state.rollSaSuit();
                state.saSuitWon = won;
                if (won) {
                    int payout = 0;
                    switch (state.saSuitLawyerTier) {
                        case "competent": payout = 8000 + (int)(Math.random()*7000); break;
                        case "top":       payout = 18000 + (int)(Math.random()*22000); break;
                        default:          payout = 2000 + (int)(Math.random()*3000); break;
                    }
                    state.saSuitPayout = payout;
                    state.money += payout;
                }
                state.addTrait(state.saSuitWon ? "__sa_suit_won__" : "__sa_suit_lost__");
            } else if ("buy_pc".equals(cmd) && parts.length > 1) {
                int tier = 1;
                try { tier = Integer.parseInt(parts[1]); } catch (Exception e) {}
                state.pcTier = Math.max(state.pcTier, tier);
            } else if ("buy_gaming_chair".equals(cmd)) {
                state.hasGamingChair = true;
            } else if ("stream_session".equals(cmd)) {
                int bonus = 0;
                if (parts.length > 1) try { bonus = Integer.parseInt(parts[1]); } catch (Exception e) {}
                int gained = state.streamPost(bonus);
                state.addTrait("__stream_gained__:" + gained);
                state.gamingSkill = Math.min(100, state.gamingSkill + 2);
            } else if ("gaming_session".equals(cmd)) {
                state.gamingSkill = Math.min(100, state.gamingSkill + (state.hasGamingPc() ? 3 : 1));
                state.happiness   = Math.min(100, state.happiness + (state.hasGamingChair ? 8 : 4));
            } else if ("start_streaming".equals(cmd)) {
                state.streamingActive = true;
            } else if ("register_pro_gamer".equals(cmd)) {
                state.isProGamer = true;
            } else if ("slutfans_job_conflict".equals(cmd)) {
                state.addTrait("__slutfans_job_conflict__");
            } else if ("buy_gun".equals(cmd) && parts.length > 1) {
                state.ownedGuns.add(parts[1]);
                state.equippedGunId = parts[1];
                state.carryingGun   = true;
            } else if ("equip_gun".equals(cmd) && parts.length > 1) {
                if (state.ownedGuns.contains(parts[1])) {
                    state.equippedGunId = parts[1];
                    state.carryingGun   = true;
                }
            } else if ("holster_gun".equals(cmd)) {
                state.carryingGun = false;
            } else if ("earn_carry_permit".equals(cmd)) {
                state.hasCarryPermit = true;
            } else if ("buy_pepper_spray".equals(cmd)) {
                state.hasPepperSpray = true;
            } else if ("buy_taser".equals(cmd)) {
                state.hasTaser = true;
            } else if ("deploy_pepper_spray".equals(cmd)) {
                boolean hit = state.deployDefenseTool();
                state.addTrait(hit ? "__defense_hit__" : "__defense_miss__");
            } else if ("deploy_taser".equals(cmd)) {
                boolean hit = state.deployDefenseTool();
                state.addTrait(hit ? "__defense_hit__" : "__defense_miss__");
            } else if ("slutfans_create".equals(cmd)) {
                state.slutFansActive = true;
                state.slutFansContentTier = state.computeSlutFansTier();
            } else if ("slutfans_post".equals(cmd) && parts.length > 1) {
                int tier = 1;
                try { tier = Integer.parseInt(parts[1]); } catch (NumberFormatException ignored) {}
                int gained = state.slutFansPost(tier);
                state.addTrait("__sf_post_gained__:" + gained);
                state.slut_rep = Math.min(100, state.slut_rep + tier);
            } else if ("slutfans_collect".equals(cmd)) {
                int pay = state.collectSlutFansPay();
                state.addTrait("__sf_pay__:" + pay);
            } else if ("slutfans_deactivate".equals(cmd)) {
                state.slutFansActive = false;
            } else if ("buy_toy".equals(cmd) && parts.length > 1) {
                state.ownedToys.add(parts[1]);
            } else if ("file_taxes".equals(cmd)) {
                state.money -= 100; // $100 filing fee
                int owedOrRefund = state.calculateYearEndTax();
                state.setNpcMemory("__tax__","owed", String.valueOf(owedOrRefund));
                if (owedOrRefund < 0) state.addTrait("__tax_refund__");
            } else if ("reset_tax_year".equals(cmd)) {
                String owedStr = state.getNpcMemory("__tax__","owed");
                if (owedStr != null) {
                    try { state.money -= Integer.parseInt(owedStr); } catch (NumberFormatException ignored) {}
                }
                state.removeTrait("__tax_refund__");
                state.resetTaxYear();
            } else if ("save_outfit".equals(cmd) && parts.length>1) {
                state.saveCurrentOutfit(parts[1]);
            } else if ("load_outfit".equals(cmd) && parts.length>1) {
                state.loadOutfit(parts[1]);
            } else if ("set_daily_outfit".equals(cmd) && parts.length>1) {
                state.dailyOutfitName = parts[1].equals("none") ? "" : parts[1];
            } else if ("set_bar_shift".equals(cmd) && parts.length>1) {
                state.barStaffShift = parts[1]; // "day" or "night"
            } else if ("take_photo".equals(cmd)) {
                // MC agreed to a photo. Record which NPC, then roll for future leak.
                String photographer = state.currentApproachingNpc;
                state.recordPhotoTaken(photographer);
                // Trait-aware leak roll: Jerk=45%, Sleazy=35%, others=8%
                double leakChance;
                if      (npcs.hasTrait(photographer,"Jerk"))   leakChance = 0.45;
                else if (npcs.hasTrait(photographer,"Sleazy"))  leakChance = 0.35;
                else if (npcs.hasTrait(photographer,"Self_Assured")) leakChance = 0.05;
                else                                             leakChance = 0.08;
                if (Math.random() < leakChance && !state.getAnyDatingNpcId().isEmpty()) {
                    state.applyPhotoLeak(photographer);
                    // Flag for scene system to pick up on next stay_home day
                    state.setNpcMemory("__sys__","photo_leaked","true");
                }
            } else if ("resolve_photo_leak".equals(cmd)) {
                state.resolvePhotoLeak();
            } else if ("try_photo_lie".equals(cmd)) {
                // Partner believes the lie based on trust level + no prior cheating suspicion
                String partnerId = state.getAnyDatingNpcId();
                int trust = partnerId.isEmpty() ? 0 : state.getNpcRep(partnerId);
                double believeChance;
                if      (trust >= 50) believeChance = 0.65;
                else if (trust >= 30) believeChance = 0.45;
                else if (trust >= 15) believeChance = 0.25;
                else                  believeChance = 0.10;
                // Prior cheating suspicion halves the chance
                if (state.hasTrait("Has_Had_Miscarriage") && state.partnerKnowsAboutPhoto)
                    believeChance *= 0.5; // already in this situation once
                state.photoLieBelieved = Math.random() < believeChance;
                if (state.photoLieBelieved) state.resolvePhotoLeak();

            } else if ("remove_underwear".equals(cmd)) {
                // Remove current underwear and clear commando flag context
                state.outfitUnderwear = "none";
                // Trigger braless/commando check via outfit system
            } else if ("shower_morning".equals(cmd))  { state.showeredMorning = true; }
            else if ("shower_night".equals(cmd))    { state.showeredNight   = true; }
            else if ("brush_teeth".equals(cmd))     { state.brushedTeeth    = true; }
            else if ("use_soap".equals(cmd))        { state.usedSoap        = true; }
            else if ("process_hygiene".equals(cmd)) { state.processHygieneDay(); }
            else if ("morning_sickness_seen".equals(cmd)) {
                state.morningSicknessShown = true;
            } else if ("start_pill".equals(cmd)) {
                int days = parts.length>1?Integer.parseInt(parts[1]):30;
                int cost = parts.length>2?Integer.parseInt(parts[2]):30;
                state.startPill(days);
                state.money -= cost;
            } else if ("subscribe_pill".equals(cmd)) {
                state.pillSubscribed = true;
                state.startPill(30);
                state.money -= parts.length>1?Integer.parseInt(parts[1]):30;
            } else if ("stop_pill".equals(cmd)) {
                state.pillSubscribed = false;
                state.removeTrait("On_The_Pill");
                state.pillExpiryDay = 0;
            } else if ("handle_birth".equals(cmd)) {
                // "handle_birth:name:gender" — gender f or m
                String bname  = parts.length>1 ? parts[1] : "your child";
                char   bgend  = (parts.length>2 && "m".equals(parts[2])) ? 'm' : 'f';
                state.handleBirth(bname, bgend);
            } else if ("give_child_away".equals(cmd)) {
                state.giveChildAway();
            } else if ("set_child_name".equals(cmd) && parts.length>1) {
                state.childName = parts[1];
            }
        }

        // Execute secondary action if present
        if (c.car_action2 != null && !c.car_action2.isEmpty()) {
            String[] parts2 = c.car_action2.split(":");
            String cmd2 = parts2[0];
            if ("set_video_type".equals(cmd2) && parts2.length > 1) {
                state.videoContentType = parts2[1];
            } else if ("set_video_mc_drunk".equals(cmd2)) {
                state.videoMcWasDrunk = true;
            } else if ("discover_leak_online".equals(cmd2)) {
                state.leakFoundOnline = true;
            } else if ("start_streaming".equals(cmd2)) {
                state.streamingActive = true;
            } else if ("buy_gaming_chair".equals(cmd2)) {
                state.hasGamingChair = true;
            } else if ("record_sex_no_consent".equals(cmd2)) {
                state.videoConsentGiven = false;
            }
        }

        if (c.change_outfit != null && !c.change_outfit.isEmpty()) {
            ClothingData item = clothes.get(c.change_outfit);
            if (item != null) {
                switch (item.slot) {
                    case "upper":     state.outfitUpper     = c.change_outfit; break;
                    case "lower":     state.outfitLower     = c.change_outfit; break;
                    case "overcoat":  state.outfitOvercoat  = c.change_outfit; break;
                    case "bra":       state.outfitBra       = c.change_outfit; break;
                    case "underwear": state.outfitUnderwear = c.change_outfit; break;
                    case "socks":     state.outfitSocks     = c.change_outfit; break;
                    case "shoes":     state.outfitShoes     = c.change_outfit; break;
                }
            }
        }
        if (c.set_wet) state.isWet = true;
        if (c.set_dry) state.isWet = false;
        if (c.advance_cycle > 0) state.advanceCycle(c.advance_cycle);
        state.visitedScenes.add(state.currentScene);
        if (c.npc_decides) {
            state.currentScene = bar.rollNpcDecision();
        } else if ("__return__".equals(c.next)) {
            state.currentScene = null;  // signals ScenePanel to call onSceneComplete
        } else if ("__hub__".equals(c.next)) {
            state.currentScene = state.hubScene;  // returns to whichever hub opened this submenu
        } else if (c.next != null && !c.next.isEmpty()) {
            state.currentScene = c.next;
        }
        return c.result_text != null ? applyTextVars(c.result_text.trim()) : "";
    }

    /** Effective upper garment — overcoat > upper */
    public ClothingData effectiveUpper() {
        if (state.outfitOvercoat != null) return clothes.get(state.outfitOvercoat);
        return clothes.get(state.outfitUpper);
    }

    /** Effective lower garment — overcoat covers lower too; fills_lower dress covers lower */
    public ClothingData effectiveLower() {
        if (state.outfitOvercoat != null) return clothes.get(state.outfitOvercoat);
        if (state.outfitLower != null)    return clothes.get(state.outfitLower);
        if (state.outfitUpper != null) {
            ClothingData upper = clothes.get(state.outfitUpper);
            if (upper != null && upper.fills_lower) return upper;
        }
        return null;
    }

    /**
     * Weighted trigger resolution — same mechanic as work scene selection.
     *
     * Collects all triggers, sums their weights, rolls against
     * total_weight × nothing_multiplier. If the roll falls in a scene's
     * weight band, that scene fires. Otherwise nothing happens.
     *
     * When triggers have mixed nothing_multipliers, the pool uses the
     * minimum (most likely to fire something), giving urgent events
     * (×2) priority over standard events (×3).
     *
     * @param triggers  list of candidate TriggerData
     * @return          scene ID to fire, or null if nothing fires
     */
    public String resolveTriggers(java.util.List<game.data.TriggerData> triggers) {
        if (triggers == null || triggers.isEmpty()) return null;

        // Filter: only include triggers whose clothing/dynamic gate is satisfied
        // and whose cooldown (if any) has expired
        java.util.Set<String> dynamicTraits = state.computeDynamicTraits(clothes);
        java.util.List<game.data.TriggerData> eligible = new java.util.ArrayList<>();
        for (game.data.TriggerData t : triggers) {
            if (t.requires_dynamic_trait != null && !t.requires_dynamic_trait.isEmpty()) {
                if (!dynamicTraits.contains(t.requires_dynamic_trait.toLowerCase())) continue;
            }
            if (t.requires_flag != null && !t.requires_flag.isEmpty()) {
                if (!state.getBodyFlag(t.requires_flag)) continue;
            }
            // Cooldown check: skip if scene fired recently
            if (t.cooldown_days > 0 && !t.scene_id.isEmpty()) {
                Integer lastDay = state.sceneLastPlayedDay.get(t.scene_id);
                if (lastDay != null && (state.dayCount - lastDay) < t.cooldown_days) continue;
            }
            // SA content filter: skip SA-tagged triggers if player has disabled SA content
            if (t.requires_sa_enabled && settings != null && !settings.saContentEnabled) continue;
            eligible.add(t);
        }
        if (eligible.isEmpty()) return null;

        int totalWeight = 0;
        int nothingMult = Integer.MAX_VALUE;
        for (game.data.TriggerData t : eligible) {
            totalWeight += t.weight;
            nothingMult  = Math.min(nothingMult, t.nothing_multiplier);
        }
        if (nothingMult == Integer.MAX_VALUE) nothingMult = 3;

        int rollMax = totalWeight * nothingMult;
        int roll    = (int)(Math.random() * rollMax) + 1;

        if (roll > totalWeight) return null;

        int cursor = 0;
        for (game.data.TriggerData t : eligible) {
            cursor += t.weight;
            if (roll <= cursor) {
                // Record the play day for cooldown tracking
                if (t.cooldown_days > 0 && !t.scene_id.isEmpty()) {
                    state.sceneLastPlayedDay.put(t.scene_id, state.dayCount);
                }
                return t.scene_id;
            }
        }
        return null;
    }
}
