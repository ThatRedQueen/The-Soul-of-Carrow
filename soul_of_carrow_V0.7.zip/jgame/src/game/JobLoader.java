package game;

import game.data.JobData;
import org.yaml.snakeyaml.Yaml;
import java.io.*;
import java.util.*;

public class JobLoader {
    private final Map<String, JobData> jobs = new LinkedHashMap<>();

    /** Base path used to resolve scene_dir and interview_file. Set in loadAll. */
    private String basePath = "";

    @SuppressWarnings("unchecked")
    public void loadAll(String dir) {
        File folder = new File(dir);
        if (!folder.exists()) return;
        // Infer base from jobs/ folder path (parent of jobs/)
        basePath = folder.getParent() != null ? folder.getParent() : "";
        Yaml yaml = new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions()));
        File[] _files = folder.listFiles(); if (_files == null) return; for (File f : _files) {
            if (!f.getName().endsWith(".yml")) continue;
            try (InputStream is = new FileInputStream(f)) {
                Map<String,Object> raw = yaml.load(is);
                if (raw == null) continue;
                JobData j = parseJob(raw);
                if (j != null && !j.id.isEmpty()) {
                    resolveContentPaths(j);
                    jobs.put(j.id, j);
                }
            } catch (Exception e) { System.err.println("Error loading job " + f.getName() + ": " + e.getMessage()); }
        }
    }

    /** Fills scene_dir and interview_file if the conventional paths exist. */
    private void resolveContentPaths(JobData j) {
        if (basePath.isEmpty()) return;
        File scenes = new File(basePath + "/scenes/work/" + j.id);
        if (scenes.isDirectory()) j.scene_dir = scenes.getAbsolutePath();
        File interview = new File(basePath + "/interviews/" + j.id + ".yml");
        if (interview.isFile()) j.interview_file = interview.getAbsolutePath();
    }

    public JobData get(String id)       { return jobs.get(id); }
    public Collection<JobData> getAll() { return jobs.values(); }
    public boolean isWorkDay(String jobId, String dayName) {
        JobData j = get(jobId);
        return j != null && j.work_days.stream().anyMatch(d -> d.equalsIgnoreCase(dayName));
    }

    private String str(Map<String,Object> m, String k) { Object v = m.get(k); return v == null ? "" : v.toString(); }
    private int intVal(Map<String,Object> m, String k, int def) {
        Object v = m.get(k); if (v == null) return def;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return def; }
    }
    private boolean boolVal(Map<String,Object> m, String k, boolean def) {
        Object v = m.get(k); return v == null ? def : Boolean.parseBoolean(v.toString());
    }
    /** Inject a job from a mod. Returns true on success. */
    @SuppressWarnings("unchecked")
    JobData parseJob(java.util.Map<String, Object> raw) {
        if (raw == null) return null;
        JobData j = new JobData();
        j.id              = str(raw, "id");
        j.label           = str(raw, "label");
        j.description     = str(raw, "description");
        j.pay_per_day     = intVal(raw, "pay_per_day",   0);
        j.slots_per_day   = intVal(raw, "slots_per_day", 4);
        j.boss_npc_id     = str(raw, "boss_npc_id");
        Object cw = raw.get("coworker_npc_ids");
        if (cw instanceof List) for (Object o : (List<?>)cw) if (o != null) j.coworker_npc_ids.add(o.toString());
        j.pay_frequency   = str(raw, "pay_frequency");
        if (j.pay_frequency.isEmpty()) j.pay_frequency = "WEEKLY";
        j.under_the_table = boolVal(raw, "under_the_table", false);
        Object wd = raw.get("work_days");
        if (wd instanceof List) for (Object o : (List<?>)wd) if (o != null) j.work_days.add(o.toString().toUpperCase());
        // Parse possible_triggers (rep/sa-gated work events)
        Object pt = raw.get("possible_triggers");
        if (pt instanceof List) {
            for (Object entry : (List<?>)pt) {
                if (!(entry instanceof java.util.Map)) continue;
                java.util.Map<?,?> tm = (java.util.Map<?,?>)entry;
                game.data.TriggerData td = new game.data.TriggerData();
                td.scene_id             = str(tm, "scene_id");
                td.weight               = intOf(tm, "weight", 5);
                td.nothing_multiplier   = intOf(tm, "nothing_multiplier", 3);
                td.cooldown_days        = intOf(tm, "cooldown_days", 0);
                td.requires_flag        = str(tm, "requires_flag");
                td.requires_dynamic_trait = str(tm, "requires_dynamic_trait");
                Object saFlag = tm.get("requires_sa_enabled");
                td.requires_sa_enabled  = saFlag != null && Boolean.parseBoolean(saFlag.toString());
                if (!td.scene_id.isEmpty()) j.possible_triggers.add(td);
            }
        }
        Object sc = raw.get("stat_changes");
        if (sc instanceof Map) for (Map.Entry<?,?> e : ((Map<?,?>)sc).entrySet()) {
            try { j.stat_changes.put(e.getKey().toString(), Integer.parseInt(e.getValue().toString())); } catch (Exception ignored) {}
        }
        return j;
    }


    public boolean injectModJob(java.util.Map<String, Object> raw, String modId) {
        try {
            JobData j = parseJob(raw);
            if (j == null || j.id == null || j.id.isEmpty()) return false;
            jobs.put(j.id, j);
            return true;
        } catch (Exception e) {
            System.err.println("[JobLoader] injectModJob failed: " + e.getMessage());
            return false;
        }
    }

}
