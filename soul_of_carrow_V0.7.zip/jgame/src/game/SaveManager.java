package game;

import game.data.NpcData;
import java.io.*;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Saves and loads game state to/from a JSON-like flat properties file.
 * Format is human-readable and mod-safe (unknown keys are ignored on load).
 *
 * Save location: saves/save_N.dat (where N is the slot number 1–3)
 * Autosave:      saves/autosave.dat (written each time advanceDay completes)
 */
public class SaveManager {

    private static final String SEP = "=";
    private static final int    SLOTS = 3;

    private final String saveDir;
    private final GameState state;

    public SaveManager(String gameDir, GameState state) {
        this.saveDir = gameDir + File.separator + "saves";
        this.state   = state;
    }

    // ── Public API ─────────────────────────────────────────────────────────────

    public boolean save(int slot)    { return writeFile(slotPath(slot)); }
    public boolean autosave()        { return writeFile(autoPath()); }
    public boolean load(int slot)    { return readFile(slotPath(slot)); }
    public boolean loadAutosave()    { return readFile(autoPath()); }

    public boolean slotExists(int slot)   { return new File(slotPath(slot)).exists(); }
    public boolean autosaveExists()       { return new File(autoPath()).exists(); }
    public SaveMeta slotMeta(int slot)    { return readMeta(slotPath(slot)); }
    public SaveMeta autosaveMeta()        { return readMeta(autoPath()); }

    // ── Paths ─────────────────────────────────────────────────────────────────

    public  String slotPath(int slot) { return saveDir + File.separator + "save_" + slot + ".dat"; }
    public  String autoPath()          { return saveDir + File.separator + "autosave.dat"; }
    /** Alias used by SaveLoadPanel. */
    public  String autosavePath()      { return autoPath(); }

    // ── Writing — atomic + backup ─────────────────────────────────────────────
    // Writes to .tmp first, then renames atomically over the real file.
    // Keeps a .bak of the previous save so corruption is always recoverable.

    private boolean writeFile(String path) {
        try {
            Files.createDirectories(Paths.get(saveDir));
            List<String> lines = new ArrayList<>();
            String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date());

            // Header
            lines.add("# The Soul of Carrow — save file");
            lines.add("save_date" + SEP + ts);
            lines.add("game_version" + SEP + GameMeta.VERSION);
            if (state.playerName != null && !state.playerName.isEmpty())
                lines.add("player_name" + SEP + state.playerName);
            lines.add("");

            // Core stats
            lines.add("day" + SEP + state.dayCount);
        // Scene cooldown tracking
        for (java.util.Map.Entry<String, Integer> e : state.sceneLastPlayedDay.entrySet()) {
            lines.add("scene_played" + SEP + e.getKey() + SEP + e.getValue());
        }
        // Inventory
        lines.add("condoms"   + SEP + state.condomCount);
        lines.add("soap"      + SEP + state.soapCount);
        lines.add("sunscreen" + SEP + state.sunscreenCount);
        lines.add("bar_shift"      + SEP + state.barStaffShift);
        lines.add("daily_outfit"   + SEP + (state.dailyOutfitName != null ? state.dailyOutfitName : ""));
        lines.add("saved_outfit_count" + SEP + state.savedOutfits.size());
        for (int _i = 0; _i < state.savedOutfits.size(); _i++) {
            GameState.SavedOutfit _o = state.savedOutfits.get(_i);
            lines.add("outfit_" + _i + "_name"  + SEP + nvl(_o.name));
            lines.add("outfit_" + _i + "_upper" + SEP + nvl(_o.upper));
            lines.add("outfit_" + _i + "_lower" + SEP + nvl(_o.lower));
            lines.add("outfit_" + _i + "_bra"   + SEP + nvl(_o.bra));
            lines.add("outfit_" + _i + "_under" + SEP + nvl(_o.underwear));
            lines.add("outfit_" + _i + "_shoes" + SEP + nvl(_o.shoes));
            lines.add("outfit_" + _i + "_socks" + SEP + nvl(_o.socks));
            lines.add("outfit_" + _i + "_coat"  + SEP + nvl(_o.overcoat));
        }

        lines.add("photo_by"    + SEP + state.photoTakenByNpcId);
        lines.add("photo_leak"  + SEP + state.photoWasLeaked);
        lines.add("photo_leak_npc" + SEP + state.photoLeakedByNpcId);
        lines.add("partner_photo"  + SEP + state.partnerKnowsAboutPhoto);

        // Hygiene
        lines.add("days_shower" + SEP + state.daysSinceShower);
        lines.add("soap_uses"   + SEP + state.soapUses);
        lines.add("soap_grace"  + SEP + state.soapGraceDays);

        // Pill
        lines.add("pill_sub"    + SEP + state.pillSubscribed);
        lines.add("pill_expiry" + SEP + state.pillExpiryDay);
        // Pregnancy stages
        lines.add("preg_stage"  + SEP + state.pregnancyStage);
        lines.add("preg_last_sc"+ SEP + state.lastPregnancyScene);
        lines.add("child_gender"+ SEP + state.childGender);
        // Child
        lines.add("child_exists"+ SEP + state.childExists);
        lines.add("child_given" + SEP + state.childGivenAway);
        lines.add("child_name"  + SEP + state.childName);
        lines.add("child_bday"  + SEP + state.childBirthDay);

        // Pregnancy timeline
        lines.add("preg_start"   + SEP + state.pregnancyStartDay);
        lines.add("unprot_sex"   + SEP + state.lastUnprotectedSexDay);
        lines.add("ms_shown"     + SEP + state.morningSicknessShown);
        lines.add("breast_surg"  + SEP + state.breastSurgeryDay);

        // Vehicle ownership
        lines.add("car_type"     + SEP + state.carOwnershipType);
        lines.add("car_model"    + SEP + state.carModel);
        lines.add("car_tier"     + SEP + state.carTier);
        lines.add("car_rent_days"+ SEP + state.carRentalDaysLeft);
        lines.add("car_rent_ban" + SEP + state.carRentalBanExpiry);
        lines.add("car_fin_pmt"  + SEP + state.carFinancePayment);
        lines.add("car_fin_due"  + SEP + state.carFinanceNextDue);
        lines.add("car_fin_left" + SEP + state.carFinanceMonthsLeft);

        // Hickey and pregnancy source tracking
        if (!state.neckHickeyFromNpcId.isEmpty())
            lines.add("neck_hickey_npc" + SEP + state.neckHickeyFromNpcId);
        if (!state.breastHickeyFromNpcId.isEmpty())
            lines.add("breast_hickey_npc" + SEP + state.breastHickeyFromNpcId);
        if (!state.pregnantByNpcId.isEmpty())
            lines.add("pregnant_by_npc" + SEP + state.pregnantByNpcId);

        // Size adaptation tracking
        for (java.util.Map.Entry<String, Integer> e : state.sizeAdaptation.entrySet()) {
            lines.add("size_adapt" + SEP + e.getKey() + SEP + e.getValue());
        }
        for (java.util.Map.Entry<String, Integer> e : state.lastSexWithSize.entrySet()) {
            lines.add("size_last_day" + SEP + e.getKey() + SEP + e.getValue());
        }
            lines.add("money" + SEP + state.money);
            lines.add("rent" + SEP + state.rent);
            lines.add("happiness" + SEP + state.happiness);
            lines.add("confidence" + SEP + state.confidence);
            lines.add("willpower" + SEP + state.willpower);
            lines.add("stress" + SEP + state.stress);
            lines.add("arousal" + SEP + state.arousal);
            lines.add("fitness" + SEP + state.fitness);
            lines.add("thrills" + SEP + state.thrills);
            lines.add("reputation" + SEP + state.reputation);
            lines.add("slut_rep" + SEP + state.slut_rep);
            lines.add("drunk" + SEP + state.drunk);
            lines.add("");

            // Housing
            lines.add("housing_wp_cap" + SEP + state.housingWillpowerCap);
            lines.add("housing_wp_recovery" + SEP + state.housingWillpowerRecovery);
            lines.add("housing_stress_reduction" + SEP + state.housingStressReduction);
            lines.add("housing_stress_min" + SEP + state.housingStressMin);
            lines.add("");

            // Season + neighbourhood
            lines.add("current_season"       + SEP + state.currentSeason);
            lines.add("current_neighbourhood" + SEP + (state.currentNeighbourhood != null ? state.currentNeighbourhood : ""));
            lines.add("");

            // Work mode system
            lines.add("work_mode"         + SEP + state.workMode);
            lines.add("office_rep"        + SEP + state.officeRep);
            lines.add("promo_progress"    + SEP + state.promotionProgress);
            lines.add("monthly_rep_gain"  + SEP + state.monthlyRepGain);
            lines.add("rep_month_start"   + SEP + state.repMonthStart);
            lines.add("");

            // Cycle
            lines.add("cycle_day" + SEP + state.cycleDay);
            lines.add("cycle_length" + SEP + state.cycleLength);
            lines.add("");

            // Job
            lines.add("job_id" + SEP + (state.currentJobId != null ? state.currentJobId : ""));
            lines.add("days_worked_this_pay" + SEP + state.daysWorkedThisPay);
            lines.add("");

            // Scene / current state
            lines.add("current_scene" + SEP + (state.currentScene != null ? state.currentScene : ""));
            lines.add("starting_outfits_only" + SEP + state.startingOutfitsOnly);
            lines.add("");

            // Outfit
            lines.add("outfit_bra" + SEP + nvl(state.outfitBra));
            lines.add("outfit_upper" + SEP + nvl(state.outfitUpper));
            lines.add("outfit_lower" + SEP + nvl(state.outfitLower));
            lines.add("outfit_overcoat" + SEP + nvl(state.outfitOvercoat));
            lines.add("outfit_underwear" + SEP + nvl(state.outfitUnderwear));
            lines.add("outfit_socks" + SEP + nvl(state.outfitSocks));
            lines.add("outfit_shoes" + SEP + nvl(state.outfitShoes));
            lines.add("");

            // Traits
            lines.add("traits" + SEP + String.join(",", state.traits));
            lines.add("");

            // Timed traits (traitName:expiryDay)
            List<String> timed = new ArrayList<>();
            for (Map.Entry<String, Integer> e : state.timedTraits.entrySet())
                timed.add(e.getKey() + ":" + e.getValue());
            lines.add("timed_traits" + SEP + String.join(",", timed));
            lines.add("");

            // Owned clothing
            lines.add("owned_clothing" + SEP + String.join(",", state.ownedClothing));
            lines.add("");

            // NPC rep (only non-zero)
            for (Map.Entry<String, Integer> e : state.npcRep.entrySet())
                if (e.getValue() != 0)
                    lines.add("npc_rep_" + e.getKey() + SEP + e.getValue());
            lines.add("");

            // NPC memory — flat map with "npcId:memKey" as key
            for (Map.Entry<String,String> e : state.npcMemory.entrySet()) {
                if (!e.getValue().isEmpty())
                    lines.add("npc_mem_" + e.getKey().replace(":", "__") + SEP + e.getValue());
            }
            lines.add("");

            // Discovered locations
            if (!state.discoveredLocations.isEmpty())
                lines.add("discovered_locs" + SEP + String.join(",", state.discoveredLocations));

            // Landlord / housing NPC
            if (state.payPerDayBonus != 0)
                lines.add("pay_bonus" + SEP + state.payPerDayBonus);
            if (state.currentLandlordNpc != null)
                lines.add("landlord_npc" + SEP + state.currentLandlordNpc);
            // Alcoholism tracking — persists across saves
            if (state.drunk13DaysThisWeek > 0)
                lines.add("drunk13_this_week" + SEP + state.drunk13DaysThisWeek);
            if (state.heavyWeeksInARow > 0)
                lines.add("heavy_weeks_in_a_row" + SEP + state.heavyWeeksInARow);
            if (state.dayOfWeek != 0)
                lines.add("day_of_week" + SEP + state.dayOfWeek);

            // Checksum — simple sum of all line lengths for corruption detection
            long checksum = lines.stream().mapToLong(String::length).sum();
            lines.add("checksum" + SEP + checksum);

            // Write to temp file first
            java.nio.file.Path realPath = Paths.get(path);
            java.nio.file.Path tmpPath  = Paths.get(path + ".tmp");
            java.nio.file.Path bakPath  = Paths.get(path + ".bak");

            Files.write(tmpPath, lines);

            // Rotate: real → .bak, then tmp → real (atomic on most filesystems)
            if (Files.exists(realPath))
                Files.move(realPath, bakPath,
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            Files.move(tmpPath, realPath,
                java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                java.nio.file.StandardCopyOption.ATOMIC_MOVE);

            System.out.println("[SaveManager] Saved to " + path);
            return true;

        } catch (Exception e) {
            CrashReporter.reportError("SaveManager.writeFile failed: " + path, e);
            return false;
        }
    }

    // ── Reading ───────────────────────────────────────────────────────────────

    /** Check checksum validity. Returns true if file is OK or has no checksum (old save). */
    public boolean validateFile(String path) {
        try {
            java.nio.file.Path p = Paths.get(path);
            if (!Files.exists(p)) return false;
            List<String> lines = Files.readAllLines(p);
            long stored = -1; long computed = 0;
            for (String line : lines) {
                if (line.startsWith("checksum" + SEP))
                    stored = Long.parseLong(line.substring(("checksum" + SEP).length()).trim());
                else computed += line.length();
            }
            return stored < 0 || stored == computed;
        } catch (Exception e) { return false; }
    }

    /** Load save, falling back to .bak if the primary file fails validation. */
    public boolean loadWithFallback(String path) {
        if (validateFile(path)) return readFile(path);
        String bak = path + ".bak";
        System.err.println("[SaveManager] Save file appears corrupt — trying backup: " + bak);
        if (validateFile(bak)) return readFile(bak);
        System.err.println("[SaveManager] Backup also invalid or missing.");
        return false;
    }

    private boolean readFile(String path) {
        if (!new File(path).exists()) return false;
        try {
            List<String> lines = Files.readAllLines(Paths.get(path));
            Map<String, String> data = new LinkedHashMap<>();
            for (String line : lines) {
                if (line.startsWith("#") || line.isBlank()) continue;
                int eq = line.indexOf(SEP);
                if (eq < 0) continue;
                String key = line.substring(0, eq).trim();
                String val = line.substring(eq + 1).trim();
                // scene_played has format: scene_played=scene_id=dayNumber
                // Multiple entries exist, so handle them here before the flat map
                if ("scene_played".equals(key)) {
                    int sep2 = val.lastIndexOf(SEP);
                    if (sep2 > 0) {
                        try {
                            String sceneId = val.substring(0, sep2).trim();
                            int day = Integer.parseInt(val.substring(sep2 + 1).trim());
                            state.sceneLastPlayedDay.put(sceneId, day);
                        } catch (NumberFormatException ignored) {}
                    }
                    continue;
                }
                if ("condoms".equals(key))     { state.condomCount            = intVal2(val,0);   continue; }
                if ("soap".equals(key))        { state.soapCount              = intVal2(val,0);   continue; }
                if ("sunscreen".equals(key))   { state.sunscreenCount         = intVal2(val,0);   continue; }
                if ("is_wet".equals(key))       { state.isWet = "true".equals(val); continue; }
                if ("gag_reflex".equals(key))   { try{state.gagReflex=Integer.parseInt(val);}catch(Exception e){} continue; }
                if ("throat_adapt".equals(key)) {
                    for (String _p : val.split(",")) { String[] kv=_p.split(":"); if(kv.length==2) try{state.throatAdaptation.put(kv[0],Integer.parseInt(kv[1]));}catch(Exception e){} }
                    continue;
                }
                if ("video_npc".equals(key))     { state.videoTakenByNpcId="null".equals(val)?"":(val==null?"":val); continue; }
                if ("video_consent".equals(key)) { state.videoConsentGiven="true".equals(val); continue; }
                if ("video_posted".equals(key))  { state.videoWasPosted="true".equals(val); continue; }
                if ("video_partner".equals(key)) { state.videoSentToPartner="true".equals(val); continue; }
                if ("preg_from_sa".equals(key))  { state.pregnancyFromSA="true".equals(val); continue; }
                if ("child_count".equals(key))   {
                    try { int n=Integer.parseInt(val);
                    while(state.children.size()<n) { GameState.Child c=new GameState.Child(); state.children.add(c); }
                    } catch(Exception e){} continue;
                }
                if (key.startsWith("kid_")) {
                    try {
                        String[] p2=key.split("_",3); int idx2=Integer.parseInt(p2[1]); String f2=p2[2];
                        while(state.children.size()<=idx2) state.children.add(new GameState.Child());
                        GameState.Child _c=state.children.get(idx2);
                        switch(f2){
                            case "name":   _c.name=val; break;
                            case "gender": if(!val.isEmpty())_c.gender=val.charAt(0); break;
                            case "bd":     _c.birthDay=Integer.parseInt(val); break;
                            case "away":   _c.givenAway="true".equals(val); break;
                            case "sa":     _c.fromSA="true".equals(val); break;
                        }
                    } catch(Exception e){}
                    continue;
                }
                if ("video_content_type".equals(key)){ state.videoContentType="null".equals(val)?"":(val==null?"":val); continue; }
                if ("video_mc_drunk".equals(key))     { state.videoMcWasDrunk="true".equals(val); continue; }
                if ("employer_found".equals(key))     { state.employerFoundOnlineContent="true".equals(val); continue; }
                if ("leak_found".equals(key))      { state.leakFoundOnline="true".equals(val); continue; }
                if ("content_tier".equals(key))    { try{state.contentLawyerTier=Integer.parseInt(val);}catch(Exception e){} continue; }
                if ("content_removed".equals(key)) { state.contentRemoved="true".equals(val); continue; }
                if ("sa_suit_filed".equals(key))   { state.saSuitFiled="true".equals(val); continue; }
                if ("sa_suit_won".equals(key))     { state.saSuitWon="true".equals(val); continue; }
                if ("sa_suit_payout".equals(key))  { try{state.saSuitPayout=Integer.parseInt(val);}catch(Exception e){} continue; }
                if ("sa_suit_tier".equals(key))    { state.saSuitLawyerTier="null".equals(val)?"":(val==null?"":val); continue; }
                if ("pc_tier".equals(key))          { try{state.pcTier=Integer.parseInt(val);}catch(Exception e){} continue; }
                if ("gaming_chair".equals(key))     { state.hasGamingChair="true".equals(val); continue; }
                if ("gaming_skill".equals(key))     { try{state.gamingSkill=Integer.parseInt(val);}catch(Exception e){} continue; }
                if ("streaming_active".equals(key)) { state.streamingActive="true".equals(val); continue; }
                if ("stream_followers".equals(key)) { try{state.streamingFollowers=Integer.parseInt(val);}catch(Exception e){} continue; }
                if ("stream_income".equals(key))    { try{state.streamingWeeklyIncome=Integer.parseInt(val);}catch(Exception e){} continue; }
                if ("stream_earned".equals(key))    { try{state.streamingTotalEarned=Integer.parseInt(val);}catch(Exception e){} continue; }
                if ("is_pro_gamer".equals(key))     { state.isProGamer="true".equals(val); continue; }
                if ("carry_permit".equals(key)) { state.hasCarryPermit="true".equals(val); continue; }
                if ("carrying_gun".equals(key)) { state.carryingGun="true".equals(val); continue; }
                if ("equipped_gun".equals(key)) { state.equippedGunId="null".equals(val)?"":(val==null?"":val); continue; }
                if ("pepper_spray".equals(key)) { state.hasPepperSpray="true".equals(val); continue; }
                if ("has_taser".equals(key))    { state.hasTaser="true".equals(val); continue; }
                if ("owned_guns".equals(key))   { if(!val.isEmpty())for(String g:val.split(","))state.ownedGuns.add(g); continue; }
                if ("sf_active".equals(key))    { state.slutFansActive = "true".equals(val); continue; }
                if ("sf_followers".equals(key)) { try{state.slutFansFollowers=Integer.parseInt(val);}catch(Exception e){} continue; }
                if ("sf_posts".equals(key))     { try{state.slutFansTotalPosts=Integer.parseInt(val);}catch(Exception e){} continue; }
                if ("sf_days_since".equals(key)){ try{state.slutFansDaysSincePost=Integer.parseInt(val);}catch(Exception e){} continue; }
                if ("sf_weekly".equals(key))    { try{state.slutFansWeeklyIncome=Integer.parseInt(val);}catch(Exception e){} continue; }
                if ("sf_total_earned".equals(key)){try{state.slutFansTotalEarned=Integer.parseInt(val);}catch(Exception e){} continue; }
                if ("sf_toys".equals(key))      { if(!val.isEmpty()) for(String t:val.split(",")) state.ownedToys.add(t); continue; }
                if ("sunburn_days".equals(key))   { try { state.sunburnDays=Integer.parseInt(val); } catch(Exception e){} continue; }
                if ("annual_gross".equals(key))   { try { state.annualGrossEarned=Integer.parseInt(val); } catch(Exception e){} continue; }
                if ("annual_withheld".equals(key)){ try { state.annualTaxWithheld=Integer.parseInt(val); } catch(Exception e){} continue; }
                if ("tax_filing_due".equals(key)) { state.taxFilingDue="true".equals(val); continue; }
                if ("bar_shift".equals(key))       { state.barStaffShift          = val;                continue; }
                if ("daily_outfit".equals(key))    { state.dailyOutfitName        = val;                continue; }
                // Outfit reconstruction
                if ("saved_outfit_count".equals(key)) {
                    try {
                        int cnt = Integer.parseInt(val);
                        while (state.savedOutfits.size() < cnt)
                            state.savedOutfits.add(new GameState.SavedOutfit());
                    } catch (Exception e) {}
                    continue;
                }
                if (key.startsWith("outfit_")) {
                    try {
                        String[] parts = key.split("_", 3);
                        int idx2 = Integer.parseInt(parts[1]);
                        String field = parts[2];
                        while (state.savedOutfits.size() <= idx2)
                            state.savedOutfits.add(new GameState.SavedOutfit());
                        GameState.SavedOutfit _o = state.savedOutfits.get(idx2);
                        String rv = "null".equals(val) ? null : val;
                        switch (field) {
                            case "name":  _o.name=val;      break;
                            case "upper": _o.upper=rv;      break;
                            case "lower": _o.lower=rv;      break;
                            case "bra":   _o.bra=rv;        break;
                            case "under": _o.underwear=rv;  break;
                            case "shoes": _o.shoes=rv;      break;
                            case "socks": _o.socks=rv;      break;
                            case "coat":  _o.overcoat=rv;   break;
                        }
                    } catch (Exception e) {}
                    continue;
                }

                if ("photo_by".equals(key))        { state.photoTakenByNpcId      = val;                continue; }
                if ("photo_leak".equals(key))      { state.photoWasLeaked         = "true".equals(val); continue; }
                if ("photo_leak_npc".equals(key))  { state.photoLeakedByNpcId     = val;                continue; }
                if ("partner_photo".equals(key))   { state.partnerKnowsAboutPhoto = "true".equals(val); continue; }
                if ("days_shower".equals(key)) { state.daysSinceShower = intVal2(val,0); continue; }
                if ("soap_uses".equals(key))   { state.soapUses        = intVal2(val,0); continue; }
                if ("soap_grace".equals(key))  { state.soapGraceDays   = intVal2(val,0); continue; }
                if ("pill_sub".equals(key))    { state.pillSubscribed    = "true".equals(val);    continue; }
                if ("pill_expiry".equals(key)) { state.pillExpiryDay     = intVal2(val,0);         continue; }
                if ("preg_stage".equals(key))  { state.pregnancyStage    = intVal2(val,0);         continue; }
                if ("preg_last_sc".equals(key)){ state.lastPregnancyScene= intVal2(val,0);         continue; }
                if ("child_gender".equals(key)){ state.childGender       = val.isEmpty()?'f':val.charAt(0); continue; }
                if ("child_exists".equals(key)){ state.childExists       = "true".equals(val);    continue; }
                if ("child_given".equals(key)) { state.childGivenAway    = "true".equals(val);    continue; }
                if ("child_name".equals(key))  { state.childName         = val;                    continue; }
                if ("child_bday".equals(key))  { state.childBirthDay     = intVal2(val,0);         continue; }
                if ("preg_start".equals(key))  { state.pregnancyStartDay      = intVal2(val,0);   continue; }
                if ("unprot_sex".equals(key))  { state.lastUnprotectedSexDay  = intVal2(val,0);   continue; }
                if ("ms_shown".equals(key))    { state.morningSicknessShown   = "true".equals(val); continue; }
                if ("breast_surg".equals(key)) { state.breastSurgeryDay       = intVal2(val,0);   continue; }
                if ("car_type".equals(key))      { state.carOwnershipType    = val;             continue; }
                if ("car_model".equals(key))     { state.carModel            = val;             continue; }
                if ("car_tier".equals(key))      { state.carTier             = intVal2(val,0);  continue; }
                if ("car_rent_days".equals(key)) { state.carRentalDaysLeft   = intVal2(val,0);  continue; }
                if ("car_rent_ban".equals(key))  { state.carRentalBanExpiry  = intVal2(val,0);  continue; }
                if ("car_fin_pmt".equals(key))   { state.carFinancePayment   = intVal2(val,0);  continue; }
                if ("car_fin_due".equals(key))   { state.carFinanceNextDue   = intVal2(val,0);  continue; }
                if ("car_fin_left".equals(key))  { state.carFinanceMonthsLeft= intVal2(val,0);  continue; }
                if ("neck_hickey_npc".equals(key))    { state.neckHickeyFromNpcId   = val; continue; }
                if ("breast_hickey_npc".equals(key))  { state.breastHickeyFromNpcId = val; continue; }
                if ("pregnant_by_npc".equals(key))    { state.pregnantByNpcId       = val; continue; }
                if ("size_adapt".equals(key)) {
                    int sep2 = val.lastIndexOf(SEP);
                    if (sep2 > 0) {
                        try {
                            String tier = val.substring(0, sep2).trim();
                            int level = Integer.parseInt(val.substring(sep2 + 1).trim());
                            state.sizeAdaptation.put(tier, level);
                        } catch (NumberFormatException ignored) {}
                    }
                    continue;
                }
                if ("size_last_day".equals(key)) {
                    int sep2 = val.lastIndexOf(SEP);
                    if (sep2 > 0) {
                        try {
                            String tier = val.substring(0, sep2).trim();
                            int day = Integer.parseInt(val.substring(sep2 + 1).trim());
                            state.lastSexWithSize.put(tier, day);
                        } catch (NumberFormatException ignored) {}
                    }
                    continue;
                }
                data.put(key, val);
            }

            // Core stats
            state.dayCount    = intVal(data, "day",        1);
            state.money       = intVal(data, "money",      1500);
            state.rent        = intVal(data, "rent",       0);
            state.happiness   = intVal(data, "happiness",  50);
            state.confidence  = intVal(data, "confidence", 50);
            state.willpower   = intVal(data, "willpower",  50);
            state.stress      = intVal(data, "stress",     20);
            state.arousal     = intVal(data, "arousal",    0);
            state.fitness     = intVal(data, "fitness",    50);
            state.thrills     = intVal(data, "thrills",    0);
            state.reputation  = intVal(data, "reputation", 0);
            state.slut_rep    = intVal(data, "slut_rep",   0);
            state.drunk       = intVal(data, "drunk",      0);

            // Housing
            state.housingWillpowerCap       = intVal(data, "housing_wp_cap",        70);
            state.housingWillpowerRecovery  = intVal(data, "housing_wp_recovery",   8);
            state.housingStressReduction    = intVal(data, "housing_stress_reduction", 3);
            state.housingStressMin          = intVal(data, "housing_stress_min",    45);

            // Season + neighbourhood
            state.currentSeason        = Math.max(0, Math.min(3, intVal(data, "current_season", 0)));
            state.currentNeighbourhood = data.getOrDefault("current_neighbourhood", "");

            // Work mode
            state.workMode          = data.getOrDefault("work_mode",        "normal");
            state.officeRep         = intVal(data, "office_rep",       60);
            state.promotionProgress = intVal(data, "promo_progress",    0);
            state.monthlyRepGain    = intVal(data, "monthly_rep_gain",  0);
            state.repMonthStart     = intVal(data, "rep_month_start",   1);

            // Cycle
            state.cycleDay    = intVal(data, "cycle_day",    14);
            state.cycleLength = intVal(data, "cycle_length", 28);

            // Job
            String jobId = data.get("job_id");
            state.currentJobId       = (jobId != null && !jobId.isEmpty()) ? jobId : null;
            state.daysWorkedThisPay  = intVal(data, "days_worked_this_pay", 0);

            // Scene
            state.currentScene        = data.getOrDefault("current_scene", "intro");
            state.startingOutfitsOnly = boolVal(data, "starting_outfits_only", true);

            // Outfit
            state.outfitBra       = nvlLoad(data.get("outfit_bra"));
            state.outfitUpper     = nvlLoad(data.get("outfit_upper"));
            state.outfitLower     = nvlLoad(data.get("outfit_lower"));
            state.outfitOvercoat  = nvlLoad(data.get("outfit_overcoat"));
            state.outfitUnderwear = nvlLoad(data.get("outfit_underwear"));
            state.outfitSocks     = nvlLoad(data.get("outfit_socks"));
            state.outfitShoes     = nvlLoad(data.get("outfit_shoes"));

            // Traits
            state.traits.clear();
            String traitStr = data.get("traits");
            if (traitStr != null && !traitStr.isEmpty())
                for (String t : traitStr.split(","))
                    if (!t.isBlank()) state.traits.add(t.trim().toLowerCase());

            // Timed traits
            state.timedTraits.clear();
            String timedStr = data.get("timed_traits");
            if (timedStr != null && !timedStr.isEmpty()) {
                for (String entry : timedStr.split(",")) {
                    int colon = entry.lastIndexOf(':');
                    if (colon > 0) {
                        try {
                            state.timedTraits.put(entry.substring(0, colon).trim(),
                                Integer.parseInt(entry.substring(colon+1).trim()));
                        } catch (Exception ignored) {}
                    }
                }
            }

            // Owned clothing
            state.ownedClothing.clear();
            String clothes = data.get("owned_clothing");
            if (clothes != null && !clothes.isEmpty())
                for (String c : clothes.split(","))
                    if (!c.isBlank()) state.ownedClothing.add(c.trim());

            // NPC rep
            state.npcRep.clear();
            for (Map.Entry<String, String> e : data.entrySet()) {
                if (e.getKey().startsWith("npc_rep_")) {
                    try {
                        state.npcRep.put(e.getKey().substring("npc_rep_".length()),
                            Integer.parseInt(e.getValue()));
                    } catch (Exception ignored) {}
                }
            }

            // NPC memory — restore flat map
            state.npcMemory.clear();
            for (Map.Entry<String,String> e : data.entrySet()) {
                if (!e.getKey().startsWith("npc_mem_")) continue;
                // Stored key: npc_mem_<npcId>__<memKey>, restore to "npcId:memKey"
                String composite = e.getKey().substring("npc_mem_".length()).replace("__", ":");
                state.npcMemory.put(composite, e.getValue());
            }

            // Discovered locations
            state.discoveredLocations.clear();
            String discLocs = data.get("discovered_locs");
            if (discLocs != null && !discLocs.isEmpty())
                for (String loc : discLocs.split(","))
                    if (!loc.isBlank()) state.discoverLocation(loc.trim());

            // Landlord
            state.currentLandlordNpc = data.get("landlord_npc");
            if (data.containsKey("pay_bonus"))
                try { state.payPerDayBonus = Integer.parseInt(data.get("pay_bonus")); } catch (Exception ignored) {}
            if (data.containsKey("drunk13_this_week"))  state.drunk13DaysThisWeek = intParse(data.get("drunk13_this_week"), 0);
            if (data.containsKey("heavy_weeks_in_a_row")) state.heavyWeeksInARow  = intParse(data.get("heavy_weeks_in_a_row"), 0);
            if (data.containsKey("day_of_week"))         state.dayOfWeek          = intParse(data.get("day_of_week"), 0);

            System.out.println("[SaveManager] Loaded from " + path);
            return true;

        } catch (Exception e) {
            CrashReporter.reportError("SaveManager.readFile failed: " + path, e);
            return false;
        }
    }

    // ── Meta (slot preview without full load) ─────────────────────────────────

    public static class SaveMeta {
        public boolean exists     = false;
        public String  date       = "";
        public int     day        = 0;
        public int     money      = 0;
        public String  jobId      = "";
        public String  playerName = "";
        public int     season     = 0;
    }

    private SaveMeta readMeta(String path) {
        SaveMeta meta = new SaveMeta();
        if (!new File(path).exists()) return meta;
        try {
            for (String line : Files.readAllLines(Paths.get(path))) {
                if (line.startsWith("#") || line.isBlank()) continue;
                int eq = line.indexOf(SEP);
                if (eq < 0) continue;
                String k = line.substring(0, eq).trim();
                String v = line.substring(eq+1).trim();
                switch (k) {
                    case "save_date":    meta.date       = v; break;
                    case "day":          meta.day        = intParse(v, 0); break;
                    case "money":        meta.money      = intParse(v, 0); break;
                    case "job_id":       meta.jobId      = v; break;
                    case "player_name":  meta.playerName = v; break;
                    case "current_season": meta.season   = intParse(v, 0); break;
                }
                if (!meta.date.isEmpty() && meta.day > 0) break;
            }
            meta.exists = true;
        } catch (Exception ignored) {}
        return meta;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private int intVal(Map<String,String> m, String k, int def) {
        return intParse(m.get(k), def);
    }
    private int intParse(String s, int def) {
        if (s == null || s.isEmpty()) return def;
        try { return Integer.parseInt(s); } catch (Exception e) { return def; }
    }
    private boolean boolVal(Map<String,String> m, String k, boolean def) {
        String s = m.get(k); return s == null ? def : Boolean.parseBoolean(s);
    }
    private String nvl(String s)     { return s != null ? s : ""; }
    private String nvlLoad(String s) { return (s == null || s.isEmpty()) ? null : s; }
    private static String nvl(String s) { return s != null ? s : "null"; }

}
