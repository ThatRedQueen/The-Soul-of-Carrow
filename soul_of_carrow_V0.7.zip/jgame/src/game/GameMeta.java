package game;

/**
 * Central game metadata — version, title, build info.
 * Update this file only when cutting a release.
 */
public class GameMeta {
    public static final String TITLE   = "The Soul of Carrow";
    public static final String VERSION = "0.1.0";
    public static final String BUILD   = "alpha";

    /** Full version string for display e.g. "v0.1.0-alpha" */
    public static String versionString() {
        return "v" + VERSION + (BUILD.isEmpty() ? "" : "-" + BUILD);
    }
}
