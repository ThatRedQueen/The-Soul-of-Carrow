package game.ui;

import game.*;
import game.data.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.util.function.IntConsumer;

public class InterviewPanel extends JPanel {

    private final GameState      state;
    private final NpcLoader      npcs;
    private final JobLoader      jobs;
    private final InterviewLoader interviews;
    private final Runnable       onComplete;

    private final JTextArea textArea;
    private final JPanel    choicesPanel;

    private JobData       currentJob;
    private InterviewData currentInterview;
    private NpcData       boss;

    private int     smallTalkIdx   = 0;
    private int     questionIdx    = 0;
    private int     wrongAnswers   = 0;
    private int     forgiveness    = 0;
    private boolean inQuiz         = false;
    private boolean goodImpression = false;
    private boolean flashUsed      = false;
    private int     signOnBonusPending = 0;

    // Trait helpers
    private boolean isShy()          { return state.hasTrait("Shy"); }
    private boolean isOutgoing()     { return state.hasTrait("Outgoing"); }
    private boolean isStreetwise()   { return state.hasTrait("Streetwise"); }
    private boolean isDom()          { return state.hasTrait("Dom"); }
    private boolean isProvocative()  { return state.isProvocativeSexual(); }
    private boolean isPrude()        { return state.isPrude(); }
    private boolean isDemure()       { return state.isDemure(); }
    private boolean isSlut()         { return state.isSlut(); }
    private boolean isWhore()        { return state.isWhore(); }
    private boolean isAttractive()  { return state.hasTrait("Pretty") || state.hasTrait("Beautiful") ||
                                             state.hasTrait("Sexy")   || state.hasTrait("Elegant")   ||
                                             state.hasTrait("Otherworldly_Beauty"); }
    private boolean isExhibitionist(){ return state.hasTrait("Likes_Being_Watched") ||
                                              state.hasTrait("Loves_Being_Watched")  ||
                                              state.hasTrait("Risky_Exhibitionist"); }
    private boolean isHighExhibitionist(){ return state.hasTrait("Loves_Being_Watched"); }
    private boolean bossIsSleazy()  { return boss != null && boss.traits != null &&
                                             boss.traits.stream().anyMatch(t ->
                                                 t.equalsIgnoreCase("Sleazy") ||
                                                 t.equalsIgnoreCase("Possessive")); }

    private boolean isNipping()     {
        return state.hasTrait("nipping") || state.hasTrait("pierced_nipping_prominent");
    }
    private boolean isBraless()     {
        return state.outfitBra == null;
    }
    /** True if braless + thin/sheer top — uses GameState body flags. */
    private boolean isExposed()     {
        return isBraless() && (state.getBodyFlag("flag_wearing_thin_top")
                            || state.getBodyFlag("flag_seethrough_top")
                            || state.getBodyFlag("flag_braless"));
    }


    public InterviewPanel(GameState state, NpcLoader npcs, JobLoader jobs,
                          InterviewLoader interviews, Runnable onComplete) {
        this.state      = state;
        this.npcs       = npcs;
        this.jobs       = jobs;
        this.interviews = interviews;
        this.onComplete = onComplete;

        setBackground(Colors.BG);
        setLayout(new BorderLayout());

        textArea = new JTextArea();
        textArea.setEditable(false); textArea.setOpaque(false);
        textArea.setForeground(Colors.TEXT);
        textArea.setFont(new Font("Georgia", Font.PLAIN, 54));
        textArea.setLineWrap(true); textArea.setWrapStyleWord(true);
        textArea.setBorder(BorderFactory.createEmptyBorder(30, 44, 20, 44));

        JScrollPane scroll = new JScrollPane(textArea);
        scroll.setOpaque(false); scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        choicesPanel = new JPanel();
        choicesPanel.setOpaque(false);
        choicesPanel.setLayout(new BoxLayout(choicesPanel, BoxLayout.Y_AXIS));
        choicesPanel.setBorder(BorderFactory.createEmptyBorder(8, 44, 28, 44));

        add(scroll,       BorderLayout.CENTER);
        add(choicesPanel, BorderLayout.SOUTH);
    }

    public void startInterview(String jobId) {
        currentJob       = jobs.get(jobId);
        currentInterview = interviews.get(jobId);
        smallTalkIdx     = 0;
        questionIdx      = 0;
        wrongAnswers     = 0;
        goodImpression   = false;
        inQuiz           = false;
        flashUsed        = false;
        signOnBonusPending = 0;

        if (currentJob == null || currentInterview == null) {
            setText("Something went wrong loading that interview."); return;
        }

        boss = npcs.get(currentJob.boss_npc_id);

        // Forgiveness calculation
        forgiveness = 0;
        if (isAttractive()) forgiveness = 1;
        if (bossIsSleazy() && isAttractive()) forgiveness = 2;

        showArrival();
    }

    // ── Arrival ──────────────────────────────────────────────────
    private void showArrival() {
        String bossName   = boss != null ? boss.name : "the manager";
        String workplace  = currentJob.label.split("—")[0].trim();

        StringBuilder text = new StringBuilder();
        text.append("You arrive at ").append(workplace).append(" for your interview.\n\n");

        // Streetwise gets an internal read on the boss
        if (isStreetwise() && bossIsSleazy()) {
            text.append("Something about the way ").append(bossName)
                .append(" looks you over before saying a word tells you everything you need to know about him. You file it away.\n\n");
        } else if (isShy()) {
            text.append("The waiting area feels smaller than it is. You remind yourself you prepared for this.\n\n");
        } else if (isOutgoing()) {
            text.append("You've done this before. You walk in like you belong here.\n\n");
        }

        text.append(bossName).append(" appears and looks you over.\n\n");
        // Nipping/exposed reactions on arrival
        if (bossIsSleazy()) {
            if (isExposed()) {
                text.append("His eyes drop to your chest for half a second before coming back up. He doesn't quite manage to make it look accidental.\n\n");
            } else if (isNipping()) {
                text.append("His eyes catch something — a glance, brief enough to be deniable — and his expression shifts by a fraction.\n\n");
            }
        }
        text.append("\"").append(getArrivalLine()).append("\"");
        // Record that player caught him looking (for exhibitionist offer later)
        if (bossIsSleazy() && (isNipping() || isExposed())) {
            state.addTrait("__interview_boss_noticed__"); // ephemeral, cleared after interview
        }


        setText(text.toString());

        List<String> choices = new ArrayList<>();
        List<Runnable> actions = new ArrayList<>();

        if (isPrude() || isDemure()) {
            choices.add("Straighten your posture and wait to be addressed properly.");
            actions.add(() -> { showNextSmallTalk(); });
            choices.add("\"Good afternoon. I appreciate you taking the time.\"");
            actions.add(() -> { goodImpression = true; showNextSmallTalk(); });
        } else if (isShy()) {
            choices.add("Smile nervously and take a seat.");
            actions.add(() -> { showNextSmallTalk(); });
            choices.add("\"Thank you for seeing me.\"");
            actions.add(() -> { goodImpression = true; showNextSmallTalk(); });
        } else if (isOutgoing()) {
            choices.add("Shake their hand and introduce yourself with a smile.");
            actions.add(() -> { goodImpression = true; showNextSmallTalk(); });
            choices.add("\"Great place. I've been looking forward to this.\"");
            actions.add(() -> { goodImpression = true; showNextSmallTalk(); });
        } else {
            choices.add("Take a seat and wait.");
            actions.add(() -> { showNextSmallTalk(); });
            choices.add("Smile and introduce yourself.");
            actions.add(() -> { goodImpression = true; showNextSmallTalk(); });
        }

        // Disposition extras with sleazy boss
        if (bossIsSleazy()) {
            if (isProvocative()) {
                choices.add("Let the silence hang and hold eye contact a beat too long.");
                actions.add(() -> { goodImpression = true; showNextSmallTalk(); });
            }
            if (isDom()) {
                choices.add("Meet his gaze and don't look away first.");
                actions.add(() -> { showNextSmallTalk(); });
            }
            if (isWhore()) {
                choices.add("Glance around the office once, assessing. Then sit down like you already work here.");
                actions.add(() -> {
                    goodImpression = true;
                    setText("He notices. Most people don't carry themselves like that in an interview.\n\n\"Interesting,\" he says, and means it.");
                    addContinueButton(this::showNextSmallTalk);
                });
            }
            if (isSlut() && isAttractive()) {
                choices.add("Give him a warm smile and settle in comfortably. No performance — just ease.");
                actions.add(() -> { goodImpression = true; showNextSmallTalk(); });
            }
            if (isPrude() && isStreetwise()) {
                choices.add("[Internal: He's already looked you over twice. File it away.] Smile professionally and sit.");
                actions.add(() -> { showNextSmallTalk(); });
            }
        }

        showChoicesFromLists(choices, actions);
    }

    private String getArrivalLine() {
        if (boss == null) return "Have a seat. I'll be right with you.";
        if (bossIsSleazy())
            return "Well. This is a pleasant surprise. Come on in.";
        if (boss.personality.equalsIgnoreCase("WARM"))
            return "You must be here for the position. Come in — can I get you anything?";
        if (boss.personality.equalsIgnoreCase("SELFISH") || boss.personality.equalsIgnoreCase("COLD"))
            return "You're on time. Sit down.";
        return "Have a seat. We'll get started in a minute.";
    }

    // ── Small talk ───────────────────────────────────────────────
    private void showNextSmallTalk() {
        if (smallTalkIdx >= currentInterview.small_talk.size()) {
            showQuizIntro(); return;
        }
        InterviewData.SmallTalk st = currentInterview.small_talk.get(smallTalkIdx);
        smallTalkIdx++;
        String bossName = boss != null ? boss.name : "They";
        setText(bossName + ":\n\n\"" + st.boss_line + "\"");

        List<String> labels  = new ArrayList<>();
        List<Runnable> acts  = new ArrayList<>();

        // Build standard answers but with trait-modified versions
        for (InterviewData.Answer a : st.answers) {
            String label = a.text;
            // Shy player gets bracketed hints
            if (isShy() && !a.positive) label = label + "  [nervous]";
            // Nipping + shy: add internal note on all choices
            if (isNipping() && isShy()) label = label + "  [you're very aware of how you're sitting]";
            labels.add(label);
            final boolean positive = a.positive;
            final String response  = a.response;
            acts.add(() -> {
                if (positive) goodImpression = true;
                String resp = (response != null && !response.isEmpty()) ? "\"" + response + "\"\n\n" : "";
                String followup = getTraitSmallTalkFollowup(positive);
                setText(resp + followup);
                addContinueButton(this::showNextSmallTalk);
            });
        }

        // Sleazy boss + attractive = extra flirty option
        if (bossIsSleazy() && isAttractive() && (isProvocative() || isOutgoing())) {
            labels.add("Give a slow smile and let the question hang a moment. \"Depends on who's asking.\"");
            acts.add(() -> {
                goodImpression = true;
                setText("His expression shifts — interested. He clears his throat.\n\n\"Ha. Fair enough.\"");
                addContinueButton(this::showNextSmallTalk);
            });
        }

        showChoicesFromLists(labels, acts);
    }

    private String getTraitSmallTalkFollowup(boolean positive) {
        if (positive && isWhore())      return "He responds to the confidence. Something shifts slightly in his favour toward you.";
        if (positive && isSlut())       return "The ease of it catches him slightly off guard. He nods, satisfied.";
        if (!positive && isPrude())     return "You gave the honest answer. Whether it costs you is his problem.";
        if (!positive && isDemure())    return "You keep your expression neutral. You didn't lie, and you won't start.";
        if (positive && isOutgoing())   return "He seems satisfied with that. The energy in the room shifts slightly in your favour.";
        if (!positive && isShy())       return "You wince internally. Not the best answer, but it's out now.";
        if (positive && isDom())        return "You hold his gaze as you say it. He notices.";
        if (!positive && isStreetwise()) return "You know it wasn't the right answer, but you weren't going to lie.";
        if (positive && isProvocative()) return "Delivered with just enough edge. He's paying attention now.";
        // Outfit state context
        if (isNipping() && bossIsSleazy() && positive) return "He nods — though his eyes drift for a half-second before coming back to your face.";
        if (isExposed() && bossIsSleazy() && positive) return "He seems very satisfied with that answer. He's been very present throughout.";
        if (isNipping() && isShy())  return "You manage it. You're acutely aware of how the room feels right now but you manage it.";
        if (isExposed() && isOutgoing()) return "You delivered that with the ease of someone who doesn't particularly mind being in this room, in this outfit.";
        return positive ? "He nods." : "He moves on without much reaction.";

    }

    // ── Quiz intro ───────────────────────────────────────────────
    private void showQuizIntro() {
        // First show job briefing, then quiz
        showJobBriefing();
    }

    private void showJobBriefing() {
        String bossName = boss != null ? boss.name : "They";
        StringBuilder text = new StringBuilder();

        // Streetwise gets an off feeling with Richard
        if (isStreetwise() && bossIsSleazy()) {
            text.append("Something about the way he sets the page down — too deliberate, too unhurried — gives you a faint unease you can't quite name. You keep your expression neutral.\n\n");
        }

        // Boss-voice intro to briefing
        if (bossIsSleazy()) {
            text.append(bossName).append(" leans back and folds his hands.\n\n");
            text.append("\"Before we get to the test — let me tell you what you'd actually be walking into.\"\n\n");
        } else if (boss != null && boss.personality.equalsIgnoreCase("WARM")) {
            text.append(bossName).append(" smiles and slides a page across the desk.\n\n");
            text.append("\"Let me tell you a bit about what the role actually looks like day to day.\"\n\n");
        } else {
            text.append(bossName).append(" pulls out a sheet and sets it in front of you.\n\n");
            text.append("\"Here's what the position involves.\"\n\n");
        }

        // Job terms
        text.append("— ").append(currentJob.label).append("\n");
        text.append("— ").append(currentJob.slots_per_day * 2).append(" hours per shift\n");
        text.append("— Working: ").append(String.join(", ", currentJob.work_days)).append("\n");
        text.append("— ").append(currentJob.daysPerWeek()).append(" days per week\n\n");

        // Pay details
        text.append("Pay:\n");
        text.append("— $").append(currentJob.grossPaycheck()).append(" gross per paycheck");
        text.append(" (paid ").append(currentJob.payFrequencyLabel()).append(")\n");

        if (currentJob.under_the_table) {
            text.append("— Paid cash, off the books. No tax withheld.\n");
            text.append("— $").append(currentJob.netPaycheck()).append(" in hand each time.\n");
        } else {
            text.append("— Tax bracket: ").append(currentJob.taxBracketLabel()).append("\n");
            text.append("— $").append(currentJob.taxAmount()).append(" withheld per paycheck\n");
            text.append("— $").append(currentJob.netPaycheck()).append(" take-home per paycheck\n");
        }

        // Sign-on bonus — Richard only, if player is stunning
        int signOnBonus = 0;
        if (bossIsSleazy() && currentJob.id.equals("skyline_office")) {
            boolean isStunning = state.hasTrait("Beautiful") || state.hasTrait("Sexy") ||
                                 state.hasTrait("Elegant")   || state.hasTrait("Otherworldly_Beauty");
            if (isStunning) {
                boolean largeChest = state.hasTrait("Breasts_D") || state.hasTrait("Breasts_DD") ||
                                     state.hasTrait("Breasts_E") || state.hasTrait("Breasts_F");
                signOnBonus = largeChest ? 750 : 500;
                text.append("\n");
                text.append("He pauses, glancing up from the sheet. His tone shifts — still casual, almost offhand.\n\n");
                if (state.hasTrait("Otherworldly_Beauty")) {
                    text.append("\"Oh — and we do a sign-on bonus for the right candidate. $").append(signOnBonus).append(". Consider it a... welcome gift.\"\n");
                } else {
                    text.append("\"We also offer a sign-on bonus for candidates who fit the culture. $").append(signOnBonus).append(", paid on your first week.\"\n");
                }
                if (isStreetwise()) {
                    text.append("\nYou note the way his eyes haven't quite left you since you sat down. The bonus feels less like policy and more like an opinion.");
                }
            }
        }
        final int bonusAmount = signOnBonus;

        // Boss follow-up
        text.append("\n");
        if (bossIsSleazy()) {
            text.append("\"Any questions before we move on?\"\n\nHe's already looking at you like the answer is irrelevant.");
        } else if (boss != null && boss.personality.equalsIgnoreCase("WARM")) {
            text.append("\"Any questions about any of that?\"");
        } else {
            text.append("\"Clear enough?\"");
        }

        setText(text.toString());

        List<String> choices = new ArrayList<>();
        List<Runnable> acts  = new ArrayList<>();

        choices.add("\"Sounds good. I'm ready for the questions.\"");
        acts.add(() -> { signOnBonusPending = bonusAmount; showActualQuizIntro(); });

        if (currentJob.under_the_table) {
            choices.add("\"Off the books — is that something I should be concerned about?\"");
            acts.add(() -> {
                String response = bossIsSleazy()
                    ? "\"Concerned?\" He smiles slowly. \"Sweetheart, half this city runs that way. You want the job or not?\""
                    : "\"It's how we've always done it. Your call.\"";
                setText(response);
                addContinueButton(() -> { signOnBonusPending = bonusAmount; showActualQuizIntro(); });
            });
        }

        if (!currentJob.under_the_table) {
            choices.add("Ask about raises or advancement.");
            acts.add(() -> {
                String response = boss != null && boss.personality.equalsIgnoreCase("WARM")
                    ? "\"We do reviews every six months. Do well and there's room to grow.\""
                    : "\"We'll cross that bridge if we get there.\"";
                setText("\"" + response + "\"");
                addContinueButton(() -> { signOnBonusPending = bonusAmount; showActualQuizIntro(); });
            });
        }

        if (bonusAmount > 0 && isStreetwise()) {
            choices.add("\"The sign-on bonus — is that standard, or is it specific to me?\"");
            acts.add(() -> {
                setText("He holds your gaze a beat too long before smiling.\n\n\"Let's just say we invest in people who fit.\"\n\nHe moves on before you can follow up.");
                addContinueButton(() -> { signOnBonusPending = bonusAmount; showActualQuizIntro(); });
            });
        }

        // ── Nipping / Exposed → exhibitionist salary flash offer ─────────────────
        boolean bossNoticed = state.hasTrait("__interview_boss_noticed__");
        if (bossIsSleazy() && bossNoticed) {
            if (isExposed() || isNipping()) {
                // Catch him looking — always available when visible
                choices.add("[You caught him looking. Say nothing. Let him.] Hold his gaze evenly.");
                acts.add(() -> {
                    StringBuilder t = new StringBuilder();
                    if (isExposed()) {
                        t.append("You don't adjust or cover up.\n\nHe realises you've caught him and holds your gaze instead of looking away.\n\n\"Well,\" he says. \"I can see you're confident.\"\n\nThe room has a different quality now.");
                    } else {
                        t.append("You catch the moment his eyes drop and come back.\n\nYou hold his gaze long enough to confirm he knows you caught it.\n\nHe clears his throat. \"Right. The test.\"\"\n\nHe knows. You both know.");
                    }
                    setText(t.toString());
                    addContinueButton(() -> { signOnBonusPending = bonusAmount; showActualQuizIntro(); });
                });
            }
            // Exhibitionist flash offer — normal exhibitionism or higher
            if (isExhibitionist() && (isNipping() || isExposed())) {
                String flashLabel = isHighExhibitionist()
                    ? "You caught him staring. Hold eye contact and pull your top aside. Brief. Deliberate."
                    : "[If you pass without flashing him, and he's noticed — offer it after.] Make a quiet offer for a starting salary raise.";
                acts.add(() -> {
                    if (flashUsed) {
                        setText("You've already played that card.\n\nHe smiles. \"Once was enough,\" he says.\n\n\"...for now.\"");
                        addContinueButton(() -> { signOnBonusPending = bonusAmount; showActualQuizIntro(); });
                        return;
                    }
                    flashUsed = true;
                    int flashBonus = isHighExhibitionist() ? 200 : 150;
                    int totalBonus = bonusAmount + flashBonus;
                    StringBuilder t = new StringBuilder();
                    if (isHighExhibitionist()) {
                        t.append("You hold his gaze.\n\nYou pull your top aside. One second. Two.\n\nThen it's done.\n\n");
                        t.append("His expression does the thing. Then he catches himself.\n\n");
                        t.append("\"$").append(flashBonus).append(" on top of the sign-on,\" he says after a beat. \"For cultural fit.\"\n\n");
                        t.append("You button up. The money is the money.");
                    } else {
                        t.append("You lean forward slightly.\n\n");
                        t.append("\"I noticed you noticed,\" you say, quietly enough that it's just between you.\n\n\"I'm happy to make the job worth more than the listing price. If the salary is negotiable.\"\n\n");
                        t.append("He takes a moment. \"I think we can find another $").append(flashBonus).append(" in the budget.\"\n\n");
                        t.append("He doesn't elaborate. You don't ask him to.");
                    }
                    signOnBonusPending = totalBonus;
                    setText(t.toString());
                    addContinueButton(this::showActualQuizIntro);
                });
                choices.add(flashLabel);
            }
        }

        if (isShy()) {
            choices.add("Nod and say nothing.");
            acts.add(() -> { signOnBonusPending = bonusAmount; showActualQuizIntro(); });
        }

        showChoicesFromLists(choices, acts);
    }

    private void showActualQuizIntro() {
        String bossName = boss != null ? boss.name : "They";
        StringBuilder text = new StringBuilder();
        text.append(bossName).append(" sets a sheet of paper on the desk.\n\n");

        if (isShy()) {
            text.append("Your hands feel slightly damp. You straighten up in your chair.\n\n");
        } else if (isOutgoing()) {
            text.append("You lean forward slightly. This part you can handle.\n\n");
        }

        text.append("\"Alright — a few questions about the role. Take your time.\"\n\n");
        text.append("(").append(currentInterview.questions.size()).append(" questions — need 100% to pass (forgiveness may apply))");
        setText(text.toString());
        addContinueButton(this::showNextQuestion);
    }

    // ── Quiz ─────────────────────────────────────────────────────
    private void showNextQuestion() {
        if (questionIdx >= currentInterview.questions.size()) {
            showResult(); return;
        }
        InterviewData.Question q = currentInterview.questions.get(questionIdx);
        questionIdx++;

        StringBuilder text = new StringBuilder();
        text.append("Question ").append(questionIdx).append(" of ")
            .append(currentInterview.questions.size()).append(":\n\n");
        text.append(q.question);

        setText(text.toString());

        List<String> labels = new ArrayList<>(q.choices);
        List<Runnable> acts = new ArrayList<>();

        for (int i = 0; i < q.choices.size(); i++) {
            final boolean correct = q.isCorrect(i);
            final InterviewData.Question question = q;
            acts.add(() -> {
                if (!correct) wrongAnswers++;

                StringBuilder response = new StringBuilder();

                // Boss face reaction — no explicit right/wrong
                response.append(getBossReactionLine(correct));

                // Trait hint — only if question has one and player has the trait
                if (!question.hint_trait.isEmpty() && !question.hint_text.isEmpty()
                        && state.hasTrait(question.hint_trait)) {
                    response.append("\n\n").append(question.hint_text);
                } else if (isStreetwise()) {
                    // Streetwise gets subtle cues on boss face
                    if (correct) {
                        response.append("\n\nSomething in his expression — barely perceptible — eases slightly.");
                    } else {
                        response.append("\n\nHis pen moves. You can't read it clearly.");
                    }
                }

                setText(response.toString());
                addContinueButton(this::showNextQuestion);
            });
        }

        showChoicesFromLists(labels, acts);
    }

    private String getBossReactionLine(boolean correct) {
        String bossName = boss != null ? boss.name : "They";
        if (bossIsSleazy()) {
            return correct
                ? bossName + " makes a small note without looking up."
                : bossName + " clicks his pen once.";
        }
        if (boss != null && boss.personality.equalsIgnoreCase("WARM")) {
            return correct
                ? bossName + " gives a small nod and moves on."
                : bossName + " pauses briefly, then continues.";
        }
        // Neutral/strict — intentionally ambiguous but subtly different
        return correct
            ? bossName + " writes something down and moves to the next question."
            : bossName + " writes something down. A beat longer than the others.";
    }

    // ── Result ───────────────────────────────────────────────────
    private void showResult() {
        int effectiveWrong = Math.max(0, wrongAnswers - forgiveness);
        int total          = currentInterview.questions.size();
        int correct        = total - wrongAnswers;
        boolean hired      = (total - effectiveWrong) >= total;

        String bossName = boss != null ? boss.name : "The manager";
        String bossId   = boss != null ? boss.id   : "";

        if (hired) {
            state.currentJobId = currentJob.id;
            // Auto-discover the location associated with this job
            java.util.Map<String,String> jobToLoc = new java.util.HashMap<>();
            jobToLoc.put("bookshop",           "bookshop");
            jobToLoc.put("tattoo_studio",      "tattoo");
            jobToLoc.put("library",            "library");
            jobToLoc.put("neon_fitness",       "gym");
            jobToLoc.put("restaurant_kitchen", "restaurant");
            jobToLoc.put("velvet_cafe",        "cafe");
            jobToLoc.put("cafe",               "cafe");
            String autoLoc = jobToLoc.get(currentJob.id);
            if (autoLoc != null) state.discoverLocation(autoLoc);
            boolean forgivenByLooks = wrongAnswers > 0 && forgiveness > 0 &&
                                      (total - wrongAnswers) < total;

            state.removeTrait("__interview_boss_noticed__"); // clear ephemeral
        if (signOnBonusPending > 0) state.money += signOnBonusPending;

            StringBuilder text = new StringBuilder();
            text.append(bossName).append(" looks over the sheet.\n\n\"")
                .append(getHiringLine(forgivenByLooks)).append("\"\n\n");
            text.append("You got the job.\n\n");
            text.append(currentJob.label).append("\n");
            text.append("$").append(currentJob.netPaycheck())
                .append(" take-home (").append(currentJob.payFrequencyLabel()).append(")\n");
            text.append(String.join(", ", currentJob.work_days))
                .append("  |  ").append(currentJob.slots_per_day * 2).append(" hrs/shift");
            if (signOnBonusPending > 0)
                text.append("\n\n$").append(signOnBonusPending).append(" sign-on bonus applied to your account.");

            setText(text.toString());
            state.changeStat("confidence", 10);
            state.changeStat("happiness", 8);
            if (!bossId.isEmpty()) state.changeNpcRep(bossId, 15);
            addContinueButton(onComplete::run);
        } else {
            if (!bossId.isEmpty()) state.changeNpcRep(bossId, -5);
            showFailedResult(bossName, correct, total);
        }
    }

    private void showFailedResult(String bossName, int correct, int total) {
        StringBuilder text = new StringBuilder();
        text.append(bossName).append(" sets the paper down.\n\n");

        if (isShy()) {
            text.append("You already knew before he opened his mouth. Your face feels warm.\n\n");
        } else if (isStreetwise() && bossIsSleazy()) {
            text.append("You watch his expression. He's about to turn you down, but he's not quite done looking at you yet.\n\n");
        }

        text.append("\"").append(getDecliningLine()).append("\"\n\n");
        text.append("You got ").append(correct).append(" out of ").append(total).append(" correct.");

        setText(text.toString());

        List<String> choices  = new ArrayList<>();
        List<Runnable> acts   = new ArrayList<>();

        choices.add("Accept the outcome and leave.");
        acts.add(() -> {
            state.changeStat("confidence", -5);
            state.changeStat("happiness", -5);
            onComplete.run();
        });

        // Only sleazy boss gets special options
        if (bossIsSleazy() && !flashUsed) {

            // Exhibitionist = flash offer
            if (isHighExhibitionist()) {
                choices.add("[Reach up and pull your top aside for a moment — let him see what he'd be missing.] (Exhibitionist)");
                acts.add(() -> { showFlashOffer(); });
            }

            // Whore — direct transactional offer, no games
            if (isWhore()) {
                choices.add("[Set your bag down slowly and hold his gaze. \"Let's talk about what getting this job actually requires.\"]");
                acts.add(() -> { showWhoreNegotiate(); });
            }

            // Slut — casual, uncomplicated offer
            if (isSlut() && isAttractive() && !isWhore()) {
                choices.add("\"Honestly? I'm flexible. In more ways than one.\" A simple smile — no performance.");
                acts.add(() -> { showSlutOffer(); });
            }

            // Attractive + provocative = tension-based offer
            if (isAttractive() && isProvocative() && !isExhibitionist() && !isWhore() && !isSlut()) {
                choices.add("Lean across the desk slightly. \"Are you sure there isn't some flexibility here?\"");
                acts.add(() -> { showFlirtyNegotiate(); });
            }

            // Dom + failed = challenge
            if (isDom()) {
                choices.add("\"I think we both know the score wasn't the only thing you were evaluating.\"");
                acts.add(() -> { showDomPushback(); });
            }

            // Prude — indignant refusal, but it costs her nothing since she's already declined
            if (isPrude() && isStreetwise()) {
                choices.add("[Internal: You know exactly what he's hoping for. Leave without giving him the satisfaction.]");
                acts.add(() -> {
                    setText("You pick up your bag, stand, and meet his eyes.\n\n\"Thank you for your time.\"\n\nYou mean the opposite. He knows it. You leave anyway.\n\nYou feel good about that, actually.");
                    state.changeStat("willpower", 5);
                    state.changeStat("confidence", 3);
                    addContinueButton(onComplete::run);
                });
            }
        }

        choices.add("Ask if you can apply again in the future.");
        acts.add(() -> {
            setState("\"Give it a month.\" He's already looking at his phone.\n\nYou let yourself out.");
            state.changeStat("confidence", -3);
            addContinueButton(() -> { onComplete.run(); });
        });

        showChoicesFromLists(choices, acts);
    }

    /** +1 base from the flash, +1 more if MC is high-tier attractive. */
    private int flashForgiveness() {
        boolean highAttractive = state.hasTrait("Beautiful") || state.hasTrait("Sexy") ||
                                 state.hasTrait("Elegant")   || state.hasTrait("Otherworldly_Beauty");
        return highAttractive ? 2 : 1;
    }

    private void showFlashOffer() {
        flashUsed = true;
        String bossId    = boss != null ? boss.id   : "";
        String bossName  = boss != null ? boss.name : "He";
        if (!bossId.isEmpty()) state.setNpcMemory(bossId, "flashed_boss", "1");
        int total        = currentInterview.questions.size();
        int flashBonus   = flashForgiveness();
        int effectiveWrong = Math.max(0, wrongAnswers - forgiveness - flashBonus);
        boolean nowHired = (total - effectiveWrong) >= total;

        if (nowHired) {
            String hireText = bossName + "'s expression changes completely.\n\n" +
                    "He leans back in his chair. A slow smile.\n\n" +
                    "\"Well. That changes things.\"\n\n" +
                    "He picks the paper back up, makes a small mark on it, and slides it aside.\n\n" +
                    "\"You can start Monday. Don't be late.\"\n\n" +
                    "You got the job — not quite the way you planned.\n\n" +
                    currentJob.label + "\n$" + currentJob.netPaycheck() +
                    " take-home (" + currentJob.payFrequencyLabel() + ")  |  " +
                    String.join(", ", currentJob.work_days);
            setText(hireText);
            state.currentJobId = currentJob.id;
            state.changeStat("confidence", 5);
            state.changeStat("reputation", -5);
            addContinueButton(onComplete::run);
        } else {
            String refuseText = bossName + "'s expression shifts — interested, definitely.\n\n" +
                    "He takes a moment. Longer than he should.\n\n" +
                    "Then he exhales and looks back at the paper.\n\n" +
                    "\"I appreciate the... gesture. But I still need someone who knows the work.\"\n\n" +
                    "He straightens up. The moment is over.\n\n" +
                    "\"Try again in a month. You might surprise me.\"";
            setText(refuseText);
            state.changeStat("confidence", -3);
            state.changeStat("happiness", -8);
            addContinueButton(onComplete::run);
        }
    }

    private void showFlirtyNegotiate() {
        flashUsed = true;
        String bossId   = boss != null ? boss.id   : "";
        String bossName = boss != null ? boss.name : "He";
        if (!bossId.isEmpty()) state.setNpcMemory(bossId, "flashed_boss", "1");
        setText(bossName + " holds your gaze for a long moment.\n\n" +
                "\"You're something else, you know that?\"\n\n" +
                "He taps the desk twice, thinking. Then:\n\n" +
                "\"Alright. Consider yourself reconsidered. Monday, nine sharp.\"\n\n" +
                "You got the job.\n\n" +
                currentJob.label + "\n$" + currentJob.netPaycheck() +
                " take-home (" + currentJob.payFrequencyLabel() + ")\n" +
                String.join(", ", currentJob.work_days) +
                "  |  " + currentJob.slots_per_day * 2 + " hrs/shift");
        state.currentJobId = currentJob.id;
        state.changeStat("confidence", 8);
        addContinueButton(onComplete::run);
    }

    private void showWhoreNegotiate() {
        flashUsed = true;
        String bossId   = boss != null ? boss.id   : "";
        String bossName = boss != null ? boss.name : "He";
        if (!bossId.isEmpty()) state.setNpcMemory(bossId, "flashed_boss", "1");

        setText(bossName + " doesn't move for a moment.\n\n" +
                "Then a slow smile. The kind that knows exactly what it's doing.\n\n" +
                "\"Well.\" He folds his hands on the desk. \"Now we're having a different conversation.\"\n\n" +
                "The terms get worked out without much ceremony. You've done this before. So has he.\n\n" +
                "\"Monday. And for the record —\" he glances at the door, \"— the test scores stay between us.\"\n\n" +
                "You got the job. On your terms.\n\n" +
                currentJob.label + "\n$" + currentJob.netPaycheck() +
                " take-home (" + currentJob.payFrequencyLabel() + ")\n" +
                String.join(", ", currentJob.work_days));
        state.currentJobId = currentJob.id;
        state.changeStat("confidence", 10);
        state.changeStat("willpower", -3); // it cost something
        if (!bossId.isEmpty()) state.changeNpcRep(bossId, 10);
        addContinueButton(onComplete::run);
    }

    private void showSlutOffer() {
        flashUsed = true;
        String bossId   = boss != null ? boss.id   : "";
        String bossName = boss != null ? boss.name : "He";
        if (!bossId.isEmpty()) state.setNpcMemory(bossId, "flashed_boss", "1");

        setText(bossName + " blinks. He wasn't expecting that — the directness of it.\n\n" +
                "Most people perform. You just said it.\n\n" +
                "\"...Yeah, alright.\" He actually looks slightly disarmed.\n\n" +
                "\"Monday. Don't be late.\"\n\n" +
                "You got the job. No drama, no games.\n\n" +
                currentJob.label + "\n$" + currentJob.netPaycheck() +
                " take-home (" + currentJob.payFrequencyLabel() + ")\n" +
                String.join(", ", currentJob.work_days));
        state.currentJobId = currentJob.id;
        state.changeStat("confidence", 7);
        state.changeStat("happiness", 5);
        addContinueButton(onComplete::run);
    }

    private void showDomPushback() {
        String bossName = boss != null ? boss.name : "He";
        setText(bossName + " goes very still.\n\n" +
                "A beat passes. Then he laughs — short, surprised.\n\n" +
                "\"Ha. You've got nerve, I'll give you that.\"\n\n" +
                "He picks up the paper again and looks at it like he's seeing it differently.\n\n" +
                "\"Come back and try again. I'll give you another shot at the test — " +
                "but you'd better actually know the answers next time.\"\n\n" +
                "Not hired. But the door's open.");
        state.changeStat("confidence", 5);
        state.changeStat("reputation", 3);
        // Mark that a re-attempt is welcome — player can re-apply immediately
        if (boss != null && !boss.id.isEmpty())
            state.setNpcMemory(boss.id, "dom_pushback", "1");
        addContinueButton(onComplete::run);
    }

    private String getHiringLine(boolean forgivenByLooks) {
        if (forgivenByLooks && bossIsSleazy())
            return "A couple of gaps. But honestly? I think you'll fit in just fine here. Welcome aboard.";
        if (goodImpression && isWhore())
            return "Exactly what this office needs. You'll start Monday.";
        if (goodImpression && isOutgoing())
            return "Good answers. And you've got the right energy for this place. You're hired.";
        if (isPrude() || isDemure())
            return "Solid answers. Professional presentation. The position is yours.";
        if (isSlut())
            return "Good. Straightforward. I like that. You're hired.";
        if (isShy())
            return "You answered well. Don't look so surprised — you earned it.";
        return "You've got what we need. The position is yours if you want it.";
    }

    private String getDecliningLine() {
        if (boss != null && boss.personality.equalsIgnoreCase("SELFISH"))
            return "Not what we're looking for. Thanks for coming in.";
        if (boss != null && boss.personality.equalsIgnoreCase("WARM"))
            return "I appreciate you coming in — it just wasn't the right fit this time. Don't give up.";
        if (bossIsSleazy() && isPrude())
            return "Appreciate your time. Wasn't quite what I had in mind for the role.";
        if (bossIsSleazy())
            return "The numbers aren't quite there. Shame.";
        return "We'll keep your details. Thanks for your time.";
    }

    // ── UI helpers ───────────────────────────────────────────────
    private void setText(String text) {
        textArea.setForeground(Colors.TEXT);
        textArea.setText(text);
        textArea.setCaretPosition(0);
        choicesPanel.removeAll();
        choicesPanel.revalidate();
    }

    private void setState(String text) { setText(text); }

    private void showChoicesFromLists(List<String> labels, List<Runnable> acts) {
        choicesPanel.removeAll();
        for (int i = 0; i < labels.size(); i++) {
            final Runnable action = acts.get(i);
            JButton btn = makeBtn(labels.get(i));
            btn.addActionListener(e -> { disableAllButtons(); action.run(); });
            choicesPanel.add(Box.createVerticalStrut(7));
            choicesPanel.add(btn);
        }
        choicesPanel.revalidate(); choicesPanel.repaint();
    }

    private void addContinueButton(Runnable action) {
        choicesPanel.removeAll();
        JButton btn = makeBtn("Continue \u2192");
        btn.addActionListener(e -> action.run());
        choicesPanel.add(Box.createVerticalStrut(7));
        choicesPanel.add(btn);
        choicesPanel.revalidate(); choicesPanel.repaint();
    }

    private void disableAllButtons() {
        for (Component c : choicesPanel.getComponents())
            if (c instanceof JButton) c.setEnabled(false);
    }

    private JButton makeBtn(String text) {
        // Label adult choices differently
        boolean isAdult = text.startsWith("[");
        JButton btn = new JButton(text) {
            boolean hov = false;
            { addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { hov = true;  repaint(); }
                public void mouseExited (MouseEvent e) { hov = false; repaint(); }
            }); }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color base = isAdult ? new Color(80, 40, 80) : Colors.BG_BTN;
                Color hovered = isAdult ? new Color(110, 55, 110) : Colors.BG_BTN_HOV;
                g2.setColor(hov ? hovered : base);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(isAdult ? new Color(180, 100, 180) : (hov ? Colors.ACCENT_LIT : Colors.BORDER));
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 8, 8);
                super.paintComponent(g);
            }
        };
        btn.setForeground(isAdult ? new Color(220, 160, 220) : new Color(210, 200, 255));
        btn.setFont(Colors.SANS_PLAIN);
        btn.setContentAreaFilled(false); btn.setBorderPainted(false); btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 52));
        btn.setAlignmentX(LEFT_ALIGNMENT);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }
}
