package game.ui;

import java.awt.Color;
import java.awt.Font;

public class Colors {
    // ── Core backgrounds ──────────────────────────────────────────────────────
    public static final Color BG          = new Color(16,  16,  28);
    public static final Color BG_PANEL    = new Color(22,  22,  38);
    public static final Color BG_BTN      = new Color(36,  36,  60);
    public static final Color BG_BTN_HOV  = new Color(54,  50,  90);

    // ── Accent + borders ──────────────────────────────────────────────────────
    public static final Color ACCENT      = new Color(120, 100, 200);
    public static final Color ACCENT_LIT  = new Color(155, 135, 235);
    public static final Color BORDER      = new Color(40,  40,  68);
    public static final Color DIVIDER     = new Color(30,  30,  52);

    // ── Text ──────────────────────────────────────────────────────────────────
    public static final Color TEXT        = new Color(218, 218, 232);
    public static final Color TEXT_DIM    = new Color(108, 108, 140);
    public static final Color TEXT_HEAD   = new Color(178, 158, 255);
    public static final Color RESULT      = new Color(140, 220, 150);

    // ── Stat bar colors ───────────────────────────────────────────────────────
    public static final Color BAR_FIT     = new Color(72,  188, 100);
    public static final Color BAR_REP     = new Color(72,  148, 218);
    public static final Color BAR_HAP     = new Color(218, 178, 52);
    public static final Color BAR_CON     = new Color(178, 72,  200);

    // ── Main content fonts — scaled for display resolution ───────────────────
    public static final Font SANS_PLAIN   = new Font("SansSerif", Font.PLAIN,  39);
    public static final Font SANS_BOLD    = new Font("SansSerif", Font.BOLD,   39);
    public static final Font SANS_SMALL   = new Font("SansSerif", Font.PLAIN,  33);
    public static final Font SERIF_TEXT   = new Font("Georgia",   Font.PLAIN,  54);

    // ── Sidebar fonts ─────────────────────────────────────────────────────────
    public static final Font PANEL_PLAIN  = new Font("SansSerif", Font.PLAIN,  12);
    public static final Font PANEL_BOLD   = new Font("SansSerif", Font.BOLD,   12);
    public static final Font PANEL_SMALL  = new Font("SansSerif", Font.PLAIN,  10);
    public static final Font PANEL_HEAD   = new Font("SansSerif", Font.BOLD,   11);

    // ── Named role fonts — semantic aliases ────────────────────────────────────
    /** Used for setting labels, section headers, small UI text. */
    public static final Font LABEL        = new Font("SansSerif", Font.PLAIN,  13);
    /** Used for tile / card headings. */
    public static final Font TITLE        = new Font("SansSerif", Font.BOLD,   16);
}

