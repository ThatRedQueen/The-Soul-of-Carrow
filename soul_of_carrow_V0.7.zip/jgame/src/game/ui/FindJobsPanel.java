package game.ui;

import game.*;
import game.data.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class FindJobsPanel extends JPanel {

    private final GameState       state;
    private final JobLoader       jobs;
    private final InterviewLoader interviews;
    private final NpcLoader       npcs;
    private final java.util.function.Consumer<String> onApply; // passes jobId to start interview

    public FindJobsPanel(GameState state, JobLoader jobs, InterviewLoader interviews,
                         NpcLoader npcs, java.util.function.Consumer<String> onApply) {
        this.state      = state;
        this.jobs       = jobs;
        this.interviews = interviews;
        this.npcs       = npcs;
        this.onApply    = onApply;

        setBackground(Colors.BG);
        setLayout(new BorderLayout());
        build();
    }

    private void build() {
        // Header
        JPanel header = new JPanel();
        header.setOpaque(false);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBorder(BorderFactory.createEmptyBorder(24, 48, 16, 48));

        JLabel title = new JLabel("Job Listings");
        title.setForeground(Colors.TEXT_HEAD);
        title.setFont(new Font("SansSerif", Font.BOLD, 60));
        title.setAlignmentX(LEFT_ALIGNMENT);

        JLabel sub = new JLabel("Select a position to apply. Higher-paying jobs have more interview questions.");
        sub.setForeground(Colors.TEXT_DIM);
        sub.setFont(Colors.SANS_SMALL);
        sub.setAlignmentX(LEFT_ALIGNMENT);

        // Current job note
        if (state.currentJobId != null) {
            JobData current = jobs.get(state.currentJobId);
            JPanel curRow = new JPanel(new BorderLayout(12, 0));
            curRow.setOpaque(false);
            curRow.setAlignmentX(LEFT_ALIGNMENT);

            JLabel cur = new JLabel("Currently employed: " + (current != null ? current.label : state.currentJobId));
            cur.setForeground(new Color(100, 200, 120));
            cur.setFont(Colors.SANS_SMALL);

            JButton quitBtn = new JButton("Quit Job");
            quitBtn.setFont(Colors.PANEL_SMALL);
            quitBtn.setForeground(new Color(220, 100, 100));
            quitBtn.setBackground(new Color(60, 30, 30));
            quitBtn.setFocusPainted(false);
            quitBtn.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createLineBorder(new java.awt.Color(140, 60, 60), 1),
                javax.swing.BorderFactory.createEmptyBorder(3, 10, 3, 10)));
            quitBtn.addActionListener(e -> {
                int confirm = javax.swing.JOptionPane.showConfirmDialog(
                    this,
                    "Quit " + (current != null ? current.label : "your job") + "?\nYou'll need to find new work.",
                    "Quit Job",
                    javax.swing.JOptionPane.YES_NO_OPTION,
                    javax.swing.JOptionPane.WARNING_MESSAGE);
                if (confirm == javax.swing.JOptionPane.YES_OPTION) {
                    state.quitJob(); // applies stat penalties and clears job state
                    // Rebuild the panel
                    removeAll();
                    build();
                    revalidate(); repaint();
                }
            });

            curRow.add(cur,     java.awt.BorderLayout.WEST);
            curRow.add(quitBtn, java.awt.BorderLayout.EAST);

            header.add(title);
            header.add(Box.createVerticalStrut(4));
            header.add(sub);
            header.add(Box.createVerticalStrut(4));
            header.add(curRow);
        } else {
            header.add(title);
            header.add(Box.createVerticalStrut(4));
            header.add(sub);
        }
        add(header, BorderLayout.NORTH);

        // Job cards
        JPanel list = new JPanel();
        list.setOpaque(false);
        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
        list.setBorder(BorderFactory.createEmptyBorder(8, 48, 24, 48));

        for (JobData job : jobs.getAll()) {
            if (interviews.get(job.id) == null) continue; // only show jobs with interviews
            list.add(buildJobCard(job));
            list.add(Box.createVerticalStrut(12));
        }

        JScrollPane scroll = new JScrollPane(list);
        scroll.setOpaque(false); scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(12);
        add(scroll, BorderLayout.CENTER);
    }

    private JPanel buildJobCard(JobData job) {
        JPanel card = new JPanel(new BorderLayout(16, 0));
        card.setBackground(Colors.BG_PANEL);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Colors.BORDER, 1),
            BorderFactory.createEmptyBorder(16, 20, 16, 20)
        ));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 140));

        // Left — job info
        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));

        JLabel name = new JLabel(job.label);
        name.setForeground(Colors.TEXT_HEAD);
        name.setFont(new Font("SansSerif", Font.BOLD, 42));
        name.setAlignmentX(LEFT_ALIGNMENT);

        JLabel desc = new JLabel("<html><body style='width:360px'>" + job.description + "</body></html>");
        desc.setForeground(Colors.TEXT_DIM);
        desc.setFont(Colors.SANS_SMALL);
        desc.setAlignmentX(LEFT_ALIGNMENT);

        // Boss info
        NpcData boss = job.boss_npc_id != null ? npcs.get(job.boss_npc_id) : null;
        String bossText = boss != null ? "Manager: " + boss.name : "";

        String payText;
        if (job.under_the_table) {
            payText = "$" + job.netPaycheck() + " cash (" + job.payFrequencyLabel() + ", untaxed)";
        } else {
            payText = "$" + job.netPaycheck() + " take-home / $" + job.grossPaycheck() +
                      " gross (" + job.payFrequencyLabel() + ", " + job.taxBracketLabel() + " tax)";
        }

        JLabel details = new JLabel(
            payText + "  |  " +
            String.join(", ", job.work_days) + "  |  " +
            job.slots_per_day * 2 + " hrs/shift" +
            (bossText.isEmpty() ? "" : "  |  " + bossText)
        );
        details.setForeground(new Color(100, 200, 120));
        details.setFont(Colors.SANS_SMALL);
        details.setAlignmentX(LEFT_ALIGNMENT);

        InterviewData iv = interviews.get(job.id);
        int qCount = iv != null ? iv.questions.size() : 0;
        JLabel questions = new JLabel(qCount + " interview question" + (qCount != 1 ? "s" : ""));
        questions.setForeground(Colors.TEXT_DIM);
        questions.setFont(Colors.SANS_SMALL);
        questions.setAlignmentX(LEFT_ALIGNMENT);

        info.add(name);
        info.add(Box.createVerticalStrut(4));
        info.add(desc);
        info.add(Box.createVerticalStrut(6));
        info.add(details);
        info.add(Box.createVerticalStrut(2));
        info.add(questions);

        // Stat changes summary
        if (!job.stat_changes.isEmpty()) {
            java.util.List<String> fx = new java.util.ArrayList<>();
            for (java.util.Map.Entry<String,Integer> e : job.stat_changes.entrySet()) {
                String sign = e.getValue() >= 0 ? "+" : "";
                fx.add(sign + e.getValue() + " " + e.getKey().replace("_", " "));
            }
            JLabel statFx = new JLabel("Daily: " + String.join("  ·  ", fx));
            statFx.setForeground(new Color(140, 140, 180));
            statFx.setFont(new Font("SansSerif", Font.PLAIN, 11));
            statFx.setAlignmentX(LEFT_ALIGNMENT);
            info.add(Box.createVerticalStrut(2));
            info.add(statFx);
        }

        // Right — apply button
        JButton applyBtn = makeApplyBtn(job.id);
        JPanel right = new JPanel(new GridBagLayout());
        right.setOpaque(false);
        right.add(applyBtn);

        card.add(info,  BorderLayout.CENTER);
        card.add(right, BorderLayout.EAST);
        return card;
    }

    private JButton makeApplyBtn(String jobId) {
        boolean isCurrentJob = jobId.equals(state.currentJobId);
        JButton btn = new JButton(isCurrentJob ? "Current Job" : "Apply") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(isEnabled() ? new Color(85, 65, 165) : new Color(40, 40, 60));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                super.paintComponent(g);
            }
        };
        btn.setForeground(Color.WHITE);
        btn.setFont(Colors.SANS_BOLD);
        btn.setContentAreaFilled(false); btn.setBorderPainted(false); btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setEnabled(!isCurrentJob);
        if (!isCurrentJob) btn.addActionListener(e -> onApply.accept(jobId));
        return btn;
    }
}
