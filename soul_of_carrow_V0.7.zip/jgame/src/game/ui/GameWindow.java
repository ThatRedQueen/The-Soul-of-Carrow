package game.ui;

import game.*;
import game.data.TraitCategoryData;
import javax.swing.*;
import java.util.*;
import java.util.stream.Collectors;

public class GameWindow extends JFrame {

    private final GameState       state;
    private final SceneLoader     scenes;
    private final NpcLoader       npcs;
    private final Engine          engine;
    private final ActivityLoader  activities;
    private final JobLoader       jobs;
    private final InterviewLoader interviews;
    private final ClothingLoader  clothes;
    private final BounceSystem    bounce;
    private final OutfitSystem    outfit;

    private StatsPanel      statsPanel;
    private ScenePanel      scenePanel;
    private DayPlannerPanel dayPlanner;
    private FindJobsPanel   findJobsPanel;
    private InterviewPanel  interviewPanel;
    private OutfitPanel     outfitPanel;
    private JPanel          centerHolder;
    private MainMenuPanel   mainMenuPanel;
    private ModManagerPanel modManagerPanel;
    private SaveLoadPanel   savePanel;
    private SaveLoadPanel   loadPanel;
    private game.SaveManager     saveManager;
    private JPanel               previousPanel; // panel shown before escape menu
    private game.GameSettings    settings;
    private game.SettingsManager settingsMgr;

    public GameWindow(GameState state, SceneLoader scenes, NpcLoader npcs,
                      Engine engine, ActivityLoader activities, JobLoader jobs,
                      InterviewLoader interviews, ClothingLoader clothes,
                      List<TraitCategoryData> traits, AssetManager assetManager,
                      ArtworkHookManager artworkManager, AudioManager audioManager,
                      TextPoolRegistry textPools, game.mod.ModSettings modSettings) {
        this.state      = state;
        this.scenes     = scenes;
        this.npcs       = npcs;
        this.engine     = engine;
        this.activities = activities;
        this.jobs       = jobs;
        this.interviews = interviews;
        this.clothes    = clothes;
        this.bounce     = new BounceSystem(state, clothes);
        this.outfit     = new OutfitSystem(state, clothes);

        setTitle("The Soul of Carrow");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1160, 740);
        setMinimumSize(new java.awt.Dimension(820, 580));
        setLocationRelativeTo(null);
        getContentPane().setBackground(Colors.BG);

        statsPanel     = new StatsPanel(state, this::showOutfit);
        if (statsPanel    != null && assetManager != null) statsPanel.setAssetManager(assetManager);
        // Note: ShoppingPanel and OutfitPanel are created on-demand via showShoppingPanel()
        // and showOutfitPanel() — assetManager is passed there at creation time
        scenePanel     = new ScenePanel(engine, state, clothes, v -> statsPanel.refresh());
        if (scenePanel != null && assetManager != null)  scenePanel.setAssetManager(assetManager);
        if (scenePanel != null && artworkManager != null) scenePanel.setArtworkManager(artworkManager);
        if (scenePanel != null && audioManager != null)   scenePanel.setAudioManager(audioManager);
        // settings may not be injected yet — use state.settings if available
        if (state.settings != null) { settings = state.settings; scenePanel.setSettings(settings); }
        dayPlanner     = new DayPlannerPanel(state, activities, jobs, bounce, outfit, engine, this::onDayEnd);
        findJobsPanel  = new FindJobsPanel(state, jobs, interviews, npcs, this::startInterview);
        interviewPanel = new InterviewPanel(state, npcs, jobs, interviews, this::showDayPlanner);

        centerHolder = new JPanel(new java.awt.BorderLayout());
        centerHolder.setOpaque(false);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, statsPanel, centerHolder);
        split.setDividerLocation(220);   // wider for card layout
        split.setDividerSize(1);
        split.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        split.setResizeWeight(0.0);
        setContentPane(split);

        CharCreationPanel cc = new CharCreationPanel(state, traits, this::onCharCreationDone);
        centerHolder.add(cc, java.awt.BorderLayout.CENTER);
    }

    private void show(JPanel panel) {
        centerHolder.removeAll();
        centerHolder.add(panel, java.awt.BorderLayout.CENTER);
        centerHolder.revalidate();
        centerHolder.repaint();
    }

    private void onCharCreationDone() {
        statsPanel.refresh();
        scenePanel.setOnSceneComplete(this::showDayPlanner);
        showScene();
    }

    public void showScene() { show(scenePanel); scenePanel.showCurrentScene(); }

    public void showDayPlanner() {
        dayPlanner.resetForNewDay();
        if (state.dayCount > 1) {
            // Build the mandatory morning sequence: morning_routine + any trait-triggered scenes
            java.util.List<String> morningQueue = new java.util.ArrayList<>();
            morningQueue.add("morning_routine");
            morningQueue.addAll(buildMandatoryMorningScenes());
            playMorningSequence(morningQueue, 0);
        } else {
            show(dayPlanner);
        }
        statsPanel.refresh();
    }

    /**
     * Plays morning scenes in order, then shows the day planner.
     * Mandatory scenes (shower breakdown, STD symptom check, etc.) fire
     * before the player can plan their day.
     */
    private void playMorningSequence(java.util.List<String> queue, int index) {
        if (index >= queue.size()) {
            statsPanel.refresh();
            show(dayPlanner);
            statsPanel.refresh();
            return;
        }
        state.currentScene = queue.get(index);
        scenePanel.setOnSceneComplete(() -> playMorningSequence(queue, index + 1));
        show(scenePanel);
        scenePanel.showCurrentScene();
    }

    /**
     * Returns mandatory scene IDs to play after morning_routine, based on current traits.
     * These fire every morning while the condition is active — player cannot skip them.
     *
     * Shaken + personality determines both which scenes fire and whether they fire.
     *   Iron_Will / Self_Assured / Driven  → home_shower only (briefer processing)
     *   Shy / Fragile_Ego / Conflict_Avoidant → home_shower + home_crying_scene (first 3 days)
     *   Default → home_shower
     *
     * STD_serious (untreated, no active treatment week) → std_symptom_morning scene
     */
    private java.util.List<String> buildMandatoryMorningScenes() {
        java.util.List<String> scenes = new java.util.ArrayList<>();

        boolean deeplyAffected = state.hasTrait("Shy")
                || state.hasTrait("Fragile_Ego")
                || state.hasTrait("Conflict_Avoidant");
        boolean resilient = state.hasTrait("Iron_Will")
                || state.hasTrait("Self_Assured")
                || state.hasTrait("Driven");

        // Broken: most severe — mandatory shower + cry every single morning
        if (state.hasTrait("Broken")) {
            scenes.add("home_shower");
            scenes.add("home_crying_scene");
        }
        // Shaken: shower mandatory; cry based on days left + personality
        else if (state.hasTrait("Shaken")) {
            scenes.add("home_shower");
            int daysLeft = state.getTimedTraitDaysLeft("Shaken");
            if (daysLeft > (deeplyAffected ? 3 : resilient ? 5 : 4)) {
                scenes.add("home_crying_scene");
            }
        }
        // Hurt: no mandatory scenes — texture lives in morning_routine variants

        // STD_serious untreated: symptom check every morning
        if (state.hasTrait("STD_serious") && !state.hasTrait("STD_treatment_active")) {
            scenes.add("std_symptom_morning");
        }

        return scenes;
    }

    /** Scenes queued to play after a special panel (find jobs, shopping, outfit) closes. */
    private List<String> pendingScenes = new java.util.ArrayList<>();

    public void showFindJobs() {
        findJobsPanel = new FindJobsPanel(state, jobs, interviews, npcs, this::startInterview);
        show(findJobsPanel);
    }

    public void showMainMenu(game.mod.ModLoader modLoader, game.SaveManager sm, game.SettingsManager smgr) {
        this.saveManager  = sm;
        this.settingsMgr  = smgr;
        this.settings     = smgr != null ? smgr.getSettings() : new game.GameSettings();
        if (scenePanel != null) scenePanel.setSettings(this.settings);
        mainMenuPanel   = new MainMenuPanel(this::showDayPlanner, modLoader,
                              this::showModManager, this::showLoadPanel, sm,
                              () -> show(new SettingsPanel(settings, settingsMgr,
                                  this::showMainMenu0,
                                  () -> { if (scenePanel!=null) scenePanel.setSettings(settings); })));
        if (modManagerPanel != null) modManagerPanel.dispose();
        modManagerPanel = new ModManagerPanel(modLoader, modSettings, this::showMainMenu0);
        SettingsPanel settingsPanel = new SettingsPanel(settings, settingsMgr,
            this::showMainMenu0,
            () -> { if (scenePanel != null) scenePanel.setSettings(settings); });
        savePanel = new SaveLoadPanel(sm, SaveLoadPanel.Mode.SAVE, this::showMainMenu0, null);
        loadPanel = new SaveLoadPanel(sm, SaveLoadPanel.Mode.LOAD, this::showMainMenu0, this::onSaveLoaded);
        show(mainMenuPanel);
    }

    private void showLoadPanel()  { if (loadPanel != null) show(loadPanel); }
    private void showSavePanel()  {
        // Rebuild save panel to reflect current state
        if (saveManager != null)
            savePanel = new SaveLoadPanel(saveManager, SaveLoadPanel.Mode.SAVE, this::showDayPlanner, null);
        if (savePanel != null) show(savePanel);
    }
    private void onSaveLoaded()   { showDayPlanner(); }

    private void showMainMenu0() { show(mainMenuPanel); }

    private void showModManager()  { show(modManagerPanel); }

    public void installEscapeKey() {
        // Listen for Escape on the root panel
        getRootPane().registerKeyboardAction(e -> showEscapeMenu(),
            javax.swing.KeyStroke.getKeyStroke(
                settings != null ? settings.keyEscape : java.awt.event.KeyEvent.VK_ESCAPE, 0),
            JComponent.WHEN_IN_FOCUSED_WINDOW);
        // Ctrl+S quick save
        getRootPane().registerKeyboardAction(e -> { if (saveManager != null) saveManager.save(1); },
            javax.swing.KeyStroke.getKeyStroke(
                settings != null ? settings.keySave : java.awt.event.KeyEvent.VK_S,
                java.awt.event.InputEvent.CTRL_DOWN_MASK),
            JComponent.WHEN_IN_FOCUSED_WINDOW);
    }

    private void showEscapeMenu() {
        // Save the current screen so Resume can restore it
        if (centerHolder.getComponentCount() > 0)
            previousPanel = (JPanel) centerHolder.getComponent(0);
        EscapeMenuPanel esc = new EscapeMenuPanel(new EscapeMenuPanel.EscapeActions() {
            public void resume()          { if (previousPanel != null) show(previousPanel); else show(centerHolder); }
            public void showSave()        { showSavePanel(); }
            public void showLoad()        { if (loadPanel!=null) show(loadPanel); }
            public void showSettings()    {
                SettingsPanel sp = new SettingsPanel(settings, settingsMgr,
                    () -> show(centerHolder),
                    () -> { if (scenePanel!=null) scenePanel.setSettings(settings); installEscapeKey(); });
                show(sp);
            }
            public void showMainMenu()    {
                if (mainMenuPanel != null) show(mainMenuPanel);
            }
            public void quitGame()        { game.CrashReporter.safeExit(); }
        });
        show(esc);
    }

    public void showOutfit() {
        outfitPanel = new OutfitPanel(state, clothes, () -> {
            statsPanel.refresh();
            afterSpecialPanel();
        });
        if (assetManager != null) outfitPanel.setAssetManager(assetManager);
        show(outfitPanel);
    }

    public void showShopping() {
        ShoppingPanel shoppingPanel = new ShoppingPanel(state, clothes, this::afterSpecialPanel);
        if (assetManager != null) shoppingPanel.setAssetManager(assetManager);
        show(shoppingPanel);
    }

    /** Called when a special panel (shopping, outfit) finishes — drains any pending scenes. */
    private void afterSpecialPanel() {
        List<String> toPlay = new java.util.ArrayList<>(pendingScenes);
        pendingScenes.clear();
        playNextScene(toPlay, 0);
    }

    public void startInterview(String jobId) {
        if (jobs.get(jobId) != null && jobs.get(jobId).boss_npc_id != null)
            state.setNpcMemory(jobs.get(jobId).boss_npc_id, "last_outfit", state.currentOutfitId());
        show(interviewPanel);
        interviewPanel.startInterview(jobId);
        statsPanel.refresh();
    }

    private void onDayEnd() {
        List<String> triggered = dayPlanner.processDay();
        statsPanel.refresh();

        // Separate regular scenes from special tokens
        pendingScenes = triggered.stream()
            .filter(s -> !s.startsWith("__")).collect(Collectors.toList());

        // Special panels fire first; afterSpecialPanel() drains pendingScenes when done
        if (triggered.contains("__find_jobs__"))  { showFindJobs();  return; }
        if (triggered.contains("__shopping__"))   { showShopping();  return; }
        if (triggered.contains("__outfit__"))     { showOutfit();    return; }

        // No special panel — play scenes directly
        List<String> toPlay = new java.util.ArrayList<>(pendingScenes);
        pendingScenes.clear();
        playNextScene(toPlay, 0);
    }

    /**
     * Plays scenes from the list in order. When each scene completes,
     * advances to the next one. After all scenes are done, shows the day planner.
     */
    private void playNextScene(List<String> scenes, int index) {
        if (index >= scenes.size()) {
            showDayPlanner();
            return;
        }
        String sceneId = scenes.get(index);
        if (sceneId == null || sceneId.isEmpty()) {
            // Skip null entries — shouldn't happen but guard anyway
            playNextScene(scenes, index + 1);
            return;
        }
        state.currentScene = sceneId;
        state.slutRepGainedThisScene = 0;
        scenePanel.setOnSceneComplete(() -> {
            statsPanel.refresh();
            // home_sleep is always the final scene — advance the day after it resolves
            // so the arousal→stress conversion uses post-choice arousal values
            if ("home_sleep".equals(sceneId)) {
                // Auto-rebuy clothing lost today (before advanceDay clears the tracker)
                if (state.settings != null && state.settings.autoRebuyClothing
                        && !state.lostClothingToday.isEmpty()) {
                    int totalCost = 0;
                    java.util.List<String> rebuyed = new java.util.ArrayList<>();
                    for (String itemId : state.lostClothingToday) {
                        game.data.ClothingData cd = clothes.get(itemId);
                        int price = (cd != null && cd.price > 0) ? cd.price : 15; // fallback $15
                        state.ownedClothing.add(itemId);
                        state.money -= price;
                        totalCost += price;
                        rebuyed.add(cd != null ? cd.name : itemId);
                    }
                    if (totalCost > 0) {
                        // Queue a receipt notification scene
                        state.rebuyReceiptItems  = new java.util.ArrayList<>(rebuyed);
                        state.rebuyReceiptTotal  = totalCost;
                        state.pendingTraitAcquisitions.add("auto_rebuy_receipt");
                    }
                }
                state.advanceDay();
                // Autosave after each day
                if (saveManager != null) saveManager.autosave();
                // Drain any trait auto-acquisitions into the tail of the scene list
                if (!state.pendingTraitAcquisitions.isEmpty()) {
                    List<String> expanded = new java.util.ArrayList<>(scenes);
                    expanded.addAll(index + 1, state.pendingTraitAcquisitions);
                    state.pendingTraitAcquisitions.clear();
                    playNextScene(expanded, index + 1);
                    return;
                }
            }
            // Check if the completed scene declares post-scene triggers
            game.data.SceneData played = engine.loadScene(sceneId);
            if (played != null && !played.possible_triggers.isEmpty()) {
                String triggered = engine.resolveTriggers(played.possible_triggers);
                if (triggered != null) {
                    List<String> expanded = new java.util.ArrayList<>(scenes);
                    expanded.add(index + 1, triggered);
                    playNextScene(expanded, index + 1);
                    return;
                }
            }
            playNextScene(scenes, index + 1);
        });
        showScene();
    }
}
