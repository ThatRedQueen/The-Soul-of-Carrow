package game.ui;

import game.GameSettings;
import game.SettingsManager;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.file.*;

/**
 * Content advisory screen shown once per installation after the age gate.
 * Lists the content categories present in the game and gives the player
 * explicit opt-in/opt-out control before they start.
 *
 * Choices are saved immediately to settings.dat.
 * The screen only shows once — a flag file records that it was seen.
 */
public class ContentAdvisoryScreen extends JDialog {

    private final GameSettings    settings;
    private final SettingsManager settingsMgr;
    private final String          flagPath;
    private       boolean         proceeded = false;

    private ContentAdvisoryScreen(Frame owner, GameSettings settings,
                                  SettingsManager settingsMgr, String gameDir) {
        super(owner, "Content Advisory", true);
        this.settings    = settings;
        this.settingsMgr = settingsMgr;
        this.flagPath    = gameDir + File.separator + "content_advisory_seen.dat";
        buildUI();
        setMinimumSize(new Dimension(500, 560));
        pack();
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setResizable(false);
    }

    private void buildUI() {
        JPanel root = new JPanel();
        root.setLayout(new BoxLayout(root, BoxLayout.Y_AXIS));
        root.setBackground(Colors.BG);
        root.setBorder(BorderFactory.createEmptyBorder(28, 36, 24, 36));

        // ── Header ──────────────────────────────────────────────────────────
        JLabel title = new JLabel("Content Advisory");
        title.setFont(Colors.PANEL_HEAD);
        title.setForeground(Colors.TEXT_HEAD);
        title.setAlignmentX(LEFT_ALIGNMENT);
        root.add(title);
        root.add(Box.createVerticalStrut(6));

        JLabel sub = new JLabel("<html><body style='width:420px; color:#888'>"
            + "This game contains adult content. The following is always present and cannot be disabled:"
            + "</body></html>");
        sub.setFont(Colors.PANEL_SMALL);
        sub.setAlignmentX(LEFT_ALIGNMENT);
        root.add(sub);
        root.add(Box.createVerticalStrut(12));

        // ── Always-present content ─────────────────────────────────────────
        String[][] always = {
            { "Explicit sexual content",        "Consensual sex scenes, nudity, sexual language." },
            { "Strong language",                "Profanity throughout." },
            { "Alcohol and substance use",      "Drinking mechanics, intoxication, dependency arcs." },
            { "Mental health themes",           "Depression, anxiety, trauma recovery, dissociation." },
            { "Financial stress",               "Debt, eviction risk, economic precarity." },
            { "Workplace harassment",           "Unwanted comments, professional boundary violations." },
        };
        for (String[] row : always) {
            root.add(alwaysRow(row[0], row[1]));
            root.add(Box.createVerticalStrut(4));
        }

        root.add(Box.createVerticalStrut(16));
        JSeparator sep = new JSeparator();
        sep.setForeground(Colors.BORDER);
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        sep.setAlignmentX(LEFT_ALIGNMENT);
        root.add(sep);
        root.add(Box.createVerticalStrut(14));

        // ── Optional content ───────────────────────────────────────────────
        JLabel optLabel = new JLabel("Optional content — choose below:");
        optLabel.setFont(new Font(Colors.SANS_BOLD.getFamily(), Font.BOLD, Colors.SANS_BOLD.getSize()));
        optLabel.setForeground(Colors.TEXT);
        optLabel.setAlignmentX(LEFT_ALIGNMENT);
        root.add(optLabel);
        root.add(Box.createVerticalStrut(10));

        // SA toggle row
        root.add(optionalToggleRow(
            "Sexual violence / non-consensual content",
            "Includes sexual assault, coercion, and content depicting non-consent. "
          + "May be distressing. Can be changed at any time in Settings.",
            "⚠ May be distressing to some players",
            settings.saContentEnabled,
            v -> settings.saContentEnabled = v
        ));

        root.add(Box.createVerticalStrut(20));

        // ── Proceed button ──────────────────────────────────────────────────
        JButton proceed = new JButton("I understand — Start the game");
        proceed.setFont(Colors.LABEL);
        proceed.setBackground(Colors.BG_BTN);
        proceed.setForeground(Colors.TEXT_HEAD);
        proceed.setAlignmentX(LEFT_ALIGNMENT);
        proceed.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        proceed.addActionListener(e -> {
            settingsMgr.save();
            proceeded = true;
            dispose();
        });
        root.add(proceed);
        root.add(Box.createVerticalStrut(6));

        JLabel note = new JLabel("These choices are saved to settings and can be changed at any time.");
        note.setFont(Colors.PANEL_SMALL);
        note.setForeground(Colors.TEXT_DIM);
        note.setAlignmentX(LEFT_ALIGNMENT);
        root.add(note);

        JScrollPane scroll = new JScrollPane(root);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        setContentPane(scroll);
        getContentPane().setBackground(Colors.BG);
    }

    private JPanel alwaysRow(String label, String desc) {
        JPanel row = new JPanel(new BorderLayout(10, 2));
        row.setOpaque(false);
        row.setAlignmentX(LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));

        JLabel lbl = new JLabel("• " + label);
        lbl.setFont(Colors.LABEL);
        lbl.setForeground(Colors.TEXT);

        JLabel dsc = new JLabel("<html><body style='color:#666'>" + desc + "</body></html>");
        dsc.setFont(Colors.PANEL_SMALL);

        JPanel inner = new JPanel();
        inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS));
        inner.setOpaque(false);
        inner.add(lbl);
        inner.add(dsc);
        row.add(inner, BorderLayout.CENTER);
        return row;
    }

    private JPanel optionalToggleRow(String label, String desc,
                                     String warning, boolean current,
                                     java.util.function.Consumer<Boolean> setter) {
        JPanel outer = new JPanel();
        outer.setLayout(new BoxLayout(outer, BoxLayout.Y_AXIS));
        outer.setOpaque(false);
        outer.setAlignmentX(LEFT_ALIGNMENT);

        // Toggle row
        JPanel top = new JPanel(new BorderLayout(12, 0));
        top.setOpaque(false);
        top.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        JLabel lbl = new JLabel(label);
        lbl.setFont(Colors.LABEL);
        lbl.setForeground(Colors.TEXT);

        JToggleButton toggle = new JToggleButton(current ? "Enabled" : "Disabled");
        toggle.setSelected(current);
        toggle.setFont(Colors.SANS_SMALL);
        toggle.setPreferredSize(new Dimension(86, 28));
        styleToggle(toggle, current);
        toggle.addActionListener(e -> {
            boolean on = toggle.isSelected();
            toggle.setText(on ? "Enabled" : "Disabled");
            styleToggle(toggle, on);
            setter.accept(on);
        });

        top.add(lbl, BorderLayout.CENTER);
        top.add(toggle, BorderLayout.EAST);
        outer.add(top);
        outer.add(Box.createVerticalStrut(3));

        // Description
        JLabel dsc = new JLabel("<html><body style='width:380px; color:#666'>" + desc + "</body></html>");
        dsc.setFont(Colors.PANEL_SMALL);
        dsc.setBorder(BorderFactory.createEmptyBorder(0, 2, 2, 0));
        outer.add(dsc);

        // Warning badge
        if (!warning.isEmpty()) {
            JLabel warn = new JLabel(warning);
            warn.setFont(new Font(Colors.PANEL_SMALL.getFamily(), Font.BOLD,
                                  Colors.PANEL_SMALL.getSize()));
            warn.setForeground(new Color(200, 140, 40));
            warn.setBorder(BorderFactory.createEmptyBorder(0, 2, 4, 0));
            outer.add(warn);
        }

        return outer;
    }

    private void styleToggle(JToggleButton t, boolean on) {
        t.setBackground(on ? new Color(40, 80, 40) : new Color(70, 30, 30));
        t.setForeground(on ? new Color(120, 220, 120) : new Color(200, 100, 100));
    }

    private boolean alreadySeen() { return new File(flagPath).exists(); }

    private void writeFlag() {
        try { Files.writeString(Paths.get(flagPath), "seen"); }
        catch (Exception ignored) {}
    }

    /**
     * Show the advisory if it hasn't been seen for this installation.
     * Always saves settings on proceed.
     */
    public static void check(Frame owner, GameSettings settings,
                             SettingsManager settingsMgr, String gameDir) {
        ContentAdvisoryScreen screen =
            new ContentAdvisoryScreen(owner, settings, settingsMgr, gameDir);
        if (screen.alreadySeen()) return;
        screen.setVisible(true); // blocks
        if (screen.proceeded) screen.writeFlag();
        else System.exit(0); // closed without proceeding — treat as decline
    }
}
