package game.ui;

import game.*;
import game.data.ClothingData;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class OutfitPanel extends JPanel {

    private final GameState      state;
    private final ClothingLoader clothes;
    private final Runnable       onClose;
    private       game.AssetManager assetManager;

    private static final String[] SLOTS       = { "bra", "upper", "lower", "overcoat", "underwear", "socks", "shoes" };
    private static final String[] SLOT_LABELS = { "Bra", "Top", "Bottom", "Overcoat", "Underwear", "Socks", "Shoes" };
    private static final String[] SLOT_NONE   = { "Braless", "Nothing (can't go out)", "Nothing (can't go out)", "None", "Commando", "No socks", "Barefoot" };

    public void setAssetManager(game.AssetManager am) { this.assetManager = am; }

    public OutfitPanel(GameState state, ClothingLoader clothes, Runnable onClose) {
        this.state   = state;
        this.clothes = clothes;
        this.onClose = onClose;
        setBackground(Colors.BG);
        setLayout(new BorderLayout());
        build();
    }

    private void build() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setBorder(BorderFactory.createEmptyBorder(22, 44, 12, 44));
        JLabel title = new JLabel("What are you wearing?");
        title.setForeground(Colors.TEXT_HEAD);
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        header.add(title, BorderLayout.WEST);
        header.add(makeCloseBtn(), BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // ── Saved Outfit Controls ────────────────────────────────────────────────
        JPanel outfitBar = buildOutfitBar();
        JPanel topSection = new JPanel();
        topSection.setLayout(new BoxLayout(topSection, BoxLayout.Y_AXIS));
        topSection.setOpaque(false);
        topSection.add(outfitBar);


        topSection.add(buildNoticesPanel());
        add(topSection, BorderLayout.NORTH);


        add(scroll, BorderLayout.CENTER);
    }

    private JPanel buildSlotRow(String slot, String label, String noneLabel) {
        JPanel row = new JPanel(new BorderLayout(14, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));

        JLabel slotLbl = new JLabel(label);
        slotLbl.setForeground(Colors.TEXT_DIM);
        slotLbl.setFont(Colors.PANEL_BOLD);
        slotLbl.setPreferredSize(new Dimension(90, 20));

        String currentId = getCurrentForSlot(slot);
        ClothingData current = currentId != null ? clothes.get(currentId) : null;
        String displayName = current != null ? current.color + " " + current.name : noneLabel;

        // If bottom slot is covered by a fills_lower dress, note it
        if ("lower".equals(slot) && current == null && state.outfitUpper != null) {
            ClothingData upper = clothes.get(state.outfitUpper);
            if (upper != null && upper.fills_lower)
                displayName = "Covered by " + upper.color + " " + upper.name;
        }

        JLabel itemLbl = new JLabel(displayName);
        itemLbl.setForeground(current != null ? Colors.TEXT : Colors.TEXT_DIM);
        itemLbl.setFont(Colors.SANS_PLAIN);

        JButton changeBtn = makeSmallBtn("Change");
        final String slotF = slot;
        changeBtn.addActionListener(e -> openSlotPicker(slotF, label, noneLabel));

        row.add(slotLbl,   BorderLayout.WEST);
        row.add(itemLbl,   BorderLayout.CENTER);
        row.add(changeBtn, BorderLayout.EAST);
        return row;
    }

    private void openSlotPicker(String slot, String slotLabel, String noneLabel) {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this),
            "Choose " + slotLabel, true);
        dialog.getContentPane().setBackground(Colors.BG_PANEL);
        dialog.setLayout(new BorderLayout());

        JLabel title = new JLabel("  " + slotLabel);
        title.setForeground(Colors.TEXT_HEAD);
        title.setFont(new Font("SansSerif", Font.BOLD, 13));
        title.setBorder(BorderFactory.createEmptyBorder(12, 0, 8, 0));
        dialog.add(title, BorderLayout.NORTH);

        JPanel list = new JPanel();
        list.setOpaque(false);
        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
        list.setBorder(BorderFactory.createEmptyBorder(0, 14, 14, 14));

        JButton noneBtn = makePickerBtn(noneLabel, Colors.TEXT_DIM);
        noneBtn.addActionListener(e -> { setSlot(slot, null); dialog.dispose(); rebuild(); });
        list.add(noneBtn); list.add(Box.createVerticalStrut(5));

        for (String ownedId : state.ownedClothing) {
            ClothingData c = clothes.get(ownedId);
            if (c == null) continue;
            if (!c.slot.equals(slot)) continue;

            String props = buildPropsStr(c);
            String fillsNote = c.fills_lower ? "  <font color='#7878a0'>· covers bottom too</font>" : "";

            JButton btn = makePickerBtn(
                "<html><b>" + c.color + " " + c.name + "</b>" + fillsNote
                + (props.isEmpty() ? "" : " <font color='#7878a0'>" + props + "</font>")
                + "<br><font color='#7878a0' size='-1'>" + shorten(c.description, 80) + "</font></html>",
                Colors.TEXT);
            btn.addActionListener(e -> {
                setSlot(slot, c.id);
                dialog.dispose();
                rebuild();
            });
            list.add(btn); list.add(Box.createVerticalStrut(5));
        }

        JScrollPane scroll = new JScrollPane(list);
        scroll.setOpaque(false); scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        dialog.add(scroll, BorderLayout.CENTER);
        dialog.setSize(440, 480);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private String buildPropsStr(ClothingData c) {
        List<String> props = new ArrayList<>();
        if (c.tight)        props.add("tight");
        if (c.loose)        props.add("loose");
        if (c.crop_top)     props.add("crop");
        if (c.off_shoulder) props.add("off-shoulder");
        if (c.seethrough || c.seethrough_when_wet) props.add(c.seethrough ? "sheer" : "sheer-wet");
        if (c.braless)      props.add("braless style");
        if (c.is_skirt)     props.add("skirt");
        if (!"none".equals(c.heel_type) && !c.heel_type.isEmpty()) props.add(c.heel_type + " heel");
        if (!"medium".equals(c.thickness) && !c.thickness.isEmpty()) props.add(c.thickness);
        if (c.has_buttons)  props.add("buttons");
        if (c.sandals)      props.add("sandals");
        if (c.lewdness_rating > 0) props.add("lewd " + c.lewdness_rating);
        if (c.formal_rating > 0)   props.add("formal " + c.formal_rating);
        return String.join(" · ", props);
    }

    private String shorten(String s, int max) { return s.length() > max ? s.substring(0, max) + "…" : s; }

    private void setSlot(String slot, String id) {
        switch (slot) {
            case "bra":       state.outfitBra       = id; break;
            case "upper":     state.outfitUpper     = id; break;
            case "lower":     state.outfitLower     = id; break;
            case "overcoat":  state.outfitOvercoat  = id; break;
            case "underwear": state.outfitUnderwear = id; break;
            case "socks":     state.outfitSocks     = id; break;
            case "shoes":     state.outfitShoes     = id; break;
        }
    }

    private String getCurrentForSlot(String slot) {
        switch (slot) {
            case "bra":       return state.outfitBra;
            case "upper":     return state.outfitUpper;
            case "lower":     return state.outfitLower;
            case "overcoat":  return state.outfitOvercoat;
            case "underwear": return state.outfitUnderwear;
            case "socks":     return state.outfitSocks;
            case "shoes":     return state.outfitShoes;
            default:          return null;
        }
    }

    private void rebuild() { removeAll(); build(); revalidate(); repaint(); }
    private String fmt(String t) { String s = t.replace("_", " "); return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1); }


    // ── Saved outfit bar ─────────────────────────────────────────────────────
    private JPanel buildOutfitBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        bar.setOpaque(false);
        bar.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 44, 0, 44));

        // Save current outfit button
        JButton saveBtn = new JButton("Save Outfit…");
        saveBtn.setFont(Colors.PANEL_PLAIN);
        saveBtn.addActionListener(e -> {
            String name = javax.swing.JOptionPane.showInputDialog(this,
                "Name this outfit:", "Save Outfit", javax.swing.JOptionPane.PLAIN_MESSAGE);
            if (name != null && !name.isBlank()) {
                state.saveCurrentOutfit(name.trim());
                refreshOutfitDropdown();
            }
        });
        bar.add(saveBtn);

        // Load dropdown
        JLabel loadLbl = new JLabel("Load:");
        loadLbl.setForeground(Colors.TEXT_DIM);
        loadLbl.setFont(Colors.PANEL_PLAIN);
        bar.add(loadLbl);

        outfitDropdown = new JComboBox<>();
        outfitDropdown.setFont(Colors.PANEL_PLAIN);
        refreshOutfitDropdown();
        bar.add(outfitDropdown);

        JButton loadBtn = new JButton("Apply");
        loadBtn.setFont(Colors.PANEL_PLAIN);
        loadBtn.addActionListener(e -> {
            String selected = (String) outfitDropdown.getSelectedItem();
            if (selected != null && !selected.isEmpty()) {
                state.loadOutfit(selected);
                rebuildContent();
            }
        });
        bar.add(loadBtn);

        // Daily outfit toggle
        JButton dailyBtn = new JButton(state.dailyOutfitName.isEmpty()
                ? "Set as Daily Outfit" : "Daily: " + state.dailyOutfitName);
        dailyBtn.setFont(Colors.PANEL_PLAIN);
        dailyBtn.addActionListener(e -> {
            String selected = (String) outfitDropdown.getSelectedItem();
            if (selected != null && !selected.isEmpty()) {
                state.dailyOutfitName = selected;
                dailyBtn.setText("Daily: " + selected);
            }
        });
        bar.add(dailyBtn);

        JButton clearDailyBtn = new JButton("Clear Daily");
        clearDailyBtn.setFont(Colors.PANEL_PLAIN);
        clearDailyBtn.setVisible(!state.dailyOutfitName.isEmpty());
        clearDailyBtn.addActionListener(e -> {
            state.dailyOutfitName = "";
            dailyBtn.setText("Set as Daily Outfit");
            clearDailyBtn.setVisible(false);
        });
        bar.add(clearDailyBtn);

        return bar;
    }

    private JComboBox<String> outfitDropdown;

    private void refreshOutfitDropdown() {
        if (outfitDropdown == null) return;
        outfitDropdown.removeAllItems();
        for (GameState.SavedOutfit o : state.savedOutfits)
            outfitDropdown.addItem(o.name);
    }

    private void rebuildContent() {
        removeAll();
        build();
        revalidate();
        repaint();
    }

    private JPanel buildNoticesPanel() {
        JPanel notices = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 4));
        notices.setOpaque(false);
        notices.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 44, 4, 44));
        Set<String> dynTraits = state.computeDynamicTraits(clothes);
        for (String t : dynTraits) {
            JLabel lbl = new JLabel("⚠ " + fmt(t));
            lbl.setForeground(new Color(220, 160, 80));
            lbl.setFont(Colors.PANEL_PLAIN);
            notices.add(lbl);
        }
        if (!state.canGoOut(clothes)) {
            JLabel warn = new JLabel("⛔  Not enough clothing to go out");
            warn.setForeground(new Color(220, 80, 80));
            warn.setFont(Colors.PANEL_BOLD);
            notices.add(warn);
        }
        return notices;
    }

    private JButton makeCloseBtn() {
        JButton b = new JButton("Done"); b.setForeground(Color.WHITE);
        b.setFont(Colors.PANEL_BOLD); b.setBackground(new Color(70,60,120));
        b.setFocusPainted(false); b.setBorder(BorderFactory.createEmptyBorder(6,16,6,16));
        b.addActionListener(e -> onClose.run()); return b;
    }
    private JButton makeSmallBtn(String t) {
        JButton b = new JButton(t); b.setForeground(Colors.TEXT_HEAD);
        b.setFont(Colors.PANEL_PLAIN); b.setBackground(Colors.BG_BTN);
        b.setFocusPainted(false); b.setBorder(BorderFactory.createEmptyBorder(5,12,5,12)); return b;
    }
    private JButton makePickerBtn(String html, Color fg) {
        JButton b = new JButton(html); b.setForeground(fg); b.setBackground(Colors.BG_BTN);
        b.setFont(Colors.PANEL_PLAIN); b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Colors.BORDER), BorderFactory.createEmptyBorder(8,10,8,10)));
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60)); b.setAlignmentX(LEFT_ALIGNMENT);
        b.setFocusPainted(false); b.setContentAreaFilled(true); return b;
    }
}
