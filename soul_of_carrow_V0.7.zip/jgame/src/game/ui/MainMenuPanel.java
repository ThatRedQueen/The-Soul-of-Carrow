package game.ui;

import game.mod.Mod;
import game.mod.ModLoader;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.List;
import java.util.function.Supplier;

/**
 * Main menu — atmospheric title screen for The Soul of Carrow.
 */
public class MainMenuPanel extends JPanel {

    private final Runnable         onPlay;
    private final ModLoader        modLoader;
    private final Runnable         onShowModManager;
    private final Runnable         onShowLoad;
    private final game.SaveManager saveManager;
    private final Runnable         onShowSettings;

    public MainMenuPanel(Runnable onPlay, ModLoader modLoader, Runnable onShowModManager,
                         Runnable onShowLoad, game.SaveManager saveManager,
                         Runnable onShowSettings) {
        this.onPlay           = onPlay;
        this.modLoader        = modLoader;
        this.onShowModManager = onShowModManager;
        this.onShowLoad       = onShowLoad;
        this.saveManager      = saveManager;
        this.onShowSettings   = onShowSettings;

        setBackground(Colors.BG);
        setLayout(new BorderLayout());
        build();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Subtle vignette gradient — darker at edges, slightly lighter at centre
        Graphics2D g2 = (Graphics2D) g;
        int w = getWidth(), h = getHeight();
        RadialGradientPaint vignette = new RadialGradientPaint(
            new Point(w/2, h/2),
            Math.max(w, h) * 0.7f,
            new float[]{0f, 1f},
            new Color[]{new Color(22,20,38,0), new Color(0,0,0,120)}
        );
        g2.setPaint(vignette);
        g2.fillRect(0, 0, w, h);
    }

    private void build() {
        // ── Left accent bar ───────────────────────────────────────────────────
        JPanel accentBar = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                    0,0, Colors.ACCENT,
                    0, getHeight(), new Color(Colors.ACCENT.getRed(), Colors.ACCENT.getGreen(), Colors.ACCENT.getBlue(), 0));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        accentBar.setPreferredSize(new Dimension(3, 0));
        accentBar.setOpaque(false);
        add(accentBar, BorderLayout.WEST);

        // ── Centre content ────────────────────────────────────────────────────
        JPanel centre = new JPanel();
        centre.setOpaque(false);
        centre.setLayout(new GridBagLayout());

        JPanel stack = new JPanel();
        stack.setOpaque(false);
        stack.setLayout(new BoxLayout(stack, BoxLayout.Y_AXIS));
        stack.setBorder(BorderFactory.createEmptyBorder(0, 80, 0, 80));

        // Title block
        stack.add(Box.createVerticalGlue());
        stack.add(buildTitleBlock());
        stack.add(Box.createVerticalStrut(56));

        // Buttons
        boolean hasSave = saveManager != null &&
            (saveManager.autosaveExists() || saveManager.slotExists(1)
             || saveManager.slotExists(2)  || saveManager.slotExists(3));

        if (hasSave) {
            stack.add(menuBtn("Continue", true, e -> onShowLoad.run()));
            stack.add(Box.createVerticalStrut(8));
        }
        stack.add(menuBtn(hasSave ? "New Game" : "New Game", !hasSave, e -> confirmNewGame(hasSave)));
        stack.add(Box.createVerticalStrut(8));
        if (hasSave) {
            stack.add(menuBtn("Load / Save", false, e -> onShowLoad.run()));
            stack.add(Box.createVerticalStrut(8));
        }
        stack.add(menuBtn("Settings", false, e -> { if (onShowSettings != null) onShowSettings.run(); }));
        stack.add(Box.createVerticalStrut(8));
        stack.add(menuBtn("Mods", false, e -> onShowModManager.run()));
        stack.add(Box.createVerticalStrut(8));
        stack.add(menuBtn("Quit", false, e -> game.CrashReporter.safeExit()));

        stack.add(Box.createVerticalStrut(48));

        // Footer — version + mod status
        stack.add(buildFooter());
        stack.add(Box.createVerticalGlue());

        centre.add(stack);
        add(centre, BorderLayout.CENTER);
    }

    private JPanel buildTitleBlock() {
        JPanel block = new JPanel();
        block.setOpaque(false);
        block.setLayout(new BoxLayout(block, BoxLayout.Y_AXIS));

        // Small eyebrow
        JLabel eyebrow = new JLabel("a life simulator");
        eyebrow.setFont(new Font("Georgia", Font.ITALIC, 13));
        eyebrow.setForeground(Colors.ACCENT);
        eyebrow.setAlignmentX(LEFT_ALIGNMENT);

        // Main title — two lines for dramatic weight
        JLabel titleLine1 = new JLabel("The Soul");
        titleLine1.setFont(new Font("Georgia", Font.BOLD, 64));
        titleLine1.setForeground(Colors.TEXT_HEAD);
        titleLine1.setAlignmentX(LEFT_ALIGNMENT);

        JLabel titleLine2 = new JLabel("of Carrow");
        titleLine2.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 64));
        titleLine2.setForeground(Colors.ACCENT_LIT);
        titleLine2.setAlignmentX(LEFT_ALIGNMENT);

        // Thin rule under title
        JSeparator rule = new JSeparator() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g;
                GradientPaint gp = new GradientPaint(
                    0,0, Colors.ACCENT,
                    getWidth(),0, new Color(Colors.ACCENT.getRed(),Colors.ACCENT.getGreen(),Colors.ACCENT.getBlue(),0));
                g2.setPaint(gp);
                g2.fillRect(0,0,getWidth(),getHeight());
            }
        };
        rule.setPreferredSize(new Dimension(240, 1));
        rule.setMaximumSize(new Dimension(240, 1));
        rule.setAlignmentX(LEFT_ALIGNMENT);

        // Tagline
        JLabel tagline = new JLabel("Carrow is waiting. So is everything else.");
        tagline.setFont(new Font("Georgia", Font.ITALIC, 14));
        tagline.setForeground(Colors.TEXT_DIM);
        tagline.setAlignmentX(LEFT_ALIGNMENT);

        block.add(eyebrow);
        block.add(Box.createVerticalStrut(4));
        block.add(titleLine1);
        block.add(titleLine2);
        block.add(Box.createVerticalStrut(14));
        block.add(rule);
        block.add(Box.createVerticalStrut(10));
        block.add(tagline);

        return block;
    }

    private JPanel buildFooter() {
        JPanel footer = new JPanel();
        footer.setOpaque(false);
        footer.setLayout(new BoxLayout(footer, BoxLayout.Y_AXIS));

        // Mod status
        List<Mod> mods = modLoader.getMods();
        String modText;
        Color  modColor;
        if (mods.isEmpty()) {
            modText  = "No mods loaded";
            modColor = new Color(50, 50, 70);
        } else {
            long ok      = mods.stream().filter(m -> m.status == Mod.Status.OK).count();
            long disabled= mods.stream().filter(m -> m.status == game.mod.Mod.Status.DISABLED).count();
            long problem = mods.stream().filter(m -> m.status == game.mod.Mod.Status.FAILED
                                                  || m.status == game.mod.Mod.Status.PARTIAL).count();
            long loaded  = mods.size() - disabled;
            modText  = loaded + " mod" + (loaded==1?"":"s") + " loaded"
                       + (disabled > 0 ? "  ·  " + disabled + " disabled" : "")
                       + (problem  > 0 ? "  ·  ⚠ " + problem + " with issues" : "  ·  ✓ all clean");
            modColor = problem > 0 ? new Color(200, 140, 50) : new Color(70, 160, 90);
        }
        JLabel modLbl = new JLabel(modText);
        modLbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
        modLbl.setForeground(modColor);
        modLbl.setAlignmentX(LEFT_ALIGNMENT);

        JLabel version = new JLabel(game.GameMeta.versionString());
        version.setFont(new Font("SansSerif", Font.PLAIN, 10));
        version.setForeground(new Color(45, 45, 60));
        version.setAlignmentX(LEFT_ALIGNMENT);

        footer.add(modLbl);
        footer.add(Box.createVerticalStrut(3));
        footer.add(version);

        return footer;
    }

    private void confirmNewGame(boolean hasSave) {
        if (hasSave) {
            int c = JOptionPane.showConfirmDialog(this,
                "Starting a new game will not delete your saves.\nContinue to character creation?",
                "New Game", JOptionPane.YES_NO_OPTION);
            if (c != JOptionPane.YES_OPTION) return;
        }
        onPlay.run();
    }

    private JPanel menuBtn(String text, boolean primary, ActionListener action) {
        // Returns a panel so we can control max width cleanly
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.setMaximumSize(new Dimension(260, 46));
        wrapper.setAlignmentX(LEFT_ALIGNMENT);

        JButton btn = new JButton(text) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Background
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                // Left accent stripe for primary
                if (primary) {
                    g2.setColor(Colors.ACCENT);
                    g2.fillRoundRect(0, 0, 3, getHeight(), 3, 3);
                }
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("SansSerif", primary ? Font.BOLD : Font.PLAIN, 15));
        btn.setForeground(primary ? Colors.TEXT_HEAD : Colors.TEXT);
        btn.setBackground(primary ? new Color(32, 28, 54) : new Color(24, 24, 38));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(primary ? Colors.BORDER : new Color(32,32,48), 1),
            BorderFactory.createEmptyBorder(11, 18, 11, 18)));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(action);

        Color baseColor = btn.getBackground();
        Color hoverColor = primary ? new Color(40, 34, 70) : new Color(30, 30, 50);
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(hoverColor); }
            public void mouseExited (MouseEvent e) { btn.setBackground(baseColor);  }
        });

        wrapper.add(btn, BorderLayout.CENTER);
        return wrapper;
    }
}
