package game.ui;

import game.*;
import game.data.ClothingData;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class ShoppingPanel extends JPanel {

    private final GameState     state;
    private final ClothingLoader clothes;
    private final Runnable      onClose;
    private       game.AssetManager assetManager;   // null = no clothing images

    private List<ClothingData> stock;
    private JLabel moneyLabel;

    public void setAssetManager(game.AssetManager am) { this.assetManager = am; }

    public ShoppingPanel(GameState state, ClothingLoader clothes, Runnable onClose) {
        this.state   = state;
        this.clothes  = clothes;
        this.onClose = onClose;
        this.stock   = generateStock();
        setBackground(Colors.BG);
        setLayout(new BorderLayout());
        build();
    }

    /** Generate a random stock of 8-10 items each visit */
    private List<ClothingData> generateStock() {
        // Exclude items MC already owns; exclude starting-only items if lock is cleared
        return clothes.randomShopStock(10, new Random(), state.ownedClothing, state.startingOutfitsOnly);
    }

    private void build() {
        // Header
        JPanel header = new JPanel(new BorderLayout(0, 4));
        header.setOpaque(false);
        header.setBorder(BorderFactory.createEmptyBorder(22, 44, 12, 44));

        JLabel title = new JLabel("Clothing Store");
        title.setForeground(Colors.TEXT_HEAD);
        title.setFont(new Font("SansSerif", Font.BOLD, 18));

        moneyLabel = new JLabel("$" + String.format("%,d", state.money));
        moneyLabel.setForeground(new Color(100, 200, 120));
        moneyLabel.setFont(Colors.PANEL_BOLD);

        JLabel sub = new JLabel("Selection changes each visit. What's here today only.");
        sub.setForeground(Colors.TEXT_DIM);
        sub.setFont(Colors.PANEL_SMALL);

        JPanel titleRow = new JPanel(new BorderLayout());
        titleRow.setOpaque(false);
        titleRow.add(title, BorderLayout.WEST);
        titleRow.add(moneyLabel, BorderLayout.EAST);

        JButton leaveBtn = makeBtn("Leave Store", new Color(60, 60, 90));
        leaveBtn.addActionListener(e -> onClose.run());

        header.add(titleRow, BorderLayout.NORTH);
        header.add(sub, BorderLayout.CENTER);
        header.add(leaveBtn, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // Item cards
        JPanel grid = new JPanel();
        grid.setOpaque(false);
        grid.setLayout(new BoxLayout(grid, BoxLayout.Y_AXIS));
        grid.setBorder(BorderFactory.createEmptyBorder(4, 44, 24, 44));

        if (stock.isEmpty()) {
            JLabel empty = new JLabel("Nothing interesting in stock today.");
            empty.setForeground(Colors.TEXT_DIM);
            empty.setFont(Colors.SANS_PLAIN);
            grid.add(empty);
        }

        for (ClothingData item : stock) {
            grid.add(buildItemCard(item));
            grid.add(Box.createVerticalStrut(10));
        }

        JScrollPane scroll = new JScrollPane(grid);
        scroll.setOpaque(false); scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(12);
        add(scroll, BorderLayout.CENTER);
    }

    private JPanel buildItemCard(ClothingData item) {
        JPanel card = new JPanel(new BorderLayout(12, 0));
        card.setBackground(Colors.BG_PANEL);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Colors.BORDER),
            BorderFactory.createEmptyBorder(14, 18, 14, 18)));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));

        // Left info
        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));

        String colorName = item.color.isEmpty() ? "" : item.color + " ";
        JLabel name = new JLabel(colorName + item.name + " — " + slotLabel(item.slot));
        name.setForeground(Colors.TEXT_HEAD);
        name.setFont(Colors.PANEL_BOLD);
        name.setAlignmentX(LEFT_ALIGNMENT);

        // Description
        JLabel descLbl = new JLabel("<html><body style='width:380px'>" + item.description + "</body></html>");
        descLbl.setForeground(Colors.TEXT_DIM);
        descLbl.setFont(Colors.PANEL_SMALL);
        descLbl.setAlignmentX(LEFT_ALIGNMENT);

        // Properties
        String props = buildPropsStr(item);
        JLabel propsLbl = new JLabel(props.isEmpty() ? "" : props);
        propsLbl.setForeground(new Color(140, 120, 200));
        propsLbl.setFont(Colors.PANEL_SMALL);
        propsLbl.setAlignmentX(LEFT_ALIGNMENT);

        // Clothing thumbnail image (from asset pack mod)
        if (assetManager != null) {
            String imgKey = "clothing_" + item.id;
            javax.swing.ImageIcon thumb = assetManager.get(imgKey, 80, 80);
            if (thumb != null) {
                javax.swing.JLabel thumbLbl = new javax.swing.JLabel(thumb);
                thumbLbl.setAlignmentX(LEFT_ALIGNMENT);
                info.add(thumbLbl);
                info.add(Box.createVerticalStrut(4));
            }
        }

        info.add(name);
        info.add(Box.createVerticalStrut(3));
        info.add(descLbl);
        if (!props.isEmpty()) { info.add(Box.createVerticalStrut(2)); info.add(propsLbl); }

        // Right — price + buy button
        JPanel right = new JPanel(new GridBagLayout());
        right.setOpaque(false);

        JPanel btnPanel = new JPanel();
        btnPanel.setOpaque(false);
        btnPanel.setLayout(new BoxLayout(btnPanel, BoxLayout.Y_AXIS));

        JLabel priceLbl = new JLabel("$" + item.price);
        priceLbl.setForeground(new Color(100, 200, 120));
        priceLbl.setFont(Colors.PANEL_BOLD);
        priceLbl.setAlignmentX(CENTER_ALIGNMENT);

        boolean alreadyOwned = state.ownedClothing.contains(item.id);
        boolean canAfford    = state.money >= item.price;

        JButton buyBtn;
        if (alreadyOwned) {
            buyBtn = makeBtn("Owned", new Color(40, 80, 40));
            buyBtn.setEnabled(false);
        } else if (!canAfford) {
            buyBtn = makeBtn("Can't afford", new Color(80, 40, 40));
            buyBtn.setEnabled(false);
        } else {
            buyBtn = makeBtn("Buy", new Color(70, 55, 140));
            buyBtn.addActionListener(e -> handleBuy(item, buyBtn, priceLbl));
        }

        btnPanel.add(priceLbl);
        btnPanel.add(Box.createVerticalStrut(5));
        btnPanel.add(buyBtn);

        // Try On button — temporarily equips item for preview
        JButton tryOnBtn = makeBtn("Try On", new Color(50, 80, 60));
        final String prevSlot;
        switch (item.slot) {
            case "upper":    prevSlot = state.outfitUpper;     break;
            case "lower":    prevSlot = state.outfitLower;     break;
            case "bra":      prevSlot = state.outfitBra;       break;
            case "underwear":prevSlot = state.outfitUnderwear; break;
            case "shoes":    prevSlot = state.outfitShoes;     break;
            default:         prevSlot = null;
        }
        tryOnBtn.addActionListener(e -> {
            // Equip temporarily
            state.setOutfitSlot(item.slot, item.id);
            // Rebuild to show updated warnings (nipping preview etc.)
            removeAll();
            this.stock = generateStock();
            build();
            revalidate(); repaint();
        });
        btnPanel.add(Box.createVerticalStrut(4));
        btnPanel.add(tryOnBtn);

        // Nipping preview label
        if ("upper".equals(item.slot) || "bra".equals(item.slot)) {
            boolean wouldNip  = item.isNipRisk() && state.isBraless();
            boolean wouldShow = item.braless || item.seethrough;
            if (wouldNip || wouldShow) {
                JLabel nipWarn = new JLabel(wouldShow ? "⚠ Visible braless" : "⚠ Nipping risk");
                nipWarn.setForeground(new Color(220, 140, 60));
                nipWarn.setFont(new Font("SansSerif", Font.PLAIN, 11));
                nipWarn.setAlignmentX(Component.CENTER_ALIGNMENT);
                btnPanel.add(Box.createVerticalStrut(3));
                btnPanel.add(nipWarn);
            }
        }

        right.add(btnPanel);

        card.add(info,  BorderLayout.CENTER);
        card.add(right, BorderLayout.EAST);
        return card;
    }

    private void handleBuy(ClothingData item, JButton btn, JLabel priceLbl) {
        state.money -= item.price;
        state.ownedClothing.add(item.id);
        btn.setText("Owned");
        btn.setEnabled(false);
        btn.setBackground(new Color(40, 80, 40));
        moneyLabel.setText("$" + String.format("%,d", state.money));
        // Rebuild stock view so affordability updates across all cards
        removeAll();
        build();
        revalidate(); repaint();
    }

    private String slotLabel(String slot) {
        switch (slot) {
            case "upper":     return "Top";
            case "lower":     return "Bottom";
            case "overcoat":  return "Overcoat / Jacket";
            case "bra":       return "Bra";
            case "underwear": return "Underwear";
            case "socks":     return "Socks";
            case "shoes":     return "Shoes";
            default:          return slot;
        }
    }

    private String buildPropsStr(ClothingData c) {
        List<String> props = new ArrayList<>();
        if (c.tight)           props.add("Tight");
        if (c.loose)           props.add("Loose");
        if (c.crop_top)        props.add("Crop top");
        if (c.off_shoulder)    props.add("Off-shoulder");
        if (c.has_buttons)     props.add("Buttons");
        if (c.seethrough || c.seethrough_when_wet) props.add(c.seethrough ? "Sheer" : "Sheer when wet");
        if (c.braless)         props.add("Braless style");
        if (c.is_skirt)        props.add("Skirt");
        if (!"none".equals(c.heel_type))  props.add(c.heel_type.substring(0,1).toUpperCase() + c.heel_type.substring(1) + " heel");
        if (!"medium".equals(c.thickness) && !c.thickness.isEmpty()) {
            props.add(c.thickness.substring(0,1).toUpperCase() + c.thickness.substring(1));
        }
        if (c.sandals) props.add("Sandals");
        if (c.lewdness_rating > 0) props.add("Lewdness " + c.lewdness_rating + "/10");
        if (c.formal_rating > 0)   props.add("Formal " + c.formal_rating + "/10");
        return String.join("  ·  ", props);
    }

    private JButton makeBtn(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFont(Colors.PANEL_BOLD);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(7, 16, 7, 16));
        btn.setAlignmentX(CENTER_ALIGNMENT);
        return btn;
    }
}
