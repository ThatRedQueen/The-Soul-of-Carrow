package game.ui;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.file.*;

/**
 * Age verification screen. Shown once per installation.
 * If the player confirms they are 18+, a flag file is written and the screen
 * never appears again. If they decline, the application exits immediately.
 *
 * No drama, no guilt — just the legal requirement.
 */
public class AgeGateScreen extends JDialog {

    private boolean confirmed = false;
    private final String flagPath;

    private AgeGateScreen(Frame owner, String gameDir) {
        super(owner, "Age Verification", true);
        this.flagPath = gameDir + File.separator + "age_confirmed.dat";
        buildUI();
        pack();
        setMinimumSize(new Dimension(420, 260));
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setResizable(false);
    }

    private void buildUI() {
        JPanel root = new JPanel();
        root.setLayout(new BoxLayout(root, BoxLayout.Y_AXIS));
        root.setBackground(Colors.BG);
        root.setBorder(BorderFactory.createEmptyBorder(32, 36, 28, 36));

        JLabel title = new JLabel("Age Verification");
        title.setFont(Colors.PANEL_HEAD);
        title.setForeground(Colors.TEXT_HEAD);
        title.setAlignmentX(LEFT_ALIGNMENT);
        root.add(title);
        root.add(Box.createVerticalStrut(16));

        JLabel body = new JLabel("<html><body style='width:340px'>"
            + "This game contains adult content including explicit sexual material, "
            + "mature themes, and content intended for adults only.<br><br>"
            + "You must be at least <b>18 years of age</b> (or the legal age of majority "
            + "in your jurisdiction, if higher) to proceed."
            + "</body></html>");
        body.setFont(Colors.LABEL);
        body.setForeground(Colors.TEXT);
        body.setAlignmentX(LEFT_ALIGNMENT);
        root.add(body);
        root.add(Box.createVerticalStrut(28));

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        btns.setOpaque(false);
        btns.setAlignmentX(LEFT_ALIGNMENT);

        JButton yes = new JButton("I am 18 or older — Continue");
        yes.setFont(Colors.LABEL);
        yes.setBackground(Colors.BG_BTN);
        yes.setForeground(Colors.TEXT_HEAD);
        yes.addActionListener(e -> { confirmed = true; dispose(); });

        JButton no = new JButton("Exit");
        no.setFont(Colors.LABEL);
        no.setBackground(Colors.BG);
        no.setForeground(Colors.TEXT_DIM);
        no.addActionListener(e -> System.exit(0));

        btns.add(yes);
        btns.add(no);
        root.add(btns);

        setContentPane(root);
        getContentPane().setBackground(Colors.BG);
    }

    private boolean alreadyConfirmed() {
        return new File(flagPath).exists();
    }

    private void writeFlag() {
        try { Files.writeString(Paths.get(flagPath), "confirmed"); }
        catch (Exception ignored) {}
    }

    /**
     * Show the age gate if it hasn't been confirmed for this installation.
     * Returns true if play should continue, false if the app should exit.
     */
    public static boolean check(Frame owner, String gameDir) {
        AgeGateScreen gate = new AgeGateScreen(owner, gameDir);
        if (gate.alreadyConfirmed()) return true;
        gate.setVisible(true); // blocks until disposed
        if (gate.confirmed) { gate.writeFlag(); return true; }
        return false; // user clicked Exit — caller should System.exit
    }
}
