package game.ui;

import game.GameSettings;
import game.GameState;
import game.SexState;

import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;

/**
 * Safety / cheat menu — always accessible from the top bar of any scene or
 * sex scene. Allows the player to:
 *   • Exit any scene immediately (returns to day hub)
 *   • End the current sex scene cleanly
 *   • Toggle SA content off with one click
 *   • Reset stuck states
 *
 * Design principle: this menu is non-judgmental, always available, and costs
 * the player nothing mechanically. It exists to give players full control
 * at all times, regardless of scene state.
 */
public class SafetyMenuPanel extends JDialog {

    public interface SafetyCallback {
        /** Called when the player chooses to exit the current scene. */
        void onExitScene();
        /** Called when the player ends the sex scene (cleans up SexState). */
        void onEndSexScene();
        /** Called after any settings change so the UI can refresh. */
        void onSettingsChanged();
    }

    private final GameSettings   settings;
    private final GameState      state;
    private final SafetyCallback cb;

    public SafetyMenuPanel(Frame owner, GameSettings settings, GameState state, SafetyCallback cb) {
        super(owner, "Safety Menu", true); // modal
        this.settings = settings;
        this.state    = state;
        this.cb       = cb;
        buildUI();
        pack();
        setLocationRelativeTo(owner);
        setResizable(false);
    }

    private void buildUI() {
        JPanel root = new JPanel();
        root.setLayout(new BoxLayout(root, BoxLayout.Y_AXIS));
        root.setBackground(Colors.BG);
        root.setBorder(BorderFactory.createEmptyBorder(20, 28, 20, 28));

        // ── Header ──────────────────────────────────────────────────────────
        JLabel title = new JLabel("Safety / Quick Exit Menu");
        title.setFont(Colors.PANEL_HEAD);
        title.setForeground(Colors.TEXT_HEAD);
        title.setAlignmentX(LEFT_ALIGNMENT);
        root.add(title);
        root.add(Box.createVerticalStrut(6));

        JLabel sub = new JLabel("<html><body style='width:340px; color:#888'>"
            + "These options are always available."
            + "</body></html>");
        sub.setFont(Colors.PANEL_SMALL);
        sub.setAlignmentX(LEFT_ALIGNMENT);
        root.add(sub);
        root.add(Box.createVerticalStrut(18));

        // ── Scene exits ──────────────────────────────────────────────────────
        addSectionHeader(root, "EXIT OPTIONS");

        addActionButton(root,
            "Exit current scene → return to day planner",
            "Ends whatever scene or conversation is active and returns you to the daily hub.",
            new Color(220, 150, 40),
            () -> { dispose(); cb.onExitScene(); });

        root.add(Box.createVerticalStrut(8));

        boolean sexActive = state.sexState.active;
        JButton sexExitBtn = makeBtn(
            "End sex scene cleanly",
            "Stops the current sex scene, resets all sex state flags, no stat changes.",
            new Color(190, 130, 50));
        sexExitBtn.setEnabled(sexActive);
        sexExitBtn.addActionListener(e -> {
            state.sexState.reset();
            dispose();
            cb.onEndSexScene();
        });
        root.add(sexExitBtn);
        root.add(Box.createVerticalStrut(4));
        if (!sexActive) {
            JLabel inactive = new JLabel("  (no active sex scene)");
            inactive.setFont(Colors.PANEL_SMALL);
            inactive.setForeground(Colors.TEXT_DIM);
            inactive.setAlignmentX(LEFT_ALIGNMENT);
            root.add(inactive);
        }

        root.add(Box.createVerticalStrut(18));

        // ── Content toggle ────────────────────────────────────────────────────
        addSectionHeader(root, "CONTENT SETTINGS");

        JPanel saRow = new JPanel(new BorderLayout(12, 0));
        saRow.setOpaque(false);
        saRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        saRow.setAlignmentX(LEFT_ALIGNMENT);

        JLabel saLabel = new JLabel("Sexual violence / SA content");
        saLabel.setFont(Colors.LABEL);
        saLabel.setForeground(Colors.TEXT);

        JToggleButton saToggle = new JToggleButton(settings.saContentEnabled ? "Enabled" : "Disabled");
        saToggle.setSelected(settings.saContentEnabled);
        saToggle.setFont(Colors.SANS_SMALL);
        saToggle.setPreferredSize(new Dimension(90, 28));
        styleToggle(saToggle, settings.saContentEnabled);

        saToggle.addActionListener(e -> {
            settings.saContentEnabled = saToggle.isSelected();
            saToggle.setText(settings.saContentEnabled ? "Enabled" : "Disabled");
            styleToggle(saToggle, settings.saContentEnabled);
            cb.onSettingsChanged();
        });

        saRow.add(saLabel, BorderLayout.CENTER);
        saRow.add(saToggle, BorderLayout.EAST);
        root.add(saRow);
        root.add(Box.createVerticalStrut(4));

        JLabel saDesc = new JLabel("<html><body style='width:340px; color:#888; font-size:11px'>"
            + "When disabled: non-consensual content and its escalation paths are suppressed."
            + "</body></html>");
        saDesc.setFont(Colors.PANEL_SMALL);
        saDesc.setAlignmentX(LEFT_ALIGNMENT);
        root.add(saDesc);

        root.add(Box.createVerticalStrut(20));

        // ── Close ────────────────────────────────────────────────────────────
        JButton close = new JButton("Close");
        close.setFont(Colors.LABEL);
        close.setAlignmentX(LEFT_ALIGNMENT);
        close.addActionListener(e -> dispose());
        root.add(close);

        setContentPane(root);
        getContentPane().setBackground(Colors.BG);
    }

    private void addSectionHeader(JPanel p, String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(Colors.SANS_BOLD);
        lbl.setForeground(Colors.TEXT_DIM);
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        p.add(lbl);
        JSeparator sep = new JSeparator();
        sep.setForeground(Colors.BORDER);
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        sep.setAlignmentX(LEFT_ALIGNMENT);
        p.add(sep);
        p.add(Box.createVerticalStrut(8));
    }

    private void addActionButton(JPanel p, String label, String tooltip, Color accent, Runnable action) {
        JButton btn = makeBtn(label, tooltip, accent);
        btn.addActionListener(e -> action.run());
        p.add(btn);
    }

    private JButton makeBtn(String label, String tooltip, Color accent) {
        JButton btn = new JButton(label);
        btn.setFont(Colors.LABEL);
        btn.setForeground(accent);
        btn.setBackground(Colors.BG_BTN);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(accent, 1),
            BorderFactory.createEmptyBorder(6, 14, 6, 14)
        ));
        btn.setToolTipText(tooltip);
        btn.setAlignmentX(LEFT_ALIGNMENT);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        return btn;
    }

    private void styleToggle(JToggleButton t, boolean on) {
        t.setBackground(on ? new Color(40, 80, 40) : Colors.BG_BTN);
        t.setForeground(on ? new Color(120, 220, 120) : Colors.TEXT_DIM);
    }

    // ── Static factory ────────────────────────────────────────────────────────

    /**
     * Open the safety menu from any point in the game.
     *
     * @param owner    parent frame (for modal centering)
     * @param settings game settings (SA toggle lives here)
     * @param state    game state (sex scene status)
     * @param cb       callbacks for exit/end actions
     */
    public static void show(Frame owner, GameSettings settings, GameState state, SafetyCallback cb) {
        new SafetyMenuPanel(owner, settings, state, cb).setVisible(true);
    }
}
