package game.ui;

import game.GameState;
import game.data.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.util.*;
import java.util.List;

/**
 * Character creation — multi-step wizard.
 *
 * Step 0: Identity  (name, personality, social energy, willpower)
 * Step 1: Body      (body type, height, breast size/sensitivity, hair)
 * Step 2: Inner Life (role, disposition, exhibitionism, preferences)
 * Step 3: Background (virginity, fertility, kids, wealth)
 *
 * Layout: Left = category cards with toggle buttons
 *         Right = live description panel (updates on hover/select)
 *         Top   = step progress dots + subtitle
 *         Bot   = Back / Next navigation
 */
public class CharCreationPanel extends JPanel {

    // ── Page groupings ────────────────────────────────────────────────────────
    private static final Map<String,Integer> CAT_PAGE = new HashMap<>();
    static {
        CAT_PAGE.put("Personality",0);   CAT_PAGE.put("Social_Energy",0);  CAT_PAGE.put("Willpower",0);
        CAT_PAGE.put("Body_Type",1);     CAT_PAGE.put("Height",1);
        CAT_PAGE.put("Breast_Size",1);   CAT_PAGE.put("Breast_Sensitivity",1); CAT_PAGE.put("Hair_Length",1);
        CAT_PAGE.put("Role",2);          CAT_PAGE.put("Sexual_Disposition",2);
        CAT_PAGE.put("Exhibitionism",2); CAT_PAGE.put("PDA_Preference",2);
        CAT_PAGE.put("Size_Preference",2); CAT_PAGE.put("Cum_Preference",2); CAT_PAGE.put("Pussy_Traits",2);
        CAT_PAGE.put("Virginity_Status",3); CAT_PAGE.put("Fertility",3);
        CAT_PAGE.put("Kids_Preference",3);
    }
    private static final String[] STEP_TITLES = {"Who Are You?","Your Body","Inner Life","Background"};
    private static final String[] STEP_SUBS   = {
        "Personality shapes how Carrow responds to you — and how you respond to it.",
        "Your physical traits affect clothing, scene reactions, and how the city reads you.",
        "Private preferences and disposition. These affect bar scenes, relationships, and intimacy.",
        "Where you're starting from. This shapes your opening stats and earliest options."
    };
    private static final int TOTAL_STEPS = 4;

    // ── Defaults ──────────────────────────────────────────────────────────────
    private static final Map<String,String> DEFAULTS = new HashMap<>();
    static {
        DEFAULTS.put("Social_Energy","Engaging"); DEFAULTS.put("Willpower","Average_Will");
        DEFAULTS.put("Role","Switch"); DEFAULTS.put("Body_Type","Body_Average");
        DEFAULTS.put("Height","Average_Height"); DEFAULTS.put("Breast_Size","Breasts_C");
        DEFAULTS.put("Breast_Sensitivity","Medium_Breast_Sensitivity");
        DEFAULTS.put("Virginity_Status","Non_Virgin"); DEFAULTS.put("Pussy_Traits","Tight");
        DEFAULTS.put("Size_Preference","Size_Doesnt_Matter"); DEFAULTS.put("Fertility","Fertile");
        DEFAULTS.put("Cum_Preference","Neutral_On_Cum"); DEFAULTS.put("Kids_Preference","Doesnt_Want_Kids");
        DEFAULTS.put("Exhibitionism","Neutral_On_Exhibitionism"); DEFAULTS.put("PDA_Preference","Neutral_On_PDA");
        DEFAULTS.put("Sexual_Disposition","Sexually_Neutral"); DEFAULTS.put("Hair_Length","Hair_Medium");
    }

    // ── State ─────────────────────────────────────────────────────────────────
    private final GameState state;
    private final List<TraitCategoryData> categories;
    private final Runnable onComplete;

    private JTextField nameField;
    private final Map<String,String>        radioSelected = new LinkedHashMap<>();
    private final Map<String,JToggleButton> checkSelected = new LinkedHashMap<>();
    private final List<JToggleButton>       shyLockedBtns = new ArrayList<>();

    private int currentStep = 0;

    private JPanel    stepDotsPanel;
    private JPanel    cardHolder;
    private CardLayout cardLayout;
    private JLabel    descTitle;
    private JLabel    descBody;
    private JButton   backBtn;
    private JButton   nextBtn;
    private JLabel    stepSubLbl;

    public CharCreationPanel(GameState state, List<TraitCategoryData> cats, Runnable onComplete) {
        this.state = state; this.categories = cats; this.onComplete = onComplete;
        for (TraitCategoryData cat : categories)
            if (cat.pickOne && !cat.traits.isEmpty())
                radioSelected.put(cat.id, DEFAULTS.getOrDefault(cat.id, cat.traits.get(0).id));
        setBackground(Colors.BG);
        setLayout(new BorderLayout());
        build();
    }

    // ── Build ──────────────────────────────────────────────────────────────────

    private void build() {
        add(buildHeader(), BorderLayout.NORTH);
        add(buildCenter(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);
        showStep(0);
    }

    private JPanel buildHeader() {
        JPanel h = new JPanel(); h.setOpaque(false);
        h.setLayout(new BoxLayout(h, BoxLayout.Y_AXIS));
        h.setBorder(BorderFactory.createEmptyBorder(28, 60, 0, 60));

        JLabel game = makeLabel("The Soul of Carrow", new Font("Georgia",Font.ITALIC,16), Colors.ACCENT);
        JLabel cc   = makeLabel("Character Creation",  new Font("SansSerif",Font.BOLD,36), Colors.TEXT_HEAD);
        game.setAlignmentX(CENTER_ALIGNMENT); cc.setAlignmentX(CENTER_ALIGNMENT);
        h.add(game); h.add(Box.createVerticalStrut(2)); h.add(cc);
        h.add(Box.createVerticalStrut(16));

        // Dot row
        stepDotsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER,8,0));
        stepDotsPanel.setOpaque(false);
        for (int i = 0; i < TOTAL_STEPS; i++) {
            JLabel dot = new JLabel(i == 0 ? "●" : "○");
            dot.setName("dot_"+i);
            dot.setFont(new Font("SansSerif",Font.PLAIN,18));
            dot.setForeground(Colors.TEXT_DIM);
            dot.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            final int s = i;
            dot.addMouseListener(new MouseAdapter(){public void mouseClicked(MouseEvent e){showStep(s);}});
            stepDotsPanel.add(dot);
            if (i < TOTAL_STEPS-1) { JLabel sep=new JLabel("·"); sep.setForeground(Colors.BORDER); stepDotsPanel.add(sep); }
        }
        stepDotsPanel.setAlignmentX(CENTER_ALIGNMENT);
        h.add(stepDotsPanel);

        stepSubLbl = makeLabel("", new Font("Georgia",Font.ITALIC,13), Colors.TEXT_DIM);
        stepSubLbl.setAlignmentX(CENTER_ALIGNMENT);
        h.add(Box.createVerticalStrut(6));
        h.add(stepSubLbl);
        h.add(Box.createVerticalStrut(14));

        // Divider
        JPanel div = new JPanel(){protected void paintComponent(Graphics g){super.paintComponent(g);g.setColor(Colors.BORDER);g.fillRect(0,getHeight()-1,getWidth(),1);}};
        div.setOpaque(false); div.setPreferredSize(new Dimension(0,10));
        h.add(div);
        return h;
    }

    private JPanel buildCenter() {
        JPanel c = new JPanel(new BorderLayout(20,0));
        c.setOpaque(false);
        c.setBorder(BorderFactory.createEmptyBorder(14,60,0,60));

        cardLayout = new CardLayout();
        cardHolder = new JPanel(cardLayout);
        cardHolder.setOpaque(false);
        for (int s = 0; s < TOTAL_STEPS; s++) buildStepCard(s);

        JScrollPane scroll = new JScrollPane(cardHolder);
        scroll.setOpaque(false); scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getVerticalScrollBar().setUnitIncrement(20);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        c.add(scroll, BorderLayout.CENTER);
        c.add(buildDescPanel(), BorderLayout.EAST);
        return c;
    }

    private void buildStepCard(int step) {
        JPanel page = new JPanel();
        page.setOpaque(false);
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
        page.setBorder(BorderFactory.createEmptyBorder(10,0,24,20));

        if (step == 0) {
            page.add(nameCard()); page.add(Box.createVerticalStrut(14));
        }

        for (TraitCategoryData cat : categories) {
            if (!cat.showInCreation) continue;
            int pg = CAT_PAGE.getOrDefault(cat.id, step == TOTAL_STEPS-1 ? step : 0);
            if (pg != step) continue;
            JPanel card = traitCard(cat);
            card.setAlignmentX(LEFT_ALIGNMENT);
            page.add(card); page.add(Box.createVerticalStrut(10));
        }
        cardHolder.add(page, "s"+step);
    }

    private JPanel nameCard() {
        JPanel card = card();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        JLabel lbl = catLabel("YOUR NAME"); lbl.setAlignmentX(LEFT_ALIGNMENT);
        card.add(lbl); card.add(Box.createVerticalStrut(8));
        nameField = new JTextField("Player");
        styleField(nameField); nameField.setAlignmentX(LEFT_ALIGNMENT);
        nameField.setMaximumSize(new Dimension(300,42));
        card.add(nameField);
        JLabel hint = makeLabel("The name Carrow will know you by.", new Font("Georgia",Font.ITALIC,11), Colors.TEXT_DIM);
        hint.setBorder(BorderFactory.createEmptyBorder(4,0,0,0)); hint.setAlignmentX(LEFT_ALIGNMENT);
        card.add(hint);
        return card;
    }

    private JPanel traitCard(TraitCategoryData cat) {
        JPanel card = card();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        JLabel header = catLabel(cat.label.toUpperCase()); header.setAlignmentX(LEFT_ALIGNMENT);
        JLabel pick = makeLabel(cat.pickOne ? "choose one" : "choose any",
                                new Font("SansSerif",Font.PLAIN,10), Colors.TEXT_DIM);
        pick.setAlignmentX(LEFT_ALIGNMENT);
        card.add(header); card.add(pick); card.add(Box.createVerticalStrut(8));

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT,5,3));
        row.setOpaque(false); row.setAlignmentX(LEFT_ALIGNMENT);
        boolean isPersonality = cat.id.equals("Personality");

        for (TraitData trait : cat.traits) {
            JToggleButton btn = toggle(trait.label);
            if (cat.pickOne) {
                btn.setSelected(trait.id.equals(radioSelected.get(cat.id)));
                final String tid = trait.id;
                btn.addActionListener(e -> {
                    if (!btn.isEnabled()) return;
                    radioSelected.put(cat.id, tid);
                    for (Component c2 : row.getComponents())
                        if (c2 instanceof JToggleButton && c2 != btn) ((JToggleButton)c2).setSelected(false);
                    btn.setSelected(true);
                    if (isPersonality) updateShyLocks(tid.equals("Shy"));
                    showDesc(trait.label, trait.description);
                });
            } else {
                checkSelected.put(trait.id, btn);
                btn.addActionListener(e -> showDesc(trait.label, trait.description));
            }
            if (trait.shy_locked) shyLockedBtns.add(btn);
            final String desc = trait.description + (trait.shy_locked ? "\n\n[Unavailable when Shy]" : "");
            btn.addMouseListener(new MouseAdapter(){public void mouseEntered(MouseEvent e){showDesc(trait.label,desc);}});
            row.add(btn);
        }
        card.add(row);
        return card;
    }

    private JPanel buildDescPanel() {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(true);
        p.setBackground(new Color(18,18,32));
        p.setPreferredSize(new Dimension(250,0));
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0,1,0,0,Colors.BORDER),
            BorderFactory.createEmptyBorder(18,16,18,16)));

        JLabel icon = new JLabel("◈");
        icon.setForeground(Colors.ACCENT);
        icon.setFont(new Font("SansSerif",Font.PLAIN,20));

        descTitle = new JLabel("Hover a trait");
        descTitle.setForeground(Colors.TEXT_HEAD);
        descTitle.setFont(new Font("SansSerif",Font.BOLD,14));

        descBody = new JLabel("<html><body style='width:190px;color:#8888aa;'>Hover or select a trait to read its description.</body></html>");
        descBody.setFont(new Font("Georgia",Font.ITALIC,12));
        descBody.setVerticalAlignment(SwingConstants.TOP);

        JPanel top = new JPanel(); top.setOpaque(false);
        top.setLayout(new BoxLayout(top,BoxLayout.Y_AXIS));
        icon.setAlignmentX(LEFT_ALIGNMENT); descTitle.setAlignmentX(LEFT_ALIGNMENT);
        top.add(icon); top.add(Box.createVerticalStrut(5)); top.add(descTitle);
        top.add(Box.createVerticalStrut(10));

        p.add(top, BorderLayout.NORTH);
        p.add(descBody, BorderLayout.CENTER);

        JLabel foot = new JLabel("<html><body style='color:#3a3a5a;font-size:10px;'>Traits define your starting point.</body></html>");
        foot.setFont(new Font("SansSerif",Font.PLAIN,10));
        p.add(foot, BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildFooter() {
        JPanel f = new JPanel(new BorderLayout());
        f.setOpaque(false);
        f.setBorder(BorderFactory.createEmptyBorder(10,60,24,60));

        JPanel divL = new JPanel(){protected void paintComponent(Graphics g){super.paintComponent(g);g.setColor(Colors.BORDER);g.fillRect(0,0,getWidth(),1);}};
        divL.setOpaque(false); divL.setPreferredSize(new Dimension(0,1));
        f.add(divL, BorderLayout.NORTH);

        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false); row.setBorder(BorderFactory.createEmptyBorder(12,0,0,0));

        backBtn = navBtn("← Back", false);
        nextBtn = navBtn("Next →", true);
        backBtn.addActionListener(e -> navigate(-1));
        nextBtn.addActionListener(e -> navigate(+1));

        row.add(backBtn, BorderLayout.WEST);
        row.add(nextBtn, BorderLayout.EAST);
        f.add(row, BorderLayout.CENTER);
        return f;
    }

    // ── Navigation ────────────────────────────────────────────────────────────

    private void showStep(int step) {
        currentStep = Math.max(0, Math.min(step, TOTAL_STEPS-1));

        // Update dots
        int dotIdx = 0;
        for (Component c : stepDotsPanel.getComponents()) {
            if (!(c instanceof JLabel)) continue;
            JLabel l = (JLabel)c;
            if (!l.getText().equals("●") && !l.getText().equals("○")) continue;
            if (dotIdx == currentStep) { l.setText("●"); l.setForeground(Colors.ACCENT_LIT); }
            else if (dotIdx < currentStep) { l.setText("●"); l.setForeground(new Color(70,60,120)); }
            else { l.setText("○"); l.setForeground(Colors.TEXT_DIM); }
            dotIdx++;
        }

        stepSubLbl.setText(STEP_SUBS[currentStep]);
        cardLayout.show(cardHolder, "s"+currentStep);
        backBtn.setVisible(currentStep > 0);
        boolean last = currentStep == TOTAL_STEPS-1;
        nextBtn.setText(last ? "Begin Your Story  →" : "Next  →");
        nextBtn.setBackground(last ? new Color(80,58,158) : new Color(40,36,72));

        SwingUtilities.invokeLater(() -> {
            try {
                Container parent = cardHolder.getParent();
                if (parent instanceof JViewport) {
                    ((JScrollPane)parent.getParent()).getVerticalScrollBar().setValue(0);
                }
            } catch (Exception ignored) {}
        });
    }

    private void navigate(int dir) {
        if (dir > 0 && currentStep == TOTAL_STEPS-1) applyAndFinish();
        else showStep(currentStep + dir);
    }

    private void showDesc(String name, String desc) {
        descTitle.setText(name);
        descBody.setText("<html><body style='width:190px'>" + desc.replace("\n","<br>") + "</body></html>");
    }

    private void updateShyLocks(boolean isShy) {
        for (JToggleButton btn : shyLockedBtns) {
            btn.setEnabled(!isShy);
            if (isShy && btn.isSelected()) {
                btn.setSelected(false);
                radioSelected.put("Exhibitionism","Neutral_On_Exhibitionism");
                Container p = btn.getParent();
                if (p != null)
                    for (Component c : p.getComponents())
                        if (c instanceof JToggleButton && ((JToggleButton)c).getText().equals("Neutral"))
                            { ((JToggleButton)c).setSelected(true); break; }
            }
        }
    }

    // ── Apply / finish ────────────────────────────────────────────────────────

    private void applyAndFinish() {
        state.playerName = nameField.getText().trim().isEmpty() ? "Player" : nameField.getText().trim();

        for (TraitCategoryData cat : categories)
            if (cat.pickOne) { String sel = radioSelected.get(cat.id); if (sel != null) state.addTrait(sel); }
        for (Map.Entry<String,JToggleButton> e : checkSelected.entrySet())
            if (e.getValue().isSelected()) state.addTrait(e.getKey());

        if (state.hasTrait("Wealthy_Background")) { state.money=3000; state.confidence=65; }
        if (state.hasTrait("Broke_Background"))   { state.money=600;  state.confidence=40; }
        if (state.hasTrait("Outgoing"))  state.changeStat("confidence",10);
        if (state.hasTrait("Shy"))       state.changeStat("confidence",-10);
        if (state.hasTrait("Athletic"))  state.changeStat("fitness",15);

        if      (state.hasTrait("Iron_Will"))    state.willpower=90;
        else if (state.hasTrait("Strong_Will"))  state.willpower=70;
        else if (state.hasTrait("Average_Will")) state.willpower=50;
        else if (state.hasTrait("Weak_Will"))    state.willpower=30;
        else if (state.hasTrait("Pushover"))     state.willpower=10;

        state.currentScene="housing";
        if (state.hasTrait("Outgoing"))     state.happiness=60;
        else if (state.hasTrait("Shy"))     state.happiness=40;
        else                                state.happiness=50;
        if (state.hasTrait("Iron_Will")||state.hasTrait("Strong_Will")) state.stress=15;
        else if (state.hasTrait("Pushover"))                             state.stress=35;
        else                                                             state.stress=20;

        state.workMode="normal"; state.officeRep=60; state.promotionProgress=0;
        if (!state.hasTrait("Wealthy_Background")) {
            state.addTrait("sleeping_on_floor"); state.rent=0;
            state.housingWillpowerCap=60; state.housingWillpowerRecovery=4;
            state.housingStressReduction=2; state.housingStressMin=50;
        } else { state.rent=0; }
        state.cycleDay=14; state.cycleLength=28; state.repMonthStart=1;
        onComplete.run();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private JPanel card() {
        JPanel p = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Colors.BG_PANEL);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.setColor(Colors.BORDER);
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,10,10);
                super.paintComponent(g);
            }
        };
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(12,16,12,16));
        return p;
    }

    private JLabel catLabel(String text) {
        JLabel l = new JLabel(text);
        l.setForeground(Colors.TEXT_HEAD);
        l.setFont(new Font("SansSerif",Font.BOLD,13));
        return l;
    }

    private JLabel makeLabel(String text, Font font, Color fg) {
        JLabel l = new JLabel(text, SwingConstants.CENTER);
        l.setFont(font); l.setForeground(fg);
        return l;
    }

    private JToggleButton toggle(String label) {
        JToggleButton b = new JToggleButton(label) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(isSelected() ? Colors.ACCENT : !isEnabled() ? new Color(24,24,40) : new Color(30,30,50));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                g2.setColor(isSelected() ? Colors.ACCENT_LIT : !isEnabled() ? new Color(34,34,52) : Colors.BORDER);
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,8,8);
                super.paintComponent(g);
            }
        };
        b.setForeground(Colors.TEXT);
        b.setFont(new Font("SansSerif",Font.PLAIN,12));
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(5,11,5,11));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private JButton navBtn(String label, boolean primary) {
        JButton b = new JButton(label) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                super.paintComponent(g);
            }
        };
        b.setForeground(Color.WHITE);
        b.setFont(new Font("SansSerif",Font.BOLD,14));
        b.setBackground(primary ? new Color(40,36,72) : new Color(32,30,50));
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(10,26,10,26));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private void styleField(JTextField f) {
        f.setBackground(new Color(26,26,44));
        f.setForeground(Colors.TEXT); f.setCaretColor(Colors.TEXT);
        f.setFont(new Font("SansSerif",Font.PLAIN,15));
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Colors.ACCENT,1),
            BorderFactory.createEmptyBorder(7,10,7,10)));
    }
}
