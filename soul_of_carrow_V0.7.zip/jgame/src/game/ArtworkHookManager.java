package game;

import javax.swing.ImageIcon;
import java.util.*;

/**
 * Evaluates condition-based artwork hooks against live GameState to pick
 * the best-matching image for the current moment.
 *
 * Artwork mods declare hooks in artwork.yml:
 *
 *   hooks:
 *     - id: grope_breast_enjoying
 *       asset:   grope_breast_enjoy      # asset ID registered in mod.yml
 *       priority: 10
 *       requires_flags:  [flag_breast_groped]
 *       requires_traits: [Likes_Being_Touched]
 *       arousal_min: 40
 *
 *     - id: grope_breast_basic
 *       asset:   grope_breast_neutral
 *       priority: 5
 *       requires_flags:  [flag_breast_groped]
 *
 *     - id: braless_walking
 *       asset:   braless_street
 *       priority: 3
 *       requires_flags:  [flag_is_braless]
 *       blocks_flags:    [flag_breast_groped, flag_being_groped]
 *
 * The hook with the highest priority that passes ALL its conditions is used.
 * If no hook matches, no artwork is shown (or the scene's own image: field is used).
 *
 * CONDITION FIELDS
 * ─────────────────────────────────────────────────────────────────────────────
 *   requires_flags   – all must be true   (AND)
 *   blocks_flags     – none must be true  (NONE)
 *   requires_traits  – all must be true   (AND)
 *   blocks_traits    – none must be true  (NONE)
 *   requires_any_flags   – at least one must be true  (OR)
 *   requires_any_traits  – at least one must be true  (OR)
 *   arousal_min      – MC arousal >= this value
 *   arousal_max      – MC arousal <= this value
 *   npc_tier_min     – current NPC tier >= this value
 *   drunk_min        – MC drunk >= this value
 *   scene_ids        – list of scene IDs this hook applies to (empty = all)
 *   image_height     – optional override for max display height in px
 */
public class ArtworkHookManager {

    public static class Hook implements Comparable<Hook> {
        public final String       id;
        public final String       assetId;
        public final int          priority;
        public final int          imageHeight;
        public final List<String> requiresFlags;
        public final List<String> blocksFlags;
        public final List<String> requiresTraits;
        public final List<String> blocksTraits;
        public final List<String> requiresAnyFlags;
        public final List<String> requiresAnyTraits;
        public final int          arousalMin;
        public final int          arousalMax;
        public final int          npcTierMin;
        public final int          drunkMin;
        public final Set<String>  sceneIds;

        public Hook(Map<?,?> raw) {
            id              = str(raw, "id");
            assetId         = str(raw, "asset");
            priority        = intVal(raw, "priority", 1);
            imageHeight     = intVal(raw, "image_height", 0);
            requiresFlags   = strList(raw, "requires_flags");
            blocksFlags     = strList(raw, "blocks_flags");
            requiresTraits  = strList(raw, "requires_traits");
            blocksTraits    = strList(raw, "blocks_traits");
            requiresAnyFlags  = strList(raw, "requires_any_flags");
            requiresAnyTraits = strList(raw, "requires_any_traits");
            arousalMin      = intVal(raw, "arousal_min", 0);
            arousalMax      = intVal(raw, "arousal_max", Integer.MAX_VALUE);
            npcTierMin      = intVal(raw, "npc_tier_min", 0);
            drunkMin        = intVal(raw, "drunk_min", 0);
            sceneIds        = new HashSet<>(strList(raw, "scene_ids"));
        }

        @Override public int compareTo(Hook o) {
            return Integer.compare(o.priority, this.priority); // descending
        }

        private String str(Map<?,?> m, String k) {
            Object v = m.get(k); return v == null ? "" : v.toString().trim();
        }
        private int intVal(Map<?,?> m, String k, int def) {
            Object v = m.get(k);
            if (v == null) return def;
            try { return Integer.parseInt(v.toString()); } catch (Exception e) { return def; }
        }
        @SuppressWarnings("unchecked")
        private List<String> strList(Map<?,?> m, String k) {
            Object v = m.get(k);
            if (v instanceof List) {
                List<String> out = new ArrayList<>();
                for (Object o : (List<?>)v) if (o != null) out.add(o.toString());
                return out;
            }
            return Collections.emptyList();
        }
    }

    // All registered hooks, sorted by priority (highest first)
    private final List<Hook> hooks = new ArrayList<>();
    private AssetManager     assetManager;

    public void setAssetManager(AssetManager am) { this.assetManager = am; }

    // ── Registration ──────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    public void loadFromYaml(List<?> hookList) {
        if (hookList == null) return;
        for (Object item : hookList) {
            if (!(item instanceof Map)) continue;
            Hook h = new Hook((Map<?,?>) item);
            if (h.assetId.isEmpty()) continue; // skip malformed
            hooks.add(h);
        }
        Collections.sort(hooks); // maintain priority order
        System.out.printf("[ArtworkHookManager] Registered %d hook(s) (total: %d)%n",
            hookList.size(), hooks.size());
    }

    // ── Evaluation ────────────────────────────────────────────────────────────

    /**
     * Evaluate all hooks against the current game state.
     * Returns the ImageIcon for the highest-priority matching hook,
     * or null if no hook matches or the asset isn't available.
     *
     * @param state      live GameState
     * @param flags      active body/game flags (from state.getBodyFlag evaluations)
     * @param npcTier    current bar NPC tier (0 outside bar)
     * @param currentScene  the scene ID currently being shown
     */
    public EvalResult evaluate(GameState state, Set<String> flags,
                               int npcTier, String currentScene) {
        if (assetManager == null || hooks.isEmpty()) return null;

        Set<String> lcTraits = new HashSet<>();
        for (String t : state.traits)     lcTraits.add(t.toLowerCase());
        for (String t : state.timedTraits.keySet()) lcTraits.add(t.toLowerCase());

        for (Hook h : hooks) { // already sorted highest priority first
            if (!passesHook(h, state, flags, lcTraits, npcTier, currentScene)) continue;
            ImageIcon icon = assetManager.get(h.assetId,
                AssetManager.MAX_SCENE_IMG_W,
                h.imageHeight > 0 ? h.imageHeight : AssetManager.MAX_SCENE_IMG_H);
            if (icon != null) return new EvalResult(icon, h.imageHeight);
        }
        return null;
    }

    private boolean passesHook(Hook h, GameState state, Set<String> flags,
                                Set<String> lcTraits, int npcTier, String sceneId) {
        // Scene filter
        if (!h.sceneIds.isEmpty() && !h.sceneIds.contains(sceneId)) return false;
        // Flags
        for (String f : h.requiresFlags)  if (!flags.contains(f.toLowerCase())) return false;
        for (String f : h.blocksFlags)    if ( flags.contains(f.toLowerCase())) return false;
        // Traits
        for (String t : h.requiresTraits) if (!lcTraits.contains(t.toLowerCase())) return false;
        for (String t : h.blocksTraits)   if ( lcTraits.contains(t.toLowerCase())) return false;
        // Any-of flags
        if (!h.requiresAnyFlags.isEmpty()) {
            boolean any = false;
            for (String f : h.requiresAnyFlags) if (flags.contains(f.toLowerCase())) { any = true; break; }
            if (!any) return false;
        }
        // Any-of traits
        if (!h.requiresAnyTraits.isEmpty()) {
            boolean any = false;
            for (String t : h.requiresAnyTraits) if (lcTraits.contains(t.toLowerCase())) { any = true; break; }
            if (!any) return false;
        }
        // Numeric gates
        if (state.arousal < h.arousalMin || state.arousal > h.arousalMax) return false;
        if (npcTier < h.npcTierMin)                                        return false;
        if (state.drunk < h.drunkMin)                                      return false;
        return true;
    }

    public int hookCount() { return hooks.size(); }

    public static class EvalResult {
        public final ImageIcon icon;
        public final int       imageHeight; // 0 = use default
        public EvalResult(ImageIcon icon, int imageHeight) {
            this.icon = icon; this.imageHeight = imageHeight;
        }
    }
}
