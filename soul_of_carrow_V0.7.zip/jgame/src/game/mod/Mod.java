package game.mod;

import java.util.*;
import java.io.File;

/**
 * Represents a single mod — its metadata and validation state.
 * Populated by ModLoader, validated by ModValidator.
 */
public class Mod {

    // ── Identity ──────────────────────────────────────────────────────────────
    public String  id              = "";   // folder name, may be qualified (pack.submod)
    public String  sourceId        = "";   // original unqualified folder name (for scene lookup)
    public String  name            = "";   // display name from mod.yml
    public String  author          = "";
    public String  version         = "";
    public String  description     = "";
    public File    folder;                 // the mod's root directory

    // ── Compatibility ─────────────────────────────────────────────────────────
    /** Minimum game version required, e.g. "0.1.0". Empty = no requirement. */
    public String  game_version_min = "";
    /** Maximum game version supported, e.g. "0.9.9". Empty = no upper bound. */
    public String  game_version_max = "";
    /** Human-readable compatibility note shown in Mod Manager. */
    public String  compatibility_note = "";

    // ── Enable/disable state ──────────────────────────────────────────────────
    /** Whether this mod is enabled. Loaded from mods_settings.yml on startup. */
    public boolean enabled = true;
    /**
     * True when the mod was skipped because it was disabled at load time.
     * Such mods appear in the Mod Manager but have no loaded content.
     */
    public boolean skipped = false;

    // ── Compatibility result (filled by CompatibilityChecker) ─────────────────
    public enum CompatStatus { UNKNOWN, COMPATIBLE, OUTDATED, INCOMPATIBLE, CHECK_FAILED }
    public CompatStatus compatStatus  = CompatStatus.UNKNOWN;
    public String       compatMessage = "";  // human-readable result

    // ── State ─────────────────────────────────────────────────────────────────
    public enum Status { PENDING, OK, PARTIAL, FAILED, DISABLED }
    public Status status = Status.PENDING;

    // ── Content counts ───────────────────────────────────────────────────────
    public int scenesLoaded  = 0;
    public int npcsLoaded    = 0;
    public int clothesLoaded = 0;
    public int jobsLoaded    = 0;
    public int assetsLoaded      = 0;
    public int artworkHooks      = 0;   // artwork.yml hook entries
    public int textEntries       = 0;   // text pool entries added
    public int audioTracks       = 0;   // soundtrack.yml tracks

    // ── Errors ───────────────────────────────────────────────────────────────
    /** Every problem found — file name + human-readable description. */
    public final List<ModError> errors = new ArrayList<>();

    public void addError(String file, String message) {
        errors.add(new ModError(file, message, ModError.Level.ERROR));
    }
    public void addWarning(String file, String message) {
        errors.add(new ModError(file, message, ModError.Level.WARNING));
    }

    public boolean hasErrors()   { return errors.stream().anyMatch(e -> e.level == ModError.Level.ERROR); }
    public boolean hasWarnings() { return errors.stream().anyMatch(e -> e.level == ModError.Level.WARNING); }

    /** Recompute status from errors list after loading. */
    public void finaliseStatus() {
        if (skipped || !enabled) { status = Status.DISABLED; return; }
        if (scenesLoaded + npcsLoaded + clothesLoaded + jobsLoaded + assetsLoaded + artworkHooks + textEntries + audioTracks == 0 && hasErrors()) {
            status = Status.FAILED;
        } else if (hasErrors()) {
            status = Status.PARTIAL;
        } else {
            status = Status.OK;
        }
    }

    /** Check whether the given game version satisfies this mod's declared requirements. */
    public boolean isCompatibleWith(String gameVersion) {
        if (!game_version_min.isEmpty() && compareVersions(game_version_min, gameVersion) > 0)
            return false;  // game too old
        if (!game_version_max.isEmpty() && compareVersions(game_version_max, gameVersion) < 0)
            return false;  // game too new
        return true;
    }

    /**
     * Compare two semver strings (major.minor.patch).
     * Returns negative if a < b, 0 if equal, positive if a > b.
     */
    public static int compareVersions(String a, String b) {
        String[] pa = a.trim().split("\\.");
        String[] pb = b.trim().split("\\.");
        for (int i = 0; i < Math.max(pa.length, pb.length); i++) {
            int va = i < pa.length ? parseIntSafe(pa[i]) : 0;
            int vb = i < pb.length ? parseIntSafe(pb[i]) : 0;
            if (va != vb) return va - vb;
        }
        return 0;
    }
    private static int parseIntSafe(String s) {
        try { return Integer.parseInt(s.replaceAll("[^0-9]","")); } catch (Exception e) { return 0; }
    }

    @Override public String toString() { return name.isEmpty() ? id : name; }

    // ── ModError inner class ──────────────────────────────────────────────────
    public static class ModError {
        public enum Level { WARNING, ERROR }
        public final String file;
        public final String message;
        public final Level  level;
        public final long   timestamp = System.currentTimeMillis();

        public ModError(String file, String message, Level level) {
            this.file    = file;
            this.message = message;
            this.level   = level;
        }

        @Override public String toString() {
            return "[" + level + "] " + file + ": " + message;
        }
    }
}
