package game.mod;

import game.SceneLoader;
import game.NpcLoader;
import game.data.SceneData;
import game.data.NpcData;

import java.util.*;

/**
 * Post-load validation: checks that mod scenes route correctly
 * and NPC fields are internally consistent.
 * Called by ModLoader after all content from a mod is injected.
 */
public class ModValidator {

    private static final Set<String> SPECIAL_ROUTES =
        new HashSet<>(Arrays.asList("__return__", "__hub__", ""));

    public static void validate(Mod mod, SceneLoader scenes, NpcLoader npcs) {
        validateSceneRoutes(mod, scenes);
        validateNpcConsistency(mod, npcs);
    }

    // ── Scene route validation ────────────────────────────────────────────────

    private static void validateSceneRoutes(Mod mod, SceneLoader scenes) {
        // Use sourceId (original folder name) for scene lookup — mod.id may be qualified
        String lookupId = mod.sourceId.isEmpty() ? mod.id : mod.sourceId;
        for (String sceneId : scenes.allIds()) {
            if (!scenes.isFromMod(sceneId, lookupId)) continue;

            SceneData scene = scenes.tryLoad(sceneId);
            if (scene == null) continue;

            for (SceneData.ChoiceData c : scene.choices) {
                String next = c.next;
                if (next == null || SPECIAL_ROUTES.contains(next)) continue;
                if (scenes.tryLoad(next) == null) {
                    mod.addWarning("scenes/" + sceneId,
                        "Choice '" + shorten(c.text) + "' routes to '" + next +
                        "' which doesn't exist. Player will see a SafeScene fallback.");
                }
            }
        }
    }

    // ── NPC consistency checks ────────────────────────────────────────────────

    private static void validateNpcConsistency(Mod mod, NpcLoader npcs) {
        String lookupId = mod.sourceId.isEmpty() ? mod.id : mod.sourceId;
        for (NpcData npc : npcs.getAll()) {
            if (!npcs.isFromMod(npc.id, lookupId)) continue;

            String src = "npcs/" + npc.id + ".yml";

            // Required field checks
            if (npc.name == null || npc.name.isEmpty())
                mod.addError(src, "NPC '" + npc.id + "' has no 'name' field.");

            if (npc.type == null || npc.type.isEmpty())
                mod.addError(src, "NPC '" + npc.id + "' has no 'type' (MALE/FEMALE).");

            // Warn on missing appearance fields (used in bar descriptions)
            if (npc.hair_color == null || npc.hair_color.isEmpty())
                mod.addWarning(src, "NPC '" + npc.id + "' has no hair_color — bar description will be incomplete.");
            if (npc.figure == null || npc.figure.isEmpty())
                mod.addWarning(src, "NPC '" + npc.id + "' has no figure — bar description will be incomplete.");

            // Stat cap sanity
            if (npc.max_liking < 0 || npc.max_liking > 100)
                mod.addWarning(src, "NPC '" + npc.id + "' max_liking=" + npc.max_liking + " is out of 0–100 range.");
            if (npc.max_love < 0 || npc.max_love > 100)
                mod.addWarning(src, "NPC '" + npc.id + "' max_love=" + npc.max_love + " is out of 0–100 range.");

            // Duplicate name check among mod NPCs
            long sameName = npcs.getAll().stream()
                .filter(n -> n.name != null && n.name.equals(npc.name) && !n.id.equals(npc.id))
                .count();
            if (sameName > 0)
                mod.addWarning(src, "NPC name '" + npc.name
                    + "' is already used by another NPC in the game — may confuse players if both appear.");
        }
    }

    private static String shorten(String s) {
        if (s == null) return "(null)";
        return s.length() > 35 ? s.substring(0, 32) + "…" : s;
    }
}
