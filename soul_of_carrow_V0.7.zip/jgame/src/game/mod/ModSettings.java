package game.mod;

import org.yaml.snakeyaml.Yaml;
import java.io.*;
import java.util.*;

/**
 * Persists per-mod enable/disable state and user preferences to
 * mods/mods_settings.yml in the game directory.
 *
 * File format:
 *   disabled_mods:
 *     - broken_mod_v1
 *     - old_art_pack
 *   suppress_warnings:
 *     - outdated_but_working
 */
public class ModSettings {

    private final File             settingsFile;
    private final Set<String>      disabledMods        = new LinkedHashSet<>();
    private final Set<String>      suppressedWarnings  = new LinkedHashSet<>();
    private boolean dirty = false;

    public ModSettings(String gameDir) {
        this.settingsFile = new File(new File(gameDir, "mods"), "mods_settings.yml");
        load();
    }

    // ── Querying ──────────────────────────────────────────────────────────────

    public boolean isEnabled(String modId)          { return !disabledMods.contains(modId); }
    public boolean isWarningsSuppressed(String modId) { return suppressedWarnings.contains(modId); }

    // ── Mutation ──────────────────────────────────────────────────────────────

    public void setEnabled(String modId, boolean enabled) {
        if (enabled) disabledMods.remove(modId);
        else         disabledMods.add(modId);
        dirty = true;
    }

    public void setSuppressWarnings(String modId, boolean suppress) {
        if (suppress) suppressedWarnings.add(modId);
        else          suppressedWarnings.remove(modId);
        dirty = true;
    }

    /** Save to disk if any changes were made. */
    public void saveIfDirty() {
        if (!dirty) return;
        save();
        dirty = false;
    }

    public void save() {
        try {
            settingsFile.getParentFile().mkdirs();
            Map<String, Object> out = new LinkedHashMap<>();
            out.put("disabled_mods",       new ArrayList<>(disabledMods));
            out.put("suppress_warnings",   new ArrayList<>(suppressedWarnings));

            try (PrintWriter pw = new PrintWriter(settingsFile)) {
                pw.println("# The Soul of Carrow — Mod Settings");
                pw.println("# Edit this file to enable/disable mods.");
                pw.println("# Changes take effect after restarting the game.");
                pw.println();
                new Yaml().dump(out, pw);
            }
        } catch (Exception e) {
            System.err.println("[ModSettings] Could not save: " + e.getMessage());
        }
    }

    // ── Loading ───────────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private void load() {
        if (!settingsFile.exists()) return;
        try (InputStream is = new FileInputStream(settingsFile)) {
            Map<String, Object> raw = (Map<String, Object>) new Yaml(
                new org.yaml.snakeyaml.constructor.SafeConstructor(
                    new org.yaml.snakeyaml.LoaderOptions())).load(is);
            if (raw == null) return;
            Object disabled = raw.get("disabled_mods");
            if (disabled instanceof List)
                for (Object o : (List<?>)disabled) if (o != null) disabledMods.add(o.toString());
            Object suppressed = raw.get("suppress_warnings");
            if (suppressed instanceof List)
                for (Object o : (List<?>)suppressed) if (o != null) suppressedWarnings.add(o.toString());
        } catch (Exception e) {
            System.err.println("[ModSettings] Could not load: " + e.getMessage());
        }
    }

    public Set<String> getDisabledMods()      { return Collections.unmodifiableSet(disabledMods); }
    public Set<String> getSuppressedWarnings() { return Collections.unmodifiableSet(suppressedWarnings); }
}
