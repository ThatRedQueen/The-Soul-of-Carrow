package game.data;

import java.util.*;

public class ClothingData {
    // Identity
    public String id          = "";
    public String name        = "";
    public String description = "";
    public String color       = "";

    // Slot: upper, lower, overcoat, bra, underwear, socks, shoes
    public String  slot       = "upper";
    public boolean fills_lower = false;  // dress flag
    public boolean oversized   = false;  // long shirt — counts as lower coverage — upper item that also covers the lower body

    // Physical properties
    public String  thickness  = "medium"; // thick, medium, thin, diaphanous
    public boolean tight      = false;
    public boolean loose      = false;
    public boolean crop_top   = false;
    public boolean off_shoulder = false;
    public boolean has_buttons  = false;
    public boolean braless      = false;  // upper items — no bra layer
    public boolean sandals      = false;  // shoes — no socks needed
    public boolean is_skirt     = false;  // enables skirt-flip scenes
    public String  heel_type    = "none"; // none / low / high — high heels can cause falls

    // Wet mechanics
    public boolean seethrough          = false;
    public boolean seethrough_when_wet = false;
    public boolean diaphanous_when_wet = false;
    public boolean is_wet              = false;

    // Ratings
    public int formal_rating   = 0;
    public int lewdness_rating = 0;
    public int casual_rating   = 50;

    // Shop
    public int price = 0;

    /** True if this item is thin enough to show nipping when braless */
    public boolean isNipRisk() {
        return "thin".equals(thickness) || "diaphanous".equals(thickness) || seethrough
            || (is_wet && (seethrough_when_wet || diaphanous_when_wet));
    }

    /** True if this item is sheer enough to show full exposure when braless */
    public boolean isExposureRisk() {
        return "diaphanous".equals(thickness) || (seethrough)
            || (is_wet && (seethrough_when_wet || diaphanous_when_wet));
    }
}
