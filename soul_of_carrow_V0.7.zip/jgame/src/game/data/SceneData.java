package game.data;

import java.util.*;

public class SceneData {
    public String            text          = "";
    public List<TextVariant> text_variants = new ArrayList<>();
    public List<ChoiceData>  choices       = new ArrayList<>();
    /** Triggers evaluated after this scene completes — weighted roll picks one or none. */
    public List<TriggerData> possible_triggers = new ArrayList<>();

    public static class TextVariant {
        public String requires_trait     = "default";
        public String requires_npc_trait = "";  // trait of current approaching NPC
        public String requires_flag      = "";   // checks getBodyFlag — for dynamic states like period
        public String text           = "";
    }

    /**
     * A mod-injected rule that hides an existing choice when a condition is met.
     * Matched against choice.text using case-insensitive substring containment.
     */
    public static class SuppressRule {
        /** Hides any choice whose text contains this string (case-insensitive). */
        public String text_contains  = "";
        /** Only active when player has this trait. Empty = always active. */
        public String when_trait     = "";
        /** Only active when this body-state flag is true. Empty = always active. */
        public String when_flag      = "";
    }

    /** Mod-injected suppression rules — hides existing choices matching the rule. */
    public java.util.List<SuppressRule> suppressRules = new java.util.ArrayList<>();

    public static class ChoiceData {
        public String              text                  = "";
        public String              next                  = "";
        public String              result_text           = "";
        public List<String>        requires_traits       = new ArrayList<>();
        public List<String>        blocks_if_traits      = new ArrayList<>();
        /**
         * OR-logic trait gate — at least one must be present for choice to be visible.
         * Complements requires_traits (which is AND-logic).
         */
        public List<String>        requires_any_traits   = new ArrayList<>();
        public Map<String,Integer> stat_changes          = new LinkedHashMap<>();
        public Map<String,Integer> stat_set              = new LinkedHashMap<>();
        public List<String>        add_traits            = new ArrayList<>();
        public List<String>        remove_traits         = new ArrayList<>();
        public List<String>        timed_traits          = new ArrayList<>();
        public Map<String,List<String>> requires_npc_traits = new LinkedHashMap<>();

        // ── Slut rep system ─────────────────────────────────────────
        /** Base slut_rep required to see this choice (before trait modifiers). Default 0. */
        public int         slut_rep_req  = 0;
        /** Slut rep gained when this choice is taken (subject to tier cap + scene cap + lifetime diminishing returns). Default 0. */
        public int         slut_rep_gain = 0;
        /**
         * If set, accidental gain is multiplied when current slut_rep is well below this value.
         * Represents the "natural" rep level for this exposure — e.g. a commando skirt flip
         * has a natural threshold of ~18 even though slut_rep_req is 0.
         * Multiplier: rep < threshold/3 -> *2, rep < threshold*2/3 -> *1, rep ≥ threshold -> *0.5
         */
        public int         accidental_threshold  = 0;
        /**
         * Used for actions that lose novelty at high rep (e.g. public flashing, 0 gain above 35).
         */
        public int         slut_rep_gain_max_rep = 0;
        /**
         * Slut rep gained from a surprise/involuntary act (50% of this value applied).
         * Use for wardrobe malfunctions, unexpected groping, etc.
         * Subject to same diminishing returns as slut_rep_gain.
         */
        public int         slut_rep_gain_surprise = 0;
        /**
         * Action type for diminishing returns tracking. Determines which lifetime cap applies.
         * Values: "low_risk_flash", "high_risk_flash", "watched_flash", "public_act"
         * If empty, inferred from path_traits (Public_Exhibitionist -> high_risk_flash, etc.)
         */
        public String      slut_rep_action_type = "";
        /**
         * Path trait labels that drive slut_rep_req modifiers and willpower gates.
         * Multiple allowed — modifiers stack multiplicatively.
         * Values: Public, Public_Exhibitionist, Low_Risk_Exhibitionist, MC_Likely_Harassment
         */
        public List<String> path_traits  = new ArrayList<>();

        // ── Additional gates ────────────────────────────────────────
        /** Minimum arousal required to see this choice. */
        public int         min_arousal   = 0;
        /** Minimum money required to pick this choice (e.g. upfront rent). */
        public int         min_money     = 0;
        /** Minimum work_rep required to see this choice. */
        public int         min_work_rep  = 0;
        /** Maximum slut_rep allowed — choice hidden if rep exceeds this. -1 = no limit. */
        public int         max_slut_rep  = -1;
        /** Minimum NPC rep required per NPC ID. Map of npcId -> minimum rep value (-100->+100). */
        public Map<String,Integer> min_npc_rep_map = new LinkedHashMap<>();

        // ── Priority locking ────────────────────────────────────────
        /**
         * Priority level for this choice (default 0).
         * Higher values are evaluated before lower values.
         * Only meaningful when locks_others is true on at least one visible choice.
         */
        public int         priority      = 0;
        /** Minimum effective willpower required to see this choice. 0 = no gate. */
        public int         min_willpower          = 0;
        /** Maximum effective willpower allowed — choice hidden if WP exceeds this. -1 = no limit. */
        public int         max_willpower          = -1;
        /**
         * Arousal penalty threshold for willpower checks.
         * For every 10 arousal above this value, subtract 2 from effective WP
         * before applying min_willpower / max_willpower gates.
         * 0 = no arousal penalty.
         * Example: arousal_wp_drain_above: 50 — at arousal 70, WP is drained by 4.
         */
        public int         arousal_wp_drain_above = 0;
        /**
         * If true, Engine calls BarSystem.rollNpcDecision() to determine the
         * next scene instead of using the static next field.
         * Used for "Let them decide" choice in bar_with_npc.
         */
        /**
         * If true and this choice is visible, all choices with lower priority
         * are suppressed. The highest-priority locking choice wins.
         */
        public boolean     locks_others            = false;
        public boolean     npc_decides             = false;
        /** If true, choice is always shown but greyed/disabled — work in progress. */
        public boolean     wip               = false;
        /**
         * If true, choice is shown (but greyed) even when its gate conditions fail.
         * Used for choices the player should know exist but can't access yet.
         */
        public boolean     show_when_locked  = false;
        public String      requires_flag           = "";
        /** Choice hidden if this body-state flag is true. Empty = no gate. */
        public String      blocks_if_flag          = "";
        /** Choice requires NPC rep >= this value. 0 = no gate. */
        public int         min_npc_rep             = 0;
        /**
         * If NPC has ANY of these traits, the min_npc_rep gate is bypassed.
         * Allows: "unlock if rep >= 25, OR if NPC is Sleazy/Jerk."
         */
        public java.util.List<String> rep_bypass_traits = new java.util.ArrayList<>();

        // Clothing requirements (minimum ratings)
        public int     min_formal_rating   = 0;
        public int     min_lewdness_rating = 0;
        public int     min_casual_rating   = 0;
        public boolean requires_seethrough = false;
        public boolean requires_wet        = false;

        // Change outfit
        public String  change_outfit       = "";
        public boolean set_wet             = false;
        public boolean set_dry             = false;

        // Cycle conditions
        public boolean requires_fertile_window = false;
        public boolean requires_period         = false;
        public boolean requires_not_period     = false;

        // Cycle
        public int     advance_cycle           = 0;
        public int     money_change            = 0;
        /** Car action string: "buy:model:tier:cost" | "rent:model:tier:days:cost" |
         *  "finance:model:tier:monthly:months" | "finance_pay" | "return_car" */
        public String  car_action              = "";
        public String  car_action2             = "";
    }
}
