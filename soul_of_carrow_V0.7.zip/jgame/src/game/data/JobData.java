package game.data;

import java.util.*;

public class JobData {
    public String       id              = "";
    public String       label           = "";
    public String       description     = "";
    public int          pay_per_day     = 0;
    public int          slots_per_day   = 4;
    public List<String> work_days       = new ArrayList<>();
    public Map<String,Integer> stat_changes = new LinkedHashMap<>();
    public String       boss_npc_id     = "";
    public List<String> coworker_npc_ids = new ArrayList<>();

    // Pay schedule: DAILY, WEEKLY, BIWEEKLY
    public String       pay_frequency   = "WEEKLY";

    // Under the table = no tax deducted
    public boolean      under_the_table = false;

    // ── Content paths — set by JobLoader at load time ─────────────────────────
    /** Path to scenes/work/{id}/ — null if folder doesn't exist */
    public String       scene_dir       = null;

    /** Extra scene triggers that can fire during a work shift (rep/sa gated). */
    public java.util.List<game.data.TriggerData> possible_triggers = new java.util.ArrayList<>();
    /** Path to interviews/{id}.yml — null if file doesn't exist */
    public String       interview_file  = null;

    /** Days worked per week based on work_days list */
    public int daysPerWeek() { return work_days.size(); }

    /** Gross pay per paycheck before tax */
    public int grossPaycheck() {
        int perDay = pay_per_day;
        switch (pay_frequency.toUpperCase()) {
            case "DAILY":    return perDay;
            case "WEEKLY":   return perDay * daysPerWeek();
            case "BIWEEKLY": return perDay * daysPerWeek() * 2;
            default:         return perDay * daysPerWeek();
        }
    }

    /** Net pay after tax (or gross if under the table) */
    public int netPaycheck() {
        if (under_the_table) return grossPaycheck();
        return grossPaycheck() - taxAmount();
    }

    /** Tax deducted per paycheck — rates from gamedata/taxes.yml */
    public int taxAmount() {
        if (under_the_table) return 0;
        int annualGross = pay_per_day * daysPerWeek() * 52;
        double rate = game.GameState.taxRateForAnnual(annualGross);
        return (int) Math.round(grossPaycheck() * rate);
    }

    public String taxBracketLabel() {
        if (under_the_table) return "Untaxed";
        return game.GameState.taxBracketLabel(pay_per_day * daysPerWeek() * 52);
    }

    public String payFrequencyLabel() {
        switch (pay_frequency.toUpperCase()) {
            case "DAILY":    return "daily";
            case "WEEKLY":   return "weekly";
            case "BIWEEKLY": return "every two weeks";
            default:         return "weekly";
        }
    }
}
