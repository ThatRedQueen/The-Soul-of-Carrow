package game;

import game.data.ClothingData;
import org.yaml.snakeyaml.Yaml;
import java.io.*;
import java.util.*;

public class ClothingLoader {
    private final Map<String, ClothingData> items = new LinkedHashMap<>();

    @SuppressWarnings("unchecked")
    public void loadAll(String dir) {
        File folder = new File(dir);
        if (!folder.exists()) return;
        loadDir(folder);
    }

    private void loadDir(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return;
        Yaml yaml = new Yaml(new org.yaml.snakeyaml.constructor.SafeConstructor(new org.yaml.snakeyaml.LoaderOptions()));
        for (File f : files) {
            if (f.isDirectory()) loadDir(f);
            else if (f.getName().endsWith(".yml")) loadFile(yaml, f);
        }
    }

    @SuppressWarnings("unchecked")
    private void loadFile(Yaml yaml, File f) {
        try (InputStream is = new FileInputStream(f)) {
            Map<String,Object> raw = yaml.load(is);
            if (raw == null) return;
            ClothingData c = parseItem(raw);
            if (c != null && !c.id.isEmpty()) items.put(c.id, c);
        } catch (Exception e) { System.err.println("Clothing error " + f.getName() + ": " + e.getMessage()); }
    }

    public ClothingData get(String id)          { return id == null ? null : items.get(id); }
    public Collection<ClothingData> getAll()    { return items.values(); }

    /** All items for a specific slot */
    public List<ClothingData> bySlot(String slot) {
        List<ClothingData> out = new ArrayList<>();
        for (ClothingData c : items.values()) if (slot.equals(c.slot)) out.add(c);
        return out;
    }

    /** Random shop stock — picks up to N random items from shop/ subfolder items */
    public List<ClothingData> randomShopStock(int count, java.util.Random rng) {
        return randomShopStock(count, rng, java.util.Collections.emptySet(), false);
    }

    public List<ClothingData> randomShopStock(int count, java.util.Random rng,
                                               java.util.Set<String> owned, boolean startingOnly) {
        List<ClothingData> shop = new ArrayList<>();
        for (ClothingData c : items.values()) {
            if (c.price <= 0) continue;
            // Don't offer items MC already owns
            if (owned.contains(c.id)) continue;
            // If starting lock still active, only show items the player doesn't have
            // (the starting set is already in ownedClothing, so owned filter covers this)
            shop.add(c);
        }
        java.util.Collections.shuffle(shop, rng);
        return shop.subList(0, Math.min(count, shop.size()));
    }

    ClothingData parseItem(Map<String,Object> raw) {
        if (raw == null) return null;
        ClothingData c = new ClothingData();
        c.id          = str(raw, "id");
        c.name        = str(raw, "name");
        c.description = str(raw, "description");
        c.color       = str(raw, "color");
        c.slot        = str(raw, "slot"); if (c.slot.isEmpty()) c.slot = "upper";
        c.fills_lower = bool(raw, "fills_lower", false);
        c.oversized   = bool(raw, "oversized",   false);
        c.thickness   = str(raw, "thickness"); if (c.thickness.isEmpty()) c.thickness = "medium";
        c.tight       = bool(raw, "tight",          false);
        c.loose       = bool(raw, "loose",          false);
        c.crop_top    = bool(raw, "crop_top",       false);
        c.off_shoulder= bool(raw, "off_shoulder",   false);
        c.has_buttons = bool(raw, "has_buttons",    false);
        c.braless     = bool(raw, "braless",        false);
        c.sandals     = bool(raw, "sandals",        false);
        c.is_skirt    = bool(raw, "is_skirt",       false);
        c.heel_type   = str(raw,  "heel_type"); if (c.heel_type.isEmpty()) c.heel_type = "none";
        c.seethrough          = bool(raw, "seethrough",          false);
        c.seethrough_when_wet = bool(raw, "seethrough_when_wet", false);
        c.diaphanous_when_wet = bool(raw, "diaphanous_when_wet", false);
        c.is_wet              = bool(raw, "is_wet",              false);
        c.formal_rating   = intv(raw, "formal_rating",   0);
        c.lewdness_rating = intv(raw, "lewdness_rating",  0);
        c.casual_rating   = intv(raw, "casual_rating",   50);
        c.price           = intv(raw, "price",            0);
        return c;
    }

    public boolean injectModClothing(java.util.Map<String,Object> raw, String modId) {
        try {
            ClothingData c = parseItem(raw);
            if (c == null || c.id.isEmpty()) return false;
            items.put(c.id, c);
            return true;
        } catch (Exception e) {
            System.err.println("[ClothingLoader] injectModClothing failed: " + e.getMessage());
            return false;
        }
    }


    private String str(Map<String,Object> m, String k) { Object v = m.get(k); return v == null ? "" : v.toString().trim(); }
    private boolean bool(Map<String,Object> m, String k, boolean def) { Object v = m.get(k); return v == null ? def : Boolean.parseBoolean(v.toString()); }
    private int intv(Map<String,Object> m, String k, int def) {
        Object v = m.get(k); if (v == null) return def;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return def; }
    }
}
