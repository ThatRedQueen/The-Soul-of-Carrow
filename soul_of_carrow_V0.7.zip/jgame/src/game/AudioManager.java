package game;

import javax.sound.sampled.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Manages soundtrack and ambient audio for mod packs.
 *
 * Mods declare tracks in soundtrack.yml:
 *
 *   tracks:
 *     - id: bar_ambient
 *       file: music/bar_ambient.wav
 *       loop: true
 *       volume: 0.7
 *       triggers:
 *         - scene_ids: [bar_night, bar_dance_floor, bar_with_npc]
 *         - flags:     [flag_at_bar]          # any of these flags → play
 *
 *     - id: tense_grope
 *       file: music/tense_ambient.wav
 *       loop: true
 *       volume: 0.5
 *       priority: 10
 *       triggers:
 *         - flags: [flag_being_groped]
 *
 *     - id: morning_theme
 *       file: music/morning.wav
 *       loop: false
 *       triggers:
 *         - scene_ids: [morning_routine, home_shower]
 *
 * SUPPORTED FORMATS: WAV (built-in Java), AIFF, AU
 * For MP3/OGG: users can convert to WAV using Audacity (free).
 * The game degrades gracefully when audio is unavailable.
 *
 * NOTES:
 * - Only one track plays at a time (highest priority wins)
 * - Tracks fade when replaced (100ms crossfade)
 * - Audio is optional — the game works silently with no mods
 * - Master volume controlled by Settings
 */
public class AudioManager {

    public static class Track {
        public final String       id;
        public final String       filePath;
        public final boolean      loop;
        public final float        volume;       // 0.0 – 1.0
        public final int          priority;
        public final List<Set<String>> flagTriggers;   // OR of AND-groups
        public final Set<String>  sceneTriggers;        // OR of scene IDs

        @SuppressWarnings("unchecked")
        public Track(Map<?,?> raw, String modDir) {
            id       = str(raw, "id");
            String f = str(raw, "file");
            filePath = new File(modDir, f).getAbsolutePath();
            loop     = !"false".equalsIgnoreCase(str(raw, "loop"));
            volume   = Math.min(1f, Math.max(0f, floatVal(raw, "volume", 0.8f)));
            priority = intVal(raw, "priority", 1);

            flagTriggers  = new ArrayList<>();
            sceneTriggers = new HashSet<>();
            Object tList = raw.get("triggers");
            if (tList instanceof List) {
                for (Object t : (List<?>)tList) {
                    if (!(t instanceof Map)) continue;
                    Map<?,?> tm = (Map<?,?>)t;
                    Object flags  = tm.get("flags");
                    Object scenes = tm.get("scene_ids");
                    if (flags instanceof List) {
                        Set<String> flagGroup = new HashSet<>();
                        for (Object fl : (List<?>)flags) flagGroup.add(fl.toString().toLowerCase());
                        if (!flagGroup.isEmpty()) flagTriggers.add(flagGroup);
                    }
                    if (scenes instanceof List)
                        for (Object sc : (List<?>)scenes) sceneTriggers.add(sc.toString());
                }
            }
        }

        /** True if this track should play given the current state. */
        public boolean matches(Set<String> activeFlags, String currentScene) {
            if (!sceneTriggers.isEmpty() && sceneTriggers.contains(currentScene)) return true;
            for (Set<String> group : flagTriggers) {
                boolean allMatch = true;
                for (String f : group) if (!activeFlags.contains(f)) { allMatch = false; break; }
                if (allMatch) return true;
            }
            return false;
        }

        private String str(Map<?,?> m, String k) { Object v=m.get(k); return v==null?"":v.toString().trim(); }
        private int intVal(Map<?,?> m, String k, int d) { Object v=m.get(k); if(v==null)return d; try{return Integer.parseInt(v.toString());}catch(Exception e){return d;} }
        private float floatVal(Map<?,?> m, String k, float d) { Object v=m.get(k); if(v==null)return d; try{return Float.parseFloat(v.toString());}catch(Exception e){return d;} }
    }

    private final List<Track>         tracks      = new ArrayList<>();
    private final ExecutorService     audioThread = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "audio-manager");
        t.setDaemon(true);
        return t;
    });
    private Clip     currentClip    = null;
    private Track    currentTrack   = null;
    private float    masterVolume   = 0.8f;
    private boolean  enabled        = true;
    private final AtomicBoolean audioAvailable = new AtomicBoolean(true);

    // ── Registration ──────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    public void loadFromYaml(List<?> trackList, String modDir) {
        if (trackList == null) return;
        int count = 0;
        for (Object item : trackList) {
            if (!(item instanceof Map)) continue;
            Track t = new Track((Map<?,?>)item, modDir);
            if (t.id.isEmpty() || t.filePath.isEmpty()) continue;
            tracks.add(t);
            count++;
        }
        // Higher priority tracks evaluated first
        tracks.sort((a, b) -> Integer.compare(b.priority, a.priority));
        System.out.printf("[AudioManager] Registered %d track(s) (total: %d)%n", count, tracks.size());
    }

    // ── Playback control ──────────────────────────────────────────────────────

    public void setMasterVolume(float v) {
        masterVolume = Math.min(1f, Math.max(0f, v));
        applyVolume(currentClip, masterVolume);
    }
    public void setEnabled(boolean e) {
        enabled = e;
        if (!e) stop();
    }

    /**
     * Called by ScenePanel whenever the scene or game state changes.
     * Evaluates which track (if any) should be playing and switches if needed.
     */
    public void update(Set<String> activeFlags, String currentScene) {
        if (!enabled || !audioAvailable.get()) return;
        Track best = null;
        for (Track t : tracks) {
            if (t.matches(activeFlags, currentScene)) { best = t; break; }
        }
        if (best == currentTrack) return; // already playing the right track
        final Track toBePlayed = best;
        audioThread.submit(() -> switchTo(toBePlayed));
    }

    public void stop() {
        audioThread.submit(() -> switchTo(null));
    }

    public void shutdown() {
        stop();
        audioThread.shutdown();
    }

    // ── Internal ─────────────────────────────────────────────────────────────

    private void switchTo(Track newTrack) {
        // Fade out current
        if (currentClip != null && currentClip.isRunning()) {
            fadeOut(currentClip, 120);
            currentClip.stop();
            currentClip.close();
            currentClip = null;
        }
        currentTrack = newTrack;
        if (newTrack == null) return;
        try {
            File f = new File(newTrack.filePath);
            if (!f.exists()) return;
            AudioInputStream ais = AudioSystem.getAudioInputStream(f);
            Clip clip = AudioSystem.getClip();
            clip.open(ais);
            applyVolume(clip, masterVolume * newTrack.volume);
            if (newTrack.loop) clip.loop(Clip.LOOP_CONTINUOUSLY);
            else               clip.start();
            currentClip = clip;
        } catch (UnsupportedAudioFileException e) {
            System.err.println("[AudioManager] Unsupported format: " + newTrack.filePath);
        } catch (Exception e) {
            System.err.println("[AudioManager] Playback error for " + newTrack.id + ": " + e.getMessage());
            audioAvailable.set(false); // disable after repeated failures
        }
    }

    private void fadeOut(Clip clip, int ms) {
        try {
            FloatControl vol = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
            float start = vol.getValue();
            float step  = (start - vol.getMinimum()) / (ms / 10f);
            for (int i = 0; i < ms / 10; i++) {
                Thread.sleep(10);
                vol.setValue(Math.max(vol.getMinimum(), vol.getValue() - step));
            }
        } catch (Exception ignored) {}
    }

    private void applyVolume(Clip clip, float volume) {
        if (clip == null) return;
        try {
            FloatControl fc = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
            float range = fc.getMaximum() - fc.getMinimum();
            float gain  = fc.getMinimum() + (range * Math.min(1f, Math.max(0f, volume)));
            fc.setValue(gain);
        } catch (Exception ignored) {}
    }

    public int trackCount() { return tracks.size(); }
    public boolean isEnabled() { return enabled; }
}
