package game;

import java.util.*;

public class GameState {

    public static final String[] DAY_NAMES      = {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
    public static final String[] DAY_SHORT      = {"MON","TUE","WED","THU","FRI","SAT","SUN"};

    public String playerName   = "Player";
    public int    money        = 1500;
    /** Injected at startup — applies multipliers for slut_rep, WP drain, stress. */
    public transient game.GameSettings settings = null;

    // ── City identity ──────────────────────────────────────────────────────
    /** The city. Manhattan, New York. */
    public static final String CITY_NAME    = "Carrow";
    public static final String CITY_TAGLINE = "You end up here. Then you stay.";

    /**
     * Neighbourhood the player is currently exploring.
     * Set when they pick a district from explore_district_hub.
     * Persists until next explore session.
     */
    public String currentNeighbourhood = ""; // e.g. "Lower East Side"

    /** Discovers a location by ID (e.g. "mall"). Idempotent. */
    public java.util.Set<String> discoveredLocations = new java.util.LinkedHashSet<>();

    // ── Clothing loss tracking (for auto-rebuy) ────────────────────────────
    public java.util.Set<String>  lostClothingToday  = new java.util.LinkedHashSet<>();
    public java.util.List<String> rebuyReceiptItems  = new java.util.ArrayList<>();
    public int                    rebuyReceiptTotal   = 0;

    public void loseClothingItem(String itemId) {
        if (ownedClothing.remove(itemId)) lostClothingToday.add(itemId);
    }
    public void clearLostClothingToday() { lostClothingToday.clear(); }

    // ── Seasons ──────────────────────────────────────────────────────────────
    /** 0=Spring 1=Summer 2=Autumn 3=Winter. Advances every 30 game days. */
    public int    currentSeason = 0;
    // Season data — loaded from gamedata/seasons.yml at startup, fallback hardcoded
    public static String[] SEASON_NAMES  = {"Spring","Summer","Autumn","Winter"};
    public static String[] SEASON_EMOJIS = {"🌸","☀️","🍂","❄️"};


    // ── Tax brackets — loaded from gamedata/taxes.yml ─────────────────────────
    /** Sorted list of [maxAnnual, rate] pairs. Last entry has maxAnnual = Integer.MAX_VALUE. */
    private static final java.util.List<int[]> TAX_BRACKETS = new java.util.ArrayList<>();
    private static final java.util.List<String> TAX_LABELS   = new java.util.ArrayList<>();
    static {
        TAX_BRACKETS.add(new int[]{15000, 10}); // 10%
        TAX_BRACKETS.add(new int[]{40000, 12}); // 12%
        TAX_BRACKETS.add(new int[]{85000, 22}); // 22%
        TAX_BRACKETS.add(new int[]{Integer.MAX_VALUE, 24}); // 24%
        TAX_LABELS.addAll(java.util.Arrays.asList("10%","12%","22%","24%"));
    }

    @SuppressWarnings("unchecked")
    public static void loadTaxes(String gameDataDir) {
        java.io.File f = new java.io.File(gameDataDir + "/taxes.yml");
        if (!f.exists()) return;
        try (java.io.InputStream is = new java.io.FileInputStream(f)) {
            org.yaml.snakeyaml.Yaml yaml = new org.yaml.snakeyaml.Yaml(
                new org.yaml.snakeyaml.constructor.SafeConstructor(
                    new org.yaml.snakeyaml.LoaderOptions()));
            java.util.Map<String,Object> raw = yaml.load(is);
            if (raw == null) return;
            java.util.List<java.util.Map<String,Object>> brackets =
                (java.util.List<java.util.Map<String,Object>>) raw.get("brackets");
            if (brackets == null || brackets.isEmpty()) return;
            TAX_BRACKETS.clear(); TAX_LABELS.clear();
            for (java.util.Map<String,Object> b : brackets) {
                Object maxRaw = b.get("max_annual");
                int max = (maxRaw == null) ? Integer.MAX_VALUE
                                           : Integer.parseInt(maxRaw.toString());
                int rate = (int)(Double.parseDouble(b.get("rate").toString()) * 100);
                TAX_BRACKETS.add(new int[]{max, rate});
                TAX_LABELS.add(b.getOrDefault("label","?").toString());
            }
            System.out.println("[GameState] Loaded " + TAX_BRACKETS.size() + " tax brackets.");
        } catch (Exception e) {
            System.err.println("[GameState] Could not load taxes.yml: " + e.getMessage());
        }
    }

    /** Tax rate (0.0-1.0) for a given annual gross income. */
    public static double taxRateForAnnual(int annualGross) {
        for (int[] bracket : TAX_BRACKETS)
            if (annualGross <= bracket[0]) return bracket[1] / 100.0;
        return 0.24;
    }

    /** Tax bracket label for display (e.g. "22%"). */
    public static String taxBracketLabel(int annualGross) {
        for (int i = 0; i < TAX_BRACKETS.size(); i++)
            if (annualGross <= TAX_BRACKETS.get(i)[0])
                return i < TAX_LABELS.size() ? TAX_LABELS.get(i) : "?";
        return "24%";
    }

    // ── Neighbourhood data — loaded from gamedata/neighbourhoods.yml ─────────────
    /** Maps flag suffix (e.g. "narrows") to display name (e.g. "The Narrows"). */
    public static final java.util.Map<String,String> NEIGHBOURHOOD_FLAGS = new java.util.LinkedHashMap<>();
    static {
        // defaults — overridden by loadNeighbourhoods() if file exists
        NEIGHBOURHOOD_FLAGS.put("narrows",    "The Narrows");
        NEIGHBOURHOOD_FLAGS.put("millgate",   "Millgate");
        NEIGHBOURHOOD_FLAGS.put("thornwick",  "Thornwick");
        NEIGHBOURHOOD_FLAGS.put("lanes",      "The Lanes");
        NEIGHBOURHOOD_FLAGS.put("caldwell",   "Caldwell");
        NEIGHBOURHOOD_FLAGS.put("ravenshill", "Ravenshill");
    }

    @SuppressWarnings("unchecked")
    public static void loadNeighbourhoods(String gameDataDir) {
        java.io.File f = new java.io.File(gameDataDir + "/neighbourhoods.yml");
        if (!f.exists()) return;
        try (java.io.InputStream is = new java.io.FileInputStream(f)) {
            org.yaml.snakeyaml.Yaml yaml = new org.yaml.snakeyaml.Yaml(
                new org.yaml.snakeyaml.constructor.SafeConstructor(
                    new org.yaml.snakeyaml.LoaderOptions()));
            java.util.Map<String,Object> raw = yaml.load(is);
            if (raw == null) return;
            java.util.List<java.util.Map<String,Object>> list =
                (java.util.List<java.util.Map<String,Object>>) raw.get("neighbourhoods");
            if (list == null) return;
            NEIGHBOURHOOD_FLAGS.clear();
            for (java.util.Map<String,Object> n : list) {
                String flag = n.getOrDefault("flag","").toString()
                               .replace("flag_neighbourhood_","");
                String name = n.getOrDefault("name","").toString();
                if (!flag.isEmpty() && !name.isEmpty()) NEIGHBOURHOOD_FLAGS.put(flag, name);
            }
            System.out.println("[GameState] Loaded " + NEIGHBOURHOOD_FLAGS.size() + " neighbourhoods.");
        } catch (Exception e) {
            System.err.println("[GameState] Could not load neighbourhoods.yml: " + e.getMessage());
        }
    }

    /** Call once at startup to load seasons from gamedata/seasons.yml if present. */    /** Call once at startup to load seasons from gamedata/seasons.yml if present. */
    @SuppressWarnings("unchecked")
    public static void loadSeasons(String gameDataDir) {
        java.io.File f = new java.io.File(gameDataDir + "/seasons.yml");
        if (!f.exists()) return;
        try (java.io.InputStream is = new java.io.FileInputStream(f)) {
            org.yaml.snakeyaml.Yaml yaml = new org.yaml.snakeyaml.Yaml(
                new org.yaml.snakeyaml.constructor.SafeConstructor(
                    new org.yaml.snakeyaml.LoaderOptions()));
            java.util.Map<String,Object> raw = yaml.load(is);
            if (raw == null) return;
            java.util.List<java.util.Map<String,Object>> list =
                (java.util.List<java.util.Map<String,Object>>) raw.get("seasons");
            if (list == null || list.isEmpty()) return;
            String[] names  = new String[list.size()];
            String[] emojis = new String[list.size()];
            for (java.util.Map<String,Object> s : list) {
                int idx = ((Number) s.getOrDefault("index", 0)).intValue();
                if (idx >= 0 && idx < list.size()) {
                    names[idx]  = s.getOrDefault("name",  "Season").toString();
                    emojis[idx] = s.getOrDefault("emoji", "").toString();
                }
            }
            SEASON_NAMES  = names;
            SEASON_EMOJIS = emojis;
            System.out.println("[GameState] Loaded " + list.size() + " seasons from seasons.yml");
        } catch (Exception e) {
            System.err.println("[GameState] Could not load seasons.yml: " + e.getMessage());
        }
    }

    public String  getSeasonName()        { return SEASON_NAMES[currentSeason];  }
    public String  getSeasonEmoji()       { return SEASON_EMOJIS[currentSeason]; }
    public boolean isSeason(String s)     { return getSeasonName().equalsIgnoreCase(s); }
    public boolean isWarmSeason()         { return currentSeason == 0 || currentSeason == 1; }
    public boolean isColdSeason()         { return currentSeason == 2 || currentSeason == 3; }

    /** Discover a location by ID (e.g. "mall"). Idempotent. */
    public void discoverLocation(String locId) {
        if (discoveredLocations.add(locId)) addTrait("found_" + locId);
    }

    public boolean hasDiscovered(String locId) { return discoveredLocations.contains(locId); }
    public int    rent         = 0;
    public int    fitness      = 50;
    public int    work_rep     = 0;     // workplace reputation (0=unknown, 100=mascot)
    public java.util.Map<String,Integer> npcReputation = new java.util.HashMap<>();  // per-NPC -100→+100, 0=neutral
    public int    happiness    = 40;
    public int    confidence   = 45;
    public int    willpower    = 35;
    public int    stress       = 50;    // starts high — floor mattress, new city, no furniture
    public int    slut_rep     = 0;     // 0=unknown, 100=propositioned daily
    public int    thrills      = 0;     // excitement from exhibitionist moments
    public int    arousal      = 0;     // daily arousal — checked mid-scene, decays each day
    public int    drunk        = 0;     // 0=sober, 15=blackout, 20=passed out — decays overnight
    public int    dayCount     = 1;
    public int    dayOfWeek    = 0;     // 0=Monday … 6=Sunday
    // ── Tax year tracking ─────────────────────────────────────────────────────
    /** Cumulative gross income from above-table jobs this year. */
    public int annualGrossEarned  = 0;
    /** Cumulative tax already withheld this year. */
    public int annualTaxWithheld  = 0;
    /** Set true on day 365; cleared after tax scene fires. */
    public boolean taxFilingDue   = false;
    // ── Sunburn ──────────────────────────────────────────────────────────────
    /** Days of sunburn remaining (0 = none, max 2). */
    public int sunburnDays        = 0;


    // Per-scene slut rep gain tracking — capped at +2 per scene
    public int    slutRepGainedThisScene = 0;
    /** Slut rep gained today across all scenes. Cleared on advanceDay(). Hard cap: 5. */
    public int    slutRepGainedToday     = 0;
    public static final int SLUT_REP_DAILY_CAP     = 5;
    public static final int SLUT_REP_SEX_DAILY_CAP = 12; // higher cap during sex scenes

    /**
     * Trait auto-acquisitions that happened during advanceDay() and need
     * to be surfaced to the player as scenes at the start of the next day.
     * Drained by GameWindow.onDayEnd() → added to pendingScenes.
     */
    public java.util.List<String> pendingTraitAcquisitions = new java.util.ArrayList<>();
    /** Last day's activity slot selection — pre-loaded into day planner each morning. */
    public String[] lastDaySlots = null;

    /**
     * Dance lock system — when MC is drunk (effWP < 25) AND enjoying the situation
     * (slut_rep puts her in "enjoy" tier), she cannot end the dance voluntarily.
     * She must cycle through 5 more dance turns before the exit unlocks.
     */
    public int     danceLockTurns  = 0;   // turns remaining before exit unlocks
    public boolean flagDanceLocked = false; // true while locked — gates YAML choices

    /**
     * Lifetime slut_rep earned broken out by action type.
     * Used for diminishing returns — each type has a lifetime cap from the spec table.
     *
     * Action types and lifetime caps:
     *   "low_risk_flash"   → cap 12  (flash with no real risk of being seen)
     *   "high_risk_flash"  → cap 16  (flash with high risk of being seen)
     *   "watched_flash"    → cap 20  (flash to someone actively watching)
     *   "public_act"       → cap 14  (generic public sexual act, not flash-specific)
     *
     * Diminishing returns formula (applied WITHIN lifetime cap):
     *   Earned 0–4   from type: full gain
     *   Earned 5–8   from type: gain halved (round up)
     *   Earned 9–12  from type: gain quartered (round up)
     *   Earned 12+   from type: 0 (at or past soft cap, hard cap from above enforces max)
     */
    public java.util.Map<String, Integer> slutRepEarnedByType = new java.util.LinkedHashMap<>();

    // Per-NPC memory — stores key events and last seen outfit
    // Keys: "npc_id:memory_key" → value (int or 0/1 for flags)
    public Map<String,String> npcMemory = new HashMap<>();

    /** Store a memory about an NPC. e.g. setNpcMemory("richard", "flashed_boss", "1") */
    public void setNpcMemory(String npcId, String key, String value) {
        npcMemory.put(npcId + ":" + key, value);
    }

    /** Get a memory about an NPC. Returns empty string if not set. */
    public String getNpcMemory(String npcId, String key) {
        return npcMemory.getOrDefault(npcId + ":" + key, "");
    }

    /** Check if a boolean NPC memory flag is set */
    public boolean hasNpcMemory(String npcId, String key) {
        return "1".equals(getNpcMemory(npcId, key));
    }

    public String currentJobId      = null;  // null = unemployed
    public int    daysWorkedThisPay = 0;    // tracks days toward next paycheck
    /** Cumulative pay raise in currency/day — stacks with job base pay. Persists. */
    public int    payPerDayBonus   = 0;

    // ── Work mode system ──────────────────────────────────────────────────────
    /** Current work mode for next shift. Persists until changed. */
    public String workMode          = "normal"; // normal/harder/slack/politics/pranks
    // ── Saved Outfits ─────────────────────────────────────────────────────────
    public static class SavedOutfit {
        public String name       = "";
        public String upper      = null;
        public String lower      = null;
        public String bra        = null;
        public String underwear  = null;
        public String shoes      = null;
        public String socks      = null;
        public String overcoat   = null;
        public SavedOutfit() {}
        public SavedOutfit(String n, String up, String lo, String br,
                           String un, String sh, String sk, String oc) {
            name=n; upper=up; lower=lo; bra=br;
            underwear=un; shoes=sh; socks=sk; overcoat=oc;
        }
    }
    /** Player-saved outfit slots (max 8). */
    public java.util.List<SavedOutfit> savedOutfits = new java.util.ArrayList<>();
    /** ID of outfit to auto-apply on morning_routine (empty = manual). */
    public String dailyOutfitName = "";

    public String getOutfitSlot(String slot) {
        switch (slot) {
            case "upper":     return outfitUpper;
            case "lower":     return outfitLower;
            case "bra":       return outfitBra;
            case "underwear": return outfitUnderwear;
            case "shoes":     return outfitShoes;
            case "socks":     return outfitSocks;
            case "overcoat":  return outfitOvercoat;
            default: return null;
        }
    }

    public void setOutfitSlot(String slot, String val) {
        switch (slot) {
            case "upper":     outfitUpper    = val; break;
            case "lower":     outfitLower    = val; break;
            case "bra":       outfitBra      = val; break;
            case "underwear": outfitUnderwear= val; break;
            case "shoes":     outfitShoes    = val; break;
            case "socks":     outfitSocks    = val; break;
            case "overcoat":  outfitOvercoat = val; break;
        }
    }

    /** Save current outfit under a name (replaces existing with same name). */
    public void saveCurrentOutfit(String name) {
        savedOutfits.removeIf(o -> o.name.equals(name));
        savedOutfits.add(new SavedOutfit(name, outfitUpper, outfitLower, outfitBra,
                                         outfitUnderwear, outfitShoes, outfitSocks, outfitOvercoat));
        if (savedOutfits.size() > 8) savedOutfits.remove(0);
    }

    /** Load a saved outfit by name. Returns false if not found. */
    public boolean loadOutfit(String name) {
        for (SavedOutfit o : savedOutfits) {
            if (o.name.equals(name)) {
                outfitUpper    = o.upper;
                outfitLower    = o.lower;
                outfitBra      = o.bra;
                outfitUnderwear= o.underwear;
                outfitShoes    = o.shoes;
                outfitSocks    = o.socks;
                outfitOvercoat = o.overcoat;
                return true;
            }
        }
        return false;
    }






    // ── Video content classification ─────────────────────────────────────────
    /**
     * What type of content is in the recorded/leaked video.
     * "consensual" | "drunk" | "coerced" | "assault"
     * Used to determine legal options, emotional weight, and consequence severity.
     */
    public String videoContentType  = "";

    /**
     * True if MC was visibly intoxicated in the video.
     * Affects consent interpretation and legal options.
     */
    public boolean videoMcWasDrunk  = false;

    /** True when online video/content about MC has been found by an employer (rolled). */
    public boolean employerFoundOnlineContent = false;

    /**
     * Compute outfit lewdness for courtroom purposes.
     * Low formal_rating + high lewdness = judge dismisses case.
     * Returns true if outfit is too inappropriate for court.
     */
    public boolean outfitInappropriateForCourt() {
        int lwd = currentLewdnessRating();
        // Also check formal_rating of the outfit
        int formal = 0;
        if (outfitUpper != null && clothes != null) {
            game.data.ClothingData c = clothes.get(outfitUpper);
            if (c != null) formal = Math.max(formal, c.formal_rating);
        }
        if (outfitLower != null && clothes != null) {
            game.data.ClothingData c = clothes.get(outfitLower);
            if (c != null) formal = Math.max(formal, c.formal_rating);
        }
        // Too slutty for court: lewdness >= 45 OR formal < 30
        return lwd >= 45 || formal < 30;
    }

        // ── Legal Action System ───────────────────────────────────────────────────
    /** True when MC has discovered their photos/video are online (from NPC or browsing). */
    public boolean leakFoundOnline   = false;
    /** Content removal lawyer hired — tier 0=none, 1=budget($500), 2=mid($2000), 3=top($5000). */
    public int     contentLawyerTier = 0;
    /** True if a content removal legal order was successfully filed. */
    public boolean contentRemovalFiled = false;
    /** True if content was successfully removed. */
    public boolean contentRemoved    = false;
    /** SA civil suit filed by MC. */
    public boolean saSuitFiled       = false;
    /** SA suit resolved (true = settled/verdict reached). */
    public boolean saSuitResolved    = false;
    /** SA suit outcome: true = won, false = lost. */
    public boolean saSuitWon         = false;
    /** SA suit payout if won ($). */
    public int     saSuitPayout      = 0;
    /** Which NPC the SA suit is against (NPC ID). */
    public String  saSuitAgainstNpc  = "";
    /** Lawyer quality for SA suit: "sleazy"|"budget"|"competent"|"top". */
    public String  saSuitLawyerTier  = "";

    /**
     * Roll outcome for content removal.
     * Budget lawyer: 40%, mid: 65%, top: 85%.
     */
    public boolean rollContentRemoval() {
        double chance;
        switch (contentLawyerTier) {
            case 1:  chance = 0.40; break;
            case 2:  chance = 0.65; break;
            case 3:  chance = 0.85; break;
            default: chance = 0.0;  break;
        }
        return Math.random() < chance;
    }

    /**
     * Roll SA civil suit outcome.
     * sleazy=25%, budget=45%, competent=65%, top=82%.
     * High slut_rep lowers chance by up to 15%.
     */
    public boolean rollSaSuit() {
        double base;
        switch (saSuitLawyerTier) {
            case "sleazy":    base = 0.25; break;
            case "budget":    base = 0.45; break;
            case "competent": base = 0.65; break;
            case "top":       base = 0.82; break;
            default:          base = 0.45; break;
        }
        // High slut_rep can hurt in civil court (up to -0.15)
        double repPenalty = Math.min(0.15, slut_rep / 700.0);
        double finalChance = Math.max(0.10, base - repPenalty);
        return Math.random() < finalChance;
    }

        // ── PC / Gaming / Streaming System ───────────────────────────────────────
    /** 0=none, 1=basic laptop, 2=gaming PC, 3=pro streaming rig */
    public int     pcTier           = 0;
    /** Gaming chair owned — bonus happiness from gaming. */
    public boolean hasGamingChair   = false;
    /** Gaming skill (0-100). Rises from playing, peaks for tournament entry. */
    public int     gamingSkill      = 0;
    /** MC is actively streaming on a gaming platform. */
    public boolean streamingActive  = false;
    /** Streaming followers (grows with gamingSkill + consistency). */
    public int     streamingFollowers = 0;
    /** Days since last stream (followers decay after 3 days). */
    public int     streamingDaysSinceStream = 0;
    /** Weekly streaming income. */
    public int     streamingWeeklyIncome = 0;
    /** Total streaming earned lifetime. */
    public int     streamingTotalEarned  = 0;
    /** MC is a registered pro gamer (unlocks tournament scenes). */
    public boolean isProGamer        = false;

    /** Streaming income update after a stream session. */
    public int streamPost(int skillBonus) {
        streamingDaysSinceStream = 0;
        int base = Math.max(1, gamingSkill / 10) + skillBonus;
        double scale = Math.max(0.3, 1.0 - streamingFollowers / 3000.0);
        int gain = Math.max(1, (int)(base * scale));
        streamingFollowers = Math.max(0, streamingFollowers + gain);
        streamingWeeklyIncome = (int)(streamingFollowers * 0.04);
        return gain;
    }

    /** Daily tick for streaming platform. */
    public void advanceStreamingDay() {
        if (!streamingActive) return;
        streamingDaysSinceStream++;
        if (streamingDaysSinceStream >= 3) {
            int decay = (int)(streamingFollowers * 0.025);
            streamingFollowers = Math.max(0, streamingFollowers - Math.max(1, decay));
            streamingWeeklyIncome = (int)(streamingFollowers * 0.04);
        }
        // Raise gaming skill passively when active
        if (gamingSkill < 100) gamingSkill = Math.min(100, gamingSkill + 1);
    }

    /** Weekly streaming payout. */
    public int collectStreamingPay() {
        if (!streamingActive || streamingWeeklyIncome <= 0) return 0;
        int pay = streamingWeeklyIncome;
        money += pay;
        streamingTotalEarned += pay;
        return pay;
    }

    public boolean hasPc()          { return pcTier >= 1; }
    public boolean hasGamingPc()    { return pcTier >= 2; }
    public boolean hasProRig()      { return pcTier >= 3; }

        // ── Self-defence / carry system ──────────────────────────────────────────
    /** Carry permit earned (required to buy a gun). */
    public boolean hasCarryPermit    = false;
    /** MC is currently carrying a firearm on their person. */
    public boolean carryingGun       = false;
    /** Which gun model is holstered (item ID). */
    public String  equippedGunId     = "";
    /** MC owns pepper spray. */
    public boolean hasPepperSpray    = false;
    /** MC owns a taser. */
    public boolean hasTaser          = false;
    /** Permit test last score (0-10). */
    public int     permitTestScore   = 0;
    /** All guns owned (item IDs). */
    public java.util.Set<String> ownedGuns = new java.util.LinkedHashSet<>();

    /** 8/10 deploy success roll for taser/spray. Returns true if deployed successfully. */
    public boolean deployDefenseTool() {
        return Math.random() < 0.80;   // 80% success, 20% NPC resists/dodges
    }

    /** True if MC is currently working a security guard shift. */
    public boolean isSecurityGuardShift() {
        return currentJobId != null && currentJobId.contains("security");
    }

        // ── SlutFans System ───────────────────────────────────────────────────────
    /** Whether the player has an active SlutFans account. */
    public boolean slutFansActive       = false;
    /** Cumulative follower count. */
    public int     slutFansFollowers    = 0;
    /** Total posts made ever. */
    public int     slutFansTotalPosts   = 0;
    /** Days since last post — followers start leaving after 3. */
    public int     slutFansDaysSincePost= 0;
    /** Weekly income from subscriptions (rebuilt each post). */
    public int     slutFansWeeklyIncome = 0;
    /** Post content tier unlocked (1-5, scales with slut_rep + post count). */
    public int     slutFansContentTier  = 1;
    /** Total lifetime earnings from SlutFans. */
    public int     slutFansTotalEarned  = 0;
    /** Whether MC is currently doing a live stream. */
    public boolean slutFansLiveActive   = false;
    /** Sex toys owned (item IDs). */
    public java.util.Set<String> ownedToys =
        new java.util.LinkedHashSet<>();

    /** Compute current content tier from slut_rep + total posts. */
    public int computeSlutFansTier() {
        int rep = slut_rep;
        int posts = slutFansTotalPosts;
        if (rep >= 60 && posts >= 30) return 5;
        if (rep >= 45 && posts >= 20) return 4;
        if (rep >= 30 && posts >= 10) return 3;
        if (rep >= 15 && posts >= 3)  return 2;
        return 1;
    }

    /** Beauty modifier for follower growth (1.0 base, up to 2.0). */
    public double beautyFollowerMod() {
        double mod = 1.0;
        if (hasTrait("Pretty"))               mod += 0.2;
        if (hasTrait("Beautiful"))            mod += 0.4;
        if (hasTrait("Sexy"))                 mod += 0.35;
        if (hasTrait("Elegant"))              mod += 0.25;
        if (hasTrait("Otherworldly_Beauty"))  mod += 0.6;
        if (hasTrait("Body_Athletic"))        mod += 0.15;
        if (hasTrait("Breasts_D") || hasTrait("Breasts_DD") ||
            hasTrait("Breasts_E") || hasTrait("Breasts_F")) mod += 0.15;
        return Math.min(mod, 2.2);
    }

    /** Called when MC makes a post. Returns followers gained. */
    public int slutFansPost(int tier) {
        slutFansTotalPosts++;
        slutFansDaysSincePost = 0;
        slutFansContentTier   = computeSlutFansTier();
        // Base gains: tier 1 = trickle, tier 5 = fast growth
        int[] baseGain = {0, 3, 8, 18, 35, 65};
        int gain = (int)(baseGain[Math.min(tier,5)] * beautyFollowerMod());
        // Diminishing returns at high follower counts
        double scale = Math.max(0.3, 1.0 - (slutFansFollowers / 5000.0));
        gain = Math.max(1, (int)(gain * scale));
        slutFansFollowers = Math.max(0, slutFansFollowers + gain);
        // Weekly income: ~$0.05 per follower per week (mid-tier sub)
        slutFansWeeklyIncome = (int)(slutFansFollowers * 0.05
                                      * (0.8 + tier * 0.1));
        return gain;
    }

    /** Called each new day to tick SlutFans state. */
    public void advanceSlutFansDay() {
        if (!slutFansActive) return;
        slutFansDaysSincePost++;
        // Follower decay after 3 days without posting
        if (slutFansDaysSincePost >= 3) {
            int decay = (int)(slutFansFollowers * 0.03); // 3% per day
            slutFansFollowers = Math.max(0, slutFansFollowers - Math.max(1, decay));
            slutFansWeeklyIncome = (int)(slutFansFollowers * 0.05);
        }
    }

    /** Weekly SlutFans payout. Call on payday. */
    public int collectSlutFansPay() {
        if (!slutFansActive || slutFansWeeklyIncome <= 0) return 0;
        int pay = slutFansWeeklyIncome;
        money += pay;
        slutFansTotalEarned += pay;
        return pay;
    }

        /** Bar staff shift: "day" | "night". Night pays 30% more, drunker patrons. */
    public String barStaffShift     = "day";

    // ── NPC source tracking ──────────────────────────────────────────────────────
    /** NPC ID who left the neck hickey (empty if no active hickey). */
    public String neckHickeyFromNpcId   = "";
    /** NPC ID who left the breast hickey. */
    public String breastHickeyFromNpcId = "";
    /** NPC ID who got MC pregnant (empty if not pregnant). */
    public String pregnantByNpcId       = "";

    /** Standing with coworkers/management. Stay above 20 or face firing. */
    public int    officeRep         = 60;       // starts at 60 (decent standing)

    /** Progress toward next promotion. 0-100; resets to 0 when promotion offered. */
    public int    promotionProgress = 0;

    /** Net office rep change since month started — negative trend risks HR meeting. */
    public int    monthlyRepGain    = 0;

    /** Game day when current month tracking started. */
    public int    repMonthStart     = 1;

    // ── Work mode helpers ────────────────────────────────────────────────────

    /** Apply diminishing returns: full gain below threshold, scaled above. */
    public int workDiminishing(int current, int raw, int threshold) {
        if (raw < 0) return raw; // losses don't diminish
        if (current >= threshold + 15) return Math.max(0, (int)(raw * 0.25));
        if (current >= threshold)      return Math.max(0, (int)(raw * 0.55));
        return raw;
    }

    /** Office rep daily gain for current work mode (with diminishing returns). */
    public int officeRepGainForMode() {
        int raw;
        switch (workMode) {
            case "harder":   raw =  3; break;
            case "politics": raw =  1; break;
            case "slack":    raw = -5; break;
            case "pranks":   raw = -8; break;
            default:         raw =  2; break;
        }
        if (raw > 0) return workDiminishing(officeRep, raw, 70);
        return raw;
    }

    /** Promotion progress daily gain for current work mode. */
    public int promotionGainForMode() {
        int raw;
        switch (workMode) {
            case "harder":   raw =  8; break;
            case "politics": raw =  6; break;
            case "pranks":   raw = -3; break;
            case "slack":    raw =  0; break;
            default:         raw =  1; break;
        }
        if (raw > 0 && "harder".equals(workMode))
            return workDiminishing(promotionProgress, raw, 60);
        if (raw > 0 && "politics".equals(workMode))
            return workDiminishing(promotionProgress, raw, 70);
        return raw;
    }

    /** Clamp office rep 0-100. */
    public void applyOfficeRepGain(int delta) {
        officeRep      = clamp(officeRep + delta, 0, 100);
        monthlyRepGain += delta;
    }

    /** Clamp promotion progress 0-100. Returns true if hit 100 (promotion ready). */
    public boolean applyPromotionGain(int delta) {
        promotionProgress = clamp(promotionProgress + delta, 0, 100);
        return promotionProgress >= 100;
    }

    /** Reset monthly rep tracking for a new month. */
    public void resetMonthlyRep() {
        monthlyRepGain = 0;
        repMonthStart  = dayCount;
    }

    /** True if the monthly period (30 days) has elapsed. */
    public boolean isMonthlyRepCheckDue() {
        return (dayCount - repMonthStart) >= 30;
    }

    /** Apply a pay raise. Returns new effective pay per day. */
    public int applyRaise(int amountPerDay) {
        payPerDayBonus += amountPerDay;
        return payPerDayBonus;
    }

    /** Quit current job — clears ID, pay tracker. Stress bump from the decision. */
    public void quitJob() {
        currentJobId      = null;
        daysWorkedThisPay = 0;
        workMode          = "normal";      // reset for next job
        officeRep         = 60;            // fresh start
        promotionProgress = 0;
        payPerDayBonus   = 0;  // raises are per-job
        monthlyRepGain    = 0;
        repMonthStart     = dayCount;
        stress = clamp(stress + 10, 0, 100);
    }

    /** Fired from job — same as quit but larger stress hit and confidence loss. */
    public void fireFromJob() {
        currentJobId      = null;
        daysWorkedThisPay = 0;
        workMode          = "normal";
        officeRep         = 60;
        promotionProgress = 0;
        monthlyRepGain    = 0;
        repMonthStart     = dayCount;
        stress      = clamp(stress + 25, 0, 100);
        confidence  = clamp(confidence - 8, 0, 100);
        happiness   = clamp(happiness - 10, 0, 100);
    }

    /** NPC ID of current landlord — set when player selects housing. */
    public String currentLandlordNpc = null;

    // ── Housing modifiers — set on housing selection, persist for run ─────────
    /** Max willpower allowed. Starts at 70 (floor mattress, no housing chosen). */
    public int housingWillpowerCap      = 70;
    /** Willpower recovered each sleep. Starts at +8 (floor mattress). */
    public int housingWillpowerRecovery = 8;
    /** Stress points reduced each new day. Starts at 3 (floor mattress). */
    public int housingStressReduction   = 3;
    /** Minimum stress floor. Starts at 45 (floor mattress — hard to rest). */
    public int housingStressMin         = 45;

    public Set<String>         traits        = new LinkedHashSet<>();
    /**
     * Timed traits expire after a set number of days.
     * Key = trait name (lowercase), Value = day number when it expires.
     * Example: Neck_Hickey added on day 3 with duration 4 → expires after day 6.
     */
    public java.util.Map<String,Integer> timedTraits = new java.util.LinkedHashMap<>();
    public String              currentScene  = "housing";
    /** Last hub scene — used by bar_serious_talk and other submenu scenes to know where to return. */
    public String              hubScene      = "bar_with_npc";
    public Set<String>         visitedScenes = new HashSet<>();
    /** scene_id → in-game day last fired. Cooldown enforcement. */
    public java.util.Map<String,Integer> sceneLastPlayedDay = new java.util.HashMap<>();
    public Map<String,Integer> variables     = new HashMap<>();

    // ── Outfit slots ─────────────────────────────────────────────
    public String outfitBra        = "basic_bra";
    public String outfitUpper      = "white_tshirt";
    public String outfitLower      = "blue_jeans";
    public String outfitOvercoat   = null;            // trenchcoat etc — covers upper AND lower
    public String outfitUnderwear  = "basic_underwear";
    public String outfitSocks      = "ankle_socks";
    public String outfitShoes      = "sneakers";
    public boolean isWet           = false;

    /** True until player buys new clothes — limits outfit panel to starting items. */
    public boolean startingOutfitsOnly = true;

    /**
     * Owned clothing item IDs.
     * Starts with 2 outfits worth: everyday jeans+tshirt and a casual dress.
     * Undergarments and shoes included as minimums (can't go out without them).
     * Shopping unlocks additional items and clears startingOutfitsOnly.
     */
    public java.util.Set<String> ownedClothing = new java.util.LinkedHashSet<>(java.util.Arrays.asList(
        // Starting bra (one only)
        "basic_bra",
        // Starting underwear (one only)
        "basic_underwear",
        // Outfit 1: jeans + t-shirt
        "white_tshirt",
        "blue_jeans",
        // Outfit 2: casual dress
        "casual_dress",
        // Minimum footwear
        "sneakers",
        // Minimum socks
        "ankle_socks"
    ));

    /** Returns primary visible upper item ID for compat */
    public String currentOutfitId() {
        if (outfitOvercoat != null) return outfitOvercoat;
        return outfitUpper != null ? outfitUpper : "white_tshirt";
    }

    public boolean isBraless() { return outfitBra == null; }

    public boolean isTopless()  { return outfitUpper == null && outfitOvercoat == null; }
    public boolean isWearingThinTop() {
        if (outfitUpper == null) return false;
        String u = outfitUpper.toLowerCase();
        return u.contains("thin") || u.contains("sheer") || u.contains("mesh")
            || u.contains("sundress") || u.contains("crop") || u.contains("tank");
    }
    public int getCurrentLewdnessRating() {
        // Rough lewdness from clothing state
        int lwd = 0;
        if (isBraless())  lwd += 20;
        if (isTopless())  lwd += 50;
        if (outfitBra == null && outfitUnderwear == null) lwd += 15;
        if (outfitLower == null) lwd += 40;
        if (getBodyFlag("flag_wearing_skirt")) lwd += 10;
        if (getBodyFlag("flag_underdressed_for_winter")) lwd += 10;
        return Math.min(100, lwd);
    }

    /** True if lower body is covered — by lower slot, a fills_lower upper, or an overcoat */
    public boolean lowerCovered(game.ClothingLoader clothes) {
        if (outfitOvercoat != null) return true;
        if (outfitLower != null)    return true;
        if (outfitUpper != null) {
            game.data.ClothingData upper = clothes.get(outfitUpper);
            return upper != null && upper.fills_lower;
        }
        return false;
    }

    /** Can the player leave home in current outfit? */
    public boolean canGoOut(game.ClothingLoader clothes) {
        // Cannot go out commando while on period
        if (isOnPeriod() && outfitUnderwear == null) return false;
        // Overcoat alone is enough to go out
        if (outfitOvercoat != null) return true;
        // Otherwise need something on top AND something on bottom
        boolean hasTop    = outfitUpper != null || outfitBra != null;
        boolean hasBottom = lowerCovered(clothes);
        return hasTop && hasBottom;
    }

    // ── Dynamic trait cache ───────────────────────────────────────
    // Invalidated whenever outfit, arousal, or wet state changes
    private transient java.util.Set<String> _dynamicCache = null;
    private transient String _cacheKey = "";

    private String dynCacheKey() {
        return outfitBra + "|" + outfitUpper + "|" + outfitLower + "|" + outfitOvercoat
             + "|" + outfitUnderwear + "|" + outfitShoes + "|" + isWet + "|" + arousal;
    }

    public void invalidateDynamicCache() { _dynamicCache = null; }

    /** Compute dynamic temporary traits — cached per outfit/arousal state */
    public java.util.Set<String> computeDynamicTraits(game.ClothingLoader clothes) {
        String key = dynCacheKey();
        if (_dynamicCache != null && key.equals(_cacheKey)) return _dynamicCache;
        java.util.Set<String> dynamic = new java.util.LinkedHashSet<>();

        // Effective upper layer — overcoat beats upper
        game.data.ClothingData upper = outfitOvercoat != null
            ? clothes.get(outfitOvercoat) : clothes.get(outfitUpper);
        game.data.ClothingData bra = clothes.get(outfitBra);

        if (upper != null) {
            upper.is_wet = isWet;
            // braless=true means the item has built-in support — acts like a bra for nipping/exposure
            boolean itemHasBuiltInSupport = upper.braless;
            boolean braProtects  = itemHasBuiltInSupport || (bra != null && !bra.isNipRisk());
            boolean topIsThick   = "thick".equals(upper.thickness);
            boolean topIsThin    = "thin".equals(upper.thickness) || "diaphanous".equals(upper.thickness)
                                   || upper.seethrough;

            // ── Pierced nipples ────────────────────────────────────────
            // Jewelry shows through any non-thick top when unprotected by a real bra.
            // Thin fabric = prominent (hardware clearly visible).
            // Medium fabric = subtle (outline/bump detectable).
            if (hasTrait("Pierced_Nipples") && !braProtects && !topIsThick) {
                dynamic.add(topIsThin ? "pierced_nipping_prominent" : "pierced_nipping");
                dynamic.add("nipping"); // generic nipping always set alongside
            }

            // ── Standard fabric nipping ────────────────────────────────
            // Thin/diaphanous/seethrough tops nip when unprotected.
            if (upper.isNipRisk() && !braProtects && !dynamic.contains("nipping")) {
                dynamic.add("nipping");
            }

            // ── Exposure — sheer/diaphanous top with no bra at all ────
            if (upper.isExposureRisk() && outfitBra == null && !itemHasBuiltInSupport) {
                dynamic.add("exposed_breasts");
            }

            // ── Arousal-based nipping ──────────────────────────────────
            // Fires independently of piercing — arousal affects any unprotected top.
            if (!braProtects) {
                boolean mediumTight = "medium".equals(upper.thickness) && upper.tight;
                if (arousal >= 75) {
                    // Very aroused — shows through any top
                    if (!dynamic.contains("nipping")) dynamic.add("nipping");
                    dynamic.add("arousal_nipping");
                } else if (arousal >= 50 && mediumTight) {
                    // Moderately aroused + tight medium top
                    if (!dynamic.contains("nipping")) dynamic.add("nipping");
                    dynamic.add("arousal_nipping");
                }
            }
        }

        // Camel toe — thin + tight lower body + no underwear
        game.data.ClothingData lower = clothes.get(outfitLower);
        if (lower == null && outfitUpper != null) {
            game.data.ClothingData up = clothes.get(outfitUpper);
            if (up != null && up.fills_lower) lower = up;
        }
        if (lower != null && lower.tight && outfitUnderwear == null
                && ("thin".equals(lower.thickness) || "diaphanous".equals(lower.thickness))) {
            dynamic.add("camel_toe");
        }

        // Commando in skirt/dress — different from camel toe (no underwear + skirt)
        boolean wearingSkirt = false;
        if (lower != null && lower.is_skirt) wearingSkirt = true;
        if (outfitOvercoat == null && outfitUpper != null) {
            game.data.ClothingData up = clothes.get(outfitUpper);
            if (up != null && up.fills_lower && up.is_skirt) wearingSkirt = true;
        }
        if (wearingSkirt) {
            dynamic.add("wearing_skirt");
            if (outfitUnderwear == null && !isOnPeriod()) {
                dynamic.add("commando");
                dynamic.add("commando_in_skirt"); // composite — used by explore/go_out triggers
            }


        // Oversized shirt worn without lower garment
        if (outfitLower == null && outfitUpper != null && outfitOvercoat == null) {
            game.data.ClothingData _up = clothes.get(outfitUpper);
            if (_up != null && _up.oversized) {
                dynamic.add("wearing_oversized_as_dress");
                dynamic.add("wearing_skirt"); // oversized shirts trigger skirt-flip scenes
            }
        }
        }

        // ── Clothing property flags ────────────────────────────────────────
        // These let scenes gate on what the MC is wearing without hardcoding item IDs.

        // Crop top — can ride up during stretching/exercise
        if (upper != null && upper.crop_top) {
            dynamic.add("wearing_crop_top");
        }

        // Off-shoulder — flash risk when combined with braless or loose fit
        if (upper != null && upper.off_shoulder) {
            dynamic.add("wearing_off_shoulder");
            boolean noBraProtection = outfitBra == null && !upper.braless;
            boolean loosFit = upper.loose;
            if (noBraProtection || loosFit) {
                dynamic.add("off_shoulder_flash_risk");
            }
        }

        // Buttons — pop risk with large chest + tight garment + no good bra
        if (upper != null && upper.has_buttons && upper.tight) {
            boolean largeChest = hasTrait("Breasts_D") || hasTrait("Breasts_DD") ||
                                 hasTrait("Breasts_E") || hasTrait("Breasts_F");
            boolean braProtects = outfitBra != null &&
                                  clothes.get(outfitBra) != null &&
                                  !"thin".equals(clothes.get(outfitBra).thickness) &&
                                  !"diaphanous".equals(clothes.get(outfitBra).thickness);
            if (largeChest && !braProtects) {
                dynamic.add("button_pop_risk");
            }
        }

        // Loose garment — can shift more dramatically during movement
        if (upper != null && upper.loose) {
            dynamic.add("wearing_loose_top");
        }

        // bounce_prone_N — directly maps to cup size when braless (1=A, 2=B, 3=C, 4=D, 5=DD, 6=E, 7=F)
        // Each level also sets all lower levels so scenes can gate on minimums.
        // Generic bounce_prone only set for B cup and above — A cup has no actual movement.
        // All require bra to be absent (or thin enough to not suppress).
        int cupLevel = 0;
        if (outfitBra == null) {
            if      (hasTrait("Breasts_F"))  cupLevel = 7;
            else if (hasTrait("Breasts_E"))  cupLevel = 6;
            else if (hasTrait("Breasts_DD")) cupLevel = 5;
            else if (hasTrait("Breasts_D"))  cupLevel = 4;
            else if (hasTrait("Breasts_C"))  cupLevel = 3;
            else if (hasTrait("Breasts_B"))  cupLevel = 2;
            else if (hasTrait("Breasts_A"))  cupLevel = 1;
        }
        if (cupLevel > 0) {
            for (int lvl = 1; lvl <= cupLevel; lvl++) {
                dynamic.add("bounce_prone_" + lvl);
            }
            if (cupLevel >= 2) dynamic.add("bounce_prone"); // actual movement — B cup and above
        }

        // Heels worn
        if (outfitShoes != null) {
            game.data.ClothingData shoes = clothes.get(outfitShoes);
            if (shoes != null) {
                if ("high".equals(shoes.heel_type))   dynamic.add("wearing_high_heels");
                else if ("low".equals(shoes.heel_type)) dynamic.add("wearing_low_heels");
            }
        }

        // Sock discomfort
        if (outfitSocks == null && outfitShoes != null) {
            game.data.ClothingData shoes = clothes.get(outfitShoes);
            if (shoes == null || !shoes.sandals) dynamic.add("uncomfortable_feet");
        }

        // ── Trauma tier: forces shy paths, suppresses assertive ones ─────────────
        // Broken > Shaken > Hurt: all three collapse the MC into withdrawn/shy behaviour.
        // Broken is total — no confident paths at all.
        // Shaken and Hurt force shy paths but with differing suppression depth.
        if (hasTrait("Broken") || hasTrait("Shaken") || hasTrait("Hurt") || hasTrait("Rattled")) {
            dynamic.add("shy");
            dynamic.add("conflict_avoidant");
            dynamic.add("shaken_suppresses_assertive"); // used by Engine.visible()
            if (hasTrait("Broken")) {
                dynamic.add("broken_suppresses_all");   // Engine can use for extra suppression
            }
        }

        _dynamicCache = dynamic;
        _cacheKey = key;
        return dynamic;
    }

    // ── Bar state ────────────────────────────────────────────────
    /** NPCs currently present in the bar. Populated by BarSystem on bar entry. */
    public List<String> currentBarNpcs        = new ArrayList<>();
    /** The NPC currently approaching the MC in the bar. Set by BarSystem, cleared after scene. */
    public String       currentApproachingNpc = "";
    /** True when the NPC chose the current activity via dice roll (not MC-initiated). */
    public boolean      npcInitiatedActivity  = false;

    // ── NPC session stats (current bar encounter only) ────────────
    // All clear at bar exit unless walk-home happens (not yet implemented).
    // Routed via changeStat("npc_frustration", n) etc. in YAML stat_changes.
    /** NPC frustration — +5 per turn in bar_with_npc, -1 on let-them-decide. High = more pushy. */
    public int currentNpcFrustration = 0;
    /** NPC arousal — modified by dialogue choices. Affects walk-home roll weighting. */
    public int currentNpcArousal     = 0;
    /** NPC liking gain this session — adds to npc_rep at bar exit (small, mostly flavor). */
    public int currentNpcLiking      = 0;
    // ── Drunk tracking for Alcoholic trait acquisition ──────────────────────
    /** Set true on any game day where drunk reaches 13+. Cleared on advanceDay(). */
    public boolean wasDrunk13Today     = false;
    /** How many days this week drunk hit 13+. Resets each 7-day week. */
    public int     drunk13DaysThisWeek = 0;
    /** How many consecutive weeks had 3+ drunk-13 days. */
    public int     heavyWeeksInARow    = 0;
    /** Day counter for week boundary tracking. */
    public int     dayOfWeek           = 0; // 0-6

    /** Increments each time bar_slow_dance loads this session. Continuation text fires at 2+. */
    public int slowDanceCount        = 0;
    /** Tracks which DanceMoment ids have already fired this session — prevents repeats. */
    public Set<String> usedDanceMoments = new java.util.LinkedHashSet<>();

    // ── Body state flags (scene cross-referencing) ────────────────
    // Set via stat_changes: "flag_breast_groped: 1" etc.
    // Cleared on bar exit or dance end.
    // Lets scenes reference what has already happened this encounter.
    public boolean flagBreastGroped  = false;
    public boolean flagAssGroped     = false;
    public boolean flagPussyGroped   = false;
    public boolean flagFingered      = false;
    public boolean flagKissed        = false;
    public boolean flagNeckKissed    = false;
    public boolean flagDeepKissed    = false;
    public boolean flagCornered      = false;
    public boolean flagCookedTonight = false;  // cooked food for NPC this session — 1x gate
    public boolean flagNpcCame         = false;  // NPC orgasmed
    public boolean flagGloryHoleUsed     = false;  // visited gloryhole in bathroom
    public boolean flagCafeJumpFlashed    = false;  // jump dice rolled a flash this session
    public boolean flagCafeSleazyVisited  = false;  // sleazy guy has helped before — routes to Branch 7
    public SexState sexState = new SexState();

    // ── Cycle ────────────────────────────────────────────────────
    public int cycleDay    = 14;
    public int cycleLength = 28;

    public void advanceCycle(int days) { cycleDay = ((cycleDay - 1 + days) % cycleLength) + 1; }
    public boolean isOnPeriod()        { return cycleDay >= 1  && cycleDay <= 5;  }
    public boolean isFertileWindow()   { return cycleDay >= 11 && cycleDay <= 17; }
    public boolean isOvulating()       { return cycleDay == 14; }

    /**
     * Per-act conception probability for a single unprotected insemination event.
     * Based on Wilcox et al. (1995) and Dunson et al. (2001) per-act fecundability data.
     *
     * Base rates reflect a normally fertile woman. Call after confirming:
     * - penetration occurred
     * - no condom
     * - NPC climaxed inside (npcClimaxed && !pullOutAgreed || npcIgnoredPullOut)
     *
     * Pull-out reduces to pre-ejaculate risk (~5% of full rate).
     * On the pill overrides all day-specific rates (~0.1% typical use modeled as 0.001).
     */

    // ── Size/tightness system ─────────────────────────────────────────────────────

    /** Numeric size level of the current approaching NPC. Returns 1 (average) if no size trait. */
    public int currentNpcSizeLevel() {
        if (currentApproachingNpc.isEmpty()) return 1;
        if (currentNpcHasTrait("Painfully_Massive_Cock")) return 6;
        if (currentNpcHasTrait("Massive_Cock"))           return 5;
        if (currentNpcHasTrait("Huge_Cock"))              return 4;
        if (currentNpcHasTrait("Large_Cock"))             return 3;
        if (currentNpcHasTrait("Medium_Large_Cock"))      return 2;
        if (currentNpcHasTrait("Small_Cock"))             return 0;
        return 1; // Medium_Cock / default
    }

    /** Size tier key for adaptation maps. */
    public String currentNpcSizeTier() {
        int lv = currentNpcSizeLevel();
        switch (lv) {
            case 0: return "small";
            case 1: return "medium";
            case 2: return "medium_large";
            case 3: return "large";
            case 4: return "huge";
            case 5: return "massive";
            case 6: return "painful";
            default: return "medium";
        }
    }

    /** MC tightness level: extremely_tight=0, tight=1, no_trait=2, loose=3. */
    public int mcTightnessLevel() {
        if (hasTrait("Extremely_Tight")) return 0;
        if (hasTrait("Tight"))           return 1;
        if (hasTrait("Loose"))           return 3;
        return 2; // no trait = average
    }

    /** Current adaptation level for a size tier (0-max). */
    public int sizeAdaptLevel(String tier) {
        return sizeAdaptation.getOrDefault(tier, 0);
    }

    /** Max adaptation level for a given size tier. */
    public int maxAdaptation(String tier) {
        switch (tier) {
            case "small": case "medium": case "medium_large": return 3; // easily adapted
            case "large":  return 3; // fully comfortable achievable
            case "huge":   return 3; // achievable with time
            case "massive":return 2; // always slightly intense at baseline
            case "painful":return 1; // always significant even adapted
            default: return 3;
        }
    }

    /**
     * Pain delta for current NPC vs MC.
     * delta = sizeLevel - (tightnessLevel + adaptationLevel)
     * ≤0 = comfortable, 1 = mild stretch, 2 = significant pain, ≥3 = serious pain
     */
    public int penetrationPainDelta() {
        int size   = currentNpcSizeLevel();
        int tight  = mcTightnessLevel();
        int adapt  = sizeAdaptLevel(currentNpcSizeTier());
        return size - (tight + adapt);
    }

    /**
     * Called after a penetration session. Advances adaptation toward max for this size tier.
     * Records the day for decay tracking.
     */
    public void recordPenetrationSession() {
        String tier = currentNpcSizeTier();
        int cur = sizeAdaptLevel(tier);
        int max = maxAdaptation(tier);
        if (cur < max) sizeAdaptation.put(tier, cur + 1);
        lastSexWithSize.put(tier, dayCount);
    }

    /**
     * Called in advanceDay(). Decays adaptation for any size tier not used in 3+ days.
     * Full regression to 0 after 14 days without sex at that size.
     */
    public void decaySizeAdaptation() {
        for (String tier : new java.util.ArrayList<>(sizeAdaptation.keySet())) {
            int lastDay = lastSexWithSize.getOrDefault(tier, 0);
            int gap = dayCount - lastDay;
            if (gap >= 14) {
                sizeAdaptation.put(tier, 0); // full regression
            } else if (gap >= 3) {
                int cur = sizeAdaptation.getOrDefault(tier, 0);
                if (cur > 0) sizeAdaptation.put(tier, cur - 1);
            }
        }
    }



    // ── Gag Reflex / Throat System ─────────────────────────────────────────────────
    /**
     * MC gag reflex level: 0 = virtually none, 10 = very strong.
     * Starts at 6 (moderate). Practice with NPC sizes reduces it; long gaps restore it.
     * Mirrors the vaginal tightness/adaptation system.
     */
    public int gagReflex = 6;

    /** Throat adaptation per size tier — how accustomed MC is to deep-throating that size. */
    public java.util.Map<String,Integer> throatAdaptation = new java.util.HashMap<>();
    /** Last day deep-throated at each size tier. */
    public java.util.Map<String,Integer> lastThroatWithSize = new java.util.HashMap<>();

    /**
     * Gag discomfort delta for current NPC vs MC throat.
     * Positive = gagging, 0 = manageable, negative = no issue.
     */
    public int throatGagDelta() {
        int sizeLevel = currentNpcSizeLevel();
        int adapt     = throatAdaptation.getOrDefault(currentNpcSizeTier(), 0);
        // gagReflex 0-10: higher = more likely to gag
        // sizeLevel 0-6: 0=small, 6=painful
        // Comfortable if: sizeLevel <= (10 - gagReflex) + adapt*2
        int threshold = (10 - gagReflex) + adapt * 2;
        return sizeLevel - threshold;
    }

    /** True if current NPC would trigger a gag reflex. */
    public boolean wouldGag() { return throatGagDelta() > 0; }

    /** True if current NPC is manageable but still intense. */
    public boolean throatIntense() {
        int d = throatGagDelta();
        return d == 0;
    }

    /**
     * Called after a deep-throat/throat-fuck session.
     * Reduces gag reflex by 1 (min 0) and increases throat adaptation for this size tier.
     */
    public void recordThroatSession() {
        if (gagReflex > 0) gagReflex--;
        String tier = currentNpcSizeTier();
        int cur = throatAdaptation.getOrDefault(tier, 0);
        int max = maxAdaptation(tier); // reuse same max as vaginal
        if (cur < max) throatAdaptation.put(tier, cur + 1);
        lastThroatWithSize.put(tier, dayCount);
    }

    /** Called in advanceDay(). Gag reflex recovers slowly if not exercised. */
    public void decayThroatAdaptation() {
        for (String tier : new java.util.ArrayList<>(throatAdaptation.keySet())) {
            int lastDay = lastThroatWithSize.getOrDefault(tier, 0);
            int gap = dayCount - lastDay;
            if (gap >= 14) {
                throatAdaptation.put(tier, 0);
                if (gagReflex < 10) gagReflex = Math.min(10, gagReflex + 1);
            } else if (gap >= 5) {
                int cur = throatAdaptation.getOrDefault(tier, 0);
                if (cur > 0) throatAdaptation.put(tier, cur - 1);
            }
        }
    }

        // ── Vehicle ownership system ──────────────────────────────────────────────────
    /** "none" | "owned" | "rented" | "financed" */
    public String carOwnershipType      = "none";
    /** Tier: 0=none, 1=cheap, 2=mid, 3=nice, 4=luxury */
    public int    carTier               = 0;
    /** Display name of the car, e.g. "Old Hatchback", "Saloon", "SUV" */
    public String carModel              = "";
    /** Days of rental remaining (rental only) */
    public int    carRentalDaysLeft     = 0;
    /** Day ban on rental company expires (0=no ban) */
    public int    carRentalBanExpiry    = 0;
    /** Monthly finance payment amount */
    public int    carFinancePayment     = 0;
    /** dayCount when next finance payment is due */
    public int    carFinanceNextDue     = 0;
    /** Months remaining to pay off financed car */
    public int    carFinanceMonthsLeft  = 0;

    // ── Car helpers ────────────────────────────────────────────────────────────────
    public boolean hasCar()       { return !"none".equals(carOwnershipType); }
    public boolean carIsNice()    { return carTier >= 3; }
    public boolean carIsLuxury()  { return carTier >= 4; }

    /**
     * Daily car system check — called from advanceDay().
     * Decrements rental, checks finance payments.
     * Returns an event key if something noteworthy happened ("rental_expired", "finance_due", "").
     */
    public String advanceCarDay() {
        if ("rented".equals(carOwnershipType)) {
            carRentalDaysLeft--;
            if (carRentalDaysLeft <= 0) {
                // Rental expired — car gone, 30-day ban
                carOwnershipType   = "none";
                carModel           = "";
                carTier            = 0;
                carRentalBanExpiry = dayCount + 30;
                return "rental_expired";
            }
        }
        if ("financed".equals(carOwnershipType) && dayCount >= carFinanceNextDue) {
            return "finance_due"; // signal to show payment scene
        }
        return "";
    }

    /** Make a finance payment. Advances due date and decrements months left. */
    public void makeFinancePayment() {
        money -= carFinancePayment;
        carFinanceNextDue += 30;
        carFinanceMonthsLeft--;
        if (carFinanceMonthsLeft <= 0) {
            // Paid off — becomes owned
            carOwnershipType = "owned";
            carFinancePayment   = 0;
            carFinanceMonthsLeft = 0;
        }
    }

    /** Buy a car outright. */
    public void buyCar(String model, int tier, int cost) {
        money -= cost;
        carOwnershipType = "owned";
        carModel = model;
        carTier  = tier;
    }

    /** Start a rental. */
    public void rentCar(String model, int tier, int days, int cost) {
        money -= cost;
        carOwnershipType    = "rented";
        carModel            = model;
        carTier             = tier;
        carRentalDaysLeft   = days;
    }

    /** Start a finance agreement. */
    public void financeCar(String model, int tier, int monthlyPayment, int months) {
        carOwnershipType        = "financed";
        carModel                = model;
        carTier                 = tier;
        carFinancePayment       = monthlyPayment;
        carFinanceMonthsLeft    = months;
        carFinanceNextDue       = dayCount + 30;
    }

    /** Return/lose the car. */
    public void loseCar() {
        carOwnershipType = "none";
        carModel = "";
        carTier  = 0;
        carRentalDaysLeft = 0;
        carFinancePayment = 0;
        carFinanceMonthsLeft = 0;
    }


    // ── Inventory ─────────────────────────────────────────────────────────────────
    public int condomCount           = 0;  // number of condoms in inventory
    public int soapCount             = 0;
    public int sunscreenCount        = 0;

    // ── Pregnancy timeline ────────────────────────────────────────────────────────
    /** dayCount when conception occurred (for Plan B timing and abortion eligibility). */
    public int pregnancyStartDay     = 0;
    /** dayCount of last unprotected sex (for Plan B window). */
    public int lastUnprotectedSexDay = 0;
    /** True once morning sickness scene has been shown. */
    public boolean morningSicknessShown = false;

    // ── Hair ──────────────────────────────────────────────────────────────────────
    // Managed via traits (Hair_Short/Medium/Long/Very_Long + Hair_Black/Brown/etc.)
    // No extra fields needed — traits cover it.

    // ── Breast surgery ────────────────────────────────────────────────────────────
    /** dayCount when breast surgery was performed (recovery tracking). */
    public int breastSurgeryDay      = 0;

    // Inventory helpers
    public boolean hasCondoms()    { return condomCount > 0; }
    public void useCondom()        { if (condomCount > 0) condomCount--; }

    // Pregnancy timeline helpers
    public int daysPregnant()      { return hasTrait("Pregnant") && pregnancyStartDay > 0 ? dayCount - pregnancyStartDay : 0; }
    public boolean canTakePlanB()  { return lastUnprotectedSexDay > 0 && (dayCount - lastUnprotectedSexDay) <= 3 && !hasTrait("Pregnant") || hasTrait("Pregnant_Unconfirmed"); }
    public boolean canTakeAbortionPill() { return hasTrait("Pregnant") && daysPregnant() <= 30; }

    /** Take Plan B. Returns true if it prevented pregnancy. Efficacy declines over time. */
    public boolean takePlanB() {
        int daysAfter = lastUnprotectedSexDay > 0 ? dayCount - lastUnprotectedSexDay : 0;
        double efficacy;
        if      (daysAfter <= 1) efficacy = 0.95;
        else if (daysAfter <= 2) efficacy = 0.85;
        else if (daysAfter <= 3) efficacy = 0.58;
        else                     efficacy = 0.15;
        boolean success = Math.random() < efficacy;
        if (success) {
            removeTrait("Pregnant");
            removeTrait("Pregnant_Unconfirmed");
            pregnantByNpcId  = "";
            pregnancyStartDay = 0;
        }
        return success;
    }

    /** Take abortion pill. ~98% effective within 30 days. */
    public boolean takeAbortionPill() {
        if (!canTakeAbortionPill()) return false;
        boolean success = Math.random() < 0.98;
        if (success) {
            removeTrait("Pregnant");
            removeTrait("Pregnant_Unconfirmed");
            pregnantByNpcId   = "";
            pregnancyStartDay = 0;
        }
        return success;
    }

    /** Hair helpers */
    public String currentHairLength() {
        if (hasTrait("Hair_Very_Long")) return "very_long";
        if (hasTrait("Hair_Long"))      return "long";
        if (hasTrait("Hair_Short"))     return "short";
        return "medium";
    }

    public void setHairLength(String length) {
        removeTrait("Hair_Short"); removeTrait("Hair_Medium");
        removeTrait("Hair_Long");  removeTrait("Hair_Very_Long");
        switch (length) {
            case "short":     addTrait("Hair_Short");    break;
            case "long":      addTrait("Hair_Long");     break;
            case "very_long": addTrait("Hair_Very_Long");break;
            default:          addTrait("Hair_Medium");   break;
        }
    }

    public void setHairColor(String color) {
        for (String c : java.util.Arrays.asList("Hair_Black","Hair_Brown","Hair_Blonde",
                "Hair_Red","Hair_Auburn","Hair_Silver","Hair_Dyed")) removeTrait(c);
        addTrait(color);
    }

    /** Breast surgery: change cup size by delta (+1=up, -1=down). */
    public void changeBreastSize(int delta) {
        String[] cups = {"Breasts_A","Breasts_B","Breasts_C","Breasts_D","Breasts_DD","Breasts_E","Breasts_F"};
        int cur = 2; // default B
        for (int i=0; i<cups.length; i++) if (hasTrait(cups[i])) { cur=i; break; }
        int next = Math.max(0, Math.min(cups.length-1, cur+delta));
        for (String c : cups) removeTrait(c);
        addTrait(cups[next]);
        money -= 10000;
        breastSurgeryDay = dayCount;
        addTimedTrait("Recovering_From_Surgery", 14); // 2 week recovery
    }


    // ── Pill subscription ─────────────────────────────────────────────────────────
    /** True when player is on a pill subscription (auto-renews every 30 days). */
    public boolean pillSubscribed    = false;
    /** dayCount when current pill course expires (0 if not on pill). */
    public int     pillExpiryDay     = 0;

    // ── Pregnancy stage tracking ──────────────────────────────────────────────────
    /** Number of times MC drank heavily during this pregnancy (miscarriage risk accumulator). */
    public int drunkWhilePregnantCount = 0;

    /** Current pregnancy stage 0-6 (0=none, 1=early, 2=showing, 3=growing, 4=large, 5=near_term, 6=birth_due) */
    public int pregnancyStage       = 0;
    /** dayCount when last pregnancy stage scene was shown. */
    public int lastPregnancyScene   = 0;
    /** Gender of unborn child: 'f'=female, 'm'=male. Set at conception. */
    public char childGender         = 'f';

    // ── Child system ──────────────────────────────────────────────────────────────
    public boolean childExists          = false;
    public boolean childGivenAway       = false;
    public String  childName            = "";
    public int     childBirthDay        = 0;   // dayCount when born
    /** In-game years: 120 days = 1 year. */
    public int childAgeYears()   { return childExists ? (dayCount - childBirthDay) / 120 : 0; }
    public int childAgeDays()    { return childExists ? (dayCount - childBirthDay) : 0; }
    public String childAgeLabel() {
        int d = childAgeDays();
        if (d < 30)  return "newborn";
        if (d < 60)  return "infant";
        if (d < 120) return "toddler";
        if (d < 240) return "young child";
        if (d < 360) return "child";
        return "older child";
    }

    // ── Multiple children + pregnancy origin ──────────────────────────────────
    /** All children (including given-away). Use childCount() for living-with-MC count. */
    public java.util.List<Child> children = new java.util.ArrayList<>();

    public static class Child {
        public String name=""; public char gender='f';
        public int birthDay=0; public boolean givenAway=false;
        public boolean fromSA=false;
        public int ageYears(int day){return givenAway?0:Math.max(0,(day-birthDay)/120);}
    }

    /** True if current/last pregnancy came from non-consensual sex. */
    public boolean pregnancyFromSA = false;

    public int childCount() {
        int c=children.stream().filter(k->!k.givenAway).mapToInt(k->1).sum();
        return c>0 ? c : (childExists && !childGivenAway ? 1 : 0);
    }
    public int oldestChildAge() {
        int fromList=children.stream().filter(k->!k.givenAway)
            .mapToInt(k->k.ageYears(dayCount)).max().orElse(0);
        return Math.max(fromList, childAgeYears());
    }
    public void addChildRecord(String name, char gender, boolean fromSA) {
        Child c=new Child(); c.name=name; c.gender=gender;
        c.birthDay=dayCount; c.fromSA=fromSA;
        children.add(c);
    }

    // ── Pill helpers ──────────────────────────────────────────────────────────────
    public boolean isOnPill()   { return hasTrait("On_The_Pill") || (pillSubscribed && dayCount < pillExpiryDay); }
    public void startPill(int days) {
        addTrait("On_The_Pill");
        pillExpiryDay = dayCount + days;
    }
    public void advancePillDay() {
        if (pillSubscribed && dayCount >= pillExpiryDay) {
            if (money >= 30) { money -= 30; pillExpiryDay = dayCount + 30; }
            else { removeTrait("On_The_Pill"); pillSubscribed = false; }
        }
        if (pillExpiryDay > 0 && dayCount >= pillExpiryDay && !pillSubscribed) {
            removeTrait("On_The_Pill");
            pillExpiryDay = 0;
        }
    }

    // ── Pregnancy stage helpers ───────────────────────────────────────────────────
    /**
     * Called daily. Advances pregnancy stage based on daysPregnant().
     * 45-day pregnancy: each ~7 days = one stage.
     * Returns stage key if a new stage was just entered, else "".
     */
    public String advancePregnancyStage() {
        if (!hasTrait("Pregnant")) { pregnancyStage = 0; return ""; }
        int d = daysPregnant();
        int newStage;
        if      (d <  7)  newStage = 1;  // early, no bump
        else if (d < 15)  newStage = 2;  // showing
        else if (d < 22)  newStage = 3;  // growing
        else if (d < 30)  newStage = 4;  // large
        else if (d < 38)  newStage = 5;  // near term
        else              newStage = 6;  // birth due
        if (newStage != pregnancyStage) {
            pregnancyStage = newStage;
            // Update bump traits
            removeTrait("Pregnancy_Early");  removeTrait("Pregnancy_Showing");
            removeTrait("Pregnancy_Growing");removeTrait("Pregnancy_Large");
            removeTrait("Pregnancy_Near_Term");
            switch (newStage) {
                case 2: addTrait("Pregnancy_Showing");   break;
                case 3: addTrait("Pregnancy_Growing");   break;
                case 4: addTrait("Pregnancy_Large");     break;
                case 5: case 6: addTrait("Pregnancy_Near_Term"); break;
            }
            return "stage_" + newStage;
        }
        return "";
    }

    /** Handle birth: clears pregnancy traits, sets child state. */
    public void handleBirth(String name, char gender) {
        addChildRecord(name, gender, pregnancyFromSA);
        pregnancyFromSA = false; // reset for next pregnancy
        removeTrait("Pregnant"); removeTrait("Pregnancy_Early");
        removeTrait("Pregnancy_Showing"); removeTrait("Pregnancy_Growing");
        removeTrait("Pregnancy_Large"); removeTrait("Pregnancy_Near_Term");
        pregnancyStage = 0; pregnancyStartDay = 0;
        childExists    = true;
        childName      = name;
        childGender    = gender;
        childBirthDay  = dayCount;
        childGivenAway = false;
    }

    /** Give child to fire station. */
    public void giveChildAway() {
        childExists    = false;
        childGivenAway = true;
    }


    /**
     * Daily miscarriage check — called from advanceDay() when pregnant.
     * Risk scales with current drunk level and pregnancy stage.
     * Earlier pregnancy = higher natural miscarriage rate.
     * Returns true if miscarriage occurs.
     */
    public boolean rollMiscarriage() {
        if (!hasTrait("Pregnant")) return false;
        if (hasTrait("Alcoholic")) return false; // alcoholics have physiological tolerance — handled by separate arc
        if (drunk < 10) return false; // below miscarriage-risk threshold

        drunkWhilePregnantCount++;

        // Base risk by drunk level
        double base;
        if      (drunk >= 19) base = 0.35;
        else if (drunk >= 15) base = 0.20;
        else if (drunk >= 11) base = 0.08;
        else                  base = 0.02;

        // Earlier pregnancy = higher risk (weeks 1-6 of real, days 1-15 of game)
        int d = daysPregnant();
        if (d < 8)  base *= 2.0;
        else if (d < 16) base *= 1.4;

        // Cumulative risk — repeated drinking increases risk
        if (drunkWhilePregnantCount > 3) base = Math.min(0.70, base * 1.5);

        return Math.random() < base;
    }

    /** Perform miscarriage — clears pregnancy, sets grief trait, records history. */
    public void applyMiscarriage() {
        removeTrait("Pregnant");
        removeTrait("Pregnant_Unconfirmed");
        removeTrait("Pregnancy_Early");
        removeTrait("Pregnancy_Showing");
        removeTrait("Pregnancy_Growing");
        removeTrait("Pregnancy_Large");
        removeTrait("Pregnancy_Near_Term");
        pregnancyStage        = 0;
        pregnancyStartDay     = 0;
        pregnantByNpcId       = "";
        drunkWhilePregnantCount = 0;
        addTimedTrait("Grieving_Miscarriage", 30); // grief lasts ~30 days
        addTrait("Has_Had_Miscarriage");
    }


    // ── Hygiene system ────────────────────────────────────────────────────────────
    public int  daysSinceShower    = 0;
    public int  soapUses           = 0;   // uses remaining (10 per bar, stackable)
    public int  soapGraceDays      = 0;   // bonus days before smell, from soap
    public boolean showeredMorning = false;
    public boolean showeredNight   = false;
    public boolean brushedTeeth    = false;
    public boolean usedSoap        = false;

    public boolean smellsUnwashed() { return daysSinceShower >= (2 + soapGraceDays); }

    public void processHygieneDay() {
        if (showeredMorning || showeredNight) {
            int cost = (showeredMorning ? 5 : 0) + (showeredNight ? 5 : 0);
            money -= cost;
            daysSinceShower = 0;
        }
        if (usedSoap && soapUses > 0) {
            soapUses--;
            soapGraceDays = Math.min(5, soapGraceDays + 1);
        }
        showeredMorning = false;
        showeredNight   = false;
        brushedTeeth    = false;
        usedSoap        = false;
    }

    public void advanceHygieneDay() {
        daysSinceShower++;
        if (soapGraceDays > 0 && daysSinceShower > 1) soapGraceDays--;
    }


    // ── Photo system ──────────────────────────────────────────────────────────────
    /** NPC ID of the person who took an intimate photo of MC (cleared if resolved). */
    public String photoTakenByNpcId    = "";
    /** True if a photo was leaked (triggers partner confrontation scene). */
    public boolean photoWasLeaked      = false;
    /** NPC ID of the NPC whose photo was leaked to the partner. */
    public String photoLeakedByNpcId   = "";
    /** Has the partner confrontation scene already fired? */
    public boolean partnerKnowsAboutPhoto = false;

    /** Find any NPC the MC is currently dating (returns first match). */
    public String getAnyDatingNpcId() {
        for (java.util.Map.Entry<String,String> e : npcMemory.entrySet()) {
            if (e.getKey().endsWith(":relationship_status") && isDating(
                    e.getKey().replace(":relationship_status","")))
                return e.getKey().replace(":relationship_status","");
        }
        return "";
    }

    /** Record that a photo was taken by the current NPC. */
    public void recordPhotoTaken(String npcId) {
        photoTakenByNpcId = npcId != null ? npcId : "";
    }

    /** Apply leak outcome — called from Engine after trait-aware roll. */
    public void applyPhotoLeak(String npcId) {
        photoWasLeaked     = true;
        photoLeakedByNpcId = npcId != null ? npcId : "";
    }

    /** The outcome of the lie — set in Engine after roll. */
    public boolean photoLieBelieved = false;

    /** Clear photo state once confrontation has resolved. */
    public void resolvePhotoLeak() {
        photoWasLeaked           = false;
        photoTakenByNpcId        = "";
        photoLeakedByNpcId       = "";
        partnerKnowsAboutPhoto   = true;
    }

    public double pregnancyChance() {
        if (hasTrait("Infertile"))   return 0.0;
        if (hasTrait("On_The_Pill")) return 0.001;  // ~0.1% typical-use pill failure

        // Day-specific base probability (28-day reference cycle, ovulation day 14)
        // Accounts for sperm viability (up to 5 days) and egg viability (~12-24h)
        int day = ((cycleDay - 1) % Math.max(1, cycleLength)) + 1; // normalise to 1-N
        double base;
        switch (day) {
            case  1: case  2: case  3: case  4: case  5: base = 0.000; break; // menstruation
            case  6:  base = 0.005; break;
            case  7:  base = 0.007; break;
            case  8:  base = 0.010; break;
            case  9:  base = 0.015; break;
            case 10:  base = 0.025; break;
            case 11:  base = 0.040; break;
            case 12:  base = 0.060; break;
            case 13:  base = 0.080; break;
            case 14:  base = 0.090; break;  // ovulation peak
            case 15:  base = 0.080; break;
            case 16:  base = 0.040; break;
            case 17:  base = 0.020; break;
            case 18:  base = 0.010; break;
            case 19:  base = 0.005; break;
            default:  base = 0.002; break;  // days 20-28 luteal phase
        }

        // Scale for cycle length variation (ovulation shifts proportionally)
        if (cycleLength != 28 && cycleLength > 0) {
            double ovDay = cycleLength * (14.0 / 28.0); // estimated ovulation day
            double dist  = Math.abs(day - ovDay);
            if      (dist <= 1) base = 0.090;
            else if (dist <= 2) base = 0.070;
            else if (dist <= 3) base = 0.050;
            else if (dist <= 5) base = 0.020;
            else if (dist <= 8) base = 0.005;
            else                base = 0.001;
        }

        // MC fertility trait modifier
        if      (hasTrait("Extremely_Fertile")) base = Math.min(0.20, base * 2.0);
        else if (hasTrait("Fertile"))           base = Math.min(0.15, base * 1.3);
        else if (hasTrait("Less_Fertile"))      base *= 0.4;

        return Math.min(0.20, base); // cap at 20% per-act (biologically plausible max)
    }

    /**
     * Full pregnancy roll for one unprotected insemination.
     * Applies NPC fertility modifiers and pull-out reduction.
     * @param npcId  the NPC who inseminated
     * @param pulledOut  true if pull-out was agreed AND followed through
     */
    public boolean rollPregnancy(String npcId, boolean pulledOut) {
        double p = pregnancyChance();
        if (p <= 0.0) return false;

        // NPC sperm quality modifier (checked via npcMemory cache)
        String hfKey = "npc_trait_high_fertility";
        String lfKey = "npc_trait_low_fertility";
        String vaKey = "npc_trait_vasectomy";
        if ("true".equals(getNpcMemory(npcId, hfKey))) p = Math.min(0.20, p * 1.2);
        if ("true".equals(getNpcMemory(npcId, lfKey))) p *= 0.6;
        if ("true".equals(getNpcMemory(npcId, vaKey))) return false;

        // Pull-out: only pre-ejaculate risk remains (~5% of full rate)
        if (pulledOut) p *= 0.05;

        return Math.random() < p;
    }

    public String cycleStatus() {
        if (isOnPeriod())      return "Period (Day " + cycleDay + ")";
        if (isOvulating())     return "Ovulating (\u26a0 Day 14)";
        if (isFertileWindow()) return "Fertile Window (Day " + cycleDay + ")";
        return "Day " + cycleDay + " of " + cycleLength;
    }

    /** Advance to next day */
    public void advanceDay() {
        dayCount++;
        // Decay size adaptation for sizes not recently used
        decaySizeAdaptation();
        // Car system daily check
        advanceCarDay();
        advancePillDay();
        advanceHygieneDay();
        // Miscarriage check — fires when drunk while pregnant
        if (hasTrait("Pregnant") && drunk >= 10) {
            if (rollMiscarriage()) {
                applyMiscarriage();
                // Signal miscarriage event via npcMemory for scene trigger
                setNpcMemory("__sys__", "miscarriage_today", "true");
            }
        }
        advancePregnancyStage();
        // Expire timed traits
        // Track which timed traits expired this tick before clearing
        java.util.Set<String> expiredTraits = new java.util.HashSet<>();
        timedTraits.entrySet().removeIf(e -> {
            if (dayCount > e.getValue()) { expiredTraits.add(e.getKey()); return true; }
            return false;
        });
        for (String expired : expiredTraits) onTimedTraitExpired(expired);

        // ── Drunk-13 tracking for Alcoholic trait acquisition ──────────────
        if (wasDrunk13Today) drunk13DaysThisWeek++;
        wasDrunk13Today = false; // reset for new day

        dayOfWeek = (dayOfWeek + 1) % 7;
        if (dayOfWeek == 0) { // new week
            if (drunk13DaysThisWeek >= 3) {
                heavyWeeksInARow++;
                if (heavyWeeksInARow >= 2 && !hasTrait("Alcoholic")) {
                    addTrait("Alcoholic");
                    pendingTraitAcquisitions.add("trait_acquired_alcoholic");
                }
            } else {
                heavyWeeksInARow = 0;
            }
            drunk13DaysThisWeek = 0;
        }

        advanceCycle(1);
        advanceSunburn();
        advanceSlutFansDay();
        advanceStreamingDay();
        decayThroatAdaptation();
        checkYearEnd();
        isWet = false; // dry off each new day
        // Deduct daily rent (monthly rent / 30, rounded)
        if (rent > 0) money -= Math.round(rent / 30.0);

        // ── Furniture passive bonuses ─────────────────────────────────────────
        // Willpower recovery — housing base + optional furniture bonuses
        int wpRecovery = housingWillpowerRecovery;
        if (hasTrait("has_good_mattress")) wpRecovery += 5;
        // Bed type bonuses (own bed beats floor, better beds = better recovery)
        if      (hasTrait("has_king_bed"))   { wpRecovery += 7; happiness = clamp(happiness + 1); }
        else if (hasTrait("has_double_bed")) { wpRecovery += 5; }
        else if (hasTrait("has_single_bed")) { wpRecovery += 3; }
        else if (hasTrait("has_bunk_bed"))   { wpRecovery += 2; }
        if (hasTrait("has_bookshelf"))     wpRecovery += 2;
        willpower = Math.min(housingWillpowerCap, willpower + wpRecovery);

        // Stress reduction — housing base + optional furniture bonuses
        int stressReduce = housingStressReduction;
        if (hasTrait("has_tv"))            stressReduce += 3;
        if (hasTrait("has_coffee_maker"))  stressReduce += 2;
        stress = Math.max(housingStressMin, stress - stressReduce);

        // Confidence — mirror and dresser give small passive lift
        int confBonus = 0;
        if      (hasTrait("has_ornate_mirror")) confBonus += 3;
        else if (hasTrait("has_large_mirror"))  confBonus += 2;
        else if (hasTrait("has_mirror"))        confBonus += 1;
        else if (hasTrait("has_small_mirror"))  confBonus += 0; // exists for flag purposes
        if (hasTrait("has_dresser_nice"))  confBonus += 1;
        if (hasTrait("has_wardrobe"))      confBonus += 2;
        if (confBonus > 0) confidence = clamp(confidence + confBonus);

        // Happiness — feeling organised and settled
        int happBonus = 0;
        if (hasTrait("has_dresser_basic")) happBonus += 1;
        if (hasTrait("has_dresser_nice"))  happBonus += 1;
        if (hasTrait("has_wardrobe"))      happBonus += 1;
        if (happBonus > 0) happiness = clamp(happiness + happBonus);
        // Arousal naturally decays each day — sleep resets it somewhat
        // If MC goes to bed aroused: arousal drops 50%, half of that drop goes to stress,
        // 1/10th of the drop lowers confidence.
        // e.g. arousal=40 → drops 20 → +10 stress, -2 confidence
        if (arousal >= 35) {
            int drop = arousal / 2;
            int stressGain  = drop / 2;
            int confPenalty = drop / 10;
            arousal    = clamp(arousal - drop);
            stress     = Math.min(100, stress + stressGain);
            confidence = clamp(confidence - confPenalty);
        } else {
            arousal = clamp(arousal - 20);
        }
        // Thrills decay slowly
        thrills = clamp(thrills - 5);
        // Drunk mostly clears overnight — sleep off about 8 points (0-20 scale)
        drunk = clampDrunk(drunk - 8);
        // Reset per-scene slut rep tracker each day
        slutRepGainedThisScene = 0;
        slutRepGainedToday     = 0;
        // Low money warning
        if (money < 200 && money >= 0 && dayCount > 1) {
            pendingTraitAcquisitions.add("low_money_warning");
        }
        // Period start notification — fires on cycle day 1
        if (cycleDay == 1) {
            pendingTraitAcquisitions.add("period_start_notice");
        }

        // Note: clearLostClothingToday() is called at end of this method after rebuy

        // Season advances every 30 days (120-day full year)
        int newSeason = (dayCount / 30) % 4;
        if (newSeason != currentSeason) {
            currentSeason = newSeason;
            pendingTraitAcquisitions.add("season_change_" + SEASON_NAMES[newSeason].toLowerCase());
        }
        // Landlord rent check — every 30 days when rent is due and player is short
        if (dayCount > 1 && (dayCount % 30) == 1
                && currentLandlordNpc != null && !currentLandlordNpc.isEmpty()
                && money < rent) {
            pendingTraitAcquisitions.add("landlord_rent_shortage");
        }

        // ── Trait passive effects ─────────────────────────────────────────────
        // ── STD treatment completion ───────────────────────────────────────────
        // Track weeks of completed treatment. Treatment traits are weekly timed traits.
        // When a week expires, increment completed-weeks counter.
        if (hasTrait("std_treatment_minor_week") && !hasTimedTrait("std_treatment_minor_week")) {
            // Week expired — increment counter (stored as a trait std_treatment_minor_wN)
            int weeksCompleted = getStdTreatmentWeeks("minor") + 1;
            removeTrait("std_treatment_minor_week");
            if (weeksCompleted >= 2) {
                // 2 weeks complete — infection cleared
                removeTrait("STD_minor");
                removeTrait("STD_treatment_active");
                pendingTraitAcquisitions.add("std_cleared_minor");
            }
        }
        if (hasTrait("std_treatment_serious_week") && !hasTimedTrait("std_treatment_serious_week")) {
            int weeksCompleted = getStdTreatmentWeeks("serious") + 1;
            removeTrait("std_treatment_serious_week");
            if (weeksCompleted >= 4) {
                // 4 weeks complete — infection managed
                removeTrait("STD_serious");
                removeTrait("STD_treatment_active");
                addTrait("STD_managed");
                pendingTraitAcquisitions.add("std_cleared_serious");
            }
        }

        // ── STD passive effects (reduced if treatment active) ──────────────────
        boolean treatmentActive = hasTrait("STD_treatment_active");
        if (hasTrait("STD_serious")) {
            // Active infection: passive daily drain (halved during treatment)
            int mult = treatmentActive ? 1 : 2;
            happiness = clamp(happiness - (treatmentActive ? 1 : 3));
            stress    = clamp(stress    + (treatmentActive ? 2 : 4));
            willpower = clamp(willpower - (treatmentActive ? 1 : 2));
        } else if (hasTrait("STD_minor")) {
            stress    = clamp(stress + (treatmentActive ? 1 : 2));
        } else if (hasTrait("STD_managed")) {
            // Managed but not cleared — minor ongoing passive
            stress = clamp(stress + 1);
        }
        // ── Trauma passive daily effects ─────────────────────────────────────────
        if (hasTrait("Broken")) {
            stress    = clamp(stress    + 5);
            willpower = clamp(willpower - 2);
        } else if (hasTrait("Shaken")) {
            stress    = clamp(stress    + 3);
        } else if (hasTrait("Hurt")) {
            stress    = clamp(stress    + 1);
        }

        // Reset daily clothing loss tracker (rebuy runs in GameWindow before this)
        clearLostClothingToday();

        // NPC text message — ~15% chance per day when any NPC has your number
        // Uses currentApproachingNpc to identify who texts; pick a random numbered NPC
        if (dayCount > 2 && Math.random() < 0.15) {
            String texterNpc = findRandomNumberedNpc();
            if (texterNpc != null && !texterNpc.isEmpty()) {
                currentApproachingNpc = texterNpc;
                // 30% chance they ask to meet (higher threshold), 70% morning message
                String textScene = (Math.random() < 0.30 && getNpcRep(texterNpc) >= 25)
                    ? "npc_text_asking_out" : "npc_text_morning_message";
                pendingTraitAcquisitions.add(textScene);
            }
        }
    }

    /** Counts completed STD treatment weeks for the given type (minor/serious). */
    public int getStdTreatmentWeeks(String type) {
        // Count trait markers std_treatment_{type}_done_N
        int count = 0;
        for (String t : traits) {
            if (t.startsWith("std_treatment_" + type + "_done_")) count++;
        }
        return count;
    }

    /** Days remaining for a timed trait. Returns 0 if not active. */
    public int getTimedTraitDaysLeft(String trait) {
        Integer expiryDay = timedTraits.get(trait.toLowerCase());
        if (expiryDay == null) return 0;
        return Math.max(0, expiryDay - dayCount);
    }

    /** Find a random NPC who has the player's number. Returns null if none. */
    public String findRandomNumberedNpc() {
        java.util.List<String> candidates = new java.util.ArrayList<>();
        for (java.util.Map.Entry<String,String> e : npcMemory.entrySet()) {
            // Keys are "npcId:has_number" → "true"
            if (e.getKey().endsWith(":has_number") && "true".equals(e.getValue())) {
                candidates.add(e.getKey().replace(":has_number",""));
            }
        }
        if (candidates.isEmpty()) return null;
        return candidates.get((int)(Math.random() * candidates.size()));
    }

    /** Get the rep for a given NPC, defaulting 0. */
    public int getNpcRep(String npcId) {
        return npcRep.getOrDefault(npcId, 0);
    }

    /** Call at end of any bar session where drunk peaked. Tracks daily drunk flag. */
    public void recordPeakDrunk(int peakDrunk) {
        if (peakDrunk >= 13) wasDrunk13Today = true;
    }

    public String getDayName()  { return DAY_NAMES[dayOfWeek]; }
    public String getDayShort() { return DAY_SHORT[dayOfWeek]; }
    public boolean isWeekend()  { return dayOfWeek == 5 || dayOfWeek == 6; }

    public boolean hasTrait(String t)   { 
        String k = t.toLowerCase();
        return traits.contains(k) || timedTraits.containsKey(k); 
    }
    public void    addTrait(String t)   { traits.add(t.toLowerCase()); }
    public void    removeTrait(String t){ 
        String k = t.toLowerCase();
        traits.remove(k); 
        timedTraits.remove(k);
    }
    /** Adds a trait that expires after the given number of in-game days. */
    public void addTimedTrait(String t, int days) {
        timedTraits.put(t.toLowerCase(), dayCount + days);
        onTimedTraitAdded(t.toLowerCase(), days);
    }

    /**
     * Side effects when a timed trait expires naturally.
     * Shaken expiry: removes Conflict_Avoidant only if Shaken added it (not original personality).
     */
    private void onTimedTraitExpired(String trait) {
        switch (trait) {
            case "rattled":
                removeTrait("Rattled");
                break;
            case "hurt":
                removeTrait("Hurt");
                break;
            case "sore_from_sex":
                removeTrait("Sore_From_Sex");
                break;
case "neck_hickey":
                removeTrait("Neck_Hickey");
                neckHickeyFromNpcId = "";   // clear source when hickey fades
                break;
            case "breast_hickey":
                removeTrait("Breast_Hickey");
                breastHickeyFromNpcId = ""; // clear source
                break;
            case "covered_neck_hickey":
                removeTrait("Covered_Neck_Hickey"); // concealer wears off
                break;
            case "shaken":
                removeTrait("Shaken");
                if (hasTrait("Shaken_Added_CA")) {
                    removeTrait("Conflict_Avoidant");
                    removeTrait("Shaken_Added_CA");
                }
                break;
            case "broken":
                removeTrait("Broken");
                if (hasTrait("Shaken_Added_CA")) {
                    removeTrait("Conflict_Avoidant");
                    removeTrait("Shaken_Added_CA");
                }
                break;
        }
    }

    /**
     * Side effects when a timed trait is applied.
     * Shaken temporarily adds Conflict_Avoidant (if MC didn't already have it)
     * and is tracked by Shaken_Added_CA so it can be removed cleanly on expiry.
     */
    /**
     * Immediate effects when a trauma trait is applied.
     * Also handles diminishing returns — getting hit while already traumatised escalates the tier.
     */
    private void onTimedTraitAdded(String trait, int days) {
        switch (trait) {
            case "rattled":
                // Lightest tier. Rattled while anything worse → no escalation.
                if (hasTrait("Broken") || hasTrait("Shaken") || hasTrait("Hurt")) return;
                // Rattled while Rattled → escalate to Hurt
                if (hasTrait("Rattled")) {
                    removeTrait("Rattled"); removeTimedTrait("rattled");
                    addTimedTrait("hurt", traumaDuration(5)); return;
                }
                changeStat("slut_rep",    -5);
                changeStat("confidence",  -3);
                changeStat("stress",      +5);
                break;

            case "hurt":
                // Hurt while Shaken/Broken → no escalation
                if (hasTrait("Broken") || hasTrait("Shaken")) return;
                // Hurt while Hurt → escalate to Shaken
                if (hasTrait("Hurt")) {
                    removeTrait("Hurt"); removeTimedTrait("hurt");
                    addTimedTrait("shaken", traumaDuration(3)); return;
                }
                // Clear Rattled (Hurt is worse)
                if (hasTrait("Rattled")) { removeTrait("Rattled"); removeTimedTrait("rattled"); }
                changeStat("slut_rep",    -10);
                changeStat("confidence",   -5);
                changeStat("stress",      +10);
                changeStat("happiness",    -5);
                break;

            case "shaken":
                // Shaken while Broken → no escalation
                if (hasTrait("Broken")) return;
                // Shaken while Shaken → escalate to Broken
                if (hasTrait("Shaken")) {
                    removeTrait("Shaken"); removeTimedTrait("shaken");
                    addTimedTrait("broken", traumaDuration(2)); return;
                }
                // Clear Hurt if present (Shaken is worse)
                if (hasTrait("Hurt")) { removeTrait("Hurt"); removeTimedTrait("hurt"); }
                // Apply immediate Shaken hits
                changeStat("slut_rep",    -20);
                changeStat("confidence",  -10);
                changeStat("stress",      +20);
                changeStat("happiness",   -10);
                // Shaken→CA: add Conflict_Avoidant temporarily if not original
                if (!hasTrait("Conflict_Avoidant")) {
                    addTrait("Conflict_Avoidant");
                    addTrait("Shaken_Added_CA");
                }
                break;

            case "broken":
                // Already Broken: no escalation beyond max
                if (hasTrait("Broken")) return;
                // First-time Broken acquisition: slut_rep penalty
                // Broken represents genuine trauma — it pulls back progression.
                // Only fires once per acquisition (guard above prevents repeat hits).
                changeStat("slut_rep", -10);
                // Clear lesser tiers
                if (hasTrait("Shaken")) {
                    if (hasTrait("Shaken_Added_CA")) {
                        removeTrait("Conflict_Avoidant"); removeTrait("Shaken_Added_CA");
                    }
                    removeTrait("Shaken"); removeTimedTrait("shaken");
                }
                if (hasTrait("Hurt")) { removeTrait("Hurt"); removeTimedTrait("hurt"); }
                // Apply immediate Broken hits
                changeStat("slut_rep",    -40);
                changeStat("confidence",  -20);
                changeStat("stress",      +30);
                changeStat("happiness",   -15);
                changeStat("willpower",   -15);
                // Broken also adds CA
                if (!hasTrait("Conflict_Avoidant")) {
                    addTrait("Conflict_Avoidant");
                    addTrait("Shaken_Added_CA");
                }
                break;
        }
    }

    /** Duration for trauma traits adjusted by personality. Min 1 day. */
    private int traumaDuration(int base) {
        boolean fragile = hasTrait("Fragile_Ego") || hasTrait("Conflict_Avoidant") || hasTrait("Shy");
        boolean resilient = hasTrait("Iron_Will") || hasTrait("Self_Assured") || hasTrait("Driven");
        if (fragile)   return base + 1;
        if (resilient) return Math.max(1, base - 1);
        return base;
    }

    /** Removes a timed trait from the timer map without triggering expiry hooks. */
    private void removeTimedTrait(String trait) {
        timedTraits.remove(trait.toLowerCase());
    }

    /** Returns true if player has any of the given traits */
    public boolean hasAnyTrait(String... ts) {
        for (String t : ts) if (hasTrait(t)) return true;
        return false;
    }

    // ── Breast descriptor pool ────────────────────────────────────
    // Rotates through options by dayCount so the same word doesn't repeat every scene.
    // Add or replace entries freely — each array is the full pool for that cup size.
    private static final String[][] BREAST_POOLS = {
        // A cup
        { "perky breasts", "small, perky breasts", "slight breasts", "neat breasts" },
        // B cup
        { "soft breasts", "gentle breasts", "soft, modest breasts", "light breasts" },
        // C cup
        { "full, soft breasts", "rounded breasts", "warm, full breasts", "soft, full breasts" },
        // D cup
        { "full breasts", "generous breasts", "heavy, full breasts", "substantial breasts" },
        // DD cup
        { "heavy breasts", "generous, heavy breasts", "full, heavy breasts", "weighty breasts" },
        // E cup
        { "large, heavy breasts", "heavy, generous breasts", "full, considerable breasts", "substantial, heavy breasts" },
        // F cup
        { "large breasts", "very full breasts", "heavy, large breasts", "considerable breasts" },
    };

    /** Returns a size-appropriate breast descriptor. Rotates by dayCount for variety. */
    public String breastDescriptor() {
        int cup = 0; // 0=A through 6=F
        if      (hasTrait("breasts_f"))  cup = 6;
        else if (hasTrait("breasts_e"))  cup = 5;
        else if (hasTrait("breasts_dd")) cup = 4;
        else if (hasTrait("breasts_d"))  cup = 3;
        else if (hasTrait("breasts_c"))  cup = 2;
        else if (hasTrait("breasts_b"))  cup = 1;
        // breasts_a → 0 (default)
        String[] pool = BREAST_POOLS[cup];
        return pool[dayCount % pool.length];
    }

    // ── Sexual disposition helpers ────────────────────────────────
    public boolean isPrude()             { return hasTrait("Prude"); }
    public boolean isDemure()            { return hasTrait("Demure"); }
    public boolean isModest()            { return hasTrait("Modest"); }
    public boolean isProvocativeSexual() { return hasTrait("Provocative_Sexual") || hasTrait("Provocative"); }
    public boolean isSlut()              { return hasTrait("Slut"); }
    public boolean isWhore()             { return hasTrait("Whore"); }
    public boolean isSexuallyOpen()      { return isProvocativeSexual() || isSlut() || isWhore(); }
    public boolean isSexuallyConservative() { return isPrude() || isDemure() || isModest(); }

    /**
     * Applies trait-based modifiers to a stat change amount before it's applied.
     * Centralises all "Shaken halves happiness" / "STD_serious drains energy" logic.
     */
    private int applyTraitStatMods(String stat, int amount) {
        // Tiered trauma system — Broken > Shaken > Hurt (most restrictive wins)
        boolean broken = hasTrait("Broken");
        boolean shaken = hasTrait("Shaken");
        boolean hurt   = hasTrait("Hurt");
        boolean anyTrauma = broken || shaken || hurt;

        if (!anyTrauma) return amount;

        boolean rattled = hasTrait("Rattled");

        switch (stat) {
            case "happiness":
                if (amount > 0) {
                    if (broken)  return 0;
                    if (shaken)  return Math.max(1, amount / 2);
                    if (hurt)    return Math.max(1, amount * 3 / 4);
                    if (rattled) return Math.max(1, amount * 9 / 10);
                }
                break;
            case "willpower":
                if (amount > 0) {
                    if (broken)  return 0;
                    if (shaken)  return Math.max(1, amount / 2);
                    if (hurt)    return Math.max(1, amount * 3 / 4);
                    if (rattled) return Math.max(1, amount * 9 / 10);
                }
                break;
            case "stress":
                if (amount > 0) {
                    if (broken)  return amount * 3;
                    if (shaken)  return amount * 2;
                    if (hurt)    return amount + (amount / 2);
                    if (rattled) return amount + (amount / 4);
                }
                break;
            case "slut_rep":
                if (amount > 0) {
                    if (broken)  return 0;
                    if (shaken)  return Math.max(0, (int)(amount * 0.3));
                    if (hurt)    return Math.max(0, (int)(amount * 0.6));
                    if (rattled) return Math.max(0, (int)(amount * 0.85));
                }
                break;
            case "arousal":
                // Cap enforcement happens in changeStat after applying amount
                break;
            case "confidence":
                break;
        }
        return amount;
    }

    /** Returns the current trauma-enforced arousal cap. */
    public int traumaArousalCap() {
        if (hasTrait("Broken"))  return 30;
        if (hasTrait("Shaken"))  return 55;
        if (hasTrait("Hurt"))    return 75;
        if (hasTrait("Rattled")) return 90;
        return 100;
    }

    /** Returns the current trauma-enforced confidence cap. */
    public int traumaConfidenceCap() {
        if (hasTrait("Broken"))  return 25;
        if (hasTrait("Shaken"))  return 45;
        if (hasTrait("Hurt"))    return 65;
        if (hasTrait("Rattled")) return 82;
        return 100;
    }

    public void changeStat(String stat, int amount) {
        amount = applyTraitStatMods(stat, amount);
        // npc_rep_<id> keys route to per-NPC reputation
        // Special alias: npc_rep_bar_npc routes to whoever is currently approaching
        if (stat.toLowerCase().startsWith("npc_rep_")) {
            String npcId = stat.substring("npc_rep_".length());
            if ("bar_npc".equals(npcId) && currentApproachingNpc != null && !currentApproachingNpc.isEmpty())
                npcId = currentApproachingNpc;
            changeNpcRep(npcId, amount);
            return;
        }
        // npc_liking — shorthand for npc_rep on current NPC (approaching or dating partner)
        if (stat.equalsIgnoreCase("npc_liking")) {
            String target = currentApproachingNpc;
            // Fall back to any NPC we're dating if no approaching NPC
            if ((target == null || target.isEmpty()) && npcMemory != null) {
                for (java.util.Map.Entry<String,String> e : npcMemory.entrySet()) {
                    if (e.getKey().endsWith(":relationship") && "dating".equals(e.getValue())) {
                        target = e.getKey().replace(":relationship","");
                        break;
                    }
                }
            }
            if (target != null && !target.isEmpty()) changeNpcRep(target, amount);
            return;
        }
        // npc_give_number — records that MC exchanged numbers with current NPC
        if (stat.equalsIgnoreCase("npc_give_number")) {
            if (currentApproachingNpc != null && amount > 0)
                giveNpcNumber(currentApproachingNpc);
            return;
        }
        // npc_relationship_<status> — sets relationship status with current NPC
        if (stat.toLowerCase().startsWith("npc_relationship_")) {
            if (currentApproachingNpc != null) {
                String status = stat.substring("npc_relationship_".length());
                setRelationshipStatus(currentApproachingNpc, amount > 0 ? status : "");
            }
            return;
        }
        // npc_living_together — sets cohabitation flag
        if (stat.equalsIgnoreCase("npc_living_together")) {
            if (currentApproachingNpc != null)
                setNpcMemory(currentApproachingNpc, "living_together", amount > 0 ? "true" : "");
            return;
        }
        switch (stat.toLowerCase()) {
            case "money":      money      = Math.max(-999, money + amount); break;
            case "rent":       rent       = Math.max(0, rent + amount); break;
            case "fitness":    fitness    = clamp(fitness    + amount); break;
            case "work_rep":
            case "reputation": work_rep   = clamp(work_rep  + amount); break;
            case "happiness": {
                // Shaken halves positive gains; STD_serious adds ambient unhappiness via advanceDay
                int ha = (amount > 0 && hasTrait("Shaken")) ? Math.max(1, amount / 2) : amount;
                happiness = clamp(happiness + ha); break;
            }
            case "confidence": {
                int cap = traumaConfidenceCap();
                confidence = Math.min(cap, clamp(confidence + amount)); break;
            }
            case "willpower":  { int _a=(settings!=null&&amount<0)?settings.applyWPDrain(amount):amount; willpower=Math.min(housingWillpowerCap,clamp(willpower+_a)); break; }
            case "stress":     { int _a=(settings!=null&&amount>0)?settings.applyStress(amount):amount; stress=Math.max(housingStressMin,clamp(stress+_a)); break; }

            // stress_sexual — stress from uncomfortable/unwanted sexual situations.
            // Scales automatically by arousal level, MC path trait, and slut_rep.
            // amount is the BASE stress at zero arousal, shy, low rep.
            //
            // Arousal scale (lower arousal = more uncomfortable):
            //   0–24:  ×1.00   25–49:  ×0.60   50–74:  ×0.20   75+:  ×−0.25 (relief)
            //
            // Path trait modifier (added to arousal scale):
            //   Shy:          +0.30   Demure:       +0.15   Exhibitionist: −0.35
            //
            // Slut_rep modifier (comfort with sexual situations grows over time):
            //   0–15:  +0.20   16–40: ±0.00   41–70: −0.20   71+:  −0.35
            case "stress_sexual": {
                // Arousal factor
                double scale;
                if      (arousal >= 75) scale = -0.25;
                else if (arousal >= 50) scale =  0.20;
                else if (arousal >= 25) scale =  0.60;
                else                    scale =  1.00;

                // Path trait modifier
                if (hasTrait("Shy"))
                    scale += 0.30;
                else if (hasTrait("Demure"))
                    scale += 0.15;
                if (hasTrait("Public_Exhibitionist") || hasTrait("Path_Trait_Public_Exhibitionist"))
                    scale -= 0.35;
                else if (hasTrait("Low_Risk_Exhibitionist") || hasTrait("Path_Trait_Low_Risk_Exhibitionist"))
                    scale -= 0.15;

                // Slut_rep comfort modifier
                if      (slut_rep >= 71) scale -= 0.35;
                else if (slut_rep >= 41) scale -= 0.20;
                else if (slut_rep <= 15) scale += 0.20;

                // Apply — floor at 0 for relief scale, respect housing stress floor
                int delta = (int) Math.round(amount * scale);
                stress = Math.max(housingStressMin, clamp(stress + delta));
                break;
            }
            case "slut_rep":   { int _a=(settings!=null)?settings.applySlutRepMult(amount):amount; slut_rep=clamp(slut_rep+_a); break; }
            // Surprise/involuntary rep gain — 50% of the amount, min 1 if amount >= 2
            case "slut_rep_surprise": {
                int reduced = Math.max(amount >= 2 ? 1 : 0, (int) Math.round(amount * 0.5));
                slut_rep = clamp(slut_rep + reduced);
                break;
            }
            case "thrills":          thrills    = clamp(thrills    + amount); break;
            // "arousal" — passive sources (dancing, being groped).
            // Diminishing returns by tier, hard cap at 80:
            //   0-25: full gain
            //  25-50: -1 drag (need +2 to gain +1)
            //  50-75: -2 drag (need +3 to gain +1)
            //  75+:   -3 drag (need +4 to gain +1), hard cap 80
            case "arousal": {
                int gain = amount - arousaldrag();
                int aCap = Math.min(80, traumaArousalCap());
                arousal = Math.min(aCap, clamp(arousal + gain));
                _dynamicCache = null;
                break;
            }
            // "arousal_direct" — MC actively participating (groping him, direct stimulation).
            // Same drag scale but cap at 90 instead of 80.
            case "arousal_direct": {
                int gain = amount - arousaldrag();
                arousal = Math.min(90, clamp(arousal + gain));
                _dynamicCache = null;
                break;
            }
            case "drunk":            drunk      = clampDrunk(drunk + amount); break;
            // drunk_drink applies Alcoholic (−1) / Lightweight (+1) modifier before adding
            // Both traits cancel each other. Displays modified amount in drink text.
            case "drunk_drink": {
                int mod   = drunkMod();
                int final_ = Math.max(0, amount + mod);
                drunk = clampDrunk(drunk + final_);
                break;
            }
            case "npc_frustration":  currentNpcFrustration = Math.max(0, currentNpcFrustration + amount); break;
            case "npc_arousal":      currentNpcArousal     = Math.max(0, currentNpcArousal     + amount); break;
            case "npc_liking":       currentNpcLiking      = Math.max(0, currentNpcLiking      + amount); break;
            case "flag_breast_groped": flagBreastGroped  = amount > 0; break;
            case "flag_ass_groped":    flagAssGroped     = amount > 0; break;
            case "flag_pussy_groped":  flagPussyGroped   = amount > 0; break;
            case "flag_fingered":      flagFingered      = amount > 0; break;
            case "flag_kissed":        flagKissed        = amount > 0; break;
            case "flag_neck_kissed":   flagNeckKissed    = amount > 0; break;
            case "flag_deep_kissed":   flagDeepKissed    = amount > 0; break;
            case "flag_cornered":         flagCornered         = amount > 0; break;
            case "flag_cooked_tonight":   flagCookedTonight    = amount > 0; break;
            case "flag_npc_came":        flagNpcCame         = amount > 0; break;
            case "flag_gloryhole_used":    flagGloryHoleUsed     = amount > 0; break;
            case "flag_cafe_jump_flashed":    flagCafeJumpFlashed   = amount > 0; break;
            case "flag_cafe_sleazy_visited":  flagCafeSleazyVisited = amount > 0; break;
            
            case "timed_neck_hickey":  addTimedTrait("Neck_Hickey", amount); break;
            case "timed_neck_hickey_faint": addTimedTrait("Neck_Hickey", 1); break;
        }
    }

    public void setStat(String stat, int value) {
        switch (stat.toLowerCase()) {
            case "money":      money      = value; break;
            case "rent":       rent       = Math.max(0, value); break;
            case "fitness":    fitness    = clamp(value); break;
            case "work_rep":
            case "reputation": work_rep   = clamp(value); break;
            case "happiness":  happiness  = clamp(value); break;
            case "confidence": confidence = clamp(value); break;
            case "willpower":                willpower              = Math.min(housingWillpowerCap, clamp(value)); break;
            case "stress":                   stress                 = Math.max(housingStressMin, clamp(value)); break;
            case "slut_rep":                 slut_rep               = clamp(value); break;
            case "thrills":                  thrills                = clamp(value); break;
            case "arousal": {
                int cap = traumaArousalCap();
                arousal = Math.min(cap, clamp(arousal + amount)); break;
            }           case "drunk":                    drunk                  = clampDrunk(value); break;
            case "housing_willpower_cap":    housingWillpowerCap      = value; break;
            case "housing_willpower_recovery": housingWillpowerRecovery = value; break;
            case "housing_stress_reduction": housingStressReduction   = value; break;
            case "housing_stress_min":       housingStressMin         = value; break;
        }
    }

    /**
     * Effective willpower after accounting for drunkenness.
     * Scales proportionally: sober = full willpower, blackout (15) = 25% of max willpower,
     * passed out (20) = 0. Formula: willpower × (20 - drunk) / 20
     * Used to gate paths where MC needs backbone to stand up for herself.
     */
    public int effectiveWillpower() {
        return (int)(willpower * (20.0 - drunk) / 20.0);
    }

    /**
     * Effective willpower with an arousal-drain penalty applied.
     * For every 10 arousal above the given threshold, subtract 2.
     * Represents losing resolve as attraction/arousal builds.
     *
     * Example: threshold=50, arousal=70 → base WP minus 4 (on top of drunk penalty).
     * Used for the bar walk-home check and similar resist scenarios.
     */
    public int effectiveWillpowerForCheck(int arousalThreshold) {
        int base = effectiveWillpower();
        if (arousalThreshold > 0 && arousal > arousalThreshold)
            base -= ((arousal - arousalThreshold) / 10) * 2;
        base -= slut_rep / 5;
        return Math.max(0, base);
    }

    /** Looks up a body-state flag by the stat_changes key name. */
    public boolean getBodyFlag(String key) {
        switch (key) {
            case "flag_breast_groped":    return flagBreastGroped;
            case "flag_ass_groped":       return flagAssGroped;
            // ── Composite grope flags ────────────────────────────────────────────
            // True when any groping is actively happening — drives "ask to stop" choice
            case "flag_being_groped":     return flagBreastGroped || flagAssGroped || flagPussyGroped;
            // True after he was told to stop and kept going — drives scream/hard push choices
            case "flag_grope_persisted":  return hasTrait("grope_persisted");
            case "flag_pussy_groped":     return flagPussyGroped;
            case "flag_fingered":         return flagFingered;
            case "flag_kissed":           return flagKissed;
            case "flag_neck_kissed":      return flagNeckKissed;
            case "flag_deep_kissed":      return flagDeepKissed;
            case "flag_cornered":         return flagCornered;
            case "flag_cooked_tonight":   return flagCookedTonight;
            case "flag_npc_came":         return flagNpcCame;
            case "flag_gloryhole_used":   return flagGloryHoleUsed;
            case "flag_cafe_jump_flashed":    return flagCafeJumpFlashed;
            case "flag_cafe_sleazy_visited":  return flagCafeSleazyVisited;
            case "flag_works_velvet_cafe":    return "velvet_cafe".equals(currentJobId)
                                               || "cafe".equals(currentJobId)
                                               || "cafe_morning".equals(currentJobId);

            // ── Sex scene state flags ─────────────────────────────────────────
            case "flag_sex_active":                  return sexState.active;
            case "flag_sex_mc_naked":                return sexState.mcNaked;
            case "flag_sex_npc_naked":               return sexState.npcNaked;
            case "flag_sex_both_naked":              return sexState.bothNaked();
            case "flag_sex_penetration":             return sexState.isPenetration;
            case "flag_sex_riding":                  return "riding".equals(sexState.position);
            case "flag_sex_missionary":              return "missionary".equals(sexState.position);
            case "flag_sex_doggy":                   return "doggy".equals(sexState.position);
            case "flag_sex_69":                      return "69".equals(sexState.position);
            case "flag_sex_oral_giving":             return "oral_giving".equals(sexState.currentActivity);
            case "flag_sex_oral_receiving":          return "oral_receiving".equals(sexState.currentActivity);
            case "flag_sex_npc_oral":                return "npc_oral".equals(sexState.currentActivity);
            case "flag_sex_handjob":                 return "handjob".equals(sexState.currentActivity);
            case "flag_sex_player_close":            return sexState.playerIsClose();
            case "flag_sex_npc_close":               return sexState.npcIsClose();
            case "flag_sex_npc_very_close":          return sexState.npcIsVeryClose();
            case "flag_sex_npc_climaxed":            return sexState.npcHasClimaxed;
            case "flag_sex_player_climaxed":         return sexState.playerHasClimaxed;
            case "flag_sex_first_time":              return sexState.virginityLostThisScene;
            case "flag_sex_player_frustrated":       return sexState.playerIsFrustrated();
            case "flag_sex_npc_frustrated":          return sexState.npcIsFrustrated();
            // ── Clothing removed during scene ─────────────────────────────────
            case "flag_sex_mc_shirt_off":            return sexState.mcShirtOff || outfitUpper == null;
            case "flag_sex_mc_bra_off":              return sexState.mcBraOff || isBraless();
            case "flag_sex_mc_bottom_off":           return sexState.mcBottomOff || outfitLower == null;
            case "flag_sex_mc_underwear_off":        return sexState.mcUnderwearOff || outfitUnderwear == null;
            case "flag_sex_mc_skirt_hiked":          return sexState.mcSkirtHiked;
            case "flag_sex_npc_top_off":             return sexState.npcTopOff;
            case "flag_sex_npc_bottom_off":          return sexState.npcBottomOff;
            // ── Access & penetration ──────────────────────────────────────────
            case "flag_sex_lower_access":            return sexState.mcHasLowerAccess(this);
            case "flag_sex_npc_accessible":          return sexState.npcIsAccessible();
            case "flag_sex_can_penetrate":           return sexState.penetrationPossible(this);
            // ── Condom / violation ────────────────────────────────────────────
            case "flag_sex_condom":                  return sexState.condomOn;
            case "flag_sex_condom_used":             return sexState.condomUsed;
            case "flag_sex_player_requested_condom": return sexState.playerRequestedCondom;
            case "flag_sex_npc_refused_condom":      return sexState.npcRefusedCondom;
            case "flag_sex_npc_ignored_condom":      return sexState.npcIgnoredCondom;
            case "flag_sex_pull_out_agreed":         return sexState.pullOutAgreed;
            case "flag_sex_mc_upset":                return sexState.mcIsUpsetDuringScene;
            case "flag_sex_condom_violation":
                return sexState.npcRefusedCondom && !sexState.condomOn && sexState.isPenetration;
            // ── Body aftermath ────────────────────────────────────────────────
            case "flag_is_sore":                     return hasTrait("Sore_From_Sex");
            // ── Car flags ──────────────────────────────────────────────────────────────
            case "flag_has_car":           return hasCar();
            case "flag_car_is_nice":       return carIsNice();
            case "flag_car_is_luxury":     return carIsLuxury();
            case "flag_car_owned":         return "owned".equals(carOwnershipType);
            case "flag_car_rented":        return "rented".equals(carOwnershipType);
            case "flag_car_financed":      return "financed".equals(carOwnershipType);
            case "flag_rental_ban_active": return carRentalBanExpiry > dayCount;
            case "flag_finance_due":       return "financed".equals(carOwnershipType) && dayCount >= carFinanceNextDue;
            case "flag_car_is_cheap":      return hasCar() && carTier == 1;
            case "flag_car_is_mid":        return hasCar() && carTier == 2;
            // ── Inventory flags ──────────────────────────────────────────────────────────
            case "flag_has_condoms":        return condomCount > 0;
            case "flag_has_soap":           return soapCount > 0;
            case "flag_has_sunscreen":      return sunscreenCount > 0;
            // Pregnancy flags
            // Pill
            // ── Missing flag resolutions ─────────────────────────────────────────────────
            // Outfit state
            case "flag_braless":           return hasTrait("Braless") || outfitBra.isEmpty() || "none".equals(outfitBra);
            case "flag_commando":          return hasTrait("Commando") || "none".equals(outfitUnderwear);
            case "flag_dressed":           return !outfitUpper.isEmpty() || !outfitLower.isEmpty();
            case "flag_wearing_button_shirt": { game.data.ClothingData cu=getClothingItem(outfitUpper); return cu!=null&&cu.has_buttons; }
            // Fitness
            case "flag_high_fitness":      return fitness >= 60;
            // NPC state — checked via traits set by NpcBehaviourSystem
            case "flag_npc_alcoholic":     return hasTrait("npc_is_alcoholic");
            case "flag_npc_approaching":   return currentApproachingNpc!=null && !currentApproachingNpc.isEmpty();
            case "flag_npc_engaging":      return hasTrait("npc_is_engaging");
            case "flag_npc_sleazy":        return hasTrait("npc_is_sleazy");
            case "flag_npc_trauma_current":return hasTrait("npc_trauma_"+currentApproachingNpc);
            // MC traits as flags
            case "flag_outgoing":          return hasTrait("Outgoing");
            // Inventory
            case "flag_owns_condoms":      return condomCount > 0;
            // Season sub-flags
            case "flag_season_morning":    return hasTrait("Time_Morning");
            case "flag_season_night":      return hasTrait("Time_Night");
            case "flag_season_rain":       return hasTrait("Weather_Rain");
            // Sex state
            case "flag_sex_dom_locked":    return sexState!=null && sexState.npcDomLocked;
            case "flag_size_adapting":     return sexState!=null && sexState.adaptationLevel>0;
            case "flag_child_is_girl":       return childGender == 'f';
            case "flag_child_is_boy":        return childGender == 'm';
            case "flag_grieving_miscarriage":  return hasTrait("Grieving_Miscarriage");
            case "flag_miscarriage_today": return "true".equals(getNpcMemory("__sys__","miscarriage_today"));
            case "flag_has_had_miscarriage": return hasTrait("Has_Had_Miscarriage");
            // Slut rep tiers
            case "flag_slut_rep_low":       return slut_rep < 15;
            case "flag_slut_rep_mid":       return slut_rep >= 15 && slut_rep < 40;
            case "flag_slut_rep_high":      return slut_rep >= 40;
            case "flag_slut_rep_very_high": return slut_rep >= 65;
            case "flag_sex_rep_high":       return slut_rep >= 40;
            case "flag_smells_unwashed":    return smellsUnwashed();
            case "flag_has_cum_breath":     return hasTrait("Cum_Breath");
            case "flag_needs_shower":       return daysSinceShower >= 2;
            // Partner trust level for lie belief mechanic
            case "flag_partner_trusts_mc": {
                String pid = getAnyDatingNpcId();
                return !pid.isEmpty() && getNpcRep(pid) >= 30; // trust threshold
            }
            case "flag_photo_lie_believed":   return photoLieBelieved;
            case "flag_partner_suspicious": {
                String pid = getAnyDatingNpcId();
                return !pid.isEmpty() && getNpcRep(pid) < 15;
            }
            // Oversized shirt worn as dress — populated by computeDynamicTraits
            case "flag_wearing_oversized_as_dress": return hasTrait("wearing_oversized_as_dress");
            case "flag_oversized_commando":         return hasTrait("wearing_oversized_as_dress")
                                                        && outfitUnderwear == null;
            // Clothing wetness state
            case "flag_trenchcoat_nothing_under": {
                if (outfitOvercoat == null) return false;
                game.data.ClothingData coat = clothes.get(outfitOvercoat);
                if (coat == null || !"trenchcoat".equals(coat.id)) return false;
                // Nothing under = no upper clothing OR braless thin top, no lower
                return (outfitUpper == null || outfitLower == null);
            }
            case "flag_wet_top":            return isWet;
            case "flag_top_diaphanous_when_wet": {
                if (!isWet) return false;
                // Check if current upper is seethrough_when_wet
                return hasTrait("upper_wet_seethrough");
            }
            case "flag_trenchcoat_only":     {
                boolean hasCoat = "trenchcoat".equals(outfitOvercoat);
                return hasCoat && outfitUpper == null && outfitBra == null && outfitLower == null;
            }
            case "flag_coat_flashed":        return hasTrait("__coat_flashed__");
            case "flag_npc_cleaned":         return hasTrait("__npc_cleaned__");
            case "flag_npc_premature":       return currentNpcHasTrait("Premature_Ejaculator");
            case "flag_npc_just_came_early":  return hasTrait("__npc_came_early__");
            case "flag_has_gag_reflex":      return gagReflex >= 6;
            case "flag_strong_gag_reflex":   return gagReflex >= 8;
            case "flag_no_gag_reflex":       return gagReflex <= 2;
            case "flag_throat_adapted":      return throatAdaptation.getOrDefault(currentNpcSizeTier(),0) >= 2;
            case "flag_would_gag":           return wouldGag();
            case "flag_mc_requested_no_mouth":    return sexState != null && sexState.mcRequestedNoMouthCum;
            case "flag_npc_agreed_no_mouth":      return sexState != null && sexState.npcAgreedNoMouth;
            case "flag_npc_refused_no_mouth":     return sexState != null && sexState.npcRefusedMouthRequest;
            case "flag_npc_ignored_no_mouth":     return sexState != null && sexState.npcIgnoredMouthRequest;
            case "flag_npc_holding_head":         return sexState != null && sexState.npcHoldingHead;
            case "flag_npc_driving_pace":         return sexState != null && sexState.npcDrivingPace;
            case "flag_npc_held_during_cum":      return sexState != null && sexState.npcHeldDuringCum;
            case "flag_ff_hair_play":             return sexState != null && sexState.ffHairPlay;
            case "flag_ff_thigh_squeeze":         return sexState != null && sexState.ffThighSqueeze;
            case "flag_video_type_consensual":  return "consensual".equals(videoContentType);
            case "flag_video_type_drunk":       return "drunk".equals(videoContentType);
            case "flag_video_type_coerced":     return "coerced".equals(videoContentType);
            case "flag_video_type_assault":     return "assault".equals(videoContentType);
            case "flag_video_mc_was_drunk":     return videoMcWasDrunk;
            case "flag_outfit_wrong_for_court": return outfitInappropriateForCourt();
            case "flag_employer_found_online":  return employerFoundOnlineContent;
            case "flag_leak_found_online":   return leakFoundOnline;
            case "flag_content_removal_filed": return contentRemovalFiled;
            case "flag_content_removed":       return contentRemoved;
            case "flag_sa_suit_filed":         return saSuitFiled;
            case "flag_sa_suit_won":           return saSuitWon;
            case "flag_sa_suit_resolved":      return saSuitResolved;
            case "flag_has_pc":              return hasPc();
            case "flag_has_gaming_pc":      return hasGamingPc();
            case "flag_has_pro_rig":         return hasProRig();
            case "flag_has_gaming_chair":    return hasGamingChair;
            case "flag_streaming_active":    return streamingActive;
            case "flag_is_pro_gamer":        return isProGamer;
            case "flag_streaming_popular":   return streamingFollowers >= 200;
            case "flag_streaming_famous":    return streamingFollowers >= 1000;
            case "flag_gaming_skilled":      return gamingSkill >= 50;
            case "flag_gaming_pro_ready":    return gamingSkill >= 80;
            case "flag_has_carry_permit":   return hasCarryPermit;
            case "flag_carrying_gun":      return carryingGun;
            case "flag_has_pepper_spray":  return hasPepperSpray;
            case "flag_has_taser":         return hasTaser;
            case "flag_has_defensive_tool":return hasPepperSpray || hasTaser;
            case "flag_gun_visible":        return carryingGun && !equippedGunId.isEmpty();
            case "flag_slutfans_active":         return slutFansActive;
            case "flag_slutfans_has_followers":  return slutFansFollowers >= 10;
            case "flag_slutfans_growing":        return slutFansFollowers >= 50;
            case "flag_slutfans_popular":        return slutFansFollowers >= 200;
            case "flag_slutfans_famous":         return slutFansFollowers >= 1000;
            case "flag_slutfans_tier2":          return computeSlutFansTier() >= 2;
            case "flag_slutfans_tier3":          return computeSlutFansTier() >= 3;
            case "flag_slutfans_tier4":          return computeSlutFansTier() >= 4;
            case "flag_slutfans_tier5":          return computeSlutFansTier() >= 5;
            case "flag_slutfans_inactive":       return slutFansActive && slutFansDaysSincePost >= 3;
            case "flag_has_sex_toy":             return !ownedToys.isEmpty();
            // Child and pregnancy flags
            case "flag_multiple_children":      return childCount() > 1;
            case "flag_pregnancy_from_sa":       return pregnancyFromSA;
            case "flag_child_from_sa":            return !children.isEmpty() && children.get(0).fromSA;
            case "flag_has_child":              return childCount() > 0;
            case "flag_has_multiple_children":  return childCount() >= 2;
            case "flag_pregnancy_from_sa":      return pregnancyFromSA;
            case "flag_child_infant":           return childExists && childAgeYears()==0;
            case "flag_child_toddler":          return childExists && childAgeYears()==1;
            case "flag_child_young":            return childExists && childAgeYears()>=2 && childAgeYears()<=4;
            case "flag_child_school_age":       return childExists && childAgeYears()>=5;
            case "flag_sunburned":            return sunburnDays > 0;
            case "flag_tax_filing_due":       return taxFilingDue;
            case "flag_tax_refund":           return hasTrait("__tax_refund__");
            case "flag_has_daily_outfit":     return dailyOutfitName!=null && !dailyOutfitName.isEmpty();
            case "flag_photo_taken":           return !photoTakenByNpcId.isEmpty();
            case "flag_photo_leaked":          return photoWasLeaked;
            // Cum mechanic flags
            case "flag_sex_is_ff":              return sexState.active && hasTrait("Lesbian") || isFFSession();
            case "flag_npc_warned_before_cum":   return sexState.npcWarnedBeforeCum;
            case "flag_npc_is_close":           return sexState.npcIsClose();
            case "flag_npc_is_very_close":      return sexState.npcIsVeryClose();
            case "flag_npc_edged":              return sexState.npcEdged;
            case "flag_npc_tied":               return sexState.npcTied;
            case "flag_npc_frustrated":         return sexState.npcIsFrustrated();
            case "flag_npc_very_frustrated":    return sexState.npcFrustration >= 70;
            case "flag_first_dick_reveal":      return sexState.firstDickReveal;
            case "flag_npc_underwear_off":      return sexState.npcUnderwearOff;
            case "flag_came_inside_no_warning":  return sexState.cameInsideNoWarning;
            case "flag_npc_will_warn":           return sexState.npcWillWarn;
            case "flag_mc_noticed_npc_close":    return sexState.mcNoticedNpcClose;
            case "flag_mc_swallowed":            return sexState.mcSwallowed;
            case "flag_cum_inside":              return "inside".equals(sexState.cumLocation);
            case "flag_cum_mouth":               return "mouth".equals(sexState.cumLocation);
            case "flag_cum_facial":              return "facial".equals(sexState.cumLocation);
            case "flag_cum_chest":               return "chest".equals(sexState.cumLocation);
            case "flag_npc_standing_oral":       return sexState.npcStandingDuringOral;
            case "flag_scared_of_kids":          return hasTrait("Scared_Of_Kids") || hasTrait("Scared_Of_Pregnancy");
            case "flag_tasty_cum":               return hasTrait("Tasty_Cum");
            case "flag_nasty_cum":               return hasTrait("Nasty_Cum");
            case "flag_hates_cum":               return hasTrait("Hates_Cum");
            case "flag_likes_cum":               return hasTrait("Likes_Cum");
            case "flag_riding_npc":              return "riding".equals(sexState.position);
            case "flag_oral_giving":             return sexState.activityBeats.getOrDefault("oral_giving",0)>3;
            case "flag_video_taken":          return !videoTakenByNpcId.isEmpty();
            case "flag_video_posted":         return videoWasPosted;
            case "flag_video_sent_partner":   return videoSentToPartner;
            case "flag_video_consent_given":  return videoConsentGiven;
            case "flag_video_noticed":        return videoNoticedByMc;
            case "flag_partner_called_sex":   return partnerCalledDuringSex;
            case "flag_very_drunk":           return drunk >= 13;
            case "flag_partner_knows_photo":   return partnerKnowsAboutPhoto;
            case "flag_has_partner":           return !getAnyDatingNpcId().isEmpty();
            case "flag_bar_night_shift":    return "night".equals(barStaffShift);
            case "flag_bar_day_shift":      return "day".equals(barStaffShift);
            case "flag_is_on_pill":          return isOnPill();
            case "flag_pill_subscribed":      return pillSubscribed;
            // Pregnancy stages
            case "flag_pregnancy_showing":    return hasTrait("Pregnancy_Showing");
            case "flag_pregnancy_growing":    return hasTrait("Pregnancy_Growing");
            case "flag_pregnancy_large":      return hasTrait("Pregnancy_Large");
            case "flag_pregnancy_near_term":  return hasTrait("Pregnancy_Near_Term");
            case "flag_pregnancy_birth_due":  return pregnancyStage >= 6;
            // Child
            case "flag_has_child":            return childExists;
            case "flag_child_given_away":     return childGivenAway;
            case "flag_child_newborn":        return childExists && childAgeDays() < 30;
            case "flag_child_infant":         return childExists && childAgeDays() >= 30 && childAgeDays() < 120;
            case "flag_child_toddler":        return childExists && childAgeDays() >= 120 && childAgeDays() < 240;
            case "flag_child_young":          return childExists && childAgeDays() >= 240 && childAgeDays() < 360;
            case "flag_child_school_age":     return childExists && childAgeDays() >= 360;
            case "flag_plan_b_success": return "success".equals(getNpcMemory("__sys__","plan_b_result"));
            case "flag_plan_b_failure": return "failure".equals(getNpcMemory("__sys__","plan_b_result"));
            case "flag_abortion_success": return "success".equals(getNpcMemory("__sys__","abortion_result"));
            case "flag_pregnant_unconfirmed": return hasTrait("Pregnant_Unconfirmed");
            case "flag_can_take_plan_b":    return canTakePlanB();
            case "flag_can_take_abortion":  return canTakeAbortionPill();
            case "flag_pregnancy_early":    return hasTrait("Pregnant") && daysPregnant() <= 14;
            case "flag_morning_sickness_due":return hasTrait("Pregnant") && daysPregnant() >= 14 && !morningSicknessShown;
            // Recovery
            case "flag_recovering_surgery": return hasTrait("Recovering_From_Surgery");
            // Hair
            case "flag_hair_short":         return hasTrait("Hair_Short");
            case "flag_hair_long":          return hasTrait("Hair_Long") || hasTrait("Hair_Very_Long");
            case "flag_hair_very_long":     return hasTrait("Hair_Very_Long");
            case "flag_mc_hiding_hickey":     return sexState != null && sexState.mcHidingHickey;
            case "flag_shirt_lifted":         return sexState != null && sexState.mcShirtLifted;
            case "flag_has_neck_hickey":             return hasTrait("Neck_Hickey");
            // Hickey from someone OTHER than current sex partner
            case "flag_hickey_from_other":
                return hasTrait("Neck_Hickey")
                    && !neckHickeyFromNpcId.isEmpty()
                    && !neckHickeyFromNpcId.equals(currentApproachingNpc);
            // Cheating sex AND has hickey from that same other person
            case "flag_hickey_visible_cheating":
                return isCheatingSexSession() && hasTrait("Neck_Hickey")
                    && !hasTrait("Covered_Neck_Hickey")
                    && !neckHickeyFromNpcId.isEmpty()
                    && !neckHickeyFromNpcId.equals(currentApproachingNpc);
            case "flag_has_breast_hickey":           return hasTrait("Breast_Hickey");
            case "flag_neck_hickey_visible":         return hasTrait("Neck_Hickey") && !hasTrait("Covered_Neck_Hickey");
            case "flag_neck_hickey_covered":         return hasTrait("Covered_Neck_Hickey");
            case "flag_is_cheating_sex":             return isCheatingSexSession();
            // ── NPC monogamy preference flags ────────────────────────────────────
            case "flag_npc_likes_swing":   return currentNpcHasTrait("Likes_To_Swing");
            case "flag_npc_hates_swing":   return currentNpcHasTrait("Hates_To_Swing");
            case "flag_npc_no_swing":      return currentNpcHasTrait("Doesnt_Like_To_Swing");
            // Partner + visible hickey — fires date confrontation scene
            case "flag_dating_with_visible_hickey":
                return hasTrait("Neck_Hickey") && !hasTrait("Covered_Neck_Hickey") && isInAnyRelationship();
            case "flag_sex_wearing_skirt":           return outfitLower != null;
            case "flag_owns_sneakers":        return hasTrait("owns_sneakers") || ownedClothing.contains("sneakers");
            case "flag_dance_locked":     return flagDanceLocked;
            // ── NPC frustration tier flags — computed from currentNpcFrustration ────
            // Used to gate groping escalation choices in YAML
            case "flag_npc_calm":       return currentNpcFrustration < 20;
            case "flag_npc_wanting":    return currentNpcFrustration >= 40;  // tier 2 threshold
            case "flag_npc_escalating": return currentNpcFrustration >= 60;  // tier 3 (fingering)
            case "flag_npc_peak":       return currentNpcFrustration >= 80;  // tier 4
            case "flag_npc_sa_territory": return currentNpcFrustration >= 92; // tier 5 SA
            // ── NPC capability flags — set by BarSystem based on NPC trait ──────────
            // npc_can_grope: NPC type allows groping (Sleazy/Jerk/Alcoholic/Confrontational/Outgoing)
            case "flag_npc_can_grope":  return hasTrait("npc_can_grope");
            // npc_can_finger: NPC type allows fingering (Sleazy/Alcoholic/Confrontational)
            case "flag_npc_can_finger": return hasTrait("npc_can_finger");
            // npc_can_sa: NPC type + frustration allows SA (Sleazy/Alcoholic tier 5 only)
            case "flag_npc_can_sa":     return hasTrait("npc_can_sa");
            // npc_sa_risk: frustration >= 85, Sleazy/Alcoholic — imminent SA territory
            case "flag_npc_sa_risk":    return hasTrait("npc_can_sa") && currentNpcFrustration >= 85;
            // npc_wants_leave: NPC at peak frustration and wants to leave
            case "flag_npc_wants_leave": return hasTrait("npc_wants_leave");
            // npc_returning_to_dance: NPC frustration dropped, going back to normal
            case "flag_npc_returning":  return hasTrait("npc_returning_to_dance");
            // Furniture ownership flags — backed by traits
            
            case "flag_season_spring": return currentSeason == 0;
            case "flag_season_summer": return currentSeason == 1;
            case "flag_season_autumn": return currentSeason == 2;
            case "flag_season_winter": return currentSeason == 3;
            case "flag_season_warm":   return isWarmSeason();
            case "flag_season_cold":   return isColdSeason();
            // Neighbourhood flags
            case "flag_neighbourhood_narrows":    return "The Narrows".equals(currentNeighbourhood);
            case "flag_neighbourhood_millgate":   return "Millgate".equals(currentNeighbourhood);
            case "flag_neighbourhood_thornwick":  return "Thornwick".equals(currentNeighbourhood);
            case "flag_neighbourhood_lanes":      return "The Lanes".equals(currentNeighbourhood);
            case "flag_neighbourhood_caldwell":   return "Caldwell".equals(currentNeighbourhood);
            case "flag_neighbourhood_ravenshill": return "Ravenshill".equals(currentNeighbourhood);
            // Clothing + season combination flags
            case "flag_is_rattled":   return hasTrait("Rattled");
            // ── Game stage tiers for variant gating ─────────────────────────────────
            // Low: inexperienced, first-time feel — full shock and shame
            // Mid: some experience — uncomfortable, pushes back, still affected
            // High: desensitised — anger or numbness over devastation
            case "flag_stage_low":    return slut_rep < 30;
            case "flag_stage_mid":    return slut_rep >= 30 && slut_rep < 65;
            case "flag_stage_high":   return slut_rep >= 65;
            case "flag_npc_traumatised_current":
                // True when the currently approaching NPC has a permanent trauma link
                return !currentApproachingNpc.isEmpty()
                    && hasTrait("npc_trauma_" + currentApproachingNpc);
            case "flag_npc_trauma_timer_active":
                // True while the acute trauma timer is still running for current NPC.
                // Drives intense scared reactions. After expiry, residual mild flash takes over.
                return !currentApproachingNpc.isEmpty()
                    && hasTimedTrait("npc_trauma_timer_" + currentApproachingNpc);
            case "flag_has_any_npc_trauma": {
                // True permanently once any NPC trauma link exists.
                // Drives the residual Rattled-level flash even after all tiers clear.
                for (String trait : traits) {
                    if (trait.startsWith("npc_trauma_") && !trait.startsWith("npc_trauma_timer_"))
                        return true;
                }
                return false;
            }
            case "flag_is_broken":    return hasTrait("Broken");
            case "flag_is_shaken":    return hasTrait("Shaken");
            case "flag_is_hurt":      return hasTrait("Hurt");
            case "flag_is_traumatised": return hasTrait("Broken") || hasTrait("Shaken") || hasTrait("Hurt");
            case "flag_has_std":      return hasTrait("STD_minor") || hasTrait("STD_serious");
            case "flag_is_braless":   return isBraless();
            case "flag_nipping":      return isBraless() && isWearingThinTop();
            case "flag_wearing_thin_top": {
                game.data.ClothingData upper = null; // resolved via outfit upper
                // Simplified: check outfitUpper item thickness via a dedicated helper
                return isWearingThinTop();
            }
            case "flag_high_lewdness": return getCurrentLewdnessRating() >= 60;
            case "flag_very_high_lewdness": return getCurrentLewdnessRating() >= 85;
            case "flag_wearing_dress": {
                String lower = outfitLower != null ? outfitLower.toLowerCase() : "";
                return lower.contains("dress") || lower.contains("sundress");
            }
            case "flag_wearing_skirt": {
                String lower = outfitLower != null ? outfitLower.toLowerCase() : "";
                return lower.contains("skirt");
            }
            case "flag_wearing_dress_or_skirt": {
                String lower = outfitLower != null ? outfitLower.toLowerCase() : "";
                return lower.contains("dress") || lower.contains("sundress") || lower.contains("skirt");
            }
            case "flag_underdressed_for_winter":
                return isColdSeason() && outfitOvercoat == null && (
                    (outfitLower != null && (outfitLower.toLowerCase().contains("dress")
                        || outfitLower.toLowerCase().contains("skirt")
                        || outfitLower.toLowerCase().contains("sundress")))
                    || isBraless()
                );
            
            
            
            
            
            
            
            
            case "flag_has_npc_number":    return currentApproachingNpc != null && hasNpcNumber(currentApproachingNpc);
            case "flag_is_dating_npc":
                // True if actively dating the current bar NPC, OR if player is dating anyone
                if (currentApproachingNpc != null && isDating(currentApproachingNpc)) return true;
                for (java.util.Map.Entry<String,String> e : npcMemory.entrySet())
                    if (e.getKey().endsWith(":relationship_status") && isDating(e.getKey().replace(":relationship_status",""))) return true;
                return false;
            case "flag_is_married_npc":    return currentApproachingNpc != null && isMarried(currentApproachingNpc);
            case "flag_is_open_rel_npc":   return currentApproachingNpc != null && isOpenRelationship(currentApproachingNpc);
            case "flag_is_living_together":return currentApproachingNpc != null && isLivingTogether(currentApproachingNpc);
            case "flag_is_pregnant":       return isPregnant();
            case "flag_is_virgin":         return hasTrait("Virgin");
            case "flag_lost_virginity_this_scene": return sexState.virginityLostThisScene;
            case "flag_alcoholic_craving":    return hasTrait("Alcoholic");
            case "flag_on_period":           return isOnPeriod();
            // Job perk flags — for discounts at visitable locations
            case "flag_works_library":       return "library".equals(currentJobId);
            case "flag_works_bookshop":      return "bookshop".equals(currentJobId);
            case "flag_works_kitchen":       return "restaurant_kitchen".equals(currentJobId);
            case "flag_works_tattoo":        return "tattoo_studio".equals(currentJobId);
            case "flag_works_neon_fitness":  return "neon_fitness".equals(currentJobId);
            case "flag_works_bar":           return "bar_staff".equals(currentJobId);
            case "flag_works_retail":        return "retail".equals(currentJobId);
            // Wellbeing flags
            case "flag_high_stress":         return stress >= 70;
            case "flag_low_willpower":       return willpower <= 25;
            case "flag_drunk_tonight":       return drunk >= 11;
            case "flag_happy":               return happiness >= 70;
            case "flag_broke":               return money < 300;
            case "flag_owns_property":         return hasTrait("owns_property");
            case "flag_neighbourhood_premium": return hasTrait("neighbourhood_premium");
            default:
                // Dynamic neighbourhood flags from neighbourhoods.yml
                if (key.startsWith("flag_neighbourhood_")) {
                    String suffix = key.substring("flag_neighbourhood_".length());
                    String name   = NEIGHBOURHOOD_FLAGS.get(suffix);
                    if (name != null) return name.equals(currentNeighbourhood);
                }
            case "flag_lives_house":           return hasTrait("lives_house");
            // Furniture / item ownership flags
            case "flag_has_tv":           return ownedClothing.contains("furniture_tv")       || hasTrait("has_tv");
            case "flag_has_bookshelf":    return ownedClothing.contains("furniture_bookshelf") || hasTrait("has_bookshelf");
            case "flag_has_mirror":       return ownedClothing.contains("furniture_mirror")    || hasTrait("has_mirror");
            case "flag_has_coffee_maker": return ownedClothing.contains("furniture_coffee")    || hasTrait("has_coffee_maker");
            case "flag_has_good_mattress":return ownedClothing.contains("furniture_mattress")  || hasTrait("has_good_mattress");
            case "flag_has_wardrobe":     return ownedClothing.contains("furniture_wardrobe")  || hasTrait("has_wardrobe");
            case "flag_has_dresser":      return ownedClothing.contains("furniture_dresser")   || hasTrait("has_dresser")
                                              || ownedClothing.contains("furniture_dresser_nice");
            case "flag_has_dresser_basic":return ownedClothing.contains("furniture_dresser")   || hasTrait("has_dresser");
            case "flag_has_dresser_nice": return ownedClothing.contains("furniture_dresser_nice") || hasTrait("has_dresser_nice");
            // NPC / social flags
            
            
            
            
            default: return false;
        }
    }


    private int clamp(int v)     { return Math.max(0,   Math.min(100, v)); }
    private int clampDrunk(int v){ return Math.max(0,   Math.min(20,  v)); }

    /**
     * Diminishing returns drag on arousal gains.
     * Returns how many points to subtract from any incoming arousal delta.
     *   0–25:  drag 0  (full gain)
     *  25–50:  drag 1  (need +2 to gain +1)
     *  50–75:  drag 2  (need +3 to gain +1)
     *  75+:    drag 3  (need +4 to gain +1)
     */
    private int arousaldrag() {
        if (arousal >= 75) return 3;
        if (arousal >= 50) return 2;
        if (arousal >= 25) return 1;
        return 0;
    }

    /**
     * Lifetime cap per action type (from spec table).
     */
    public static int slutRepLifetimeCap(String actionType) {
        switch (actionType) {
            // Breast flash tiers
            case "low_risk_flash":         return 12;
            case "high_risk_flash":        return 16;
            case "watched_flash":          return 20;
            // Lower body flash tiers — significantly more intimate
            case "low_risk_flash_lower":   return 28;
            case "high_risk_flash_lower":  return 38;
            case "watched_flash_lower":    return 48;
            // Generic
            case "public_act":             return 14;
            // ── Sexual intimacy action types ──────────────────────────────────────────
            case "sex_handjob":            return  8;
            case "sex_fingering":          return  8;
            case "sex_oral_give":          return 12;
            case "sex_oral_receive":       return 12;
            case "sex_69":                 return 10;
            case "sex_penetrate":          return 20;
            case "sex_bareback":           return 15;
            case "sex_anal":               return 12;
            case "sex_dirty_talk":         return  6;
            case "sex_undress":            return  5;
            case "sex_rough":              return  8;
            case "sex_hickey":             return  4;
            default:                       return 20;
        }
    }

    /**
     * Applies diminishing returns to a slut_rep gain based on how much
     * has already been earned from this action type over the game lifetime.
     *
     * Formula:
     *   Earned 0–4:   full gain
     *   Earned 5–8:   ceil(gain / 2)
     *   Earned 9–12:  ceil(gain / 4), minimum 0
     *   Earned 12+:   0 (soft cap reached)
     *
     * Also enforces the hard lifetime cap for the type.
     * Returns the effective gain (may be 0).
     */
    public int applySlutRepEarned(String actionType, int baseGain) {
        int cap    = slutRepLifetimeCap(actionType);
        int earned = slutRepEarnedByType.getOrDefault(actionType, 0);

        if (earned >= cap) return 0; // hard lifetime cap

        // Diminishing returns — thresholds scale with lifetime cap so higher-cap
        // action types (watched_flash cap=20) allow proportionally more total gain
        // than lower-cap types (low_risk_flash cap=12).
        //
        // Thresholds at cap * [0.25, 0.50, 0.75]:
        //   low_risk  (cap=12): full <3, half <6, quarter <9, zero 9+
        //   high_risk (cap=16): full <4, half <8, quarter <12, zero 12+
        //   watched   (cap=20): full <5, half <10, quarter <15, zero 15+
        //   public_act(cap=14): full <4, half <7, quarter <11, zero 11+
        int q1 = cap / 4;
        int q2 = cap / 2;
        int q3 = (cap * 3) / 4;

        int dimGain;
        if      (earned < q1) dimGain = baseGain;
        else if (earned < q2) dimGain = Math.max(1, (int) Math.ceil(baseGain / 2.0));
        else if (earned < q3) dimGain = Math.max(0, (int) Math.ceil(baseGain / 4.0));
        else                  dimGain = 0;

        // Don't exceed remaining lifetime cap
        int remaining = cap - earned;
        int effective = Math.min(dimGain, remaining);

        if (effective > 0) {
            slutRepEarnedByType.put(actionType, earned + effective);
        }
        return effective;
    }

    /**
     * Modifier applied to drink buzz.
     * Alcoholic: −1 per drink (tolerance — still feels less).
     * Lightweight: +1 per drink (goes faster).
     * Both: cancel out → 0.
     */

    /**
     * Multiplier applied to slut_rep_req thresholds when MC is drunk.
     * Drunk MC will do things she normally wouldn't — thresholds lower.
     * Returns a value < 1.0 (easier to unlock when drunk).
     */
    public double drunkSlutRepModifier() {
        int d = drunk;
        boolean alco  = hasTrait("Alcoholic");
        boolean coa   = hasTrait("Conflict_Avoidant"); // gives in easier when drunk
        boolean lite  = hasTrait("Lightweight");

        // Lightweight: effects kick in at lower drunk levels
        if (lite) d = (int)(d * 1.4);

        double mod;
        if      (d >= 19) mod = 0.20;  // blackout — almost all gates removed
        else if (d >= 15) mod = 0.45;  // very drunk
        else if (d >= 11) mod = 0.65;  // drunk
        else if (d >=  6) mod = 0.80;  // tipsy
        else              mod = 1.00;  // sober — no change

        // Alcoholic: drunk modifiers are gentler (tolerance), but apply earlier
        if (alco && d >= 4) mod = Math.min(mod, 0.85); // always slightly lowered
        // Conflict_Avoidant: gives in more when impaired
        if (coa  && d >= 6) mod = Math.min(mod, mod * 0.85);

        return mod;
    }

    public int drunkMod() {
        boolean alco = hasTrait("Alcoholic");
        boolean lite = hasTrait("Lightweight");
        if (alco && lite) return 0;
        if (alco)         return -1;
        if (lite)         return +1;
        return 0;
    }

    /** Get reputation with a specific NPC (defaults to 0 = neutral) */
    public int getNpcRep(String npcId) {
        return npcReputation.getOrDefault(npcId, 0);
    }

    /** Change reputation with a specific NPC (-100 hate … 0 neutral … +100 love) */
    public void changeNpcRep(String npcId, int amount) {
        int current = getNpcRep(npcId);
        npcReputation.put(npcId, clampNpc(current + amount));
    }

    /** Set reputation with a specific NPC */
    public void setNpcRep(String npcId, int value) {
        npcReputation.put(npcId, clampNpc(value));
    }

    private int clampNpc(int v) { return Math.max(-100, Math.min(100, v)); }

    // ── Per-NPC relationship helpers ─────────────────────────────────────────
    // Relationship statuses: "" (none), "dating", "partnered", "married",
    //                        "open_relationship", "friends_with_benefits"
    // Stored in npcMemory as npcId:relationship_status

    public boolean hasNpcNumber(String npcId) {
        return "true".equals(getNpcMemory(npcId, "has_number"));
    }
    public void giveNpcNumber(String npcId) {
        setNpcMemory(npcId, "has_number", "true");
    }

    public String getRelationshipStatus(String npcId) {
        return getNpcMemory(npcId, "relationship_status"); // "" = none
    }
    public void setRelationshipStatus(String npcId, String status) {
        String prev = getRelationshipStatus(npcId);
        setNpcMemory(npcId, "relationship_status", status);
        // Record start day when entering a relationship for the first time
        if (!prev.isEmpty() && "".equals(status)) {
            setNpcMemory(npcId, "relationship_start_day", "");
        } else if (prev.isEmpty() && !status.isEmpty()) {
            setNpcMemory(npcId, "relationship_start_day", String.valueOf(dayCount));
        }
    }
    /** Days MC has been with this NPC (0 if not dating). */
    public int daysWithNpc(String npcId) {
        if (!isDating(npcId)) return 0;
        String s = getNpcMemory(npcId, "relationship_start_day");
        if (s == null || s.isEmpty()) return 0;
        try { return Math.max(0, dayCount - Integer.parseInt(s)); }
        catch (NumberFormatException e) { return 0; }
    }
    public int monthsWithNpc(String npcId) { return daysWithNpc(npcId) / 30; }
    /**
     * True if a sex scene is active with an NPC who is NOT the MC's dating partner.
     * Used to gate possessive/marking NPC behaviour.
     */
    /** Checks if the NPC currently approaching/in scene has a given trait. */
    public boolean currentNpcHasTrait(String trait) {
        if (currentApproachingNpc == null || currentApproachingNpc.isEmpty()) return false;
        // Check npcMemory for trait flag: "npc_trait_{trait_lower}" = "true"
        String key = "npc_trait_" + trait.toLowerCase().replace("_","_");
        return "true".equals(getNpcMemory(currentApproachingNpc, key));
    }

    /** True if MC is in any dating/partnered relationship with any NPC. */
    public boolean isInAnyRelationship() {
        for (java.util.Map.Entry<String,String> e : npcMemory.entrySet()) {
            String key = e.getKey();
            if (key.endsWith(":relationship_status") && isDating(key.replace(":relationship_status","")))
                return true;
        }
        return false;
    }

    public boolean isCheatingSexSession() {
        if (!sexState.active || currentApproachingNpc.isEmpty()) return false;
        // If in a relationship with the current NPC — not cheating
        if (isDating(currentApproachingNpc)) return false;
        // Check if MC is in any relationship at all
        for (java.util.Map.Entry<String,String> e : npcMemory.entrySet()) {
            String key = e.getKey();
            if (key.endsWith(":relationship_status") && isDating(key.replace(":relationship_status","")))
                return true;
        }
        return false;
    }

    public boolean isDating(String npcId) {
        String s = getRelationshipStatus(npcId);
        return "dating".equals(s) || "partnered".equals(s) || "married".equals(s)
            || "open_relationship".equals(s) || "friends_with_benefits".equals(s);
    }
    public boolean isMarried(String npcId) {
        return "married".equals(getRelationshipStatus(npcId));
    }
    public boolean isOpenRelationship(String npcId) {
        return "open_relationship".equals(getRelationshipStatus(npcId));
    }
    public boolean isLivingTogether(String npcId) {
        return "true".equals(getNpcMemory(npcId, "living_together"));
    }
    public boolean isPregnant() {
        return hasTrait("Pregnant");
    }


}
