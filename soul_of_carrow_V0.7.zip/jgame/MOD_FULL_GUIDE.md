# Full Modding Guide — The Soul of Carrow

---

## Overview of mod types

| Folder contents | What it does |
|----------------|-------------|
| `scenes/` | New or replacement scene YAML files |
| `npcs/` | New NPC definitions |
| `clothes/` | New clothing items |
| `jobs/` | New job definitions |
| `mod.yml` (assets block) | Images, sprites, animated GIFs |
| `artwork.yml` | Dynamic state-driven artwork hooks |
| `text_pools/` | Add/remove prose variants from BarSystem, CafeSystem, scene pools |
| `soundtrack.yml` | Music and ambient audio tracks |
| `sidebar.yml` | Stats sidebar appearance (portrait, background, accent color) |
| `modpack.yml` | A container for multiple sub-mods (art pack + story mod together) |

---

## 1. Simple mods — folder structure

```
mods/
└── my_mod/
    ├── mod.yml        ← required
    ├── scenes/        ← optional
    ├── npcs/          ← optional
    ├── clothes/       ← optional
    └── jobs/          ← optional
```

**mod.yml minimum:**
```yaml
id:      my_mod
name:    My Mod
author:  You
version: 1.0.0
```

---

## 2. Image / sprite / animation packs

Declare assets in `mod.yml` under `assets:`, then reference by ID in scenes.

```yaml
id:   my_art_pack
name: My Art Pack

assets:
  bar_night:       images/bar_at_night.png
  grope_reaction:  images/grope_neutral.gif   # animated GIF supported
  mc_portrait:     images/mc_portrait.png
  sidebar_bg:      images/sidebar_bg.png
```

**In a scene YAML:**
```yaml
id: bar_dance_floor
text: The floor is loud. {npc_name} is right there with you.
image: bar_night
image_position: top       # top | left | right (left/right reserved)
image_height: 240         # optional max pixel height
```

Images only appear when the asset is registered. Missing assets produce a
warning in mod_errors.log and the scene renders text-only.

**Clothing thumbnails:** register an asset as `clothing_{item_id}`:
```yaml
assets:
  clothing_black_dress: images/clothes/black_dress.png
  clothing_heels:       images/clothes/heels.png
```
These appear in the shopping panel and outfit panel automatically.

**Supported formats:** PNG · JPG/JPEG · GIF (animated) · BMP

---

## 3. Artwork overhaul mods (dynamic state-driven images)

Create `artwork.yml` in your mod folder. Instead of tying images to specific
scenes, you define *conditions* — the game picks the matching image based on
what's actually happening.

```yaml
# artwork.yml

hooks:
  # Breast grope — shy MC enjoying it
  - id: grope_breast_shy_enjoying
    asset: grope_breast_enjoy        # from your mod.yml assets block
    priority: 20
    requires_flags:  [flag_breast_groped]
    requires_traits: [Shy, Likes_Being_Touched]
    arousal_min: 40

  # Breast grope — neutral
  - id: grope_breast_neutral
    asset: grope_breast_neutral
    priority: 10
    requires_flags: [flag_breast_groped]

  # Braless in public (not being groped)
  - id: braless_walking
    asset: braless_street
    priority: 5
    requires_flags: [flag_is_braless]
    blocks_flags:   [flag_breast_groped, flag_being_groped]

  # Bar dance floor
  - id: bar_dancing
    asset: bar_dance
    priority: 3
    scene_ids: [bar_dance_floor, bar_slow_dance, bar_transition_to_dance]
```

**Hook priority:** Higher number = evaluated first. When multiple hooks match,
the highest priority one is used.

**Condition fields:**

| Field | Type | Meaning |
|-------|------|---------|
| `requires_flags` | list | All flags must be active (AND) |
| `blocks_flags` | list | None may be active |
| `requires_traits` | list | All MC traits required (AND) |
| `blocks_traits` | list | None may be active |
| `requires_any_flags` | list | At least one must be active (OR) |
| `requires_any_traits` | list | At least one required (OR) |
| `arousal_min` / `arousal_max` | int | MC arousal range |
| `npc_tier_min` | int | Current bar NPC tier (0–5) |
| `drunk_min` | int | MC drunk level |
| `scene_ids` | list | Only apply in these scenes (empty = all) |
| `image_height` | int | Override max display height in px |

**Available flags (all 94, always computed):**

*Body/outfit:* `flag_is_braless` · `flag_nipping` · `flag_wearing_skirt` · `flag_wearing_dress`
`flag_wearing_dress_or_skirt` · `flag_wearing_thin_top` · `flag_high_lewdness` · `flag_very_high_lewdness`
`flag_underdressed_for_winter` · `flag_owns_sneakers`

*Bar/grope:* `flag_breast_groped` · `flag_ass_groped` · `flag_pussy_groped` · `flag_fingered`
`flag_being_groped` · `flag_grope_persisted` · `flag_kissed` · `flag_neck_kissed` · `flag_deep_kissed`
`flag_cornered` · `flag_dance_locked` · `flag_npc_can_grope` · `flag_npc_can_finger` · `flag_npc_can_sa`
`flag_npc_escalating` · `flag_npc_peak` · `flag_npc_returning` · `flag_npc_wanting`
`flag_npc_wants_leave` · `flag_npc_calm` · `flag_npc_came` · `flag_npc_sa_risk` · `flag_npc_sa_territory`
`flag_npc_traumatised_current` · `flag_npc_trauma_timer_active` · `flag_gloryhole_used`
`flag_cafe_jump_flashed` · `flag_cafe_sleazy_visited`

*Relationships:* `flag_is_dating_npc` · `flag_has_npc_number` · `flag_is_living_together`
`flag_is_married_npc` · `flag_is_open_rel_npc` · `flag_is_pregnant`

*Season:* `flag_season_spring` · `flag_season_summer` · `flag_season_autumn` · `flag_season_winter`
`flag_season_warm` · `flag_season_cold`

*Neighbourhood:* `flag_neighbourhood_narrows` · `flag_neighbourhood_millgate`
`flag_neighbourhood_caldwell` · `flag_neighbourhood_lanes` · `flag_neighbourhood_thornwick`
`flag_neighbourhood_ravenshill` · `flag_neighbourhood_premium`

*Work:* `flag_works_bar` · `flag_works_bookshop` · `flag_works_kitchen` · `flag_works_library`
`flag_works_neon_fitness` · `flag_works_retail` · `flag_works_tattoo` · `flag_works_velvet_cafe`

*State/stats:* `flag_high_stress` · `flag_low_willpower` · `flag_happy` · `flag_broke`
`flag_drunk_tonight` · `flag_alcoholic_craving` · `flag_has_std` · `flag_on_period`
`flag_cooked_tonight` · `flag_stage_low` · `flag_stage_mid` · `flag_stage_high`

*Trauma:* `flag_is_traumatised` · `flag_is_broken` · `flag_is_shaken` · `flag_is_hurt`
`flag_is_rattled` · `flag_has_any_npc_trauma`

*Housing/furniture:* `flag_has_mirror` · `flag_has_tv` · `flag_has_coffee_maker`
`flag_has_dresser` · `flag_has_dresser_basic` · `flag_has_dresser_nice`
`flag_has_wardrobe` · `flag_has_bookshelf` · `flag_has_good_mattress`
`flag_lives_house` · `flag_owns_property`

All MC **traits** and **timed traits** are also usable as condition values (e.g. `requires_traits: [Shy]`).

All MC traits and timed traits also work as condition values.

---

## 4. Text variance mods

Add your own prose variants to any BarSystem, CafeSystem, or scene pool.
Create YAML files in a `text_pools/` directory inside your mod folder.

```
my_mod/
└── text_pools/
    ├── shy_grope_reactions.yml
    ├── sleazy_approach_lines.yml
    └── morning_routine_extras.yml
```

**File format:**
```yaml
# shy_grope_reactions.yml

pool: bar.grope.breast.shy_mc    # which pool to add to

add:
  # Simple string (weight 1, no gates)
  - "You go completely still. His hand is on you and you don't have a plan for this."

  # Weighted entry with conditions
  - id: shy_grope_drunk_v1
    text: "The alcohol means you take a beat longer to process it. By then it's already happening."
    weight: 2
    requires: [drunk_high]    # MC trait or flag

  - id: shy_grope_high_rep_v1
    text: "You've been here before. Doesn't mean you like it."
    requires: [grope_persisted]
    weight: 1

# Suppress base game entries by their stable ID
suppress:
  - shy_grope_base_old_v2
  - shy_grope_base_v3
```

**Pool naming convention:**
**Bar pools (25 families):**
- `bar.slow_dance.{personality}` — full slow dance prose per NPC type *(live)*
- `bar.dance_scene.{personality}` — entire dance scene override *(live)*
- `bar.npc_approach.{personality}` — NPC approach lines *(live)*
- `bar.eye_contact.{personality}` — eye contact outcome *(live)*
- `bar.dirty_whisper.{personality}` — NPC whisper lines *(live)*
- `bar.grope.ass.{personality}` — ass grope prose by NPC personality *(live)*
- `bar.grope.ass.{tier}_mc` — ass grope MC reaction *(live)*
- `bar.grope.breast.{tier}_mc` — breast grope MC reaction *(live)*
- `bar.grope.pussy.{personality}` — pussy grope prose *(live)*
- `bar.fingering.{personality}` — fingering prose *(live)*
- `bar.fingering_continues.{personality}` — continued fingering prose *(live)*
- `bar.hickey.{personality}` — hickey attempt prose *(live)*
- `bar.kiss.neck.{tier}_mc` — neck kiss MC reaction *(live)*
- `bar.kiss.mouth.{tier}_mc` — mouth kiss MC reaction *(live)*
- `bar.sexy_dance.mc.{tier}` — sexy dance MC action *(live)*
- `bar.sexy_dance.npc.{personality}` — sexy dance NPC reaction *(live)*
- `bar.full_escalation.{personality}` — breast→ass→pussy escalation prose *(live)*
- `bar.orgasm_aftermath.{personality}` — post-orgasm aftermath *(live)*
- `bar.bystander_reaction` — bystander notices escalation *(live)*
- `bar.npc_leave.{personality}` — NPC leaves the bar *(live)*
- `bar.walk_home.{personality}` — walk-home prose *(live)*
- `bar.walk_home_kiss.{personality}` — kiss goodnight on walk home *(live)*
- `bar.home_arrival.{personality}` — arriving at MC's door *(live)*
- `bar.home.invite.{personality}` — NPC invites MC inside *(live)*
- `bar.home.goodnight.{personality}` — goodbye at door *(live)*
- `bar.morning_after.{tier}` — morning-after prose *(live)*

**Cafe pools (3 families):**
- `cafe.top_shelf.stretch` — top-shelf reach prose *(live)*
- `cafe.customer.{tier}` — customer reaction: low/medium/high *(live)*
- `cafe.sleazy_customer.first` — first sleazy customer encounter *(live)*

**Future pools (scaffolded, not yet wired):**
- `scene.{scene_id}` — prose variants for specific scenes

**NPC personality keys (for {personality} pools):**
`shy` · `magnetic` · `engaging` · `outgoing` · `self_assured` · `streetwise`
`alcoholic` · `sleazy` · `jerk` · `confrontational` · `boring`

**MC tier values (for {tier} pools):** `shy` · `flustered` · `enjoy`

**Bar pool gate flags (use in `requires:` / `blocks:`):**
`drunk_high` `drunk_mid` `braless` `nipping` `wearing_skirt` `commando`
`being_groped` `grope_persisted` `npc_sleazy` `dance_locked`
`arousal_high` `arousal_mid`
`shy_mc` `outgoing_mc` `magnetic_mc` `fragile_ego_mc`
`bold_mc` `conflict_avoidant_mc`
`npc_tier_mid` `npc_tier_high` `npc_tier_max`
*(plus any MC trait or timed trait, lowercase)*

**Cafe pool gate flags:**
`braless` `nipping` `wearing_skirt` `commando`
`drunk_high` `drunk_mid` `arousal_high`
`shy_mc` `fragile_ego_mc`
*(plus any MC trait or timed trait)*

**Entry fields:**
| Field | Default | Meaning |
|-------|---------|---------|
| `id` | auto | Stable ID for suppression targeting |
| `text` | required | The prose string (tokens like {npc_name} supported) |
| `weight` | 1 | Selection weight; higher = more likely |
| `requires` | [] | Traits/flags all required (AND) |
| `blocks` | [] | Traits/flags none may be active |

---

## 5. Soundtrack packs

Create `soundtrack.yml` in your mod folder. WAV, AIFF, and AU formats are
supported natively. Convert MP3/OGG to WAV using Audacity (free).

```yaml
# soundtrack.yml

tracks:
  - id: bar_ambient
    file: music/bar_ambient.wav
    loop: true
    volume: 0.7
    priority: 5
    triggers:
      - scene_ids: [bar_night, bar_dance_floor, bar_with_npc, bar_slow_dance]
      - flags:     [flag_at_bar]

  - id: grope_tense
    file: music/tense_pulse.wav
    loop: true
    volume: 0.5
    priority: 20      # higher priority = overrides bar_ambient when both match
    triggers:
      - flags: [flag_being_groped]

  - id: morning
    file: music/morning_piano.wav
    loop: false
    volume: 0.6
    priority: 3
    triggers:
      - scene_ids: [morning_routine, home_shower, home_sleep]

  - id: city_walk
    file: music/city_ambient.wav
    loop: true
    volume: 0.4
    priority: 2
    triggers:
      - scene_ids: [city_wander_park, city_wander_carrow_tram, city_wander_carrow_evening]
```

**Trigger conditions (OR logic — first matching trigger activates the track):**
- `scene_ids` — list of scene IDs; track plays when in any of these scenes
- `flags` — list of flags; ALL must be active (AND within each trigger group)

**Priority:** Higher-priority tracks override lower-priority ones.
Only one track plays at a time. Tracks fade in/out (100ms crossfade).

**Volume:** 0.0 (silent) to 1.0 (full). Combined with the player's master volume setting.

---

## 6. Sidebar customization

```yaml
# sidebar.yml

portrait_asset:   mc_portrait       # asset ID from mod.yml
background_asset: sidebar_bg        # full-panel background
accent_color:     "#8866cc"         # hex, overrides default purple
transparent:      true              # semi-transparent sidebar (70% opacity)
```

---

## 7. Modpacks — multiple mods in one folder

A modpack is a folder containing `modpack.yml` and multiple sub-mod folders.
This lets you ship an art pack and a story mod together, or combine several
independent mods into a distributable bundle.

```
mods/
└── full_overhaul_pack/
    ├── modpack.yml              ← declares this is a pack
    ├── art_pack/                ← sub-mod 1
    │   ├── mod.yml
    │   ├── artwork.yml
    │   └── images/
    ├── audio_pack/              ← sub-mod 2
    │   ├── mod.yml
    │   ├── soundtrack.yml
    │   └── music/
    └── story_expansion/         ← sub-mod 3
        ├── mod.yml
        └── scenes/
```

**modpack.yml:**
```yaml
id:          full_overhaul_pack
name:        Full Overhaul Pack
author:      You
version:     2.0.0
description: Art, audio, and story expansion bundle.
```

Sub-mods without `mod.yml` are still loaded if they contain recognisable
content directories (`scenes/`, `artwork.yml`, etc.).

Multiple modpacks and standalone mods can coexist in `mods/`. They are loaded
alphabetically. Later mods override earlier ones on ID collision.

---

## 8. Asset naming convention for clothing packs

| Asset ID format | Shows in |
|----------------|---------|
| `clothing_{item_id}` | Shopping panel thumbnail, Outfit picker |
| `sidebar_bg` | Stats sidebar background |
| `mc_portrait` | Stats sidebar top portrait |
| `bar_night_img` | Any scene referencing `image: bar_night_img` |

---

## 9. Error handling and debugging

- Errors and warnings are written to `mod_errors.log` inside each mod's folder
- Missing assets produce warnings; the game never crashes due to mod issues
- Path traversal (`../`) is blocked
- Unsupported audio formats produce a warning and that track is skipped
- The Mod Manager panel (⚙ Mods from the main menu) shows load status per mod

---

## 10. Example: shy MC grope reaction pack

```
mods/
└── shy_grope_reactions/
    ├── mod.yml
    └── text_pools/
        └── shy_breast_grope.yml
```

**mod.yml:**
```yaml
id:      shy_grope_reactions
name:    Shy MC — 50 New Breast Grope Reactions
author:  Modder
version: 1.0.0
```

**shy_breast_grope.yml:**
```yaml
pool: bar.grope.breast.shy_mc

add:
  - "You go rigid. His hand is there and your brain has logged off."
  - "One hand still on his shoulder. The other one doesn't know what to do."
  - id: shy_high_arousal_v1
    text: "Your face does something complicated. His hand stays."
    requires: [arousal_high]
    weight: 2
  # ... 47 more entries
```

That's the entire mod. No code. Drop it in `mods/` and it works.

