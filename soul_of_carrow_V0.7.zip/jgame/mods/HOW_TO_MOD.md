# The Soul of Carrow Modding Guide

Mods live in the `mods/` folder. Each mod is a subfolder. The game
loads all mods alphabetically on startup. Errors are reported in the
Mod Manager (main menu) and written to `mod_errors.log` in your mod folder.

---

## MOD SAFETY

Mods are YAML files — they don't run code. The game's mod loader has
two protections built in:

**1. Safe YAML parsing**
The game uses SnakeYAML's `SafeConstructor` for all YAML loading.
This means `!!java.lang.Runtime` type tags (the standard YAML code-execution
exploit) are rejected entirely. A malicious YAML file cannot instantiate
Java classes or call system methods.

**2. Path validation**
Every file opened during mod loading is checked against the `mods/` directory
using canonical path resolution. Symlinks pointing outside the mod folder
and path traversal strings like `../../etc/passwd` are rejected before the
file is opened.

**What this doesn't protect against:**
- A mod that contains genuinely bad *game content* — the game can't judge that
- A mod distributed as a `.jar` or executable disguised as a mod — don't run
  arbitrary executables from mod packs
- Running the game itself with elevated permissions — run it as a normal user

The mod system only loads YAML. It cannot make network requests, write to
arbitrary filesystem locations, or execute system commands. If you see a
"mod" that asks you to run a separate installer or executable: don't.


---

## Folder Structure

```
mods/
  your_mod_name/
    mod.yml          ← required: mod metadata
    npcs/            ← custom NPC files (.yml)
    scenes/          ← custom scene files (.yml, subfolders OK)
    clothes/         ← custom clothing items (.yml)
    jobs/            ← custom jobs (.yml)
```

---

## mod.yml (required)

```yaml
name: My Mod
author: YourName
version: 1.0
description: Adds a new NPC and a scene.
```

---

## ADDING AN NPC

Save as `npcs/yourname.yml`. Required fields: `id`, `type`. Everything
else is optional but affects bar descriptions and approach text.

```yaml
id: marcus_mod           # unique ID — use underscores, no spaces
name: Marcus             # display name shown to player

type: MALE               # MALE or FEMALE — required
age: ADULT               # YOUNG_ADULT / ADULT / OLDER_ADULT
race: black              # free text — affects nothing mechanically
personality: WARM        # WARM / NEUTRAL / OUTGOING / SELFISH / CARING

hair_style: SHORT
hair_color: BLACK
eye_color: BROWN
figure: LEAN             # LEAN / AVERAGE / ATHLETIC / MUSCULAR / CURVY / SLIM / PETITE / HEAVYSET

traits:
  # Personality traits (affects approach text and bar behaviour)
  - Engaging
  - Thoughtful
  - Well_Read
  - Conflict_Avoidant
  # Role/preferences
  - Dom
  - Likes_Girls
  - Average_Cock
  - Neutral_On_Condoms
  - Comfortable_With_PDA

max_liking: 100          # 0–100, how much this NPC can like the player
max_love: 100            # 0–100

intro: >
  He has a quiet certainty about him. Says what he means without
  needing the room to agree. You find yourself listening.
```

### Useful traits for personality
`Magnetic`, `Engaging`, `Shy`, `Self_Assured`, `Outgoing`, `Confrontational`,
`Mysterious`, `Thoughtful`, `Creative_Type`, `Well_Read`, `Warm`, `Reliable`,
`Protective`, `Flirty`, `Overconfident`, `Driven`, `Party_Animal`, `Impulsive`

### work_only
Set `work_only: true` if this NPC should never appear in the bar or social scenes.
Use for characters who only appear in specific work content.

---

## ADDING A SCENE

Save as `scenes/my_scene.yml`. Multi-document YAML supported (separate
scenes with `---`). Subfolders are fine.

```yaml
id: my_custom_scene      # unique — must not clash with base game scene IDs

text: |
  You find yourself in a small coffee shop.
  The woman behind the counter has a tattoo of a fox on her wrist.
  She looks up when you come in.

text_variants:
  # Shown instead of 'text' when the player has this trait
  - requires_trait: Shy
    text: |
      The coffee shop is quiet. Good. You needed quiet.

choices:
  - text: Order a coffee.
    slut_rep_req: 0       # minimum slut_rep to show this choice (0 = always)
    result_text: |
      She makes it without asking how you take it.
      Gets it right anyway.
    money_change: -4
    stat_changes:
      happiness: 6
      stress: -8
    next: __return__      # return to whatever called this scene

  - text: Just browse the menu.
    slut_rep_req: 0
    result_text: You take your time. Nobody minds.
    next: __return__

  - text: Ask about the tattoo.
    slut_rep_req: 0
    min_npc_rep: 20       # requires 20+ rep with current NPC (if in NPC context)
    result_text: |
      "Fox," she says. "My sister drew it."
      She doesn't explain further. You don't push.
    stat_changes:
      npc_rep_bar_npc: 8  # gives rep to currently-approaching NPC
      happiness: 4
    next: __return__
```

### next values
- `__return__` — go back to wherever this scene was called from
- `__hub__` — return to the bar hub (bar context only)
- `another_scene_id` — go directly to another scene

### stat_changes keys
`happiness`, `confidence`, `willpower`, `stress`, `arousal`, `fitness`,
`thrills`, `reputation`, `slut_rep`, `drunk`,
`npc_liking`, `npc_rep_bar_npc`, `npc_rep_<npc_id>`

### add_traits
```yaml
add_traits:
  - some_trait           # adds a trait to player
  - _quit_job            # special: fires GameState.quitJob()
  - owns_tank_top        # special: adds tank_top to ownedClothing
```

### requires_trait / requires_flag
```yaml
- text: Only shown if player is a homebody.
  requires_trait: Homebody
  ...

- text: Only shown while on period.
  requires_flag: flag_on_period
  ...
```

### text_variants
Used to show different text based on player traits. The first matching
variant is used. Use `requires_trait: default` as a fallback.

```yaml
text_variants:
  - requires_trait: Outgoing
    text: You walk in like you belong. You always do.
  - requires_trait: Shy
    text: You slip in and take a corner table.
  - requires_trait: default
    text: You find a seat.
```

---

## ADDING CLOTHING

Save as `clothes/item_name.yml`.

```yaml
id: red_miniskirt
name: Red Mini Skirt
slot: lower            # upper / lower / shoes / bra / underwear
color: red
description: "Short, fitted, red. Does what it sets out to do."
thickness: thin
tight: true
is_skirt: true
price: 55
formal_rating: 30      # 0–100
lewdness_rating: 65    # 0–100 — affects slut_rep calculation
casual_rating: 55      # 0–100
```

### Slot options
- `upper` — top, dress, shirt (use `fills_lower: true` if it covers the lower half)
- `lower` — skirt, trousers, shorts
- `bra` — bra only
- `underwear` — underwear only
- `shoes` — footwear

---

## ADDING A JOB

Save as `jobs/job_name.yml`. Jobs appear in the job listing panel.

```yaml
id: flower_shop
label: Petal & Stem — Shop Assistant
description: "Quiet flower shop. Smells nice. Steady hours."
pay_per_day: 60
slots_per_day: 3
work_days:
  - TUE
  - WED
  - THU
  - FRI
  - SAT
stat_changes:
  happiness: 6
  stress: 2
  confidence: 2
boss_npc_id: my_boss_npc   # NPC ID — shown as boss in job listing
coworker_npc_ids:
  - another_npc
pay_frequency: WEEKLY       # DAILY / WEEKLY / BIWEEKLY
under_the_table: false
```

Custom jobs need matching WORK_SCENES entries in DayPlannerPanel.java to fire
work scenes. Without these, work days apply stat_changes silently.

---

## TRIGGERING A SCENE

To make a scene appear during the game, add it as an activity trigger.
This requires editing the base activity YAML (not possible from mods yet)
or routing to it from another scene via `next: your_scene_id`.

For NPC conversations, the easiest approach is routing from the bar via
custom choices added to bar scenes — not currently hot-patchable from mods
without editing base scenes.

**Tip:** Name your scenes with your mod ID as a prefix to avoid collisions:
`mymod_coffee_shop`, `mymod_encounter_intro`, etc.

---

## COMMON ERRORS

| Error | Fix |
|---|---|
| `NPC missing 'id' field` | Add `id: your_npc_id` at the top |
| `NPC 'X' missing 'type'` | Add `type: MALE` or `type: FEMALE` |
| `YAML parse error` | Check indentation — use 2 spaces, not tabs |
| `Scene routes to 'X' which doesn't exist` | Fix the `next:` value or create the target scene |
| `Clothing missing 'slot'` | Add `slot: upper` / `lower` / `shoes` / etc. |

---

## NOTES

- Mod scene IDs that match base game scenes **override** the original.
  Use this carefully — prefix your IDs to be safe.
- NPCs added by mods appear in the bar and social pool automatically.
- Clothing added by mods appears in the shopping panel.
- Error logs are written to `mods/your_mod/mod_errors.log` after each load.
- The game must be restarted to reload mod changes.

---

## SETTINGS THAT AFFECT MOD CONTENT

**Visibility Mode** — players can set this in Settings. Your mod scenes will
automatically respect it:
- *Normal* — text only, no hints
- *Player* — stat changes shown after each choice: `[ +4 arousal  −2 willpower ]`
- *Dev* — hover tooltips on every choice button showing: required traits, slut_rep
  threshold, stat_changes, path_traits, money_change, timed_traits

**Difficulty Multipliers** — players can set slut_rep gain to ×1/×2/×4. Your
scenes don't need to account for this; it's applied automatically in `changeStat`.
Same for willpower drain (×0.5–×1.5) and stress gain (×0.5–×1.5).

**Font & Text Size** — players choose their own font from 11 options. Your scenes
display in whatever font the player has set. Use plain prose — avoid ASCII art or
alignment that depends on monospace.

---

## ESCAPE MENU & SAVE SYSTEM

Players can press **Escape** at any time to pause and access save/load/settings.
Mods don't need to do anything for this — it's handled by the game.

Saves happen automatically after every night (autosave). Players also have
**3 manual save slots**. All mod-added NPC rep, memory, and state is saved
automatically — you don't need to do anything special for save compatibility.

When a player loads a save made while your mod was active, everything restores
correctly as long as:
- Your NPC IDs haven't changed between versions
- Your scene IDs haven't changed between versions

If you rename an ID between versions, the old rep/memory data orphans silently
(no crash, just lost data for that NPC).


---

## PATCHING AN EXISTING SCENE

The most-requested mod feature: adding your own choices or text variants to
a scene that already exists in the base game, without replacing the whole
scene.

Use `patch_scene` instead of `id` in your scene YAML file:

```yaml
patch_scene: city_wander_park    # the scene you want to extend

add_choices:
  - text: Head to the fountain. You have an idea.
    slut_rep_req: 0
    result_text: |
      The fountain in the Lanes is always running.
      You sit on the edge and think the thing through.
      It helps more than you expected.
    stat_changes:
      happiness: 8
      stress: -5
    next: __return__

  - text: Check if anyone's watching before you sit.
    slut_rep_req: 8
    requires_flag: flag_is_braless
    result_text: |
      Two people are definitely watching.
      You sit anyway. The bench is warm.
    stat_changes:
      arousal: 6
      confidence: 5
      slut_rep: 1
    next: __return__

add_text_variants:
  - requires_flag: flag_season_summer
    text: |
      The park in summer. Every bench taken,
      everyone with the same idea, nobody minding.
      You find a spot near the fountain.
```

### Patch rules

- `patch_scene` must match an existing scene ID exactly. If the target doesn't
  exist, the patch is silently skipped and a warning is written to your mod log.
- `add_choices` are appended after all existing choices. Ordering within the
  YAML is preserved.
- `add_text_variants` are appended to the pool. When multiple variants match
  the player's current state (traits, flags), **one is picked at random**.
  Your added variant will randomly compete with other matching variants including
  base game ones — this is intentional, it keeps scenes fresh on repeat visits.
  If you need your variant to always show, use scene override (`id: scene_id`).
- Patches are applied after all mod scenes load, so you can patch scenes added
  by other mods too (load order is alphabetical by mod folder name).
- A single mod can patch as many scenes as you like from one YAML file using
  multi-document syntax (`---`):

```yaml
patch_scene: city_wander_park

add_choices:
  - text: My choice for the park.
    slut_rep_req: 0
    result_text: It happens.
    next: __return__

---
patch_scene: morning_routine

add_text_variants:
  - requires_trait: Outgoing
    text: |
      You wake up feeling good today. Nothing specific.
      Just good.
```

### Patching vs overriding

| | Patch | Override |
|---|---|---|
| How | `patch_scene: scene_id` | `id: scene_id` (matches existing) |
| What it does | Appends choices/variants | Replaces the whole scene |
| Original content | Preserved | Gone |
| Safe to use | Yes — other mods can also patch | Risky — breaks other patches |
| Best for | Adding options, new variants | Rewriting a scene completely |

### Full list of supported choice fields in patches

```yaml
add_choices:
  - text: The choice label shown to the player.
    slut_rep_req: 0          # minimum slut rep (0 = always shown)
    requires_trait: Shy      # only shown if player has this trait
    requires_flag: flag_is_braless   # only shown if flag is true
    blocks_if_trait: Homebody        # hidden if player has this trait
    min_npc_rep: 30          # only shown if current NPC rep ≥ 30
    result_text: |
      What happens when this choice is picked.
    stat_changes:
      happiness: 5
      stress: -3
      arousal: 8
      slut_rep: 1
      npc_liking: 4
    money_change: -20
    add_traits:
      - some_trait
      - owns_red_heels
    remove_traits:
      - some_other_trait
    timed_traits:
      - Neck_Hickey:3        # trait lasts 3 days
    slut_rep_gain: 3         # explicit rep gain (bypasses diminishing returns)
    next: __return__
```


---

## GATING — SHOWING AND HIDING OPTIONS

Choices can be shown, hidden, or greyed out based on player state.
All gates combine with AND logic unless otherwise noted.

---

### Rep gates

```yaml
# Show only when slut_rep is high enough
slut_rep_req: 15

# Hide when slut_rep exceeds this — choice disappears once the player
# is too experienced for it to make sense (e.g. shy first-time flash)
max_slut_rep: 20

# Both together: only visible in a rep window
- text: Flash quickly, hands shaking.
  slut_rep_req: 5
  max_slut_rep: 18
  result_text: You do it. Briefly. Heart hammering.
  next: __return__
```

---

### Trait gates

```yaml
# Requires specific trait (AND logic — all must be present)
requires_trait: Shy

# Multiple traits required simultaneously
requires_traits:
  - Shy
  - Conflict_Avoidant

# OR logic — at least one of these must be present
requires_any_traits:
  - Outgoing
  - Nightlife_Lover
  - Provocative_Sexual

# Hide if player has this trait
blocks_if_trait: Homebody

# Hide if player has ANY of these traits
blocks_if_traits:
  - Homebody
  - Antisocial
```

---

### Flag gates (body/world state)

Flags are dynamic states — braless, nipping, wearing skirt, on period, etc.
Unlike traits, flags are recalculated each frame from current game state.

```yaml
# Show only when flag is true
requires_flag: flag_is_braless

# Hide when flag is true (opposite of requires_flag)
blocks_if_flag: flag_wearing_skirt

# Combine: braless AND not in a skirt
requires_flag: flag_is_braless
blocks_if_flag: flag_wearing_skirt
```

**Available flags:**
```
flag_is_braless           — no bra equipped
flag_nipping              — braless + thin/sheer top
flag_wearing_thin_top     — thin/crop/tank/mesh/sheer top
flag_wearing_skirt        — skirt lower item
flag_wearing_dress        — dress
flag_wearing_dress_or_skirt
flag_underdressed_for_winter
flag_high_lewdness        — lewdness rating ≥ 60
flag_very_high_lewdness   — lewdness rating ≥ 85
flag_on_period
flag_is_dating_npc        — currently dating someone
flag_season_spring / flag_season_summer / flag_season_autumn / flag_season_winter
flag_season_warm / flag_season_cold
flag_neighbourhood_narrows / flag_neighbourhood_lanes / flag_neighbourhood_caldwell
flag_neighbourhood_millgate / flag_neighbourhood_thornwick / flag_neighbourhood_ravenshill
flag_has_mirror           — any mirror in flat
flag_broke                — very low money
```

---

### Arousal, money, willpower gates

```yaml
# Show only when arousal is this high
min_arousal: 40

# Show only when player has this much money
min_money: 50

# Show only when willpower is this high
min_willpower: 30

# Hide when willpower is this high (e.g. hide reckless choice if player has willpower)
max_willpower: 25

# Arousal reduces effective willpower for this check
# At arousal 70 with arousal_wp_drain_above: 50, effective WP is reduced by 4
arousal_wp_drain_above: 50
```

---

### NPC rep gates

```yaml
# Requires at least this much rep with the currently-approaching NPC
min_npc_rep: 30

# Bypass the rep gate if NPC has any of these traits
# Useful for: "unlock at rep 25, OR immediately with Sleazy NPCs"
rep_bypass_traits:
  - Sleazy
  - Jerk

# Require rep with a specific named NPC
min_npc_rep_map:
  kai: 40
```

---

### Show greyed out (preview locked choices)

```yaml
# Choice is visible but greyed/disabled when gate conditions fail.
# Player sees the option exists but can't pick it yet.
# Shows after all active choices.
show_when_locked: true
slut_rep_req: 25
```

---

### Priority locking (suppress other options)

```yaml
# When this choice is visible AND locks_others is true,
# all choices with lower priority are hidden.
# Use for forced/panic scenarios.
priority: 10
locks_others: true
```

Example — commando skirt flip panic override for shy MC:
```yaml
- text: Freeze. Cross your legs immediately.
  priority: 10
  locks_others: true
  requires_trait: Shy
  max_slut_rep: 14
  result_text: You don't give anyone time to process it.
  next: __return__
```

---

## CAN I CHANGE AN EXISTING CHOICE'S REP REQUIREMENT?

No. Patches can only add new choices — they can't edit existing ones.

If you want a lower-rep version of something, add your own choice at the
rep you want. Use `max_slut_rep` to make it disappear once the original unlocks:

```yaml
patch_scene: city_wander_park

add_choices:
  - text: Notice him looking. Don't quite meet his eyes.
    slut_rep_req: 5
    max_slut_rep: 11        # gone once the original choice at rep 12 unlocks
    result_text: |
      You're aware of him. You let him know you're aware.
      That's enough for now.
    stat_changes:
      arousal: 4
      confidence: 3
    next: __return__
```


---

## SUPPRESSING EXISTING CHOICES

You can hide choices that already exist in a base game scene using `suppress_choices`.
Match by text — any choice whose text contains the string gets hidden when the condition is met.

```yaml
patch_scene: bar_drink_order

suppress_choices:
  # Hide the "Order another drink" choice when the NPC has cut the player off
  - text_contains: "Order another"
    when_trait: mymod_npc_cut_off_drinks

  # Hide the round-buying option when player is broke — no condition needed
  - text_contains: "Buy a round"
    when_flag: flag_broke

  # Always hide this choice (no condition = always suppressed)
  - text_contains: "Ask for a free one"
```

`text_contains` is case-insensitive partial match — `"Order another"` will hide
`"Order another drink"`, `"Order another round"`, anything containing that string.

`when_trait` and `when_flag` are optional. Leave them out and the choice is always hidden.
Both can be combined — the choice hides only when the trait AND the flag are both true.

---

## USING TRAITS AS PERSISTENT FLAGS

Traits added via `add_traits` persist for the rest of the session (and save/load).
This makes them useful as flags to track things that happened — NPC said something,
player made a choice, a scene fired.

```yaml
# Scene: NPC cuts the player off
id: mymod_npc_cuts_off

text: |
  {npc_name} puts a hand over your glass.
  "You're done for tonight. I mean it."

choices:
  - text: Fair enough.
    slut_rep_req: 0
    add_traits:
      - mymod_npc_cut_off_drinks    # sets the flag
    result_text: You back off. He means it.
    next: __return__
```

```yaml
# Patch: add an alternative drink choice that disappears after the above fires
patch_scene: bar_drink_order

add_choices:
  - text: Ask {npc_name} to reconsider.
    slut_rep_req: 0
    blocks_if_trait: mymod_npc_cut_off_drinks    # gone after he cuts you off
    result_text: He shakes his head. Not tonight.
    next: __return__
```

**Combined: suppress the original AND add your own replacement:**

```yaml
patch_scene: bar_drink_order

# Hide the original when the NPC has cut you off
suppress_choices:
  - text_contains: "Order another"
    when_trait: mymod_npc_cut_off_drinks

# Add your own alternative for when you're cut off
add_choices:
  - text: Ask {npc_name} to reconsider.
    slut_rep_req: 0
    requires_trait: mymod_npc_cut_off_drinks
    result_text: He shakes his head. Not tonight.
    next: __return__
```

**Naming your traits:** prefix them with your mod ID to avoid clashing
with base game traits or other mods. `mymod_` is a safe convention.

**Timed traits** expire after N days if you'd rather the flag reset:
```yaml
add_traits:
  - mymod_npc_cut_off_drinks    # permanent until removed

timed_traits:
  - mymod_npc_cut_off_drinks:1  # expires next day instead
```

## COMMON GATING PATTERNS

**"Only show when braless AND some reputation built up":**
```yaml
requires_flag: flag_is_braless
slut_rep_req: 8
```

**"Show early choices that disappear at high rep":**
```yaml
slut_rep_req: 0
max_slut_rep: 15
```

**"Show to shy players, hide to confident ones":**
```yaml
requires_trait: Shy
blocks_if_traits:
  - Self_Assured
  - Outgoing
```

**"Available if rep is high OR NPC is Sleazy":**
```yaml
slut_rep_req: 30
rep_bypass_traits:
  - Sleazy
```

**"Only during winter when underdressed":**
```yaml
requires_flag: flag_season_cold
requires_flag: flag_underdressed_for_winter
```

**"Only when braless AND aroused":**
```yaml
requires_flag: flag_is_braless
min_arousal: 35
```

**"Only works in The Narrows":**
```yaml
requires_flag: flag_neighbourhood_narrows
```

---

## ARTWORK MODS (dynamic state-driven images)

Create `artwork.yml` in your mod folder. Hooks fire based on what the MC is
experiencing right now — no need to edit specific scenes.

```yaml
# artwork.yml
hooks:
  - id: grope_breast_neutral
    asset: my_grope_image        # registered in mod.yml assets block
    priority: 10
    requires_flags: [flag_breast_groped]

  - id: braless_relaxed
    asset: my_braless_image
    priority: 3
    requires_flags:  [flag_is_braless]
    blocks_flags:    [flag_being_groped]
    arousal_min: 0
    arousal_max: 59
```

Hooks are evaluated highest-priority first. First match wins.
Full condition reference: see MOD_FULL_GUIDE.md.

---

## TEXT VARIANCE MODS (add prose variants to any pool)

Create a `text_pools/` directory in your mod folder and add YAML files:

```yaml
# text_pools/shy_grope_reactions.yml
pool: bar.grope.breast.shy_mc

add:
  - "You go rigid. His hand is there and your brain has logged off."
  - id: shy_grope_v2
    text: "Your breath catches. You don't look at him."
    weight: 2

suppress:
  - base_shy_grope_old_v1    # suppress base game entries by their stable ID
```

Pool naming: `system.context.subcontext` — e.g. `bar.slow_dance.shy`,
`bar.npc_approach.sleazy`, `bar.grope.breast.shy_mc`. See MOD_FULL_GUIDE.md.

**Live pools (active in current game version):**

| Pool | Fires when |
|------|-----------|
| `bar.slow_dance.shy` | Slow dance with Shy NPC |
| `bar.slow_dance.magnetic` | Slow dance with Magnetic NPC |
| `bar.slow_dance.engaging` | Slow dance with Engaging NPC |
| `bar.slow_dance.outgoing` | Slow dance with Outgoing/Nightlife NPC |
| `bar.slow_dance.self_assured` | Slow dance with Self-Assured NPC |
| `bar.slow_dance.streetwise` | Slow dance with Streetwise NPC |
| `bar.slow_dance.alcoholic` | Slow dance with Alcoholic NPC |
| `bar.slow_dance.sleazy` | Slow dance with Sleazy NPC |
| `bar.slow_dance.jerk` | Slow dance with Jerk NPC |
| `bar.slow_dance.confrontational` | Slow dance with Confrontational NPC |
| `bar.slow_dance.boring` | Slow dance with Boring NPC |
| `bar.npc_approach.shy` | Shy NPC approaches MC at bar |
| `bar.npc_approach.magnetic` | Magnetic NPC approaches |
| `bar.npc_approach.sleazy` | Sleazy NPC approaches |
| *(and all other personalities)* | |
| `bar.grope.ass.shy` | Ass grope by Shy NPC |
| `bar.grope.ass.sleazy` | Ass grope by Sleazy NPC |
| *(and all other personalities)* | |
| `bar.grope.breast.shy_mc` | Breast grope — shy MC reaction |
| `bar.grope.breast.flustered_mc` | Breast grope — flustered MC reaction |
| `bar.grope.breast.enjoy_mc` | Breast grope — enjoying MC reaction |
| `bar.grope.ass.{tier}_mc` | Ass grope MC reaction — `shy_mc`, `flustered_mc`, `enjoy_mc` |
| `bar.grope.ass.{personality}` | Ass grope by NPC personality (full prose) |
| `bar.kiss.neck.{tier}_mc` | Neck kiss MC reaction |
| `bar.kiss.mouth.{tier}_mc` | Mouth kiss MC reaction |
| `bar.grope.ass.{tier}_mc` | Ass grope MC reaction by tier |
| `bar.sexy_dance.mc.{tier}` | Sexy dance — MC action prose |
| `bar.sexy_dance.npc.{personality}` | Sexy dance — NPC reaction prose |
| `bar.eye_contact.{personality}` | Eye contact outcome |
| `bar.dirty_whisper.{personality}` | Dirty whisper lines from NPC |
| `bar.walk_home.{personality}` | Walk-home prose after bar |
| `bar.morning_after.{tier}` | Morning-after prose (no NPC context) |

Entry gate flags available in **bar** pool entries:

| Flag | Condition |
|------|-----------|
| `drunk_high` | MC drunk ≥ 10 |
| `drunk_mid` | MC drunk ≥ 5 |
| `braless` | MC not wearing bra |
| `nipping` | Visible through clothing |
| `wearing_skirt` | MC wearing skirt or dress |
| `commando` | MC wearing no underwear |
| `being_groped` | Active groping in progress |
| `grope_persisted` | Groping has continued across turns |
| `npc_sleazy` | Current NPC is Sleazy |
| `dance_locked` | Dance has reached locked phase |
| `arousal_high` | MC arousal ≥ 60 |
| `arousal_mid` | MC arousal ≥ 30 |
| `shy_mc` | MC has Shy trait |
| `outgoing_mc` | MC has Outgoing trait |
| `magnetic_mc` | MC has Magnetic trait |
| `fragile_ego_mc` | MC has Fragile Ego trait |
| `npc_tier_mid` | NPC frustration/escalation tier ≥ 3 |
| `npc_tier_high` | NPC escalation tier ≥ 4 |
| `npc_tier_max` | NPC at maximum escalation (tier 5) |
| *(any MC trait)* | e.g. `Athletic`, `Bookish`, `Driven` |
| *(any timed trait)* | e.g. `Neck_Hickey`, `std_treatment_active` |

Entry gate flags available in **cafe** pool entries:
`braless` · `nipping` · `wearing_skirt` · `commando` · `drunk_high` · `drunk_mid`
`arousal_high` · `shy_mc` · `fragile_ego_mc` · *(plus all MC traits/timed traits)*

---

## SOUNDTRACK PACKS

Create `soundtrack.yml`. Supports WAV, AIFF, AU (convert MP3 with Audacity).

```yaml
# soundtrack.yml
tracks:
  - id: bar_ambient
    file: music/bar.wav
    loop: true
    volume: 0.7
    priority: 5
    triggers:
      - scene_ids: [bar_night, bar_dance_floor]
      - flags:     [flag_at_bar]

  - id: grope_tense
    file: music/tense.wav
    loop: true
    volume: 0.5
    priority: 20       # overrides bar_ambient when MC is being groped
    triggers:
      - flags: [flag_being_groped]
```

---

## SIDEBAR CUSTOMIZATION

Create `sidebar.yml`:

```yaml
portrait_asset:   my_portrait    # declared in mod.yml assets block
background_asset: my_sidebar_bg
accent_color:     "#8866cc"
transparent:      true
```

---

## MODPACKS (multiple mods in one folder)

Put `modpack.yml` in your folder and place sub-mods inside:

```
mods/
└── my_pack/
    ├── modpack.yml          ← identifies this as a pack
    ├── art_mod/
    │   ├── mod.yml
    │   └── artwork.yml
    └── audio_mod/
        ├── mod.yml
        └── soundtrack.yml
```

```yaml
# modpack.yml
id:   my_pack
name: My Pack
```

Each sub-folder with content is loaded as an independent mod.
Sub-mods can be individually disabled in the Mod Manager.

---

## COMPATIBILITY FIELDS (mod.yml)

```yaml
game_version_min: 0.1.0      # oldest game version this works with
game_version_max: 0.9.9      # newest tested version (leave blank = no limit)
compatibility_note: |
  Works best with the art pack installed alongside.
requires_features:
  - artwork_hooks
  - text_pools
```

The Mod Manager's "Check Compatibility" button validates these fields
one mod at a time. A failed check never crashes the game.
