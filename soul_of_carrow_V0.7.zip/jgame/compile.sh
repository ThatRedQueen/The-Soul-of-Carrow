#!/bin/bash
echo "════════════════════════════════════════"
echo "  The Soul of Carrow — Build"
echo "════════════════════════════════════════"
rm -rf out && mkdir -p out
find src -name "*.java" > sources.txt
javac -cp "lib/snakeyaml-2.2.jar" -d out @sources.txt
EXIT=$?
rm -f sources.txt
if [ $EXIT -eq 0 ]; then
    echo "✓ Compile OK. Run ./run.sh to launch."
else
    echo "✗ Compile failed."
    exit 1
fi
