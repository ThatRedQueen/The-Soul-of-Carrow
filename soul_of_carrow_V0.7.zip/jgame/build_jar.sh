#!/bin/bash
echo "════════════════════════════════════════"
echo "  The Soul of Carrow — Build JAR"
echo "════════════════════════════════════════"

# Compile first
rm -rf out && mkdir -p out
find src -name "*.java" > sources.txt
javac -cp "lib/snakeyaml-2.2.jar" -d out @sources.txt
if [ $? -ne 0 ]; then echo "✗ Compile failed."; rm -f sources.txt; exit 1; fi
rm -f sources.txt

# Extract SnakeYAML into out/ so it bundles cleanly
cd out && jar xf ../lib/snakeyaml-2.2.jar && cd ..

# Manifest
echo "Main-Class: game.Main" > manifest.txt

# Build fat JAR named after the game
jar cfm TheSoulOfCarrow.jar manifest.txt -C out .
rm manifest.txt

echo ""
echo "✓ Built: TheSoulOfCarrow.jar"
echo ""
echo "Distribute alongside:"
echo "  scenes/  npcs/  clothes/  gamedata/  housing/  jobs/  interviews/"
echo ""
echo "Players run:  java -jar TheSoulOfCarrow.jar"
echo "Or wrap with Launch4j to produce TheSoulOfCarrow.exe"
